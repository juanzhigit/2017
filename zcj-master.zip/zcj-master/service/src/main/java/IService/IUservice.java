package IService;
/**
 * Created by zhongchaojie on 2017/6/29.
 */

import entity.User;

/**
 * @author zhongchaojie
 * @create 2017-06-29 11:27
 *
 * 接口
 **/
public interface IUservice {
    /**
     * 验证用户登录并返回更多信息
     * @param user
     * @return
     */
    User checkUser(User user);

    /**
     * 改变出生地
     * @param user
     * @return
     */
    User changBirthPlace(User user);

}
