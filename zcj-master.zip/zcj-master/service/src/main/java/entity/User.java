package entity;/**
 * Created by zhongchaojie on 2017/6/29.
 */

import java.io.Serializable;

/**
 * @author zhongchaojie
 * @create 2017-06-29 11:27
 **/
public class User  implements Serializable{
    private static final long serialVersionUID = -8567577199125237911L;

    //姓名
    public String username;
    //密码
    public String password;
    //部门
    public String deptName;
    //用户id
    public String userId;
    //出生地
    public String birthplace;

    public String userShortName;

    public String getUserShortName() {
        return userShortName;
    }

    public void setUserShortName(String userShortName) {
        this.userShortName = userShortName;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getBirthplace() {
        return birthplace;
    }

    public void setBirthplace(String birthplace) {
        this.birthplace = birthplace;
    }
}
