package entity.base;/**
 * Created by zhongchaojie on 2017/6/29.
 */

import java.io.Serializable;
import java.util.List;

/**
 * @author zhongchaojie
 * @create 2017-06-29 14:35
 **/
public class Result<T> implements Serializable {

    private  boolean success;
    private  T data;
    private  String successMessage;
    private List<String> errorMessage;

    public T getData() {
        return data;
    }

    public void setData(T data) {
        this.data = data;
    }

    public String getSuccessMessage() {
        return successMessage;
    }

    public void setSuccessMessage(String successMessage) {
        success=true;
        this.successMessage = successMessage;
    }

    public List<String> getErrorMessage() {
        return errorMessage;
    }

    public void setErrorMessage(List<String> errorMessage) {
        this.success = false;
        this.errorMessage = errorMessage;
    }

    public boolean isSuccess() {
        if(errorMessage==null){
            success=true;
        }else{
            success=false;
        }
        return success;
    }

    public void setSuccess(boolean success) {
        this.success = success;
    }
}
