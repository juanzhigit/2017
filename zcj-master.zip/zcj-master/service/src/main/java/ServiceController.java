/**
 * Created by zhongchaojie on 2017/6/29.
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @author zhongchaojie
 * @create 2017-06-29 15:48
 **/
@SpringBootApplication
//@MapperScan(basePackages = "com.hikvision.it.expense.rpc.dao")
public class ServiceController {
    public static void main(String[] args) {
        SpringApplication.run(ServiceController.class, args);
    }
}
