package com.zcj.rpc.serviceImpl;/**
 * Created by zhongchaojie on 2017/6/29.
 */

import IService.IUservice;
import com.alibaba.dubbo.config.annotation.Reference;
import entity.User;
import entity.base.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @author zhongchaojie
 * @create 2017-06-29 9:13
 * 初始化controller
 **/
@Controller
public class Controllertest {


    @Reference(version = "1.0.0")
    IUservice uservice;

    @RequestMapping("/index")
    public String index(User user, Model model) {
        user = uservice.checkUser(user);
        model.addAttribute("user", user);
        return "index";
    }

    @RequestMapping("/login")
    public String login(User user, Model model) {
        return "index";
    }

    @ResponseBody
    @RequestMapping("/changBirthPlace")
    public Result<User> changBirthPlace(User user) {
        user = uservice.changBirthPlace(user);
        Result<User> userResult= new Result<>();
        userResult.setData(user);
        return userResult;
    }


}
