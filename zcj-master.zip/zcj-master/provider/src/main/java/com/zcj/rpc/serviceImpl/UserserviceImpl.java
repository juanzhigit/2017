package com.zcj.rpc.serviceImpl;/**
 * Created by zhongchaojie on 2017/6/29.
 */









import IService.IUservice;
import com.alibaba.dubbo.config.annotation.Service;
import entity.User;


/**
 * @author zhongchaojie
 * @create 2017-06-29 14:03
 **/
@Service(version="1.0.0")
public class UserserviceImpl implements IUservice {

    @Override
    public User checkUser(User user) {
        System.out.println("检查登录");
        if("admin".equals(user.getUsername())){
            user= new User();
            user.setUserId("HZ001");
            user.setBirthplace("杭州");
            user.setDeptName("研发");
            user.setUserShortName("j");
            return  user;
        }
        return null;

    }

    @Override
    public User changBirthPlace(User user) {
        System.out.println("改变出生地");
        return user;
    }
}
