package com.zcj.rpc.config;/**
 * Created by zhongchaojie on 2017/6/30.
 */

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ProtocolConfig;
import com.alibaba.dubbo.config.ProviderConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.spring.AnnotationBean;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.context.properties.EnableConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

/**
 * @author zhongchaojie
 * @create 2017-06-30 14:38
 **/
@Configuration
//@EnableConfigurationProperties(DubboProperties.class)
//@PropertySource(value = "classpath:/dubbo.properties")
public class DubboConfig {

    @Value("${spring.dubbo.application.name}")
    private String applicationName;
    @Value("${spring.dubbo.registry.protocol}")
    private String protocol;
    @Value("${spring.dubbo.registry.address}")
    private String registryAddress;

    @Value("${spring.dubbo.protocol.port}")
    private int protocolPort;
    @Value("${spring.dubbo.timeout}")
    private int timeout;

    /**
     * 设置dubbo扫描包
     */
    @Bean
    public static AnnotationBean annotationBean(
            @Value("${spring.dubbo.scan}") String packageName) {
        System.out.println("开启dubbo");
        AnnotationBean annotationBean = new AnnotationBean();
        annotationBean.setPackage("com/zcj/rpc");
        return annotationBean;
    }

    /**
     * 注入dubbo上下文
     */
    @Bean
    public ApplicationConfig applicationConfig() {
        // 当前应用配置
        ApplicationConfig applicationConfig = new ApplicationConfig();
        applicationConfig.setName(applicationName);
        return applicationConfig;
    }

    /**
     * 注入dubbo注册中心配置,基于zookeeper
     */
    @Bean
    public RegistryConfig registryConfig() {
        // 连接注册中心配置
        RegistryConfig registry = new RegistryConfig();
        registry.setProtocol(protocol);
        registry.setAddress(registryAddress);
        return registry;
    }

    /**
     * 默认基于dubbo协议提供服务
     */
    @Bean
    public ProtocolConfig protocolConfig() {
        // 服务提供者协议配置
        ProtocolConfig protocolConfig = new ProtocolConfig();
        protocolConfig.setPort(protocolPort);
        protocolConfig.setSerialization("kryo");
        protocolConfig.setThreads(200);
        return protocolConfig;
    }

    /**
     * dubbo服务提供
     */
    @Bean(name = "defaultProvider")
    public ProviderConfig providerConfig(ApplicationConfig applicationConfig,
                                         RegistryConfig registryConfig, ProtocolConfig protocolConfig) {
        ProviderConfig providerConfig = new ProviderConfig();
        providerConfig.setTimeout(timeout);
        providerConfig.setRetries(0);
        providerConfig.setApplication(applicationConfig);
        providerConfig.setRegistry(registryConfig);
        providerConfig.setProtocol(protocolConfig);
//        providerConfig.setFilter("currentUserFilter");
        return providerConfig;
    }




}
