package com.zcj.rpc.serviceImpl;/**
 * Created by zhongchaojie on 2017/6/30.
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.web.support.SpringBootServletInitializer;

/**
 * @author zhongchaojie
 * @create 2017-06-30 10:14
 **/
@SpringBootApplication
public class ProviderApplication extends SpringBootServletInitializer {

    public static void main(String[] args) {
        SpringApplication.run(ProviderApplication.class, args);
    }
}
