package Index;/**
 * Created by zhongchaojie on 2017/6/29.
 */

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author zhongchaojie
 * @create 2017-06-29 11:48
 **/
public class BaseController {
    protected Logger logger = LoggerFactory.getLogger(getClass());
}
