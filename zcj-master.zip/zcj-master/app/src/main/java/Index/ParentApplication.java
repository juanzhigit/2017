package Index;/**
 * Created by zhongchaojie on 2017/6/29.
 */

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @author zhongchaojie
 * @create 2017-06-29 9:17
 * main方法启动 一个springboot项目只允许一个main方法
 **/

@SpringBootApplication
public class ParentApplication {
    public static void main(String[] args) {
        SpringApplication.run(ParentApplication.class, args);
    }
}
