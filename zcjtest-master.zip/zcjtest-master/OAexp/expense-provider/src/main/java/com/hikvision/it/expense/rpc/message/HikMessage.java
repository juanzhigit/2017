package com.hikvision.it.expense.rpc.message;


/**
 * 返回消息entity
 * <p>Title: RetMessage.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2015年7月2日
 *
 */
public class HikMessage {
	private String	msgCode;		//消息编号
	private String  msg;			//消息
	
	public String getMsgCode() {
		return msgCode;
	}
	public void setMsgCode(String msgCode) {
		this.msgCode = msgCode;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
