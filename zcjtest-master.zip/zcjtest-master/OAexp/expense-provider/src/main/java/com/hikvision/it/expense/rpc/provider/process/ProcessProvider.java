package com.hikvision.it.expense.rpc.provider.process;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.service.process.IProcessService;

@Service(version= Version.VERSION_LATEST)
public class ProcessProvider implements IProcessService {
	@Autowired
	IProcessService processService;
	
	@Override
	public HikResult<ProcessInstance> createAndStartProcess(String docId, String processObjectId) {
		return processService.createAndStartProcess(docId, processObjectId);
	}

	@Override
	public HikResult<String> retrackProcess(String processId, String suggest) {
		return processService.retrackProcess(processId, suggest);
	}

	@Override
	public HikResult<String> undoProcess(String processId, String suggest) {
		return processService.undoProcess(processId, suggest);
	}

}
