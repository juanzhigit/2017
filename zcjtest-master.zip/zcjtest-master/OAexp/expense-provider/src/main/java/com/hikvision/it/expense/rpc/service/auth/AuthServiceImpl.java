package com.hikvision.it.expense.rpc.service.auth;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.rpc.dao.auth.IAuthDao;

@Service
public class AuthServiceImpl {
	@Autowired
	IAuthDao authDao;
	
	/**
	 * 校验当前登录人是否有权限获取授权人的数据权限
	 * @param autherUserId
	 * @param docType
	 * @return
	 */
	public boolean checkHasPermission(String autherUserId, String docType) {
		String loginUserId = UserContext.getUserId();
		//当登陆人与授权人一致时，直接返回true
		//否则根据授权类别获取授权数量，数量为0 返回 false 否则返回 true
		if (loginUserId.equalsIgnoreCase(autherUserId)) {
			return true;
		} else {
			int number = authDao.countAuthNumber(loginUserId, autherUserId, docType);
			
			return number == 0 ? false : true;
		}
	}
}
