package com.hikvision.it.expense.rpc.dao.voucher;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.entity.voucher.OnLineBsik;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;

public interface IVoucherDao {
	/**
	 * 统计凭证付款大于0的条目
	 * @param docId
	 * @return
	 */
	int countPayAmountAboverZero(@Param("docId") String docId);
	
	/**
	 * 获取单据过账次数(包含已冲销凭证)
	 * @param docId
	 * @return
	 */
	int countDocWirteOffTimes(@Param("docId") String docId);
	
	/**
	 * 获取单据过账次数（不包含冲销凭证）
	 * @param docId
	 * @return
	 */
	int countDocPostedTimes(@Param("docId") String docId);
	
	/**
	 * 获取报销系统在途未清明细
	 * @param userId
	 * @param bukrs
	 * @return
	 */
	List<OnLineBsik> listReimOnLineBsik(@Param("userId") String userId, 
										@Param("bukrs") String bukrs);

	/**
	 * 根据单据编号获取所有凭证抬头信息
	 * @param docId
	 * @return
	 */
	List<VoucherHeader> getVoucherHeaderByDocId(@Param("docId") String docId);

    /**
     * 根据单据编号获取临时(F001/F002)凭证抬头信息
     */
	default List<VoucherHeader> getTempVoucherHeaderByDocId(@Param("docId") String docId) {
		return getVoucherHeaderByDocId(docId).stream().filter(o -> "F001".equals(o.getFiOrderStatus()) || "F002".equals(o.getFiOrderStatus())).collect(Collectors.toList());
	}

	/**
	 * 根据凭证抬头ID获取凭证明细行
	 * @param headerId
	 * @return
	 */
	List<VoucherItem> getTempVoucherItemsByHeaderId(@Param("headerId") String headerId);
	
	/**
	 * 删除临时凭证行项目信息
	 * @param docId
	 * @return
	 */
	int deleteTempVoucherItem(@Param("docId") String docId);

	/**
	 * 删除临时凭证抬头
	 * @param docId
	 * @return
	 */
	int deleteTempVoucherHeader(@Param("docId") String docId);

	/**
	 * 新增凭证抬头信息
	 * @param voucherHeaders
	 * @return
	 */
	int insertVoucherHeader(@Param("voucherHeaders") List<VoucherHeader> voucherHeaders);
	
	/**
	 * 新增凭证明细
	 * @param voucherItems
	 * @return
	 */
	int batchInsertVoucherItem(@Param("voucherItems") List<VoucherItem> voucherItems);
	
	/**
	 * 过账成功
	 * @param voucherHeader
	 * @return
	 */
	int postSuccess(@Param("voucherHeader") VoucherHeader voucherHeader);
	
	/**
	 * 付款成功
	 * @param docId
	 * @return
	 */
	int updateFkStatus(@Param("docId") String docId);

	/**
	 * 根据当前登陆人员 获取可以付款的报销单据
	 * @param userId		员工编号
	 * @param docNo         申请单号
	 * @param postUser      过账会计
	 * @param bukrs         公司代码
	 * @return
	 */
	List<CashierAudit> getDocsToPayment(@Param("userId") String userId,
										@Param("docNo") String docNo,
										@Param("postUser") String postUser,
										@Param("bukrs") String bukrs);

	/**
	 * 更新凭证行项目清帐标识
	 * @param items
	 * @return
	 */
	int updateVoucherClearingFlag(@Param("items") List<CashierAudit> items);

	/**
	 * 获取所有可以付款的行项目
	 * @param userId
	 * @param docNo
	 * @param postUser
	 * @param bukrs
	 * @return
	 */
	List<CashierAudit> listItemToPayment(@Param("userId") String userId,
										 @Param("docNo") String docNo,
										 @Param("postUser") String postUser,
										 @Param("bukrs") String bukrs);
}
