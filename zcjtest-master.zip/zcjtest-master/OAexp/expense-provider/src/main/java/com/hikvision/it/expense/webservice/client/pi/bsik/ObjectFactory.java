
package com.hikvision.it.expense.webservice.client.pi.bsik;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hikvision.it.expense.rpc.webservice.client package.
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hikvision.it.expense.rpc.webservice.client
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ZIREIMBURSEGETBSIKResponse }
     * 
     */
    public ZIREIMBURSEGETBSIKResponse createZIREIMBURSEGETBSIKResponse() {
        return new ZIREIMBURSEGETBSIKResponse();
    }

    /**
     * Create an instance of {@link BAPIRETURN1 }
     * 
     */
    public BAPIRETURN1 createBAPIRETURN1() {
        return new BAPIRETURN1();
    }

    /**
     * Create an instance of {@link ZIREIMBURSEGETBSIKResponse.ETRETURN }
     * 
     */
    public ZIREIMBURSEGETBSIKResponse.ETRETURN createZIREIMBURSEGETBSIKResponseETRETURN() {
        return new ZIREIMBURSEGETBSIKResponse.ETRETURN();
    }

    /**
     * Create an instance of {@link ZIREIMBURSEGETBSIK }
     * 
     */
    public ZIREIMBURSEGETBSIK createZIREIMBURSEGETBSIK() {
        return new ZIREIMBURSEGETBSIK();
    }

    /**
     * Create an instance of {@link ZSREIMBURSEGETBSIK }
     * 
     */
    public ZSREIMBURSEGETBSIK createZSREIMBURSEGETBSIK() {
        return new ZSREIMBURSEGETBSIK();
    }

}
