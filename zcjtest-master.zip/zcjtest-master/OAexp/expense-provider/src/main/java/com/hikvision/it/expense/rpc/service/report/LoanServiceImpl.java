package com.hikvision.it.expense.rpc.service.report;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.report.ForeignCurrencyLoanDetail;
import com.hikvision.it.expense.api.service.report.ILoanService;
import com.hikvision.it.expense.rpc.dao.report.IReportDao;

@Service
public class LoanServiceImpl implements ILoanService {

    @Autowired
    IReportDao reportDao;

    @Override
    public List<ForeignCurrencyLoanDetail> listForeignCurrencyLoans() {
        return reportDao.listForeignCurrencyLoans();
    }
}
