package com.hikvision.it.expense.rpc.task;


import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.ApplicationContext;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.report.IReportService;
import com.hikvision.it.expense.rpc.util.WebServiceStatus;


/**
 *
 * 定时任务
 *
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/5
 * Time: 10:25
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ScheduledTask {
    private static final Logger logger = LoggerFactory.getLogger(ScheduledTask.class);

    @Value("${system.oa.todo.url}")
    private String todoUrl;
    @Autowired
    ApplicationContext context;
    /**
     * 测试oa待办是否连通
     */
    @Scheduled(cron="0 0/5 * * * ?")
    public void testTodoWsdlConnectted() {
        try {
            URL urlObj = new URL(todoUrl);
            HttpURLConnection oc = (HttpURLConnection) urlObj.openConnection();
            oc.setUseCaches(false);
            oc.setConnectTimeout(3000); //设置超时时间
            int status = oc.getResponseCode();//请求状态
            if(200 == status && !WebServiceStatus.OA_TODO_WEBSERVICE_REACHABLE){
                WebServiceStatus.OA_TODO_WEBSERVICE_REACHABLE = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
            if (WebServiceStatus.OA_TODO_WEBSERVICE_REACHABLE )
                WebServiceStatus.OA_TODO_WEBSERVICE_REACHABLE = false;
        }
    }

    /**
     * 每月1号0点
     * 发送预付未核销催收邮件
     *
     */
//    @Scheduled(cron = "0 0/1 * * * ?")
    @Scheduled(cron="0 0 0 1 * ?")
    public void vendorReportMail() {
        IReportService reportService = (IReportService) context.getBean("reportServiceImpl");
        IFormService formServiceImpl = (IFormService) context.getBean("formServiceImpl");
        List<VendorFormHeader> list = reportService.listVendorAdvice(null, null, null, null, null);
        HikResult<String> result = formServiceImpl.recordMail(list);
        if (!result.isSuccess()) {
            logger.error("每月1日定时发送未核销邮件失败");
        }
    }
}
