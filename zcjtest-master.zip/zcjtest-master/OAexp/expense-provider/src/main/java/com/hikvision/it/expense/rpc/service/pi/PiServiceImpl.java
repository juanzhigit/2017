package com.hikvision.it.expense.rpc.service.pi;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.entity.user.UserBank;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.service.pi.IPiService;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.service.auth.AuthServiceImpl;

/**
 *  对外统一提供PI调用服务
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/5/27
 * Time: 13:59
 * To change this template use File | Settings | File Templates.
 */
@Service
@Primary
public class PiServiceImpl implements IPiService {

    @Autowired
    private BankServiceImpl bankService;
    @Autowired
    private BsikServiceImpl bsikService;
    @Autowired
    private RateServiceImpl rateService;
    @Autowired
    private WBSServiceImpl wbsService;
    @Autowired
    private CrmServiceImpl crmService;
    @Autowired
    private AuthServiceImpl authService;
    @Autowired
    private ClearingServiceImpl clearingService;
    @Autowired
    private IUserDao userDao;

    @Override
    public List<UserBank> findUserBankFromSAP(List<UserBank> users) {
        return bankService.findUserBankFromLocal(users);
    }

    @Override
	public UserBank synchUserBankFromSAP(UserBank user) {
    	try {
        	user = bankService.findUserBankFromSAP(Lists.newArrayList(user)).get(0);
        	
        	if (!Strings.isNullOrEmpty(user.getBankN())) {
        		userDao.deleteUserBank(user);
        		userDao.recordUserBank(user);
        	}
        	
        	return user;
    	} catch (Exception e) {
    	}
    	
		return null;
	}

	@Override
    public List<Bsik> getBsik(String userId, String bukrs) {
		//判断权限
		boolean isPermit = authService.checkHasPermission(userId, DocTypeEnum.WEM003.name());

		if (!isPermit)
			return null;
        return bsikService.getBsik(userId, bukrs);
    }

    @Override
    public BigDecimal getLocalAmount(Date date, BigDecimal amount, String currency, String localCurreny) {
        return rateService.getLocalAmount(date, amount, currency, localCurreny);
    }

	@Override
	public List<SelectOpt> getWBSFromSap(String bukrs, String filter) {
		UserContext.get();
		return wbsService.getWBSFromSap(bukrs, filter);
	}

    @Override
	public List<SelectOpt> getBusinessOpportunityFromCRM(String userId, String filter) {
        LoginUser user = UserContext.get();
        if (null == user) {
            return Lists.newArrayList();
        }
        return crmService.getBusinessOpportunityFromCRM(user.getNotesId() + "@hikvision.com.cn", filter);
    }

    @Override
    public List<SelectOpt> getPartnerFromCRM(String userId, String filter) {
        LoginUser user = UserContext.get();
        if (null == user) {
            return Lists.newArrayList();
        }
        return crmService.getPartnerFromCRM(user.getNotesId() + "@hikvision.com.cn", filter);
    }

    @Override
    public List<CashierAudit> synchClearingStatus(List<CashierAudit> list) {
        LoginUser user = UserContext.get();
        if (null == user) {
            return Lists.newArrayList();
        }
        return clearingService.synchSAPPaymentStatus(list);
    }
}