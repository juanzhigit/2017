package com.hikvision.it.expense.rpc.provider.fee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.fee.DeductionInfo;
import com.hikvision.it.expense.api.entity.fee.ExpensedTrafficFee;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.service.fee.IFeeService;

@Service(version= Version.VERSION_LATEST)
public class FeeProvider implements IFeeService {
	@Autowired
	private IFeeService feeService;
	
	@Override
	public List<ChartData> listUnExpenseFeeDataForChart(String userId) {
		return feeService.listUnExpenseFeeDataForChart(userId);
	}

	@Override
	public List<FeeDetail> listUnExpensedCarSubsidy(String userId) {
		return feeService.listUnExpensedCarSubsidy(userId);
	}

	@Override
	public List<FeeDetail> listUnExpensedBirthInfo(String userId) {
		return feeService.listUnExpensedBirthInfo(userId);
	}

	@Override
	public FeeDetail checkFeeStatus(FormHeader header, FeeDetail feeDetail) {
		return feeService.checkFeeStatus(header, feeDetail);
	}

    @Override
    public List<ExpensedTrafficFee> getExpensedTrafficFees(String userId, String year, String month) {
        return feeService.getExpensedTrafficFees(userId, year, month);
    }

    @Override
    public GridData<DeductionInfo> getDeductionInfos(String userId, String docId) {
        return feeService.getDeductionInfos(userId, docId);
    }

    @Override
    public void saveDeductionInfos(String docId, List<DeductionInfo> list) {
        feeService.saveDeductionInfos(docId, list);
    }
}
