package com.hikvision.it.expense.rpc.dao.trip;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.form.NationalTrip;
import com.hikvision.it.expense.api.entity.trip.TravelReport;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.entity.trip.TripDuplicated;
import com.hikvision.it.expense.api.entity.trip.TripLine;
import com.hikvision.it.expense.api.entity.trip.TripTogether;

public interface ITripDao {
	/**
	 * 新增行程信息
	 * @param trips
	 * @param docId
	 * @param docNo
	 * @return
	 */
	int insertTrips(@Param("trips") List<Trip> trips,
					@Param("docId") String docId,
					@Param("docNo") String docNo);
	
	/**
	 * 新增同行人信息
	 * @param tripTogethers
	 * @param docId
	 * @param docNo
	 * @return
	 */
	int insertTripTogethers(@Param("tripTogethers") List<TripTogether> tripTogethers,
							@Param("docId") String docId,
							@Param("docNo") String docNo);
	
	/**
	 * 软删除差旅行程信息
	 * @param docId
	 * @return
	 */
	int softDelTrips(@Param("docId") String docId);
	
	/**
	 * 删除同行人信息
	 * @param docId
	 * @return
	 */
	int delTripTogethers(@Param("docId") String docId);
	
	/**
	 * 删除每一天的差旅行程信息
	 * @param docId
	 * @return
	 */
	int delTripDays(@Param("docId") String docId);
	
	/**
	 * 获取单据行程信息
	 * @param docId
	 * @param language
	 * @return
	 */
	List<Trip> getTrips(@Param("docId") String docId, @Param("language") String language);
	
	/**
	 * 获取单据同行人信息
	 * @param docId
	 * @return
	 */
	List<TripTogether> getTripTogethers(@Param("docId") String docId);
	
	/**
	 * 行程交叉校验逻辑
	 * 
	 * 1、首先需要排除本单据的行程
	 * 2、当起始日期与终止日期相同时，判断日期是否完全被谋一个申请的行程包含 fromdate < date < todate
	 * 3、当截止日期 > 起始日期时
	 * 	 (fromdate <= 起始日期 < todate)
	 *   or 
	 *	 (fromdate < 截止日期 <= todate)
	 *	 or 
	 *	 (fromdate >= 起始日期 and to_date <= 完成日期)
	 * 
	 * @param docId
	 * @param fromDate
	 * @param toDate
	 * @param allTripEmployees
	 * @return
	 */
	List<TripDuplicated> getDuplicateTrip(@Param("docId") String docId,
										  @Param("fromDate") String fromDate, 
										  @Param("toDate") String toDate,
										  @Param("allTripEmployees") List<String> allTripEmployees);
	
	/**
	 * 新增行程段信息
	 * @param tripLines
	 * @return
	 */
	int insertTripLine(@Param("tripLines") List<TripLine> tripLines);
	
	/**
	 * 根据申请单获取行程段信息
	 * @param docId
	 * @return
	 */
	List<TripLine> listTripLine(@Param("docId") String docId);
	
	/**
	 * 根据申请单号，删除行程段信息
	 * @param docNo
	 * @return
	 */
	int deleteTripLineByDocNo(@Param("docNo") String docNo);
	
	/**
	 * 根据申请单号删除每天的行程明细
	 * @param docNo
	 * @return
	 */
	int deleteTripDayByDocNo(@Param("docNo") String docNo);
	
	/**
	 * 新增每天差旅明细信息
	 * @param tripDays
	 * @return
	 */
	int insertTripDays(@Param("tripDays") List<TripDays> tripDays);
	
	/**
	 * 新增员工差旅城市信息
	 * @param tripCitys
	 * @return
	 */
	int insertUserTripCity(@Param("tripCitys") List<TripDays> tripCitys);
	
	/**
	 * 删除最近20个去过的城市之外的差旅城市记录
	 * @param userId
	 * @return
	 */
	int deleteTripCityOutOfLatest20s(@Param("userId") String userId);
	
	/**
	 * 获取配置国家的海外差旅行程
	 * @param docId
	 * @return
	 */
	List<NationalTrip> listConfigNationalTrips(@Param("docId") String docId);

	/**
	 * 新增差旅报告
	 */
	void insertTravelReport(TravelReport report);
	
	@Delete("delete from z_wem_bus_travel_report where processid = #{docId, jdbcType=VARCHAR}")
	void deleteTravelReport(@Param("docId") String docId);

	/**
	 * 获取差旅报告
	 */
	TravelReport getTravelReport(@Param("docId") String docId);
}
