package com.hikvision.it.expense.rpc.service.approver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.flow.FinalApproveConfig;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.service.execute.ITaskOwnerService;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 获取终审员工信息
 * 
 * 1、如果是分公司单据终审默认是分总
 * 2、根据单据金额获取终审人员需要满足什么级别
 * 3、根据报销人的主管逐级查找满足终审级别的主管信息
 * 4、根据查询到的终审人员进行授权处理
 * 
 * <p>Title: FindFinalApproverServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="findFinalApprover")
public class FindFinalApproverServiceImpl implements ITaskOwnerService {
	@Autowired
	AgentFilterServiceImpl agentService;
	@Autowired
	IFormDao formDao;
	@Autowired
	IApproverDao approverDao;
	
	@Override
	public List<TaskOwner> execute(TaskObject taskObject, String docId) {
		List<TaskOwner> owners = Lists.newArrayList();
		
		FormHeader header = formDao.getFormHeader(docId);
		String deptCode = header.getDeptCode();
		String language = UserContext.getLanguage();
		//判断是否分公司单据、分公司单据终审人员默认分总
		TaskOwner owner = approverDao.getSubCompManager(deptCode, language);
		if (owner == null) {
			//先从审批配置表中读取配置信息，获取逐级审批配置信息
			FinalApproveConfig config = agentService.getFinalApproveConfig(header);
			if (config != null ) {
				int grade = config.getGrade();
				//查询终审人员
				owner = this.getFinalApprover(header.getExpensor(), grade, language);
			}
		} 
		//授权人员过滤
		if (owner != null)
			owners = agentService.filterAgentApprover(taskObject, owner, docId);
		
		return owners;
	}
	
	/**
	 * 获取第一个匹配到的终审主管
	 * @param userId
	 * @param grade
	 * @param language
	 * @return
	 */
	private TaskOwner getFinalApprover(String userId, int grade, String language) {
		//逐级获取主管信息，直到获取到符合条件的为止
		return approverDao.getFirstMatchDirector(userId, grade, language);
	}
}
