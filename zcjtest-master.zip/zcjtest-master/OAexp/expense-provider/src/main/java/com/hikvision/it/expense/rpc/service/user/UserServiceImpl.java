package com.hikvision.it.expense.rpc.service.user;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.user.SearchUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.user.IUserService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;

@Service
@Primary
public class UserServiceImpl implements IUserService {
	@Autowired
	private IUserDao userDao;
	
	@Override
	public User findUserByUserShortName(String userShortName, String language) {
		if (Strings.isNullOrEmpty(userShortName)) {
            return null;
        }
		User user = userDao.findUserByUserShortName(userShortName, language);
		if (user != null) {
		    user.setBranch(userDao.isBranch(user.getDeptCode()));

			Map<String, Object> paramMap = new HashMap<String, Object>();
			//获取员工信用等级
			paramMap.put("userId", user.getUserId());
			paramMap.put("indate", DateUtil.getCurrentDateTime());
			paramMap.put("lv_code", "");
			paramMap.put("lv_desc", "");
			userDao.getCreditByEmpid(paramMap);
			user.setCreditLv(paramMap.get("lv_code").toString());
		}

		return user;
	}

	@Override
	public List<SelectOpt> findAuthUser(String docType) {
		List<SelectOpt> opts = Lists.newArrayList();
		//首先获取所有授权列表
		String language = UserContext.getLanguage();
		List<User> userOpts = userDao.findAuthUser(UserContext.getUserId(), docType, language);
		if (!ListUtil.isEmpty(userOpts)) {
			for (User user : userOpts) {
				SelectOpt opt = new SelectOpt();
				
				opt.setId(user.getUserId());
				opt.setText(user.getUserName());
				//根据人员处理权限范围
				List<User> authScope = userDao.findUserAuthScope(user.getUserId(), docType, language);
				if (!ListUtil.isEmpty(authScope)) {
					//定义权限范围map key未部门代码，value为部门权限
					Map<String, SelectOpt> scopeMap = Maps.newLinkedHashMap();
					//匹配权限范围
					this.matchAuthScope(authScope, scopeMap);
					
					opt.getSubOpt().addAll(scopeMap.values());
				}
				
				opts.add(opt);
			}
		}
		
		return opts;
	}
	
	/**
	 * 匹配权限范围
	 * @param authScope
	 * @param scopeMap
	 */
	private void matchAuthScope(List<User> authScope, Map<String, SelectOpt> scopeMap) {
		String maxLevel = null;
		String preDeptCode = null;
		for (User scope : authScope) {
			String curDeptCode = scope.getDeptCode();
			
			if (!Strings.isNullOrEmpty(curDeptCode)) {
				if (Strings.isNullOrEmpty(preDeptCode) || 
						!preDeptCode.equalsIgnoreCase(curDeptCode)) {
					preDeptCode = curDeptCode;
				}
				//匹配是否是部门权限
				if (StringUtil.COMMON_REGEX.equalsIgnoreCase(scope.getUserId())) {
					//部门权限只取匹配度部门级别最高的部门权限
					//最近的一个部门通配设置
					if (Strings.isNullOrEmpty(maxLevel)) {
						maxLevel = scope.getDeptLevel();
					} else if (!maxLevel.equalsIgnoreCase(scope.getDeptLevel())) {
						continue;
					}
					
					//将权限配置到部门权限中
					this.matchDeptScope(curDeptCode, scope, scopeMap);
				} else {
					//将权限配置到部门权限中
					this.matchDeptScope(curDeptCode, scope, scopeMap);
				}
			}
		}
	}
	
	/**
	 * 匹配部门权限
	 * @param curDeptCode
	 * @param scope
	 * @param scopeMap
	 */
	private void matchDeptScope(String curDeptCode, User scope, Map<String, SelectOpt> scopeMap) {
		SelectOpt deptScop = null;
		if (scopeMap.containsKey(curDeptCode)) {
			deptScop = scopeMap.get(curDeptCode);
		} else {
			//创建部门和公司权限范围entity
			deptScop = new SelectOpt();
			
			deptScop.setId(scope.getDeptCode());
			deptScop.setText(scope.getDeptName());
			
			scopeMap.put(curDeptCode, deptScop);
		}
		SelectOpt bukrsScop = new SelectOpt();
		
		bukrsScop.setId(scope.getBukrs());
		bukrsScop.setText(scope.getBukrsName());
		
		deptScop.getSubOpt().add(bukrsScop);
	}

	@Override
	public List<SearchUser> findUserToAddTripTogether(String filter) {
		return userDao.findUserToAddTripTogether(filter, UserContext.getLanguage());
	}

	@Override
	public String judgeUserFormType(String userId) {
		if (userDao.getVpUserIds().contains(userId)) { // VP
			return "vp";
		}
		String deptCodePath = userDao.getDeptCodePath(userId);
		if (Strings.isNullOrEmpty(deptCodePath)) {
		    throw new ExpenseException("用户无部门信息, userId: " + userId);
        }
		if (deptCodePath.contains("001700")) { // 技服
		    return "jf";
        }
        if (deptCodePath.startsWith("000113\\000170")) { // 交通事业部
		    return "jtsyb";
        }
        if (deptCodePath.startsWith("000113\\000164")) { // 系统交付部
		    return "xtjf";
        }
        if (deptCodePath.startsWith("000113")) { // 系统公司
		    return "xt";
        }
        if (userDao.isBranch(userId)) {
		    return "fgs";
        }
        return "zb";
	}
}
