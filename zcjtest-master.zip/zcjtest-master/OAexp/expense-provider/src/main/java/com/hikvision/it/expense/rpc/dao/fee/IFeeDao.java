package com.hikvision.it.expense.rpc.dao.fee;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.OverStandard;
import com.hikvision.it.expense.api.entity.fee.AdjustItem;
import com.hikvision.it.expense.api.entity.fee.DeductionInfo;
import com.hikvision.it.expense.api.entity.fee.ExpensedTrafficFee;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;

/**
 * 费用记录dao
 * <p>Title: IFeeDao.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月19日
 *
 */
@Component
public interface IFeeDao {
	/**
	 * 获取未报销费用统计信息用于图表展示
	 * @param userId
	 * @param language
	 * @return
	 */
	List<ChartData> listUnExpenseFeeDataForChart(@Param("userId") String userId,
												 @Param("language") String language);
	
	/**
	 * 获取所有未报销的生育费用信息
	 * @param userId
	 * @return
	 */
	List<FeeDetail> listUnExpensedBirthInfo(@Param("userId") String userId);
	
	/**
	 * 获取所有未报销的车辆补贴信息
	 * @param userId
	 * @return
	 */
	List<FeeDetail> listUnExpensedCarSubsidy(@Param("userId") String userId);

	@Select("select count(*) from Z_WEM_BUS_VEHICLE_ALLOWANCE where user_empid = #{userId} and year = #{year} and month = #{month}")
	boolean hasCarAllowance(@Param("userId") String userId, @Param("year") String year, @Param("month") String month);
	
	/**
	 * 计算已报销的市内交通金额
	 * @param userId
	 * @param allowances
	 * @return
	 */
	List<FeeDetail> countExpensedCityTrafficAmount(@Param("userId") String userId,
								   				   @Param("allowances") List<FeeDetail> allowances);

	/**
	 * 获取员工指定年月已报销市内交通费用
	 */
	List<ExpensedTrafficFee> getExpensedTrafficFees(@Param("userId") String userId,
                                                    @Param("year") String year,
                                                    @Param("month") String month);
	
	/**
	 * 根据交通工具级别获取交通工具超标标识
	 * @param toolLevel
	 * @return
	 */
	@Select("select t.overstandard from hikepadm.t_mdm_traffic_tool t "
		   + "where t.tooltype = 'LONGTRIP' "
		     + "and t.toolcode = #{toolLevel, jdbcType = VARCHAR} and rownum = 1")
	String getTrafficToolLevelOverStandardFlag(@Param("toolLevel") String toolLevel);
	
	/**
	 * 根据招待方式，获取所有匹配的招待标准
	 * @param serveType
	 * @return
	 */
	List<OverStandard> listServeStandards(@Param("serveType") String serveType); 
	
	/**
	 * 获取办事处住宿标准
	 * 
	 * @param cityId
	 * @return
	 */
	@Select("select t.zs_amt from hikepadm.z_wem_basic_bsc t where t.cityid = #{cityId, jdbcType=VARCHAR}")
	BigDecimal matchOfficeStandard(@Param("cityId") String cityId);
	
	/**
	 * 匹配住宿标准
	 * @param bukrs
	 * @param userGrade
	 * @param placeGrade
	 * @return
	 */
	OverStandard matchStaysStandard(@Param("bukrs") String bukrs, 
									@Param("userGrade") String userGrade, 
									@Param("placeGrade") String placeGrade);
	
	/**
	 * 根据国家id获取国家级别
	 * @param countryId
	 * @return
	 */
	@Select("select t.regclassid from hikepadm.z_wem_basic_district t "
		   + "where t.cityid = #{countryId, jdbcType=VARCHAR} "
		   + "and t.startdate <= sysdate and t.enddate >= sysdate")
	String getPlaceGradeByCountryId(@Param("countryId") String countryId);
	
	/**
	 * 根据城市id获取城市级别
	 * @param cityId
	 * @return
	 */
	@Select("select t.regclassid from hikepadm.z_wem_basic_district t "
		   + "where t.cityid = #{cityId, jdbcType=VARCHAR} "
		   + "and t.startdate <= sysdate and t.enddate >= sysdate")
	String getPlaceGradeByCityid(@Param("cityId") String cityId);
	
	/**
	 * 从ofee表中删除费用明细
	 * @param docId
	 */
	@Delete("delete from hikepadm.z_wem_bus_travel_ofees_detail t where t.processid = #{docId, jdbcType=VARCHAR} and feetype not in ('SNJT', 'YWZD', 'OTHER')")
	void deleteFeeDetailsFromOfeeTable(@Param("docId") String docId);
	
	/**
	 * 从stays表中删除费用明细
	 * @param docId
	 */
	@Delete("delete from hikepadm.z_wem_bus_travel_stays_detail t where t.processid = #{docId, jdbcType=VARCHAR}")
	void deleteFeeDetailsFromStaysTable(@Param("docId") String docId);
	
	/**
	 * 新增生育报销费用信息到ofee表中
	 * @param header
	 * @param fees
	 */
	void insertBirthOfeeDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 新增车辆补贴报销费用信息到ofee表中
	 * @param header
	 * @param fees
	 */
	void insertCarAllowanceOfeeDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 新增市内交通费用信息到ofee表中
	 * @param header
	 * @param fees
	 */
	void insertCityTrafficOfeeDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 新增业务招待费用信息到ofee表中
	 * @param header
	 * @param fees
	 */
	void insertServeOfeeDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 新增房屋租赁费用信息到ofee表中
	 * @param header
	 * @param fees
	 */
	void insertRentOfeeDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 新增其他费用信息到ofee表中
	 * @param header
	 * @param fees
	 */
	void insertOtherOfeeDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);

	/**
	 * 批量新增市内派车信息到stays表
	 */
	void insertInsideCityDriverFees(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);

	/**
	 * 批量新增长途交通费用信息到stays表中
	 * @param header
	 * @param fees
	 */
	void insertLongTrafficStaysDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 批量新增住宿费用信息到stays表中
	 * @param header
	 * @param fees
	 */
	void insertStaysDetails(@Param("header") FormHeader header, @Param("fees") List<FeeDetail> fees);
	
	/**
	 * 更新车补报销状态
	 * @param docId
	 * @param docNo
	 * @return
	 */
	int updateCarAllowanceExpensed(@Param("docId") String docId, @Param("docNo") String docNo);
	
	/**
	 * 更新生育费用报销状态
	 * @param docId
	 * @param docNo
	 * @return
	 */
	int updateBirthExpensed(@Param("docId") String docId, @Param("docNo") String docNo);
	
	/**
	 * 重置车补报销状态
	 * @param docId
	 * @return
	 */
	int resetCarAllowanceExpenseFlag(@Param("docId") String docId);
	
	/**
	 * 重置生育费用报销状态
	 * @param docId
	 * @return
	 */
	int resetBirthExpenseFlag(@Param("docId") String docId);

    /**
     * 获取单据费用(市内交通/业务招待/其他等)
     */
    List<FeeDetail> getFeeDetails(@Param("docId") String docId, @Param("language") String language);

	/**
	 * 获取差旅费用(长途交通费用/住宿费用)
	 */
	List<FeeDetail> getTravelFees(@Param("docId") String docId, @Param("language") String language);

	/**
	 * 会计调减费用
	 */
	@Update("update z_wem_bus_travel_ofees_detail set ctajafamt = #{adjustAmount, jdbcType=VARCHAR}, tzbwbamt = #{paymentAmount, jdbcType=VARCHAR}, taxrate = #{taxRate, jdbcType=VARCHAR}, taxamount = #{taxAmount, jdbcType=VARCHAR} where id = #{id, jdbcType=VARCHAR}")
	void adjustFeeDetailsAmount(AdjustItem item);

	@Update("update z_wem_bus_travel_stays_detail set adjusted_amount = #{adjustAmount, jdbcType=VARCHAR}, payment_amount = #{paymentAmount, jdbcType=VARCHAR}, taxrate = #{taxRate, jdbcType=VARCHAR}, taxamount = #{taxAmount, jdbcType=VARCHAR} where id = #{id, jdbcType=VARCHAR}")
	void adjustTravelFeesAmount(AdjustItem item);

    /**
     * 获取扣款信息
     */
	List<DeductionInfo> getDeductionInfos(@Param("userId") String userId, @Param("docId") String docId);

    /**
     * 保存扣款信息
     */
    void saveDeductionInfos(@Param("items") List<DeductionInfo> list);

    @Delete("delete from z_wem_bus_flow_kk_detail where processid = #{docId, jdbcType=VARCHAR}")
	void deleteDeductionInfos(@Param("docId") String docId);
}
