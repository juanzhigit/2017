package com.hikvision.it.expense.rpc.service.allowance;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.google.common.collect.Multimap;
import com.google.common.collect.Multimaps;
import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.allowance.SubsidyInfo;
import com.hikvision.it.expense.api.entity.allowance.WPOrSXInfo;
import com.hikvision.it.expense.api.entity.base.District;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripLine;
import com.hikvision.it.expense.api.enums.DeductionReasonEnum;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.SubsidyTypeEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.allowance.ICalculateSubsidyService;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.subsidy.ISubsidyDao;
import com.hikvision.it.expense.rpc.dao.trip.ITripDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.util.CalculateUtil;
import com.hikvision.it.expense.rpc.util.FormUtil;

@Service
@Primary
public class CalculateSubsidyServiceImpl implements ICalculateSubsidyService {
	@Autowired
    ISubsidyDao subsidyDao;
	@Autowired
    ITripDao tripDao;
	@Autowired
	IFormDao formDao;
	@Autowired
	IBaseService baseService;
	@Autowired
	IFormService formService;

	@Override
	public void adjustAllowances(List<Allowance> list) {
		String docId = null;
		for (Allowance allowance : list) {
			docId = allowance.getDocId();
			subsidyDao.adjustAllowance(allowance);
		}
		// 更新表头补贴金额
		BigDecimal subsidyAmount = subsidyDao.sumSubsidyAmount(docId);
		formDao.updateSubsidyAmount(docId, subsidyAmount);
	}

	@Override
	@Transactional
	public List<Allowance> calculateAllowance(FormHeader formHeader,
                                              List<Trip> trips) {
		Map<String, Allowance> allowanceMap = Maps.newHashMap();

		String minDate = "2099-12-31";
        String maxDate = "2000-01-01";
        for (Trip trip : trips) {
            if (!Strings.isNullOrEmpty(trip.getFromDate())) {
                if (trip.getFromDate().compareTo(minDate) < 0) {
                    minDate = trip.getFromDate();
                }
                if (trip.getFromDate().compareTo(maxDate) > 0) {
                    maxDate = trip.getFromDate();
                }
            }
            if (!Strings.isNullOrEmpty(trip.getToDate())) {
                if (trip.getToDate().compareTo(minDate) < 0) {
                    minDate = trip.getToDate();
                }
                if (trip.getToDate().compareTo(maxDate) > 0) {
                    maxDate = trip.getToDate();
                }
            }
        }

        formHeader.setTripFromDate(minDate);
        formHeader.setTripToDate(maxDate);
        List<HolidayWork> workDays = formService.listWorkingHolidays(formHeader.getDocId(), formHeader.getBukrs(), minDate, maxDate);

		//校验权限
		if (formService.checkCanEditDoc(formHeader)) {
			//计算补贴
			this.packageAllowance(formHeader, workDays, trips, allowanceMap);

			List<Allowance> allowances = Lists.newArrayList(allowanceMap.values());
			//保存补贴明细
			List<AllowanceDetail> details = this.getAllowanceDetail(allowances);
			this.saveAllowanceDetail(formHeader.getDocId(),
                    details,
                    Strings.isNullOrEmpty(formHeader.getDocNo()) || formHeader.getDocNo().startsWith("T"),
                    false);

            // 累加表头补贴金额
            BigDecimal totalSubsidyAmount = formHeader.getSubsidyAmount();
            for (AllowanceDetail allRentAllowance : details) {
                totalSubsidyAmount = totalSubsidyAmount.add(allRentAllowance.getPayAmount());
            }
            formHeader.setSubsidyAmount(totalSubsidyAmount);

            return allowances;
		}

		return Lists.newArrayList();
	}

	/**
	 * 获取补贴明细
	 * @param allowances
	 * @return
	 */
	private List<AllowanceDetail> getAllowanceDetail(List<Allowance> allowances) {
		List<AllowanceDetail> details = Lists.newArrayList();

		if (!ListUtil.isEmpty(allowances)) {
			for (Allowance allowance : allowances) {
				details.addAll(allowance.getSubsidyDetails());
			}
		}

		return details;
	}

	/**
	 * 计算差旅补贴
	 * @param formHeader
	 * @param workDays
	 * @param allowanceMap
	 */
	private void packageAllowance(FormHeader formHeader,
								  List<HolidayWork> workDays,
								  List<Trip> trips,
								  Map<String, Allowance> allowanceMap) {
		String startDate = formHeader.getTripFromDate();
		String endDate = formHeader.getTripToDate();
		java.util.Date subDate = formHeader.getSubmittedOn();

		if (Strings.isNullOrEmpty(startDate) ||
				Strings.isNullOrEmpty(endDate))
			return;
		if (subDate == null)
			subDate = DateUtil.getCurrentUtilDate();
		//获取差旅行程段信息
		List<TripLine> tripLines = FormUtil.packageTripLine(formHeader, trips);
		if (ListUtil.isEmpty(tripLines)) {
            return;
        } else {
            List<String> cityIds = tripLines.stream().map(TripLine::getTripCity).collect(Collectors.toList());
            List<String> countryIds = tripLines.stream().filter(o -> !"CN".equals(o.getTripCountry())).map(TripLine::getTripCountry).collect(Collectors.toList());
            cityIds.addAll(countryIds);
            List<District> cityLevels = subsidyDao.listDistrictLevel(cityIds);
            ImmutableMap<String, District> levelMap = Maps.uniqueIndex(cityLevels, District::getCityId);
            for (TripLine tripLine : tripLines) {
                if ("CN".equals(tripLine.getTripCountry())) {
                    if (levelMap.containsKey(tripLine.getTripCity())) {
                        tripLine.setPlaceGrade(levelMap.get(tripLine.getTripCity()).getCityLevel());
                    } else {
                        throw new ExpenseException(MessageCache.getMessage(MessageCode.MSG_NO_REGION_LEVEL, tripLine.getTripCountry() + "," + tripLine.getTripCity()));
                    }
                } else {
                    if (levelMap.containsKey(tripLine.getTripCountry())) {
                        tripLine.setPlaceGrade(levelMap.get(tripLine.getTripCountry()).getCityLevel());
                    } else {
                        throw new ExpenseException(MessageCache.getMessage(MessageCode.MSG_NO_REGION_LEVEL, tripLine.getTripCountry() + "," + tripLine.getTripCity()));
                    }
                }
            }
        }
		//校验是否超过60天
		if (CalculateUtil.checkHasSubsidy(DateUtil.stringToSQLDate(endDate), subDate)) {//未超过 有补贴
			this.packageNormalAllowance(formHeader, tripLines, workDays, allowanceMap);
		} else {//超期无补贴
			CalculateUtil.packageOutOfDateAllowance(formHeader, tripLines, allowanceMap);
		}
		//判断是否是长途派车
		String docType = formHeader.getDocType();
		if (DocTypeEnum.WEM012.name().equalsIgnoreCase(docType)) {
			//计算里程补贴
			this.packageCTPCLineSubsidy(formHeader, allowanceMap);
			//计算早晚补贴
			this.packageCTPCZWSubsidy(formHeader, trips, allowanceMap);
		}
	}

	/**
	 * 正常差旅计算逻辑
	 * @param formHeader
	 * @param tripLines
	 * @param holidayWorks
	 * @param allowanceMap
	 */
	private void packageNormalAllowance(FormHeader formHeader,
									    List<TripLine> tripLines,
									    List<HolidayWork> holidayWorks,
									    Map<String, Allowance> allowanceMap) {
		String bukrs = formHeader.getBukrs();
		String startDate = formHeader.getTripFromDate();
		String endDate = formHeader.getTripToDate();
		//获取城市伙食补贴标准
		List<SubsidyInfo> foodSubsidyST = subsidyDao.listSubsidyStandard(SubsidyTypeEnum.FOOD.getCode(), bukrs, startDate, endDate);
		//获取节假日补贴标准
		List<SubsidyInfo> holidaySubsidyST = null;
		if (!DocTypeEnum.WEM010.name().equalsIgnoreCase(formHeader.getDocType())) {
			//非国际差旅计算节假日补贴
			holidaySubsidyST = subsidyDao.listSubsidyStandard(SubsidyTypeEnum.HOLI.getCode(), bukrs, startDate, endDate);
		}
		//获取差旅城市中有艰苦补贴的城市补贴信息
		List<SubsidyInfo> hardSubsidyST = subsidyDao.listHardSubsidyStandard(bukrs, tripLines);
		//获取区间范围内的所有外派记录信息
		List<WPOrSXInfo> wpList = subsidyDao.listWPInfo(formHeader.getExpensor(), startDate, endDate);
		//获取区间范围内的所有实习记录信息
		List<WPOrSXInfo> sxList = subsidyDao.listSXInfo(formHeader.getExpensor(), startDate, endDate);
		//获取周末调休信息
		List<Date> offWeekends = subsidyDao.listOffWeekend(bukrs, startDate, endDate);
		//定义伙食补贴、艰苦补贴、节假日补贴map
		Map<String, AllowanceDetail> foodSubMap = Maps.newHashMap();
		Map<String, AllowanceDetail> hardSubMap = Maps.newHashMap();
		Map<String, AllowanceDetail> holidaySubMap = Maps.newHashMap();

		//解析行程段明细
		for (TripLine tripLine : tripLines) {
			Date fromDate = tripLine.getFromDate();
			Date toDate = tripLine.getToDate();

			//开始计算补贴
			while (fromDate.compareTo(toDate) <= 0) {
				String subsidyDate = DateUtil.dateToString(fromDate);

				//获取补贴日期当天的补贴汇总entity
				Allowance allowance = CalculateUtil.getAllowance(subsidyDate, formHeader, allowanceMap);;

				if (CalculateUtil.isTrainee(fromDate, sxList)) {
					//实习期无补贴
					allowance.setUserState("SX");
				} else {
					WPOrSXInfo wpInfo = CalculateUtil.matchExpatriateInfo(fromDate, wpList);

					//匹配工作信息
					boolean isNoWork = CalculateUtil.isNoWork(fromDate, holidayWorks);
					//计算伙食补贴
					this.packageFoodSubsidy(fromDate, wpInfo, formHeader, allowance,
							tripLine, isNoWork, foodSubsidyST, foodSubMap);
					//计算艰苦补贴
					this.packageHardSubsidy(fromDate, wpInfo, formHeader, allowance,
							tripLine, isNoWork, hardSubsidyST, hardSubMap);
					if (wpInfo == null) {
						//正常补贴计算
						allowance.setUserState("ZC");
						//判断是否周末或者节假日上班
						boolean needPay = CalculateUtil.checkNeedPayHolidaySubsidy(subsidyDate, formHeader.getExpensor(), holidayWorks, offWeekends);
						if (needPay && !holidaySubMap.containsKey(subsidyDate)) {
							//非外派节假日补贴
							this.packageHolidaySubsidy(fromDate, formHeader, allowance,
									tripLine, holidaySubsidyST, holidaySubMap);
						}
					} else {
						//外派补贴计算逻辑
						allowance.setUserState("WP");
					}
				}
				//设置每天补贴汇总entity到map中
				allowanceMap.put(subsidyDate, allowance);

				//起始天数+1
				fromDate = DateUtil.addDay(fromDate);
			}
		}
	}

	/**
	 * 计算伙食补贴
	 * @param date				补贴日期
	 * @param wp				外派信息
	 * @param header			表单信息
	 * @param allowance			汇总补贴信息
	 * @param tripLine			行程信息
	 * @param isNoWork			未工作标识
	 * @param foodSubsidyST		伙食补贴标准信息
	 * @param map				伙食补贴map
	 */
	private void packageFoodSubsidy(Date date,
									WPOrSXInfo wp,
									FormHeader header,
									Allowance allowance,
									TripLine tripLine,
									boolean isNoWork,
									List<SubsidyInfo> foodSubsidyST,
								    Map<String, AllowanceDetail> map) {
		SubsidyInfo foodSubsidy = null;
		SubsidyInfo wpfoodSubsidy = null;
		if (!ListUtil.isEmpty(foodSubsidyST))
			foodSubsidy = CalculateUtil.matchSubsidyStandard(date, tripLine.getPlaceGrade(), foodSubsidyST);
		if (wp != null)
			wpfoodSubsidy = CalculateUtil.matchSubsidyStandard(date, wp.getPlaceGrade(), foodSubsidyST);
		if (foodSubsidy == null)
			throw new ExpenseException(ExceptionCode.SUBSIDY_NOT_FOUND_ERROR_FOOD);
		if (wp != null && wpfoodSubsidy == null)
			throw new ExpenseException(ExceptionCode.SUBSIDY_NOT_FOUND_ERROR_FOOD_WP);
		AllowanceDetail foodAllowance = this.packageAllowanceDetail(
				SubsidyTypeEnum.FOOD, date, header, allowance, tripLine, isNoWork,
				foodSubsidy, wpfoodSubsidy, map);

		if (foodAllowance != null) {
			//设置伙食补贴到每天汇总信息中
			allowance.setFoodAllowanceAmount(foodAllowance.getPayAmount());
			allowance.getSubsidyDetails().add(foodAllowance);

			if (foodAllowance.getPayAmount().compareTo(BigDecimal.ZERO) > 0)
				map.put(allowance.getAllowanceDate(), foodAllowance);
		}
	}

	/**
	 * 计算艰苦补贴
	 * @param date				补贴日期
	 * @param wp				外派信息
	 * @param header			表单信息
	 * @param allowance			汇总补贴信息
	 * @param tripLine			行程信息
	 * @param isNoWork			未工作
	 * @param hardSubsidyST		伙食补贴标准信息
	 * @param map				伙食补贴map
	 */
	private void packageHardSubsidy(Date date,
									WPOrSXInfo wp,
									FormHeader header,
									Allowance allowance,
									TripLine tripLine,
									boolean isNoWork,
									List<SubsidyInfo> hardSubsidyST,
								    Map<String, AllowanceDetail> map) {
		SubsidyInfo hardSubsidy = null;
		SubsidyInfo wpHardSubsidy = null;

		if (!ListUtil.isEmpty(hardSubsidyST))
			hardSubsidy = CalculateUtil.matchHardSubsidyStandard(date, tripLine.getTripCountry(), tripLine.getTripCity(), hardSubsidyST);
		if (wp != null)
			wpHardSubsidy = CalculateUtil.matchHardSubsidyStandard(date, wp.getCountry(), wp.getCity(), hardSubsidyST);
//		if (hardSubsidy == null)
//			throw new ExpenseException(ExceptionCode.SUBSIDY_NOT_FOUND_ERROR_HARD);
//		if (wp != null && wpHardSubsidy == null)
//			throw new ExpenseException(ExceptionCode.SUBSIDY_NOT_FOUND_ERROR_HARD_WP);
		AllowanceDetail hardAllowance = this.packageAllowanceDetail(
				SubsidyTypeEnum.HARD, date, header, allowance, tripLine,
				isNoWork, hardSubsidy, wpHardSubsidy, map);

		if (hardAllowance != null) {
			//设置补贴到每天汇总信息中
			allowance.setHardAllowanceAmount(hardAllowance.getPayAmount());
			allowance.getSubsidyDetails().add(hardAllowance);

			if (hardAllowance.getPayAmount().compareTo(BigDecimal.ZERO) > 0)
				map.put(allowance.getAllowanceDate(), hardAllowance);
		}
	}

	/**
	 * 计算艰苦补贴
	 * @param date				补贴日期
	 * @param header			表单信息
	 * @param allowance			汇总补贴信息
	 * @param tripLine			行程信息
	 * @param holidaySubsidyST	伙食补贴标准信息
	 * @param map				伙食补贴map
	 */
	private void packageHolidaySubsidy(Date date,
										FormHeader header,
										Allowance allowance,
										TripLine tripLine,
										List<SubsidyInfo> holidaySubsidyST,
									    Map<String, AllowanceDetail> map) {
		SubsidyInfo holidaySubsidy = null;
		String subsidyDate = allowance.getAllowanceDate();

		if (!ListUtil.isEmpty(holidaySubsidyST))
			holidaySubsidy = CalculateUtil.matchSubsidyStandard(date, holidaySubsidyST);

		AllowanceDetail holidayAllowance = null;
		//未生成有效补贴且未发放过补贴，进行补贴计算
		if (holidaySubsidy != null) {
			String holidayCur = holidaySubsidy.getCurrency();

			Rate rate = this.getRate(subsidyDate, holidayCur, header.getCurrency(), null);
			holidayAllowance = CalculateUtil.packageSubsidy(SubsidyTypeEnum.HOLI,
					holidaySubsidy, subsidyDate, rate.getRate(), allowance);
		}

		if (holidayAllowance != null &&
				holidayAllowance.getPayAmount().compareTo(BigDecimal.ZERO) > 0) {
			//设置补贴到每天汇总信息中
			allowance.setHolidayAllowanceAmount(holidayAllowance.getPayAmount());
			allowance.getSubsidyDetails().add(holidayAllowance);
			map.put(allowance.getAllowanceDate(), holidayAllowance);
		}
	}

	/**
	 * 通用补贴计算逻辑
	 * @param subsidyType
	 * @param date
	 * @param header
	 * @param allowance
	 * @param tripLine
	 * @param isNoWork
	 * @param subsidy
	 * @param wpSubsidy
	 * @param map
	 * @return
	 */
	private AllowanceDetail packageAllowanceDetail(SubsidyTypeEnum subsidyType,
													Date date,
													FormHeader header,
													Allowance allowance,
													TripLine tripLine,
													boolean isNoWork,
													SubsidyInfo subsidy,
													SubsidyInfo wpSubsidy,
												    Map<String, AllowanceDetail> map) {
		String subsidyDate = allowance.getAllowanceDate();
		String userId = header.getExpensor();
		String payCur = header.getCurrency();

		//未生成有效补贴且未发放过补贴，进行补贴计算
		if (subsidy != null &&
				!map.containsKey(subsidyDate) &&
				!this.checkSubsidyIsPaid(subsidyType, userId, subsidyDate)) {
			//判断伙食补贴是否发放
			String currency = subsidy.getCurrency();
			//获取汇率
			Rate rate = this.getRate(subsidyDate, currency, payCur, null);
			//生成伙食补贴
			AllowanceDetail allowanceDetail = CalculateUtil.packageSubsidy(
					subsidyType, subsidy, subsidyDate, rate.getRate(), allowance);
			//设置补贴城市
			allowanceDetail.setCountry(tripLine.getTripCountry());
			allowanceDetail.setCity(tripLine.getTripCity());
			allowanceDetail.setCityName(tripLine.getTripCityDesc());

			if (!isNoWork) {
				//非节假日或者节假日上班正常给补贴
				//判断是否外派
				if (wpSubsidy == null) {
					switch (subsidyType) {
						case FOOD:
							this.packageFoodSubsidy(header, allowanceDetail);
							break;
						default:
							break;
					}
				} else {
					DeductionReasonEnum reason = DeductionReasonEnum.WP_SUB;
					//外派差额补贴计算
					this.packageWPSubsidy(allowanceDetail, wpSubsidy, reason, payCur);
				}
			} else {
				//节假日未工作，无补贴
				allowanceDetail.setDeductionAmount(allowanceDetail.getAllowanceAmount());
				allowanceDetail.setPayAmount(BigDecimal.ZERO);
				allowanceDetail.setDeductionCurrency(allowanceDetail.getCurrency());
				allowanceDetail.setDeductionReason(DeductionReasonEnum.HOLIDAY_NO_WORK.name());
			}

			return allowanceDetail;
		} else {
			return CalculateUtil.packageSubsidy(subsidyType, allowance);
		}
	}

	/**
	 * 生成伙食补贴明细
	 * @param header
	 * @param allowanceDetail
	 */
	private void packageFoodSubsidy(FormHeader header, AllowanceDetail allowanceDetail) {
		String hybcFlag = header.getHybcFlag();
		String currency = header.getCurrency();
		String allowanceCurrency = allowanceDetail.getCurrency();
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(hybcFlag)) {
			//会议包餐扣除伙食补贴
			allowanceDetail.setDeductionAmount(BigDecimal.valueOf(20));
			allowanceDetail.setAllowanceAmount(allowanceDetail.getAllowanceAmount().subtract(allowanceDetail.getDeductionAmount()));
			allowanceDetail.setDeductionCurrency(allowanceDetail.getCurrency());
			allowanceDetail.setDeductionReason(DeductionReasonEnum.HYBC.name());
		}

		if (!currency.equalsIgnoreCase(allowanceCurrency)) {
			Rate ceRate = this.getRate(allowanceDetail.getAllowanceDate(), currency, allowanceCurrency, allowanceDetail.getAllowanceAmount());
			allowanceDetail.setPayAmount(ceRate.getPayAmount());
			allowanceDetail.setRate(ceRate.getRate());
		}
	}

	/**
	 * wp差额补贴计算逻辑
	 * @param allowanceDetail
	 * @param wpSubsidy
	 * @param reason
	 */
	private void packageWPSubsidy(AllowanceDetail allowanceDetail,
								  SubsidyInfo wpSubsidy,
								  DeductionReasonEnum reason,
								  String payCur) {
		BigDecimal deducationAmount = BigDecimal.ZERO;
		String currency = allowanceDetail.getCurrency();

		if (wpSubsidy != null) {
            deducationAmount = wpSubsidy.getAmount();
            currency = wpSubsidy.getCurrency();
        }

		allowanceDetail.setDeductionReason(reason.name());
		allowanceDetail.setDeductionAmount(deducationAmount);
		allowanceDetail.setDeductionCurrency(currency);

		if (payCur.equalsIgnoreCase(currency)) {
			//外派地补贴币别与付款币别一致
			allowanceDetail.setPayAmount(allowanceDetail.getPayAmount().subtract(deducationAmount));
		} else if (allowanceDetail.getCurrency().equalsIgnoreCase(currency)) {
			//外派地补贴币别与出差地补贴币别一致
			if (deducationAmount.compareTo(allowanceDetail.getAllowanceAmount()) < 0) {
				//外派地补贴标准低于差旅地补贴标准，设置差额补贴
				BigDecimal ce = allowanceDetail.getAllowanceAmount().subtract(deducationAmount);
				allowanceDetail.setPayAmount(ce.multiply(allowanceDetail.getRate()).setScale(2, BigDecimal.ROUND_HALF_UP));
			} else {
				//设置差额补贴为0
				allowanceDetail.setPayAmount(BigDecimal.ZERO);
			}
		} else {
			//外派地补贴币别与付款币别和差旅地补贴币别都不相同时，折算成本位币后扣减
			Rate rate = this.getRate(allowanceDetail.getAllowanceDate(), currency, payCur, deducationAmount);

			BigDecimal deducatLocatAmount = rate.getPayAmount();
			if (deducationAmount.compareTo(allowanceDetail.getPayAmount()) < 0) {
				//外派地补贴标准低于差旅地补贴标准，设置差额补贴
				allowanceDetail.setPayAmount(allowanceDetail.getPayAmount().subtract(deducatLocatAmount));
			} else {
				//设置差额补贴为0
				allowanceDetail.setPayAmount(BigDecimal.ZERO);
			}
		}
	}

	/**
	 * 计算第一行行程的出发时间以及最后一行到达时间的早晚补贴
	 * @param formHeader
	 * @param trips
	 * @param allowanceMap
	 */
	private void packageCTPCZWSubsidy(FormHeader formHeader,
									  List<Trip> trips,
									  Map<String, Allowance> allowanceMap) {
		//第一行行程的出发时间以及最后一行到达时间的早晚补贴
		SubsidyTypeEnum amSubsidyType = SubsidyTypeEnum.AM;
		SubsidyTypeEnum pmSubsidyType = SubsidyTypeEnum.PM;
		String bukrs = formHeader.getBukrs();
		Trip firstTrip = trips.get(0);
		Trip lastTrip = trips.get(trips.size() - 1);
		String firstDate = firstTrip.getFromDate();
		int firstTime = firstTrip.getFromTime() == null ? -1 : firstTrip.getFromTime();
		String lastDate = lastTrip.getToDate();
		int lastTime = lastTrip.getToTime() == null ? -1 : lastTrip.getToTime();

		Map<String, AllowanceDetail> amMap = Maps.newHashMap();
		Map<String, AllowanceDetail> pmMap = Maps.newHashMap();

		SubsidyInfo amSubsidy = matchSubsidy(firstDate, amSubsidyType, bukrs);
		SubsidyInfo pmSubsidy = matchSubsidy(firstDate, pmSubsidyType, bukrs);
		if (firstTime != -1 && firstTime <= amSubsidy.getHour()) {// 有早补贴
			this.packageAllowanceZWSubsidy(amSubsidyType, firstDate, amSubsidy,
					formHeader, amMap, allowanceMap);
		} else if (firstTime != -1 && firstTime >= pmSubsidy.getHour()) {// 有晚补贴
			this.packageAllowanceZWSubsidy(pmSubsidyType, firstDate, pmSubsidy,
					formHeader, pmMap, allowanceMap);
		}

		if (lastTime != -1 && lastTime <= amSubsidy.getHour()) {// 有早补贴
			this.packageAllowanceZWSubsidy(amSubsidyType, lastDate, amSubsidy,
					formHeader, amMap, allowanceMap);
		} else if (lastTime != -1 && lastTime >= pmSubsidy.getHour()) {// 有晚补贴
			this.packageAllowanceZWSubsidy(pmSubsidyType, lastDate, pmSubsidy,
					formHeader, pmMap, allowanceMap);
		}
	}

	/**
	 *
	 * @param subsidyType
	 * @param subsidyDate
	 * @param subsidy
	 * @param formHeader
	 * @param map
	 * @param allowanceMap
	 */
	private void packageAllowanceZWSubsidy(SubsidyTypeEnum subsidyType,
											String subsidyDate,
											SubsidyInfo subsidy,
											FormHeader formHeader,
											Map<String, AllowanceDetail> map,
											Map<String, Allowance> allowanceMap) {
		BigDecimal amount = this.packageZWSubsidy(subsidyType, subsidyDate, subsidy, formHeader, map);
		if (BigDecimal.ZERO.compareTo(amount) >= 0) {
			return;
		}
		//获取今天补贴汇总明细 
		Allowance allowance = CalculateUtil.getAllowance(subsidyDate, formHeader, allowanceMap);

		AllowanceDetail detail = map.get(subsidyDate);
		switch (subsidyType) {
			case AM:
				allowance.setAmAllowanceAmount(detail.getPayAmount());
				break;

			case PM:
				allowance.setPmAllowanceAmount(detail.getPayAmount());
				break;
			default:
				break;
		}
		allowance.getSubsidyDetails().add(detail);

		allowanceMap.put(subsidyDate, allowance);
	}

	/**
	 * 长途派车额外计算里程补贴
	 * @param formHeader
	 * @param allowanceMap
	 */
	private void packageCTPCLineSubsidy(FormHeader formHeader,
										Map<String, Allowance> allowanceMap) {
		String bukrs = formHeader.getBukrs();
		String curDate = DateUtil.getCurrentDateString();
		String payCur = formHeader.getCurrency();
		//计算里程补贴
		BigDecimal miles = formHeader.getKilometre();
		if (miles != null && miles.compareTo(BigDecimal.ZERO) > 0) {
			List<SubsidyInfo> mileSubsidys = subsidyDao.listSubsidyStandard(
					SubsidyTypeEnum.LINE.getCode(), bukrs, curDate, curDate);

			if (!ListUtil.isEmpty(mileSubsidys)) {
				//获取匹配的里程补贴
				SubsidyInfo mileSubsidy = CalculateUtil.matchLineSubsidy(miles, mileSubsidys);

				if (mileSubsidy != null) {
					Rate rate = this.getRate(curDate, mileSubsidy.getCurrency(), payCur, null);
					//计算里程补贴
					AllowanceDetail detail = CalculateUtil.packageSubsidy(SubsidyTypeEnum.LINE, mileSubsidy, curDate, rate.getRate(), formHeader);
					//获取今天补贴汇总明细
					Allowance allowance = CalculateUtil.getAllowance(curDate, formHeader, allowanceMap);

					allowance.setLineAllowanceAmount(detail.getPayAmount());
					allowance.getSubsidyDetails().add(detail);

					allowanceMap.put(curDate, allowance);
				}
			}
		}
	}

	/**
	 * 获取金额汇率转换信息
	 * @param date
	 * @param currency
	 * @param payCur
	 * @param amount
	 * @return
	 */
	private Rate getRate(String date, String currency, String payCur, BigDecimal amount) {
		Rate rate = new Rate();

		rate.setAmount(amount);
		rate.setCurrency(currency);
		rate.setDate(date);
		rate.setPayCurrency(payCur);
		//需要汇率转换
		return baseService.getRates(rate);
	}

	/**
	 * 判断补贴是否已发放
	 * @param subsidyType
	 * @param userId
	 * @param subsidyDate
	 * @return
	 */
	private boolean checkSubsidyIsPaid(SubsidyTypeEnum subsidyType, String userId, String subsidyDate) {
		int countNum = subsidyDao.countSubsidyPaidTimes(userId, subsidyType.getCode(), subsidyDate, null);

		return countNum > 0 ? true : false;
	}

	@Override
	public List<AllowanceDetail> calculateRentAllowance(FormHeader formHeader, String fromDate, String toDate) {
		if (fromDate == null || toDate == null)
			return null;
		if ((DateUtil.daysBetween(DateUtil.stringToSQLDate(fromDate),
				DateUtil.stringToSQLDate(toDate)) + 1) < 14) {
			// 14天以内无租住补贴
			return null;
		}

		List<AllowanceDetail> rentAllowances = Lists.newArrayList();
		//计算并生产租住补贴
		this.packageRentSubsidy(formHeader, fromDate, toDate, rentAllowances);
		this.saveAllowanceDetail(formHeader.getDocId(), rentAllowances, formHeader.getDocNo().startsWith("T"),true);
        //返回租住补贴明细
		return rentAllowances;
	}

	@Override
	public List<AllowanceDetail> calculateRentAllowance(FormHeader formHeader, List<FeeDetail> stayFees) {

        List<AllowanceDetail> allRentAllowances = Lists.newArrayList();
        for (FeeDetail stayFee : stayFees) {
            List<AllowanceDetail> rentAllowances = Lists.newArrayList();

            String fromDate = stayFee.getFeeFromDate();
            String toDate = stayFee.getFeeToDate();
            if ("N".equals(stayFee.getRentType()) || fromDate == null || toDate == null) {
                continue;
            } else if ((DateUtil.daysBetween(DateUtil.stringToSQLDate(fromDate),
                    DateUtil.stringToSQLDate(toDate)) + 1) < 14) {
                // 14天以内无租住补贴
                continue;
            }
            //计算并生产租住补贴
            this.packageRentSubsidy(formHeader, fromDate, toDate, rentAllowances);
            allRentAllowances.addAll(rentAllowances);
        }

		this.saveAllowanceDetail(formHeader.getDocId(),
				                 allRentAllowances,
								Strings.isNullOrEmpty(formHeader.getDocNo()) || formHeader.getDocNo().startsWith("T"),
								true);

        // 累加表头补贴金额
        BigDecimal totalSubsidyAmount = formHeader.getSubsidyAmount();
        for (AllowanceDetail allRentAllowance : allRentAllowances) {
            totalSubsidyAmount = totalSubsidyAmount.add(allRentAllowance.getPayAmount());
        }
        formHeader.setSubsidyAmount(totalSubsidyAmount);

        //返回租住补贴明细
		return allRentAllowances;
	}

	/**
	 * <p>计算某一区间段内员工租住补贴补贴明细</p>
	 *
	 * 如果当天属于外派，则扣减掉租住补贴，设置扣减原因为 DeductionReasonEnum.WP.name()
	 * 如果当天已享受租住补贴，则口减掉租住补贴，设置扣减原因为 DeductionReasonEnum.PAID.name()
	 * 如果未维护补贴，则设置补贴金额为0，设置扣减原因为 DeductionReasonEnum.NOMATCH.name()
	 *
	 * @param formHeader
	 * @param fromDate
	 * @param toDate
	 * @param rentAllowances
	 * @return
	 */
	private void packageRentSubsidy(FormHeader formHeader,
								    String fromDate, String toDate,
								    List<AllowanceDetail> rentAllowances) {
		String subsidyType = SubsidyTypeEnum.RENT.getCode();
		String userId = formHeader.getExpensor();
		String docId = formHeader.getDocId();

		//根据公司代码获取补贴标准
		List<SubsidyInfo> subsidys = subsidyDao.listSubsidyStandard(subsidyType, formHeader.getBukrs(), fromDate, toDate);
		if (ListUtil.isEmpty(subsidys))//未获取到补贴配置
			return;
		//获取区间范围内的所有实习记录信息
		List<WPOrSXInfo> sxList = subsidyDao.listSXInfo(userId, fromDate, toDate);
		//获取区间范围内的所有外派记录信息
		List<WPOrSXInfo> wpList = subsidyDao.listWPInfo(userId, fromDate, toDate);
		//获取区间范围内的所有已付租住补贴信息
		List<AllowanceDetail> paidAllowances = subsidyDao.listPaidSubsidy(userId, docId, subsidyType, fromDate, toDate);

		Date startDate = DateUtil.stringToSQLDate(fromDate);
		Date endDate = DateUtil.stringToSQLDate(toDate);
		//计算租住补贴
		CalculateUtil.calculateRentSubsidy(formHeader, startDate, endDate,
				subsidys, sxList, wpList, paidAllowances, rentAllowances);
	}

	@Override
	@Transactional
	public List<Trip> calculateCityCar(FormHeader formHeader, List<Trip> trips) {
		//校验权限
		if (formService.isEditable(formHeader.getDocId())) {
			//计算早晚补贴
			List<AllowanceDetail> subsidies = this.packageZWSubsidy(formHeader, trips);

            //保存补贴信息
            // 将补贴明细按日期分组后累加
			List<Allowance> allowances = Lists.newArrayList();
            Multimap<String, AllowanceDetail> allowanceDetailMultimap = Multimaps.index(subsidies, AllowanceDetail::getAllowanceDate);
            allowanceDetailMultimap.asMap().forEach((date, collection) -> {
                List<AllowanceDetail> list = (List<AllowanceDetail>) collection;
                // 设置公共信息
                Allowance allowance = new Allowance();
                allowance.setId(StringUtil.getUUID());
                allowance.setDocId(formHeader.getDocId());
                allowance.setDocNo(formHeader.getDocNo());
                allowance.setUserId(formHeader.getExpensor());
                allowance.setUserName(formHeader.getExpensorName());
                allowance.setAllowanceDate(date);
                for (AllowanceDetail detail : list) {// 根据明细的补贴类型设置到不同字段
                    allowance.setCurrency(detail.getCurrency());
                    if (Objects.equals(detail.getAllowanceType(), SubsidyTypeEnum.AM.getCode())) {
                        allowance.setAmAllowanceAmount(detail.getPayAmount());
                    } else if (Objects.equals(detail.getAllowanceType(), SubsidyTypeEnum.PM.getCode())) {
                        allowance.setPmAllowanceAmount(detail.getPayAmount());
                    }
                }
                allowances.add(allowance);
            });
			// 将早晚补贴明细汇总
			subsidyDao.deleteAllowance(formHeader.getDocId());
			if (ListUtil.isNotEmpty(allowances)) {
				subsidyDao.batchInsertAllowance(allowances);
			}

			//保存补贴信息
            this.saveAllowanceDetail(formHeader.getDocId(), subsidies,
                    Strings.isNullOrEmpty(formHeader.getDocNo()) || formHeader.getDocNo().startsWith("T"), false);
            return trips;
		}

		return null;
	}

	/**
	 * 公共保存补贴明细方法
     *  补贴明细分两种: 租住补贴和其他差旅补贴集合(伙食,节假日等)
	 * @param docId
	 * @param details
     * @param temp 否是临时单据
     * @param isRentAllowanceDetail 是否租住补贴明细
	 */
	private void saveAllowanceDetail(String docId, List<AllowanceDetail> details, boolean temp, boolean isRentAllowanceDetail) {
        subsidyDao.deleteAllowanceDetail(docId, isRentAllowanceDetail);
        if (ListUtil.isEmpty(details)) {
            return;
        }
		int number = subsidyDao.batchInsertAllowanceDetail(details, temp ? "T" : "D");

		if (number != details.size()) {
			//补贴数据发生变更，需要重新计算
			throw new ExpenseException(ExceptionCode.SUBSIDY_ERROR_NEED_CALCULATE_AGAIN);
		}
	}

	/**
	 * 匹配早晚补贴标准
	 * @param subsidyDate
	 * @param subsidyType
	 * @param bukrs
	 * @return
	 */
	private SubsidyInfo matchSubsidy(String subsidyDate, SubsidyTypeEnum subsidyType, String bukrs) {
		SubsidyInfo subsidy = null;
		//获取早晚补贴标准
		List<SubsidyInfo> subsidys = subsidyDao.listSubsidyStandard(subsidyType.getCode(), bukrs, subsidyDate, subsidyDate);
		if (!ListUtil.isEmpty(subsidys)) {
			subsidy = subsidys.get(0);
		}
		if (subsidy == null)
			throw new ExpenseException(ExceptionCode.SUBSIDY_NOT_FOUND_ERROR_ZW);

		return subsidy;
	}

	/**
	 * 计算早晚补贴
	 * @param formHeader
	 * @param trips
	 * @return
	 */
	private List<AllowanceDetail> packageZWSubsidy(FormHeader formHeader, List<Trip> trips) {
		SubsidyTypeEnum amSubsidyType = SubsidyTypeEnum.AM;
		SubsidyTypeEnum pmSubsidyType = SubsidyTypeEnum.PM;
		String bukrs = formHeader.getBukrs();
		String curDate = DateUtil.getCurrentDateString();
		//匹配早晚补贴标准
		SubsidyInfo amSubsidy = matchSubsidy(curDate, amSubsidyType, bukrs);
		SubsidyInfo pmSubsidy = matchSubsidy(curDate, pmSubsidyType, bukrs);

		Map<String, AllowanceDetail> amMap = Maps.newHashMap();
		Map<String, AllowanceDetail> pmMap = Maps.newHashMap();
		//先计算补贴
		if (!ListUtil.isEmpty(trips)) {
			List<AllowanceDetail> listAllowances = Lists.newArrayList();
			for (Trip trip : trips) {
				BigDecimal amount = BigDecimal.ZERO;
				String fromDate = trip.getFromDate();
				String toDate = trip.getToDate();
				int fromTime = trip.getFromTime();
				int toTime = trip.getToTime();

				if (fromTime <= amSubsidy.getHour()) {//有早补贴
					amount = amount.add(this.packageZWSubsidy(amSubsidyType, fromDate, amSubsidy, formHeader, amMap));
				} else if (fromTime >= pmSubsidy.getHour()) {//有晚补贴
                    amount = amount.add(this.packageZWSubsidy(pmSubsidyType, fromDate, pmSubsidy, formHeader, pmMap));
				}

				if (toTime <= amSubsidy.getHour()) {//有早补贴
					amount = amount.add(this.packageZWSubsidy(amSubsidyType, toDate, amSubsidy, formHeader, amMap));
				} else if (toTime >= pmSubsidy.getHour()) {//有晚补贴
					amount = amount.add(this.packageZWSubsidy(pmSubsidyType, toDate, pmSubsidy, formHeader, pmMap));
				}
				//设置当前行程补贴总金额
				trip.setSubsidyAmount(amount);
			}

			if (amMap.size() > 0)
				listAllowances.addAll(amMap.values());
			if (pmMap.size() > 0)
				listAllowances.addAll(pmMap.values());

			return listAllowances;
		}

		return Lists.newArrayList();
	}

	/**
	 * 计算早晚补贴
	 * @param subsidyType
	 * @param subsidyDate
	 * @param subsidy
	 * @param header
	 * @param map
	 */
	private BigDecimal packageZWSubsidy(SubsidyTypeEnum subsidyType,
								  String subsidyDate,
								  SubsidyInfo subsidy,
								  FormHeader header,
								  Map<String, AllowanceDetail> map) {
		if (!map.containsKey(subsidyDate) &&
				!this.checkSubsidyIsPaid(subsidyType, header.getExpensor(), subsidyDate)) {
			AllowanceDetail detail = null;
			String payCur = header.getCurrency();
			if (payCur.equalsIgnoreCase(subsidy.getCurrency())) {
				detail = CalculateUtil.packageSubsidy(
						subsidyType, subsidy, subsidyDate, BigDecimal.valueOf(1),
						header);
			} else {
				Rate rate = this.getRate(subsidyDate, subsidy.getCurrency(), payCur, null);

				detail = CalculateUtil.packageSubsidy(
						subsidyType, subsidy, subsidyDate, rate.getRate(),
						header);
			}
			map.put(subsidyDate, detail);

			return detail.getPayAmount();
		}

		return BigDecimal.ZERO;
	}
}
