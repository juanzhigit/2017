package com.hikvision.it.expense.rpc.util;

public class VoucherConstant {
	/**
	 * 科目类型(Y:研发科目)
	 */
	public static final String SUBJ_Y = "Y";
	
	/**
	 * 科目类型(N:非研发科目)
	 */
	public static final String SUBJ_N = "N";
	
	/**
	 * 付款方式-供应链
	 */
	public static final String PYMT_M = "M";
	
	/**
	 * 付款方式-非供应链
	 */
	public static final String PYMT_C = "C";
	
	/**
	 * 记账码 29
	 */
	public static final String BSCHL_29 = "29";
	
	/**
	 * 记账码 30
	 */
	public static final String BSCHL_30 = "30";
	
	/**
	 * 记账码 31
	 */
	public static final String BSCHL_31 = "31";

	/**
	 * 记账码 39
	 */
	public static final String BSCHL_39 = "39";
	
	/**
	 * 记账码 40
	 */
	public static final String BSCHL_40 = "40";
	
	/**
	 * 记账码 50
	 */
	public static final String BSCHL_50 = "50";
	
	/**
	 * 凭证类型(AB-会计凭证)
	 */
	public static final String DOCTY_AB = "AB";
	
	/**
	 * 付款条件(T000)
	 */
	public static final String PMNTTRMS_T000 = "T000";
	
	/**
	 * 税码(JO)
	 */
	public static final String TAX_CODE_JO = "JO";
	
	/**
	 * 特别总账标识(X-备用金)
	 */
	public static final String SP_GL_X = "X";
	
	/**
	 * 特别总账标识(O-日常/差旅/总经理项目借款)
	 */
	public static final String SP_GL_O = "O"; 
	
	/**
	 * 特别总账标识(R-住房借款)
	 */
	public static final String SP_GL_R = "R";
	
	/**
	 * 付款原因代码112
	 */
	public static final String RSTGR_112 = "112";
	
	/**
	 * 付款原因代码103
	 */
	public static final String RSTGR_103 = "103";
	
	/**
	 * 付款原因代码119
	 */
	public static final String RSTGR_119 = "119";
	
	/** 未清中的贷方未清项标识 */
	public static final String HKZG = "H";
	
	/**
	 * 未清金额
	 */
	public static final String WQJE = "WQJE";
	
	/**
	 * 在途未清金额
	 */
	public static final String ZTWQJE = "ZTWQJE";
	
	/**
	 * 到期未清金额
	 */
	public static final String DQWQJE = "DQWQJE";
	
	/**
	 * BAPI消息类型: S 成功,E 错误,W 警告,I 信息,A 中断<br/>
	 * 在封装时，S/W当成S处理，其他E
	 */
	public static final String TYPE_S = "S";
	
	/**
	 * BAPI消息类型: S 成功,E 错误,W 警告,I 信息,A 中断<br/>
	 * 在封装时，S/W当成S处理，其他E
	 */
	public static final String TYPE_E = "E";
	
	/**
	 * BAPI消息类型: S 成功,E 错误,W 警告,I 信息,A 中断<br/>
	 * 在封装时，S/W当成S处理，其他E
	 */
	public static final String TYPE_W = "W";
	
	/**
	 * BAPI消息类型: S 成功,E 错误,W 警告,I 信息,A 中断<br/>
	 * 在封装时，S/W当成S处理，其他E
	 */
	public static final String TYPE_I = "I";
	
	/**
	 * BAPI消息类型: S 成功,E 错误,W 警告,I 信息,A 中断<br/>
	 * 在封装时，S/W当成S处理，其他E
	 */
	public static final String TYPE_A = "A";
}
