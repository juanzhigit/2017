package com.hikvision.it.expense.rpc.service.plug;

import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;

/**
 * 核高基费用判断，如果是核高基费用需要到核高基财务专员
 * 
 * 目前无核高基费用，直接到通用财务环节
 * 
 * <p>Title: JudgeHGJServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="judgeHgjService")
public class JudgeHGJServiceImpl implements IExecutePlugService {
	@Override
	public String execute(TaskObject taskObject, String docId) {
		return "TO_F01";
	}
}
