package com.hikvision.it.expense.rpc.service.batch;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.batch.PayDetail;
import com.hikvision.it.expense.api.entity.batch.PayFilter;
import com.hikvision.it.expense.api.entity.batch.PayInfo;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.service.batch.IBatchService;
import com.hikvision.it.expense.rpc.dao.batch.IBatchDao;
import com.hikvision.it.expense.rpc.service.pi.ClearingServiceImpl;

@Service
@Primary
public class BatchServiceImpl implements IBatchService {
	// private Logger logger = LoggerFactory.getLogger(getClass());

	@Autowired
	IBatchDao batchDao;

	@Autowired
	ClearingServiceImpl clearingService;

	/**
	 * 获取他人收款列表
	 */
	@Override
	public List<PayInfo> getPayInfos(String userId, String language, PayFilter filter) {

		List<PayInfo> pays = new ArrayList<PayInfo>();
		Map<String, PayInfo> map = new HashMap<String, PayInfo>();

		List<PayDetail> details = batchDao.getPayDetails(userId, language, filter);
		List<CashierAudit> audtis = clearingService.synchSAPPaymentStatus(getAudits(details));
		updateStatus(details, audtis);
		for (PayDetail detail : details) {
			// 从明细表中获取抬头信息及关键字docId对应的表体信息
			String docId = detail.getDocId();
			PayInfo tmp = map.get(docId);
			if (tmp == null) {
				PayInfo info = new PayInfo();
				info.setApplyId(detail.getApplyId());
				info.setApUserName(detail.getApUserName());
				info.setBukrs(detail.getBukrs());
				info.setBukrsName(detail.getBukrsName());
				info.setDocId(detail.getDocId());
				info.setProcessName(detail.getProcessName());
				info.setExpensorName(detail.getExpensorName());
				info.setTaskId(detail.getTaskId());
				info.setExpensor(detail.getExpensor());
				if (detail.getStatus() != null && detail.getStatus().equalsIgnoreCase("Y")) {
					info.setStatus("Y");
				} else {
					info.setStatus("N");
				}
				info.getDetails().add(detail);
				pays.add(info);
				map.put(docId, info);
			} else {
				tmp.getDetails().add(detail);
				if (detail.getStatus() == null || !detail.getStatus().equalsIgnoreCase("Y")) {
					tmp.setStatus("N");
				}
			}
		}
		return pays;
	}

	// 得到输入参数清单
	private List<CashierAudit> getAudits(List<PayDetail> details) {
		List<CashierAudit> audits = new ArrayList<CashierAudit>();
		for (PayDetail detail : details) {
			try {
				int lineNo = Integer.valueOf(detail.getLineNo());
				detail.setLineNo(String.format("%03d", lineNo)); // 左补0
			} catch (Exception e) {
				e.printStackTrace();
			}
			CashierAudit audit = new CashierAudit();
			audit.setDocId(detail.getDocId());
			audit.setBelnr(detail.getBelnr());
			audit.setLineNo(detail.getLineNo());
			audit.setBukrs(detail.getBukrs());
			audit.setExpensor(detail.getExpensor());
			audit.setGjahr(detail.getGjahr());
			audits.add(audit);
		}
		return audits;
	}

	// 修改状态
	private void updateStatus(List<PayDetail> details, List<CashierAudit> audits) {
		Map<String, CashierAudit> map = new HashMap<String, CashierAudit>();
		for (CashierAudit audit : audits) {
			String key = audit.getBukrs() + audit.getGjahr() + audit.getBelnr() + audit.getLineNo();
			if (map.get(key) == null) {
				map.put(key, audit);
			}
		}
		for (PayDetail detail : details) {
			CashierAudit audit = map
					.get(detail.getBukrs() + detail.getGjahr() + detail.getBelnr() + detail.getLineNo());
			if (audit != null) {
				detail.setStatus(audit.getPayStatus());
			}
		}
	}

}
