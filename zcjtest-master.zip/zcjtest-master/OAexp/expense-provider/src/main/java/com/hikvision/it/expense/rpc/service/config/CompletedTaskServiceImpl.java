package com.hikvision.it.expense.rpc.service.config;

import java.net.URL;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.entity.flow.MailEntity;
import com.hikvision.it.expense.api.entity.flow.OaTodo;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.enums.TaskNameEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.logs.ISendLogDao;
import com.hikvision.it.expense.rpc.dao.task.ITaskDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.util.WebServiceStatus;
import com.hikvision.it.expense.webservice.client.todo.TodoWebServiceBean;
import com.hikvision.it.expense.webservice.client.todo.TodoWebServiceBeanPortType;

/**
 * 任务审批后通用服务执行
 * 
 * 1、非R01、R02环节，结束任务审批待办
 * 2、发送非默认审批意见邮件给报销人
 * 3、撤回、撤销、LOOP的驳回、拒绝环节可能会存在DELETE的待办，需要将DELETE环节的oa待办结束
 * 
 * <p>Title: CompletedTaskServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月24日
 *
 */
@Service(value="completedTaskServiceImpl")
public class CompletedTaskServiceImpl implements IExecuteService {
	@Value("${system.doc.direct}")
	private String docDirect;
	@Value("${system.oa.todo.url}")
	private String url;
	@Autowired
    ISendLogDao logDao;
	@Autowired
    IFormDao formDao;
	@Autowired
    ITaskDao taskDao;
	@Autowired
	TemplateEngine templateEngine;
	
	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		if (!ListUtil.isEmpty(tasks)) {
			//非R01、R02环节，结束任务审批待办
			//撤回、撤销、LOOP的驳回、拒绝环节可能会存在DELETE的待办，需要将DELETE环节的oa待办结束
			this.recordOaTodos(process, tasks);
			//发送非默认审批意见邮件给报销人
			this.recordMails(process, tasks);
		}
	}
	
	/**
	 * 发送非默认审批意见邮件给报销人
	 * @param process
	 * @param tasks
	 */
	private void recordMails(ProcessInstance process, List<TaskInstance> tasks) {
		String toAddress = formDao.getDocCreatorsMailAddress(process.getDocId());
		
		if (!Strings.isNullOrEmpty(toAddress)) {
			List<MailEntity> mails = Lists.newArrayList();
			
			for (TaskInstance task : tasks) {
				MailEntity mail = this.packageMail(process, task);
				
				if (mail != null) {
					//设置邮件接收人
					mail.setReceivors(toAddress);
					mails.add(mail);
				}
			}
			
			if (mails.size() > 0) {
				logDao.batchRecordMailInfo(mails);
			}
		}
	}
	
	/**
	 * 生成邮件实体
	 * @param process
	 * @param taskInstance
	 * @return
	 */
	private MailEntity packageMail(ProcessInstance process, TaskInstance taskInstance) {
		// 判断是否需要发送邮件
		ResultEnum result = ResultEnum.valueOf(taskInstance.getResult());
		
		String suggest = taskInstance.getSuggest();
		boolean needSendMail = false;
		if (ResultEnum.AGREE.equals(result)) {
			// 同意并且输入了审批意见
			if (StringUtil.isNotEmptyTrim(suggest) && 
					!ResultEnum.AGREE.getCode().equalsIgnoreCase(suggest.trim())&& 
					!ResultEnum.AGREE.getDesc().equalsIgnoreCase(suggest.trim())) {
				needSendMail = true;
			}
		} else if (ResultEnum.REFUSE.equals(result)
				|| ResultEnum.REJECT.equals(result)
				|| ResultEnum.RETRACK.equals(result)
				|| ResultEnum.UNDO.equals(result)) {
			// 驳回、撤回、撤销、拒绝
			needSendMail = true;
		}
		// 如需发送邮件
		if (needSendMail) {
			String docId = process.getDocId();
			
			FormHeader header = formDao.getFormHeader(docId);
			// 存在机票信息则将参数设置model中，传给模板引擎进行渲染
			MailEntity mail = new MailEntity();
			// 获取打开单据链接
			String url = docDirect + docId;
			String applyId = header.getDocNo();

			Context model = new Context();
			// 设置查看单据url
			model.setVariable("url", url);
			model.setVariable("applyId", applyId);
			model.setVariable("userName", taskInstance.getCompletedByName());
			model.setVariable("result", result);
			model.setVariable("suggest", suggest);
			// 设置邮件正文
			mail.setContent(this.getMessage(model));
			Object[] args = { applyId };
			// 设置邮件标题
			mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_APPROVED_TEMP, args));
			//设置内外网邮件
			mail.setIsOutMail("N");
			mail.setTaskId(taskInstance.getTaskId());
			mail.setDocId(docId);
			mail.setIsApprove(YesOrNoEnum.N.name());

			return mail;
		}

		return null;
	}

	/**
	 * 将参数设置到模板文件中，并且返回文件内容
	 * @param model
	 * @return
	 */
	protected final String getMessage(Context model) {
		return templateEngine.process("zh/comments", model);
	}
	
	/**
	 * 记录oa待办结束日志
	 * @param process
	 * @param tasks
	 */
	private void recordOaTodos(ProcessInstance process, List<TaskInstance> tasks) {
		String docId = process.getDocId();

		TaskInstance firstTask = tasks.get(0);
		String taskName =firstTask.getTaskName();
		//非R01、R02环节，结束任务审批待办
		List<OaTodo> todos = Lists.newArrayList();
		if (!TaskNameEnum.R01.name().equalsIgnoreCase(taskName) &&
				!TaskNameEnum.R02.name().equalsIgnoreCase(taskName)) {
			this.setOaEndTodoIntoTodoList(tasks, todos, docId);
		}
		//撤回、撤销、LOOP的驳回、拒绝环节可能会存在DELETE的待办，需要将DELETE环节的oa待办结束
		//获取当前回合所有删除的待办
		List<TaskInstance> deletedTasks = taskDao.listDeletedTasks(process.getProcessId());
		if (!ListUtil.isEmpty(deletedTasks)) {//结束删除环节的oa待办
			this.setOaEndTodoIntoTodoList(deletedTasks, todos, docId);
		}
		if (!ListUtil.isEmpty(todos)) {//批量记录oa待办结束日志
			logDao.batchRecordOaTodoInfo(todos);
			//结束待办
			this.sendTodo(todos);
		}
	}

	/**
	 * 实时结束完成待办服务
	 * @param todos
	 */
	private void sendTodo(List<OaTodo> todos) {
		try {
			if (WebServiceStatus.OA_TODO_WEBSERVICE_REACHABLE) {
				TodoWebServiceBean tdService = new TodoWebServiceBean(new URL(url));
				TodoWebServiceBeanPortType serPort = tdService.getTodoWebServiceBeanHttpPort();
				for (OaTodo todo : todos) {
					this.send(todo, serPort);
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	/**
	 * 调用接口结束待办
	 * @param todo
	 * @param serPort
	 */
	private void send(OaTodo todo, TodoWebServiceBeanPortType serPort) {
		//需要发送待办，并且存在待办接收人时发送待办
		boolean success = true;

		try {
			success = serPort.createTodoInfo(todo.getUnid(), // 主键
					todo.getCurdealer(), // 当前处理人
					todo.getServername(), // 服务器名称
					todo.getDbfilepath(), // 数据库路径
					"FM System", // 应用名称
					"SAP报销系统", // 流程名称
					todo.getDocid(), // 流程文档ID
					todo.getStatus(), // 当前状态
					todo.getArrivetime(), // 上一步提交时间
					todo.getPredealer(), // 上一步处理人
					todo.getSubject(), // 文档标题/主题
					todo.getPriority(), // 流程优先级
					todo.getWebdns(), // WEB域名
					todo.getUrl(), // 目标文档地址
					todo.getPriorityType(),// 类型
					todo.getFlowid(),
					todo.getProposer());
		} catch (Exception e) {
			e.printStackTrace();
			success = false;
		} finally {
			if (success) {
				logDao.updateOaTodoSendStatus(todo.getId(), "S");
			} else {
				logDao.updateOaTodoSendStatus(todo.getId(), "E");
			}
		}
	}
	
	/**
	 * 
	 * @param tasks
	 * @param todos
	 * @param docId
	 */
	private void setOaEndTodoIntoTodoList(List<TaskInstance> tasks, List<OaTodo> todos, String docId) {
		for (TaskInstance task : tasks) {
			// 结束oa待办
			OaTodo oaTodo = new OaTodo();

			oaTodo.setUnid(task.getTaskId());
			oaTodo.setCurdealer(null);
			oaTodo.setSubject("结束待办");
			oaTodo.setDocid(docId);
			
			todos.add(oaTodo);
		}
	}
}
