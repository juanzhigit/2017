package com.hikvision.it.expense.rpc.util;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

import com.hikvision.it.expense.common.utils.StringUtil;

public class PIAuthenticator extends Authenticator {
	private String userId;
	private String password;
	
	public PIAuthenticator(String userId, String password) {
		super();
		this.userId = userId;
		this.password = password;
	}

	protected PasswordAuthentication getPasswordAuthentication() {
		return new PasswordAuthentication(StringUtil.decodeStr(userId),
				StringUtil.decodeStr(password).toCharArray());
	}
}
