package com.hikvision.it.expense.rpc.service.config;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.rpc.dao.process.IProcessDao;

/**
 * 事由（包含单据事由和费用事由、备注）替换
 * 
 * 单据到达财务前对事由的敏感词替换，费用事由备注整体替换
 * 单据被财务退回回滚事由
 * 
 * <p>Title: RemarkReplaceServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月24日
 *
 */
@Service(value="remarkReplaceServiceImpl")
public class RemarkReplaceServiceImpl implements IExecuteService {
	@Autowired
	IProcessDao processDao;
	
	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		//获取单据编号
		String docId = process.getDocId();
		Map<String, Object> paramMap = new HashMap<String, Object>();
		paramMap.put("docId", docId);
		processDao.updateApplyRemark(paramMap);
	}
}
