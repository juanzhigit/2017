package com.hikvision.it.expense.rpc.provider.report;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.QueryForm;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.service.report.IReportService;

@Service(version = Version.VERSION_LATEST)
public class ReportProvider implements IReportService {
    @Autowired
    IReportService reportService;

    @Override
    public List<FormHeader> listExpenses(int pageNumber, int pageSize) {
        return reportService.listExpenses(pageNumber, pageSize);
    }

    @Override
    public List<FormHeader> listLoanAndRepayments(int pageNumber, int pageSize) {
        return reportService.listLoanAndRepayments(pageNumber, pageSize);
    }

    @Override
    public List<FormHeader> listTravelApplys(int pageNumber, int pageSize) {
        return reportService.listTravelApplys(pageNumber, pageSize);
    }

    @Override
    public List<FormHeader> listDrafts(int pageNumber, int pageSize) {
        return reportService.listDrafts(pageNumber, pageSize);
    }

    @Override
    public GridData<DocumentInfo> listDraftDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        return reportService.listDraftDoc(form, userId, sidx, sord, page, rows);
    }

    @Override
    public GridData<DocumentInfo> listApplyDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        return reportService.listApplyDoc(form, userId, sidx, sord, page, rows);
    }

    @Override
    public GridData<DocumentInfo> listPublicExpenseDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        return reportService.listPublicExpenseDoc(form, userId, sidx, sord, page, rows);
    }

    @Override
    public GridData<DocumentInfo> listPrivateExpenseDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        return reportService.listPrivateExpenseDoc(form, userId, sidx, sord, page, rows);
    }

    @Override
    public GridData<DocumentInfo> listLoanAndRepayDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        return reportService.listLoanAndRepayDoc(form, userId, sidx, sord, page, rows);
    }

    @Override
    public List<VendorFormHeader> listVendorAdvice(List<String> bukrsList, List<String> expensorList, List<String> lifnrList, List<String> currencyList, List<String> smaFeeList) {
        return reportService.listVendorAdvice(bukrsList, expensorList, lifnrList, currencyList, smaFeeList);
    }

    @Override
    public List<ChartData> getOnlineReimTotal(String userId) {
        return reportService.getOnlineReimTotal(userId);
    }
}
