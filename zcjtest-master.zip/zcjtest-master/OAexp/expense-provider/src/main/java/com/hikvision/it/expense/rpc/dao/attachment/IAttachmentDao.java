package com.hikvision.it.expense.rpc.dao.attachment;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.hikvision.it.expense.api.entity.attachment.Attachment;

public interface IAttachmentDao {

    /**
     * 保存附件
     */
    void saveAttachment(@Param("attachment") Attachment attachment);

    /**
     * 删除附件
     */
    @Update("UPDATE Z_WEM_BUS_ATTACHMENT SET ISDEL = 'Y', MODIFY_DATE = sysdate, MODIFYOR=#{userId} WHERE ATTACHID = #{attachmentId}")
    void deleteAttachment(@Param("attachmentId") String attachmentId, @Param("userId") String userId);

    /**
     * 获取单据附件信息
     */
    List<Attachment> getByDocId(@Param("docId") String docId, @Param("language") String language);

    /**
     * 获取附件信息
     */
    Attachment getOne(@Param("attachmentId") String attachmentId);

    /**
     * 获取附件数量
     */
    @Select("SELECT count(1) FROM Z_WEM_BUS_ATTACHMENT WHERE ISDEL IS NULL AND PROCESSID=#{docId, jdbcType=VARCHAR}")
    Long countAttachment(@Param("docId") String docId);

}
