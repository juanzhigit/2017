package com.hikvision.it.expense.rpc.service.fee;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.OverStandard;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.fee.DeductionInfo;
import com.hikvision.it.expense.api.entity.fee.ExpensedTrafficFee;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.api.service.fee.IFeeService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.fee.IFeeDao;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.service.auth.AuthServiceImpl;
import com.hikvision.it.expense.rpc.util.CalculateUtil;

@Service
@Primary
public class FeeServiceImpl implements IFeeService {

    private BigDecimal num20 = BigDecimal.valueOf(20);

    @Autowired
    IFeeDao feeDao;
    @Autowired
    IUserDao userDao;
    @Autowired
    IBaseDao baseDao;
    @Autowired
    IBaseService baseService;
    @Autowired
    AuthServiceImpl authService;

    @Override
    public FeeDetail checkFeeStatus(FormHeader header, FeeDetail feeDetail) {
        boolean isPermit = authService.checkHasPermission(header.getExpensor(), DocTypeEnum.WEM006.name());

        if (isPermit && feeDetail != null) {
            //判断是否超期
            boolean overDate = this.checkIsOverDate(feeDetail, header);
            //判断是否超标
            boolean overStandrad = this.checkIsOverStandrand(feeDetail, header);
            if (!overDate) {
                feeDetail.setOverDateFlag(YesOrNoEnum.N.name());
            } else {
                feeDetail.setOverDateFlag(YesOrNoEnum.Y.name());
            }
            if (!overStandrad) {
                feeDetail.setOverStandardFlag(YesOrNoEnum.N.name());
                feeDetail.setExcessAmount(BigDecimal.ZERO);
            } else {
                feeDetail.setOverStandardFlag(YesOrNoEnum.Y.name());
            }

            return feeDetail;
        }

        return null;
    }

    @Override
    public List<ExpensedTrafficFee> getExpensedTrafficFees(String userId, String year, String month) {
        return feeDao.getExpensedTrafficFees(userId, year, month);
    }

    @Override
    public GridData<DeductionInfo> getDeductionInfos(String userId, String docId) {
        List<DeductionInfo> deductionInfos = feeDao.getDeductionInfos(userId, docId);
        deductionInfos.sort(Comparator.comparing(DeductionInfo::getSubsidyDate));

        List<DeductionInfo> returnList = Lists.newArrayList();
        for (DeductionInfo item : deductionInfos) {
            item.setYkAmount(num20.multiply(BigDecimal.valueOf(item.getCount())));
            if (item.getYkAmount().compareTo(item.getSubAmount()) > 0) {
                item.setAdjustAmount(item.getYkAmount().subtract(item.getSubAmount()));
                returnList.add(item);
            }
        }
        return new GridData<>(returnList.size(), 1, (long) returnList.size(), returnList);
    }

    @Override
    public void saveDeductionInfos(String docId, List<DeductionInfo> list) {
        if (ListUtil.isEmpty(list)) {
            return;
        }
        String operator = UserContext.getUserId();
        for (DeductionInfo item : list) {
            if  (item.getAdjustAmount() == null || item.getAdjustAmount().compareTo(BigDecimal.ZERO) == 0) {
                continue;
            }
            Rate rate = new Rate();
            rate.setPayCurrency("CNY");
            rate.setCurrency(item.getCurrency());
            rate.setAmount(item.getAdjustAmount());
            rate.setDate(item.getSubsidyDate());
            rate = baseService.getRates(rate);

            item.setExchangeRate(rate.getRate());
            item.setAdjustAmount(item.getAdjustAmount().negate());
            item.setAdjustLocalAmount(rate.getPayAmount().negate());
            item.setType(1);
            item.setRemark("业务招待扣除");
            item.setOperator(operator);
        }
        feeDao.deleteDeductionInfos(docId);
        if (ListUtil.isNotEmpty(list)) {
            feeDao.saveDeductionInfos(list);
        }
    }

    /**
     * 校验是否超标
     *
     * @param feeDetail
     * @param header
     * @return
     */
    private boolean checkIsOverStandrand(FeeDetail feeDetail, FormHeader header) {
        if (userDao.getVpUserIds().contains(header.getExpensor())) { // VP无超期
            return false;
        }
        String feeType = feeDetail.getFeeType();

        switch (feeType) {
            case "CTJT":
                return this.checkLongTrifficOverStandard(feeDetail, header);
            case "YWZD":
                return this.checkAndSetServeOverStandard(feeDetail, header);
            case "STAYS":
                return this.checkAndSetStaysOverStandard(feeDetail, header);
            default:
                break;
        }

        return false;
    }

    /**
     * 校验住宿是否超标
     * <p>
     * 根据住宿地点、住宿天数、房间数、员工级别判断住宿是否超标，并且设置超标金额到费用entity中
     *
     * @param feeDetail
     * @param header
     * @return
     */
    private boolean checkAndSetStaysOverStandard(FeeDetail feeDetail, FormHeader header) {
        String rentType = feeDetail.getRentType();

        //租住无超标
        if (!Strings.isNullOrEmpty(rentType) &&
                YesOrNoEnum.Y.name().equalsIgnoreCase(rentType)) {
            return false;
        }

        String userId = header.getExpensor();
        String rentCity = feeDetail.getRentCity();
        String rentCountry = feeDetail.getRentCountry();
        String userGrade = userDao.getUserGrade(userId);
        int days = feeDetail.getRentDays();
        int rooms = feeDetail.getRentRooms();

        if (Strings.isNullOrEmpty(rentCity))
            return false;
        if (Strings.isNullOrEmpty(rentCountry))
            rentCountry = "CN";
        if (Strings.isNullOrEmpty(userGrade)) {
            userGrade = userDao.getUserGrade(userId);
        }
        if (Strings.isNullOrEmpty(userGrade))
            return true;
        if (days == 0)
            return true;
        if (rooms == 0)
            return true;

        //判断是否分公司员工（分总除外），分公司员工优先判断住宿地是否有办事处，如果有办事处，按照办事处标准执行，否则按照总部标准
        int branceManagerNum = userDao.countBranchManager(userId);
        if (branceManagerNum == 0) {
            int branceEmpNum = userDao.countBranchUser(userId);

            if (branceEmpNum != 0) {
                BigDecimal standAmount = feeDao.matchOfficeStandard(rentCity);

                if (standAmount != null) {
                    //存在特殊城市住宿标准配置，或者属于办事处
                    BigDecimal payAmount = feeDetail.getAmount();
                    //标准限额
                    BigDecimal maxAmount = standAmount.multiply(BigDecimal.valueOf(days)).multiply(BigDecimal.valueOf(rooms));

                    if (maxAmount.compareTo(payAmount) < 0) {
                        feeDetail.setExcessAmount(payAmount.subtract(maxAmount));

                        return true;
                    }
                }
            }
        }
        //分总、总部员工、分公司未维护特殊标准的住宿，按照总部标准执行
        String bukrs = header.getBukrs();
        String placeGrade = null;
        if ("CN".equalsIgnoreCase(rentCountry)) {
            placeGrade = feeDao.getPlaceGradeByCityid(rentCity);
        } else {
            placeGrade = feeDao.getPlaceGradeByCountryId(rentCountry);
        }
        OverStandard stand = feeDao.matchStaysStandard(bukrs, userGrade, placeGrade);

        if (stand != null) {
            String payCurrency = feeDetail.getCurrency();    //消费币别
            String standCurrency = stand.getStandardCurrency();
            BigDecimal exchangeRate = BigDecimal.ONE;
            if (!payCurrency.equalsIgnoreCase(standCurrency)) {
                Rate rate = new Rate();

                rate.setCurrency(payCurrency);
                rate.setPayCurrency(standCurrency);
                rate.setDate(feeDetail.getFeeFromDate());

                rate = baseService.getRates(rate);

                exchangeRate = rate.getRate();
            }
            //计算标准金额
            BigDecimal standAmount = CalculateUtil.setScale(stand.getStandardAmount()
                    .multiply(BigDecimal.valueOf(rooms))
                    .multiply(BigDecimal.valueOf(days)));
            BigDecimal payAmount = CalculateUtil.setScale(feeDetail.getAmount().multiply(exchangeRate));

            if (standAmount.compareTo(payAmount) < 0) {
                feeDetail.setExcessAmount(payAmount.subtract(standAmount));

                return true;
            }

        }
        feeDetail.setExcessAmount(BigDecimal.ZERO);
        return false;
    }

    /**
     * 校验业务招待是否超标
     * <p>
     * 根据招待方式、招待级别、公司、岗位级别、招待人数、次数判断招待是否超标
     *
     * @param feeDetail
     * @param header
     * @return
     */
    private boolean checkAndSetServeOverStandard(FeeDetail feeDetail, FormHeader header) {
        String serveType = feeDetail.getEntertain();
        String serveLevel = feeDetail.getEntertainLevel();
        //获取员工岗位级别
        String postLevel = userDao.getUserPostGrade(header.getExpensor());
        int persons = feeDetail.getPerCounts();
        int days = feeDetail.getDayCounts();

        String bukrs = header.getBukrs();
        if (Strings.isNullOrEmpty(bukrs))
            return false;
        if (Strings.isNullOrEmpty(serveLevel))
            return false;
        if (Strings.isNullOrEmpty(postLevel))
            return false;
        if (persons == 0) {
            feeDetail.setExcessAmount(feeDetail.getLocalAmount());
            return true;
        }
        if (days == 0) {
            feeDetail.setExcessAmount(feeDetail.getLocalAmount());
            return true;
        }

        List<OverStandard> lists = feeDao.listServeStandards(serveType);
        if (!ListUtil.isEmpty(lists)) {
            //先精确匹配
            OverStandard stand = this.matchSupportStandard(lists, serveLevel, postLevel);

            if (stand == null)//模糊匹配人员级别
                stand = this.matchSupportStandard(lists, serveLevel, StringUtil.COMMON_REGEX);

            if (stand == null)//模糊匹配招待级别
                stand = this.matchSupportStandard(lists, StringUtil.COMMON_REGEX, postLevel);

            if (stand == null)//模糊匹配招待级别和岗位级别
                stand = this.matchSupportStandard(lists, StringUtil.COMMON_REGEX, StringUtil.COMMON_REGEX);

            if (stand != null) {
                String payCurrency = feeDetail.getCurrency();    //消费币别
                String standCurrency = stand.getStandardCurrency();
                BigDecimal exchangeRate = BigDecimal.ONE;
                if (!payCurrency.equalsIgnoreCase(standCurrency)) {
                    Rate rate = new Rate();

                    rate.setCurrency(payCurrency);
                    rate.setPayCurrency(standCurrency);
                    rate.setDate(feeDetail.getFeeFromDate());

                    rate = baseService.getRates(rate);

                    exchangeRate = rate.getRate();
                }
                //计算标准金额
                BigDecimal standAmount = CalculateUtil.setScale(stand.getStandardAmount()
                        .multiply(BigDecimal.valueOf(persons))
                        .multiply(BigDecimal.valueOf(days)));
                BigDecimal payAmount = CalculateUtil.setScale(feeDetail.getAmount().multiply(exchangeRate));

                if (standAmount.compareTo(payAmount) < 0) {
                    feeDetail.setExcessAmount(payAmount.subtract(standAmount));

                    return true;
                }
            }
        }
        feeDetail.setExcessAmount(BigDecimal.ZERO);
        return false;
    }

    /**
     * 匹配适用的标准
     *
     * @param lists
     * @param serveLevel
     * @param postLevel
     * @return
     */
    private OverStandard matchSupportStandard(List<OverStandard> lists,
                                              String serveLevel,
                                              String postLevel) {
        for (OverStandard stand : lists) {
            if (serveLevel.equalsIgnoreCase(stand.getServeGrade()) &&
                    postLevel.equalsIgnoreCase(stand.getUserGrade())) {
                return stand;
            }
        }

        return null;
    }

    /**
     * 校验长途交通是否超标
     *
     * @param feeDetail
     * @return
     */
    private boolean checkLongTrifficOverStandard(FeeDetail feeDetail, FormHeader header) {
        String trafficToolLevel = feeDetail.getTrafficToolLevel();

        String overFlag = feeDao.getTrafficToolLevelOverStandardFlag(trafficToolLevel);
        if (YesOrNoEnum.Y.name().equalsIgnoreCase(overFlag)) {
            return true;
        } else {
            return false;
        }
    }

    /**
     * 校验是否超期报销
     *
     * @param feeDetail
     * @param header
     * @return
     */
    private boolean checkIsOverDate(FeeDetail feeDetail, FormHeader header) {
        Date submittedOn = header.getSubmittedOn();
        if (userDao.getVpUserIds().contains(header.getExpensor())) { // VP无超期
            return false;
        }
        if (submittedOn == null) {
            submittedOn = new Date();
        }
        String feeDate = feeDetail.getFeeFromDate();
        if (!Strings.isNullOrEmpty(feeDetail.getFeeToDate())) {
            feeDate = feeDetail.getFeeToDate();
        }

        if (Strings.isNullOrEmpty(feeDate)) {
            return false;
        }

        Date date = DateUtil.stringToDate(feeDate);

        int days = DateUtil.daysBetween(date, submittedOn);

        if (days > 60) {
            return true;
        }

        return false;
    }

    @Override
    public List<ChartData> listUnExpenseFeeDataForChart(String userId) {
        boolean isPermit = authService.checkHasPermission(userId, DocTypeEnum.WEM006.name());

        if (isPermit) {
            //获取语言
            String language = UserContext.getLanguage();
            //返回查询结果
            return feeDao.listUnExpenseFeeDataForChart(userId, language);
        }

        return null;
    }

    @Override
    public List<FeeDetail> listUnExpensedCarSubsidy(String userId) {
        boolean isPermit = authService.checkHasPermission(userId, DocTypeEnum.WEM008.name());

        if (!isPermit) {
            return Lists.newArrayList();
        }
        List<FeeDetail> lists = feeDao.listUnExpensedCarSubsidy(userId);

        if (!ListUtil.isEmpty(lists)) {
            List<FeeDetail> expenseSnjt = feeDao.countExpensedCityTrafficAmount(userId, lists);
            //设置每个月已报销的市内交通汇总
            for (FeeDetail expensedItem : expenseSnjt) {
                String year = expensedItem.getYear();
                String month = expensedItem.getMonth();

                for (FeeDetail allowanceItem : lists) {
                    if (year.equalsIgnoreCase(allowanceItem.getYear()) &&
                            month.equalsIgnoreCase(allowanceItem.getMonth())) {
                        allowanceItem.setExpensedCityTrafficAmount(expensedItem.getExpensedCityTrafficAmount());
                    }
                }
            }
        }
        return lists;
    }

    @Override
    public List<FeeDetail> listUnExpensedBirthInfo(String userId) {
        boolean isPermit = authService.checkHasPermission(userId, DocTypeEnum.WEM008.name());

        if (isPermit) {
            return feeDao.listUnExpensedBirthInfo(userId);
        }

        return Lists.newArrayList();
    }
}
