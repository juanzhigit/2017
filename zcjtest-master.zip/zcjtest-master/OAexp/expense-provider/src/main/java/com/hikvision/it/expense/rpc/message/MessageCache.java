package com.hikvision.it.expense.rpc.message;

import java.util.Locale;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.enums.MessageCode;

public class MessageCache {
	private static String path = "properties/message";

	/**
	 * 根据消息代码、语言获取消息信息
	 * 
	 * @param messageCode
	 * @param language
	 * @param args
	 * @return
	 */
	public static String getMessage(MessageCode messageCode, Object... args) {
		return getMessageResource().getString(messageCode.name(), args);
	}

	/**
	 * 获取messageResource
	 * 
	 * @param language
	 * @return
	 */
	private static MessageResource getMessageResource() {
		MessageResourceFactory resourceFactory = MessageResourceFactory.getInstance();
		
		String language = UserContext.getLanguage();
		Locale locale = null;
		if (Strings.isNullOrEmpty(language)) {
			locale = Locale.CHINESE;
		} else {
			if (language.equalsIgnoreCase("en")) {
				locale = Locale.ENGLISH;
			} else {
				locale = Locale.CHINESE;
			}
		}

		return resourceFactory.createMessageResource(path, locale);
	}
}
