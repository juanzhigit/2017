package com.hikvision.it.expense.rpc.provider.allowance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.service.allowance.ISubsidyService;

@Service(version = Version.VERSION_LATEST)
public class SubsidyProvider implements ISubsidyService {

    @Autowired
    ISubsidyService subsidyService;

    @Override
    public List<Allowance> listAllowance(String docId) {
        return subsidyService.listAllowance(docId);
    }

    @Override
    public List<AllowanceDetail> listAllowanceDetail(String docId) {
        return subsidyService.listAllowanceDetail(docId);
    }

    @Override
    public List<AllowanceDetail> listRentAllowanceDetail(String docId) {
        return subsidyService.listRentAllowanceDetail(docId);
    }
}
