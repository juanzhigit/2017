package com.hikvision.it.expense.rpc.provider.fee;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.service.fee.IFeeItemService;

@Service(version = Version.VERSION_LATEST)
public class FeeItemProvider implements IFeeItemService {

    @Autowired
    IFeeItemService feeItemService;

    @Override
    public List<String> checkItem(FormHeader header, FeeDetail fee) {
        return feeItemService.checkItem(header, fee);
    }

    @Override
    public List<FeeDetail> findAll(String docId, String type) {
        return feeItemService.findAll(docId, type);
    }

    @Override
    public FeeDetail findOne(String id, String type) {
        return feeItemService.findOne(id, type);
    }

    @Override
    public FeeDetail save(FeeDetail fee) {
        return feeItemService.save(fee);
    }

    @Override
    public List<FeeDetail> save(List<FeeDetail> feeList) {
        return feeItemService.save(feeList);
    }

    @Override
    public void delete(String id, String type) {
        feeItemService.delete(id, type);
    }

    @Override
    public FeeDetail update(FeeDetail fee) {
        return feeItemService.update(fee);
    }

    @Override
    public List<FeeDetail> initStaysDetail(String docId, List<FeeDetail> ctjtList) {
        return feeItemService.initStaysDetail(docId, ctjtList);
    }
}
