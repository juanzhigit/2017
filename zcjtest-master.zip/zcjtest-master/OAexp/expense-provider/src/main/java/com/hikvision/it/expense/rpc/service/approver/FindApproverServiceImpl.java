package com.hikvision.it.expense.rpc.service.approver;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.DocParam;
import com.hikvision.it.expense.api.entity.flow.FinalApproveConfig;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.service.execute.ITaskOwnerService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 通用审批人查询逻辑
 * 
 * 1、首先根据（部门、公司）精确匹配，（费用细类、费用大类、单据类别）先精确，然后依次模糊匹配直至查询到审批人
 * 2、重置费用细类、费用大类、单据类别，模糊匹配部门，精确匹配公司,（费用细类、费用大类、单据类别）先精确，然后依次模糊匹配直至查询到审批人
 * 3、重置费用细类、费用大类、单据类别，模糊匹配部门、公司,（费用细类、费用大类、单据类别）先精确，然后依次模糊匹配直至查询到审批人
 * 
 * <p>Title: FindApproverServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="findCommonApprover")
public class FindApproverServiceImpl implements ITaskOwnerService {
	@Autowired
	AgentFilterServiceImpl filterService;
	@Autowired
	IFormDao formDao;
	@Autowired
    IApproverDao approverDao;
	
	@Override
	public List<TaskOwner> execute(TaskObject taskObject, String docId) {
		List<TaskOwner> owners = Lists.newArrayList();
		
		FormHeader header = formDao.getFormHeader(docId);
		//解析费用类别 费用大小类
		DocParam docParam = new DocParam();
		
		docParam.setBukrs(header.getBukrs());
		docParam.setDeptCode(header.getDeptCode());
		docParam.setDocType(header.getDocType());
		docParam.setAmount(header.getAmount() == null ? BigDecimal.ZERO : header.getAmount());
		
		String docType = header.getDocType();
		String language = UserContext.getLanguage();
		String bigFeeType = null;
		String smaFeeType = null;
		FinalApproveConfig expenseDetail = approverDao.getExpenseTypeDetail(header.getExpenseType());
		if (expenseDetail != null) {
			bigFeeType = expenseDetail.getBigFeeType();
			smaFeeType = expenseDetail.getSmaFeeType();
		} else {
			bigFeeType = header.getExpenseType();
			smaFeeType = StringUtil.COMMON_REGEX;
		}
		docParam.setBigFeeType(bigFeeType);
		docParam.setSmaFeeType(smaFeeType);
		//根据部门、公司精确匹配审批人信息
		String taskName = taskObject.getTaskName();
		owners = this.getTaskOwner(taskName, docParam, language);
		
		if (owners == null || owners.size() == 0) {
			//查询参数信息
			this.resetDocParam(bigFeeType, smaFeeType, docType, docParam);
			//通配部门
			docParam.setDeptCode(StringUtil.COMMON_REGEX);
			owners = this.getTaskOwner(taskName, docParam, language);
		}
		if (owners == null || owners.size() == 0) {
			//查询参数信息
			this.resetDocParam(bigFeeType, smaFeeType, docType, docParam);
			//通配公司
			docParam.setBukrs(StringUtil.COMMON_REGEX);
			owners = this.getTaskOwner(taskName, docParam, language);
		}
//		if (owners == null || owners.size() == 0) {
//			//查询参数信息
//			this.resetDocParam(bigFeeType, smaFeeType, docType, docParam);
//			//通配公司
//			docParam.setBukrs(StringUtil.COMMON_REGEX);
//			docParam.setDeptCode(StringUtil.COMMON_REGEX);
//			owners = this.getTaskOwner(taskName, docParam, language);
//		}
		
		if (!ListUtil.isEmpty(owners)) {
			owners = filterService.filterApprovedTaskOwners(owners, taskObject, docId);
		}
		
		return owners;
	}
	
	/**
	 * 重置单据类别参数
	 * @param bigFeeType
	 * @param smaFeeType
	 * @param docType
	 * @param docParam
	 * @return
	 */
	private DocParam resetDocParam(String bigFeeType,
								   String smaFeeType,
								   String docType,
								   DocParam docParam) {
		docParam.setBigFeeType(bigFeeType);
		docParam.setSmaFeeType(smaFeeType);
		docParam.setDocType(docType);
		
		return docParam;
	}
	
	/**
	 * 根据单据信息进行审批人读取
	 * @param taskName
	 * @param docParam
	 * @param language
	 * @return
	 */
	private List<TaskOwner> getTaskOwner(String taskName,
										 DocParam docParam,
										 String language) {
		List<TaskOwner> owners = new ArrayList<TaskOwner>();

		//精确匹配所有维度
		owners = approverDao.getApprovers(taskName, docParam, language);
		if (owners == null || owners.size() == 0) {
			//通配费用细类
			if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(docParam.getSmaFeeType())) {
				docParam.setSmaFeeType(StringUtil.COMMON_REGEX);
				owners = approverDao.getApprovers(taskName, docParam, language);
			}
		}
		if (owners == null || owners.size() == 0) {
			//通配费用大类
			if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(docParam.getBigFeeType())) {
				docParam.setBigFeeType(StringUtil.COMMON_REGEX);
				owners = approverDao.getApprovers(taskName, docParam, language);
			}
		}
		if (owners == null || owners.size() == 0) {
			if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(docParam.getDocType())) {
				//通配单据类别
				docParam.setDocType(StringUtil.COMMON_REGEX);
				owners = approverDao.getApprovers(taskName, docParam, language);
			}
		}
		
		return approverDao.getApprovers(taskName, docParam, language);
	}
}
