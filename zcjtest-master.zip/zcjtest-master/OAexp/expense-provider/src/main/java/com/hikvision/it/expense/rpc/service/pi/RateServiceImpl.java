package com.hikvision.it.expense.rpc.service.pi;

import java.math.BigDecimal;
import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.sql.Date;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.rate.SICONVERTTOLOCALCURRENCYSYNOUT;
import com.hikvision.it.expense.webservice.client.pi.rate.SICONVERTTOLOCALCURRENCYSYNOUTService;
import com.hikvision.it.expense.webservice.client.pi.rate.ZCONVERTTOLOCALCURRENCY;
import com.hikvision.it.expense.webservice.client.pi.rate.ZCONVERTTOLOCALCURRENCYResponse;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;

@Service(value="rateServiceImpl")
public class RateServiceImpl {
	@Value("${system.pi.rate.url}")
	private String url;
	@Value("${system.pi.rate.namespace}")
	private String nameSpace;
	@Value("${system.pi.rate.localpart}")
	private String localPart;
	@Value("${system.pi.user}")
	private String piUser;
	@Value("${system.pi.password}")
	private String piUserPassWord;
	
	/**
	 * 调用接口获取sap平均汇率
	 * @param date
	 * @param amount
	 * @param currency
	 * @param localCurreny
	 * @return
	 */
	public BigDecimal getLocalAmount(Date date, BigDecimal amount,
										  String currency, String localCurreny) {
		if (!Strings.isNullOrEmpty(currency) && 
				!Strings.isNullOrEmpty(localCurreny) &&
				date != null &&
				amount != null && 
				amount.compareTo(BigDecimal.ZERO) != 0) {
			if (!currency.equalsIgnoreCase(localCurreny)) {
				String inputDateStr = DateUtil.dateToString(date, "yyyy-MM-dd");
				//实际调用接口获取sap平均汇率
				return this.getLocalAmount(inputDateStr, amount, currency, localCurreny);
			}
		}
		//默认返回汇率为1
		return BigDecimal.valueOf(1).setScale(2);
	}
	
	/**
	 * 获取sap平均汇率
	 * @param date
	 * @param amount
	 * @param currency
	 * @param localCurreny
	 * @return
	 */
	private BigDecimal getLocalAmount(String date, BigDecimal amount, 
			  						   String currency, String localCurreny) {
		URL wsdlURL = null;
		try {
			wsdlURL = new URL(url);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return null;
		}

		Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
		SICONVERTTOLOCALCURRENCYSYNOUTService ss = new SICONVERTTOLOCALCURRENCYSYNOUTService(wsdlURL, new QName(nameSpace, localPart));
		SICONVERTTOLOCALCURRENCYSYNOUT port = ss.getHTTPPort();

		BindingProvider bp = (BindingProvider) port;
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
		context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

		ZCONVERTTOLOCALCURRENCY params = new ZCONVERTTOLOCALCURRENCY();

		params.setCLIENT("800");
		params.setDATE(date);
		params.setFOREIGNAMOUNT(amount);
		params.setFOREIGNCURRENCY(currency);
		params.setLOCALCURRENCY(localCurreny);

		ZCONVERTTOLOCALCURRENCYResponse response = port.convertTOLOCALCURRENCY(params);

		return response.getLOCALAMOUNT();
	}
}
