package com.hikvision.it.expense.rpc.provider.base;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.service.base.IDictionaryService;

@Service(version = Version.VERSION_LATEST)
public class DictionaryProvider implements IDictionaryService {

    @Autowired
    IDictionaryService dictionaryService;

    @Override
    public String findOne(String dataType, String dataCode) {
        return dictionaryService.findOne(dataType, dataCode, UserContext.getLanguage());
    }

    @Override
    public String findOne(String dataType, String dataCode, String language) {
        return dictionaryService.findOne(dataType, dataCode, language);
    }
}
