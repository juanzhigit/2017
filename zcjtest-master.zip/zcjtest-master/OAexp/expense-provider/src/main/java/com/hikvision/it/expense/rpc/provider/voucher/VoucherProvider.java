package com.hikvision.it.expense.rpc.provider.voucher;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.batch.PayHead;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.entity.voucher.OnlineBsikSummary;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;

@Service(version = Version.VERSION_LATEST)
public class VoucherProvider implements IVoucherService {
    
    @Autowired
    IVoucherService voucherService;

	@Override
    public HikResult<List<Voucher>> previewVoucher(String docId) {
        return voucherService.previewVoucher(docId);
    }

    @Override
    public void previewVoucher(String docId, List<Voucher> vouchers) {
        voucherService.previewVoucher(docId, vouchers);
    }

    @Override
    public HikResult<String> postVoucher(String docId, boolean manual) {
        return voucherService.postVoucher(docId, manual);
    }
    
    @Override
    public HikResult<String> paySure(List<PayHead> heads) {
        return voucherService.paySure(heads);
    }

    @Override
    public HikResult<String> checkPreVoucher(String docId) {
        return voucherService.checkPreVoucher(docId);
    }

	@Override
	public HikResult<Map<String, BigDecimal>> countWqje(List<Bsik> bsiks, BigDecimal ztwqje) {
		return voucherService.countWqje(bsiks, ztwqje);
	}

    @Override
    public boolean checkAllVoucherPosted(String docId) {
        return voucherService.checkAllVoucherPosted(docId);
    }

    @Override
	public OnlineBsikSummary countOnlineReim(String bukrs, String userId) {
		return voucherService.countOnlineReim(bukrs, userId);
	}

    @Override
    public List<CashierAudit> getDocsToPayment(String docNo, String postUser, String bukrs) {
        return voucherService.getDocsToPayment(docNo, postUser, bukrs);
    }
}
