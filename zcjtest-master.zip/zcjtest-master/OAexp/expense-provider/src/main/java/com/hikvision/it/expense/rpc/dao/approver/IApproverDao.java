package com.hikvision.it.expense.rpc.dao.approver;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.base.DocParam;
import com.hikvision.it.expense.api.entity.flow.FinalApproveConfig;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.ApproveAuth;
import com.hikvision.it.expense.api.entity.task.TaskOwner;

/**
 * 审批人查询dao
 * 
 * 	用于查询各环节审批人
 * 
 * <p>Title: IApproverDao.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
public interface IApproverDao {
	/**
	 * 获取流程创建人
	 * @param docId
	 * @param language
	 * @return
	 */
	List<TaskOwner> getDocCreator(@Param("docId") String docId,
								  @Param("language") String language);
	
	/**
	 * 根据单据的费用归属公司、任务名称获取审批人
	 * @param docId
	 * @param taskName
	 * @param language
	 * @return
	 */
	List<TaskOwner> getSpecialApprover(@Param("docId") String docId, 
									   @Param("taskName") String taskName,
									   @Param("language") String language);
	
	/**
	 * 获取单据报销人直接主管
	 * 	如果是金艳总则返回胡总，如果是其他总裁（M5）级别人员，返回金艳总
	 * 	其他人员返回直接主管
	 * @param docId
	 * @param language
	 * @return
	 */
	TaskOwner getDirector(@Param("docId") String docId,
			 			  @Param("language") String language);
	
	/**
	 * 根据授权人, 单据的单据金额、费用归属部门 获取审批授权信息
	 * @param author
	 * @param docId
	 * @param language
	 * @return
	 */
	List<ApproveAuth> getApproverAuth(@Param("author") String author,
									  @Param("docId") String docId,
									  @Param("language") String language);
	
	/**
	 * 过滤已审批过的人员
	 * @param docId
	 * @param owners
	 * @return
	 */
	List<TaskOwner> filterApprovedOwners(@Param("docId") String docId,
										 @Param("owners") List<TaskOwner> owners);

	/**
	 * 匹配适用终审审批级别
	 * @param formHeader
	 * @return
	 */
	List<FinalApproveConfig> matchFinalApproveConfig(@Param("formHeader") FormHeader formHeader);
	
	/**
	 * 根据费用类别获取，费用大小类明细
	 * @param expenseType
	 * @return
	 */
	FinalApproveConfig getExpenseTypeDetail(@Param("expenseType") String expenseType);
	
	/**
	 * 获取当前单据审批的直接主管级别
	 * 
	 * 如果不属于授权审批，直接返回审批人的级别
	 * 如果当前审批人属于授权审批，则比较背授权人与授权人的级别，返回较大的级别
	 * 如果当前环节属于转发转接，则获取原始直接主管环节的审批人级别，获取逻辑同上
	 * 		
	 * @param docId
	 * @return
	 */
	int getDirectorGradeLevel(@Param("docId") String docId);
	
	/**
	 * 根据任务名称、流程参数 获取审批人
	 * @param taskName
	 * @param docParam
	 * @param language
	 * @return
	 */
	List<TaskOwner> getApprovers(@Param("taskName") String taskName, 
								 @Param("docParam") DocParam docParam,
								 @Param("language") String language);
	
	/**
	 * 查询分总信息
	 * @param deptCode
	 * @param language
	 * @return
	 */
	TaskOwner getSubCompManager(@Param("deptCode") String deptCode,
								@Param("language") String language);
	
	/**
	 * 获取第一个匹配到的终审主管
	 * @param userId
	 * @param grade
	 * @param language
	 * @return
	 */
	TaskOwner getFirstMatchDirector(@Param("userId") String userId,
									@Param("grade") int grade,
									@Param("language") String language);
	
	/**
	 * 获取vp财务审核人员任务数列表
	 * @param language
	 * @return
	 */
	List<TaskOwner> getVPFinancialApprovers(@Param("language") String language);
	
	/**
	 * 获取借款财务审核人员任务数列表
	 * @param language
	 * @return
	 */
	List<TaskOwner> getLoanFinancialApprovers(@Param("language") String language);
	
	/**
	 * 从会计池中获取当前任务数最少的会计
	 * @param language
	 * @return
	 */
	TaskOwner findAccountingWithLeastTasks(@Param("language") String language);
}
