package com.hikvision.it.expense.rpc.service.approver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.execute.ITaskOwnerService;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;

/**
 * 获取单据报销人直接主管审批人list
 * 
 * 	1、如果是金艳总则返回胡总，如果是其他总裁（M5）级别人员，返回金艳总
 * 	2、其他人员返回直接主管
 *  3、根据主管授权列表，进行授权过滤当前单据适用的授权人
 *  4、过滤已审批的可授权审批人列表
 *  
 * <p>Title: FindDirectorServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
@Service(value="findDirector")
public class FindDirectorServiceImpl implements ITaskOwnerService {
	@Autowired
    IApproverDao approverDao;
	@Autowired
	AgentFilterServiceImpl agentService;
	
	@Override
	public List<TaskOwner> execute(TaskObject taskObject, String docId) {
		TaskOwner director = approverDao.getDirector(docId, UserContext.getLanguage());
		
		if (director == null)//未获取到直接主管抛出异常
			throw new ExpenseException(ExceptionCode.USER_DIRECTOR_NOT_FOUND);
		//返回获取到的被授权人列表
		return agentService.filterAgentApprover(taskObject, director, docId);
	}
}
