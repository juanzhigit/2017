package com.hikvision.it.expense.rpc.provider.batch;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.batch.PayFilter;
import com.hikvision.it.expense.api.entity.batch.PayInfo;
import com.hikvision.it.expense.api.service.batch.IBatchService;

@Service(version= Version.VERSION_LATEST)
public class BatchProvider implements IBatchService {

    @Autowired
	IBatchService batchService;

	/**
	 * 获取他人收款列表
	 */
	@Override
	public List<PayInfo> getPayInfos(String userId, String language, PayFilter filter) {
		return batchService.getPayInfos(userId, language, filter);
	}
}
