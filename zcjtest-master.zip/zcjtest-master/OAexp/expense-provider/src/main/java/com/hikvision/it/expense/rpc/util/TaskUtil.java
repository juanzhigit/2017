package com.hikvision.it.expense.rpc.util;

import java.util.ArrayList;
import java.util.List;

import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.enums.DeviceEnum;
import com.hikvision.it.expense.api.enums.NodeTypeEnum;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.enums.TaskNameEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.common.utils.StringUtil;

public class TaskUtil {
	/**
	 * 生成加签环节实例
	 * @param process
	 * @param taskObject
	 * @param owners
	 * @return
	 * @throws CloneNotSupportedException 
	 */
	public static final List<TaskInstance> genAddStepTaskInstance(ProcessInstance process,
											  TaskObject taskObject, 
									  		  List<TaskOwner> owners,
									  		  String refTaskId) throws ExpenseException {
		List<TaskInstance> tasks = new ArrayList<TaskInstance>();
		String groupId = StringUtil.getUUID();
		TaskInstance task = genCommonTaskInstance(process, taskObject);

		StringBuffer operatorBuf = new StringBuffer();
		for (TaskOwner owner : owners) {
			String taskId = StringUtil.getUUID();
			
			TaskInstance curTask;
			try {
				curTask = task.clone();
			} catch (CloneNotSupportedException e) {
				throw new ExpenseException(ExceptionCode.POJO_CLONE_ERROR);
			} 
			
			curTask.setTaskName(TaskNameEnum.A02.name());
			curTask.setTaskId(taskId);
			curTask.setGroupId(groupId);
			curTask.setNodeType(NodeTypeEnum.LOOP.name());
			curTask.setRefTaskId(refTaskId);
			//任务所有人与任务进行关联
			owner.setTaskId(taskId);
			//设置任务所有人
			List<TaskOwner> curOwners = new ArrayList<TaskOwner>();
			curOwners.add(owner);

			if (operatorBuf.length() > 0) {
				operatorBuf.append(",");
			}
			operatorBuf.append(owner.getOwnerName());
			curTask.setOwners(curOwners);
			
			tasks.add(curTask);
		}
		
		process.setOperators(operatorBuf.toString());
		
		return tasks;
	}
	
	/**
	 * 生成任务实例
	 * @param process
	 * @param taskObject
	 * @param nodeType
	 * @param owners
	 */
	public static final TaskInstance packageManuTaskAndProcessOperator(
			ProcessInstance process, TaskObject taskObject,
			List<TaskOwner> owners) {
		TaskInstance task = genCommonTaskInstance(process, taskObject);
		
		String taskId = StringUtil.getUUID();
		task.setTaskId(taskId);
		task.setGroupId(StringUtil.getUUID());
		task.setNodeType(NodeTypeEnum.MANU.name());
		
		StringBuffer operatorBuf = new StringBuffer();
		if (owners != null) {
			for (TaskOwner owner : owners) {
				owner.setTaskId(taskId);
				if (operatorBuf.length() > 0) {
					operatorBuf.append(",");
				}
				operatorBuf.append(owner.getOwnerName());
			}
		}
		//设置流程当前处理人信息
		process.setOperators(operatorBuf.toString());
		task.setOwners(owners);
		operatorBuf.setLength(0);

		return task;
	}
	
	/**
	 * 生成通用任务实例
	 * @param process
	 * @param taskObject
	 */
	private static TaskInstance genCommonTaskInstance(ProcessInstance process,
													  TaskObject taskObject) {
		TaskInstance task = new TaskInstance();
		
		task.setProcessId(process.getProcessId());
		task.setTaskName(taskObject.getTaskName());
		task.setNodeType(taskObject.getNodeType());
		task.setVersionRd(process.getVersionRd());
		Long millisecond = System.currentTimeMillis();
		task.setCrTime(millisecond);
		task.setUpTime(millisecond);
		
		return task;
	}
	
	/**
	 * 创建开始环节
	 * @param process
	 * @param taskObject
	 * @return
	 */
	public static final TaskInstance genStartTaskInstance(ProcessInstance process) {
		TaskInstance task = new TaskInstance();

		task.setProcessId(process.getProcessId());
		task.setTaskName(TaskNameEnum.START.name());
		task.setTaskId(StringUtil.getUUID());
		task.setVersionRd(process.getVersionRd());
		task.setNodeType(NodeTypeEnum.AUTO.name());
		task.setCompletedBy(process.getCreatedBy());
		task.setCompletedByName(process.getCreatedByName());
		task.setResult(ResultEnum.SUBMIT.name());
		task.setDevice(DeviceEnum.PC.name());
		task.setGroupId(StringUtil.getUUID());
		Long millisecond = System.currentTimeMillis();
		task.setCrTime(millisecond);
		task.setCmTime(millisecond);
		task.setUpTime(millisecond);
		
		return task;
	}
	
	public static final TaskInstance genAutoTaskInstance(ProcessInstance process, 
													 	 TaskObject taskObject) {
		TaskInstance task = genCommonTaskInstance(process, taskObject);
		
		task.setTaskId(StringUtil.getUUID());
		task.setNodeType(NodeTypeEnum.AUTO.name());
		task.setDevice(DeviceEnum.SYSTEM.name());
		task.setGroupId(StringUtil.getUUID());
		task.setCmTime(task.getCrTime());
		
		return task;
	}
}
