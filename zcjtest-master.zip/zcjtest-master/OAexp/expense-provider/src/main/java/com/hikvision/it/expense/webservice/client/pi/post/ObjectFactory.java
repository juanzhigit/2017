
package com.hikvision.it.expense.webservice.client.pi.post;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hikvision.it.expense.pi.webservice.client.post package.
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hikvision.it.expense.pi.webservice.client.post
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ZZFI0409 }
     * 
     */
    public ZZFI0409 createZZFI0409() {
        return new ZZFI0409();
    }

    /**
     * Create an instance of {@link ZZFI0409Response }
     * 
     */
    public ZZFI0409Response createZZFI0409Response() {
        return new ZZFI0409Response();
    }

    /**
     * Create an instance of {@link ZZFI0409Response.RETURNDATA }
     * 
     */
    public ZZFI0409Response.RETURNDATA createZZFI0409ResponseRETURNDATA() {
        return new ZZFI0409Response.RETURNDATA();
    }

    /**
     * Create an instance of {@link ZZFI0409 .ITHEADER }
     * 
     */
    public ZZFI0409 .ITHEADER createZZFI0409ITHEADER() {
        return new ZZFI0409 .ITHEADER();
    }

    /**
     * Create an instance of {@link ZZFI0409 .ITITEM }
     * 
     */
    public ZZFI0409 .ITITEM createZZFI0409ITITEM() {
        return new ZZFI0409 .ITITEM();
    }

    /**
     * Create an instance of {@link ZZFI0409HEADERS }
     * 
     */
    public ZZFI0409HEADERS createZZFI0409HEADERS() {
        return new ZZFI0409HEADERS();
    }

    /**
     * Create an instance of {@link ZZFI0409ITEMS }
     * 
     */
    public ZZFI0409ITEMS createZZFI0409ITEMS() {
        return new ZZFI0409ITEMS();
    }

    /**
     * Create an instance of {@link ZZFI0409Response.RETURNDATA.ITHEADER }
     * 
     */
    public ZZFI0409Response.RETURNDATA.ITHEADER createZZFI0409ResponseRETURNDATAITHEADER() {
        return new ZZFI0409Response.RETURNDATA.ITHEADER();
    }

    /**
     * Create an instance of {@link ZZFI0409Response.RETURNDATA.ITITEM }
     * 
     */
    public ZZFI0409Response.RETURNDATA.ITITEM createZZFI0409ResponseRETURNDATAITITEM() {
        return new ZZFI0409Response.RETURNDATA.ITITEM();
    }

}
