package com.hikvision.it.expense.rpc.service.fee;

import java.util.Date;
import java.util.List;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.fee.IFeeItemService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.fee.IFeeDao;
import com.hikvision.it.expense.rpc.dao.fee.IFeeItemDao;
import com.hikvision.it.expense.rpc.entity.check.CheckOption;
import com.hikvision.it.expense.rpc.service.form.FormCheckServiceImpl;

@Service
public class FeeItemServiceImpl implements IFeeItemService {

    @Autowired
    IFeeItemDao feeItemDao;

    @Autowired
    IFeeDao feeDao;

    @Autowired
    FormCheckServiceImpl formCheckService;

    @Override
    public List<String> checkItem(FormHeader header, FeeDetail fee) {
        List<String> errorList = Lists.newArrayList();
        CheckOption checkOpt = formCheckService.packageCheckOption(header, true);
        if ("SNJT".equals(fee.getFeeType())) {
            formCheckService.checkSNJTDetail(checkOpt, Lists.newArrayList(fee), errorList);
        } else if ("YWZD".equals(fee.getFeeType())) {
            formCheckService.checkYWZDDetail(checkOpt, Lists.newArrayList(fee), errorList);
        } else if ("OTHER".equals(fee.getFeeType())) {
            formCheckService.checkOtherDetail(checkOpt, Lists.newArrayList(fee), errorList);
        } else {
            throw new ExpenseException("unknown fee type [" + fee.getFeeType() + "]");
        }
        return errorList;
    }

    @Override
    public List<FeeDetail> findAll(String docId, String type) {
        List<FeeDetail> list = Lists.newArrayList();
        if ("ofees".equals(type)) {
            list = feeItemDao.findOfeesAll(docId, UserContext.getLanguage());
        } else if ("stays".equals(type)) {
            list = feeItemDao.findStaysAll(docId, UserContext.getLanguage());
        }
        return list;
    }

    @Override
    public FeeDetail findOne(String id, String type) {
        if ("ofees".equals(type)) {
            return feeItemDao.findOfeesOne(id, UserContext.getLanguage());
        } else if ("stays".equals(type)) {
            return feeItemDao.findStaysOne(id, UserContext.getLanguage());
        } else {
            return null;
        }
    }

    @Override
    public FeeDetail save(FeeDetail fee) {

        if (Strings.isNullOrEmpty(fee.getId())) {
            fee.setId(StringUtil.getUUID());
        }
        if ("CTJT".equals(fee.getFeeType())) {
            feeItemDao.insertCTJT(fee);
        } else if ("STAYS".equals(fee.getFeeType())) {
            feeItemDao.insertSTAYS(fee);
        } else if ("SNJT".equals(fee.getFeeType())) {
            feeItemDao.insertSNJT(fee);
        } else if ("YWZD".equals(fee.getFeeType())) {
            feeItemDao.insertYWZD(fee);
        } else if ("OTHER".equals(fee.getFeeType())) {
            feeItemDao.insertOTHER(fee);
        } else {
            throw new ExpenseException("unknown fee type [" + fee.getFeeType() + "]");
        }
        return fee;
    }

    @Override
    public List<FeeDetail> save(List<FeeDetail> feeList) {
        List<FeeDetail> list = Lists.newArrayList();
        for (FeeDetail fee : feeList) {
            list.add(save(fee));
        }
        return list;
    }

    @Override
    public void delete(String id, String type) {
        delete(id, type, true);
    }

    private void delete(String id, String type, boolean updateSeqNo) {
        if ("ofees".equals(type)) {
            feeItemDao.deleteOfees(id);
        } else if ("stays".equals(type)) {
            if (updateSeqNo) {
                FeeDetail detail = feeItemDao.findStaysOne(id, "ZH");
                if (detail != null) {
                    feeItemDao.updateStaysSeqNo(detail.getRn(), -1, detail.getFeeType());
                }
            }
            feeItemDao.deleteStays(id);
        }
    }

    @Override
    public FeeDetail update(FeeDetail fee) {
        String tableType;
        if ("SNJT".equals(fee.getFeeType()) || "YWZD".equals(fee.getFeeType()) || "OTHER".equals(fee.getFeeType())) {
            tableType = "ofees";
        } else {
            tableType = "stays";
        }
        delete(fee.getId(), tableType, false);
        return save(fee);
    }

    @Override
    public List<FeeDetail> initStaysDetail(String docId, List<FeeDetail> ctjtList) {
        List<FeeDetail> staysList = Lists.newArrayList();
        String date = null;
        int rn = 1;
        for (int i = 0; i < ctjtList.size(); i++) {
            FeeDetail detail = ctjtList.get(i);
            if (i == 0) {
                date = detail.getFeeToDate();
                continue;
            }
            if (!Objects.equals(date, detail.getFeeFromDate())) {
                FeeDetail staysDetail = new FeeDetail();
                staysDetail.setFeeType("STAYS");
                staysDetail.setRn(rn++);
                staysDetail.setDocId(docId);
                staysDetail.setId(StringUtil.getUUID());
                staysDetail.setRentType("N");
                staysDetail.setFeeFromDate(date);
                staysDetail.setFeeToDate(detail.getFeeFromDate());
                staysDetail.setCurrency(detail.getCurrency());
                staysDetail.setCurrencyDesc(detail.getCurrencyDesc());

                Date early = DateUtil.stringToDate(detail.getFeeFromDate());
                Date late = DateUtil.stringToDate(detail.getFeeToDate());
                staysDetail.setRentDays(DateUtil.daysBetween(early, late));
                staysDetail.setRentCity(detail.getPlaceFrom());
                staysDetail.setRentCityDesc(detail.getPlaceFromDesc());
                staysDetail.setRentCountry(detail.getCountryFrom());
                staysList.add(staysDetail);

                date = detail.getFeeToDate();
            }
        }
        feeItemDao.batchDeleteStays(docId);
        return this.save(staysList);
    }
}
