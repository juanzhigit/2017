package com.hikvision.it.expense.rpc.dao.auth;


import org.apache.ibatis.annotations.Param;

/**
 * 授权dao
 * <p>Title: IAuthDao.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月26日
 *
 */
public interface IAuthDao {
	/**
	 * 获取授权数量
	 * @param userId			被授权人
	 * @param autherUserId		授权人
	 * @param docType			报销单据类别
	 * @return
	 */
	int countAuthNumber(@Param("userId") String userId, @Param("autherUserId") String autherUserId, @Param("docType") String docType);
}
