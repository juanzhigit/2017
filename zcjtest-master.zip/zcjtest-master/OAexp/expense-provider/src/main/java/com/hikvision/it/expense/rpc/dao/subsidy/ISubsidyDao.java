package com.hikvision.it.expense.rpc.dao.subsidy;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.allowance.SubsidyInfo;
import com.hikvision.it.expense.api.entity.allowance.WPOrSXInfo;
import com.hikvision.it.expense.api.entity.base.District;
import com.hikvision.it.expense.api.entity.trip.TripLine;

public interface ISubsidyDao {
	/**
	 * 根据公司代码获取补贴范围内所有有效的租住补贴标准
	 * @param subsidyType
	 * @param bukrs
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	List<SubsidyInfo> listSubsidyStandard(@Param("subsidyType") String subsidyType, 
										  @Param("bukrs") String bukrs, 
										  @Param("fromDate") String fromDate, 
										  @Param("toDate") String toDate);
	
	/**
	 * 根据公司代码、差旅城市获取去过城市是否有需要发放艰苦补贴的城市
	 * @param bukrs
	 * @param tripLines
	 * @return
	 */
	List<SubsidyInfo> listHardSubsidyStandard(@Param("bukrs") String bukrs, 
											  @Param("tripLines") List<TripLine> tripLines);
	
	/**
	 * 根据公司代码、差旅城市获取去过城市的伙食补贴标准
	 * @param bukrs
	 * @param fromDate
	 * @param toDate
	 * @param tripLines
	 * @return
	 */
	List<SubsidyInfo> listFoodSubsidyStandard(@Param("bukrs") String bukrs, 
											  @Param("fromDate") String fromDate, 
											  @Param("toDate") String toDate, 
											  @Param("tripLines") List<TripLine> tripLines);
	
	
	
	/**
	 * 获取员工补贴范围内已发放的补贴明细(需剔除当前单据)
	 * @param userId
	 * @param docId
	 * @param subsidyType
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	List<AllowanceDetail> listPaidSubsidy(@Param("userId") String userId,
											@Param("docId") String docId,
											@Param("subsidyType") String subsidyType,
											@Param("fromDate") String fromDate, 
											@Param("toDate") String toDate);
	
	/**
	 * 获取员工补贴范围内的外派信息
	 * @param userId
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	List<WPOrSXInfo> listWPInfo(@Param("userId") String userId,
								@Param("fromDate") String fromDate, 
								@Param("toDate") String toDate);
	
	/**
	 * 获取员工补贴范围内的实习信息
	 * @param userId
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	List<WPOrSXInfo> listSXInfo(@Param("userId") String userId,
								@Param("fromDate") String fromDate, 
								@Param("toDate") String toDate);
	
	/**
	 * 根据公司获取周末调休信息
	 * @param bukrs
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	List<Date> listOffWeekend(@Param("bukrs") String bukrs,
							  @Param("fromDate") String fromDate,
							  @Param("toDate") String toDate);
	
	/**
	 * 统计补贴发放次数
	 * @param userId
	 * @param subsidyType
	 * @param subsidyDate
	 * @param dateType
	 * @return
	 */
	int countSubsidyPaidTimes(@Param("userId") String userId, 
							  @Param("subsidyType") String subsidyType, 
							  @Param("subsidyDate") String subsidyDate, 
							  @Param("dateType") String dateType);
	
	/**
	 * 批量保存补贴汇总信息
	 * @param allowances
	 * @return
	 */
	int batchInsertAllowance(@Param("allowances") List<Allowance> allowances);
	
	/**
	 * 删除补贴信息
	 * @param docId
	 * @return
	 */
	int deleteAllowance(@Param("docId") String docId);
	
	/**
	 * 删除补贴明细
	 * @param docId
	 * @return
	 */
	int deleteAllowanceDetail(@Param("docId") String docId, @Param("isRentAllowanceDetail") boolean isRentAllowanceDetail);
	
	/**
	 * 批量新增补贴明细信息
	 * @param allowanceDetails
	 * @return
	 */
	int batchInsertAllowanceDetail(@Param("allowanceDetails") List<AllowanceDetail> allowanceDetails, @Param("flag") String flag);

	/**
	 * 获取补贴汇总信息
	 */
	List<Allowance> listAllowance(@Param("docId") String docId);

	/**
	 * 获取补贴明细(除租住补贴)
	 */
	List<AllowanceDetail> listAllowanceDetail(@Param("docId") String docId);
	/**
	 * 获取补贴明细(租住补贴)
	 */
	List<AllowanceDetail> listRentAllowanceDetail(@Param("docId") String docId);

    /**
     * 根据城市id获取区域等级
     * @param cityIds
     * @return
     */
	List<District> listDistrictLevel(@Param("items") List<String> cityIds);

    void adjustAllowance(Allowance allowance);

    /**
     * 统计单据报销金额
     */
    @Select("select nvl(sum(food_paid + hard + weekend_paid + am_paid + pm_paid + line_paid + rent_paid), 0) from t_form_exp_subsidy where docid = #{docId}")
    BigDecimal sumSubsidyAmount(@Param("docId") String docId);

}
