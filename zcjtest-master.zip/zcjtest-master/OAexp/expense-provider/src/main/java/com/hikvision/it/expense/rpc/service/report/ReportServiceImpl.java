package com.hikvision.it.expense.rpc.service.report;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.QueryForm;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.service.report.IReportService;
import com.hikvision.it.expense.rpc.dao.report.IReportDao;
import com.hikvision.it.expense.rpc.util.PageConverter;

@Service
public class ReportServiceImpl implements IReportService {
    @Autowired
    IReportDao reportDao;

    @Override
    public List<FormHeader> listExpenses(int pageNumber, int pageSize) {
        return reportDao.listExpenses(UserContext.getUserId(), pageNumber, pageSize);
    }

    @Override
    public List<FormHeader> listLoanAndRepayments(int pageNumber, int pageSize) {
        return reportDao.listLoanAndRepayments(UserContext.getUserId(), pageNumber, pageSize);
    }

    @Override
    public List<FormHeader> listTravelApplys(int pageNumber, int pageSize) {
        return reportDao.listTravelApplys(UserContext.getUserId(), pageNumber, pageSize);
    }

    @Override
    public List<FormHeader> listDrafts(int pageNumber, int pageSize) {
        return reportDao.listDrafts(UserContext.getUserId(), pageNumber, pageSize);
    }

    @Override
    public GridData<DocumentInfo> listDraftDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        PageHelper.startPage(page, rows, true);
        Page<DocumentInfo> info = reportDao.listDraftDoc(form, userId);
        return PageConverter.convert(info);
    }

    /**
     * 转换日期查询条件
     *
     * @param form
     */

    @Override
    public GridData<DocumentInfo> listApplyDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        PageHelper.startPage(page, rows, true);
        tranDateParam(form);
        Page<DocumentInfo> info = reportDao.listApplyDoc(form, userId);
        return PageConverter.convert(info);

    }

    @Override
    public GridData<DocumentInfo> listPublicExpenseDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        PageHelper.startPage(page, rows, true);
        tranDateParam(form);
        Page<DocumentInfo> info = reportDao.listPublicExpenseDoc(form, userId);
        return PageConverter.convert(info);
    }

    @Override
    public GridData<DocumentInfo> listPrivateExpenseDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        PageHelper.startPage(page, rows, true);
        tranDateParam(form);
        Page<DocumentInfo> info = reportDao.listPrivateExpenseDoc(form, userId);
        return PageConverter.convert(info);
    }

    @Override
    public GridData<DocumentInfo> listLoanAndRepayDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows) {
        PageHelper.startPage(page, rows, true);
        tranDateParam(form);
        Page<DocumentInfo> info = reportDao.listLoanAndRepayDoc(form, userId);
        return PageConverter.convert(info);
    }

    /**
     * 转换日期查询条件
     *
     * @param form
     */
    private void tranDateParam(QueryForm form) {
        if (form.getDocStatus() != null && form.getDocStatus().contains("S000")) {
            List<String> docStatus = form.getDocStatus();
            docStatus.add("S002");
            docStatus.add("S003");
            docStatus.add("S005");
            docStatus.add("S006");
        }
    }

    @Override
    public List<VendorFormHeader> listVendorAdvice(List<String> bukrsList, List<String> expensorList, List<String> lifnrList, List<String> currencyList, List<String> smaFeeList) {
        //-TODO 判断权限
        return reportDao.listVendorAdvice(null,bukrsList, expensorList, lifnrList, currencyList, smaFeeList);
    }

    @Override
    public List<ChartData> getOnlineReimTotal(String userId) {
        return reportDao.getOnlineReimTotal(userId);
    }
}
