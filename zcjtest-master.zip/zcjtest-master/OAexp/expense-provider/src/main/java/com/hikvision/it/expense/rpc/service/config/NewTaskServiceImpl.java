package com.hikvision.it.expense.rpc.service.config;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.entity.flow.MailEntity;
import com.hikvision.it.expense.api.entity.flow.OaTodo;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.NodeTypeEnum;
import com.hikvision.it.expense.api.enums.TaskNameEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.logs.ISendLogDao;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.message.MessageCache;

/**
 * 创建新任务后执行审批前配置服务
 * 
 * 1、开始环节，需要将报销人当前信用等级更新到单据中
 * 2、发送审批待办
 * 3、发送审批邮件
 * 
 * <p>Title: NewTaskServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月24日
 *
 */
@Service(value="newTaskServiceImpl")
public class NewTaskServiceImpl implements IExecuteService {
	@Value("${system.task.direct}")
	private String taskDirect;
	@Autowired
	IUserDao userDao;
	@Autowired
    IFormDao formDao;
	@Autowired
    ISendLogDao logDao;
	@Autowired
	TemplateEngine templateEngine;
	
	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		FormHeader header = formDao.getFormHeader(process.getDocId());
		
		if (!ListUtil.isEmpty(tasks)) {
			TaskInstance task = tasks.get(0);
			//更新员工当前信用等级到单据中
			this.setUserCreditToDoc(header, task);
			//审批待办和邮件
			this.recordTodoAndMail(header, tasks);
		}
	}
	
	/**
	 * 记录待办和邮件日志信息
	 * @param header
	 * @param tasks
	 */
	private void recordTodoAndMail(FormHeader header, List<TaskInstance> tasks) {
		if (!ListUtil.isEmpty(tasks)) {
			for (TaskInstance task : tasks) {
				String nodeType = task.getNodeType();
				
				if (!NodeTypeEnum.AUTO.name().equalsIgnoreCase(nodeType)) {
					List<OaTodo> todos = Lists.newArrayList();
					List<MailEntity> mails = Lists.newArrayList();
					//记录审批oa待办
					this.packageTodo(header, task, todos);
					//记录审批邮件
					this.packageMail(header, task, mails);
					
					if (!ListUtil.isEmpty(todos)) {
						logDao.batchRecordOaTodoInfo(todos);
					}
					if (!ListUtil.isEmpty(mails)) {
						logDao.batchRecordMailInfo(mails);
					}
				}
			}
		}
	}
	
	/**
	 * 记录审批待办
	 * @param header
	 * @param task
	 * @param todos
	 */
	private void packageTodo(FormHeader header, TaskInstance task, List<OaTodo> todos) {
		List<TaskOwner> owners = task.getOwners();
		
		if (ListUtil.isEmpty(owners)) 
			return;
		// 拼接待办信息
		// 报销人姓名、流程名称、报销单号、金额
		String docType = header.getDocType();
		String title = null;
		if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM002.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM003.name().equalsIgnoreCase(docType))  {
			//差旅申请、行程变更、借款单标题不设置金额
			Object[] args = { header.getExpensorName(), header.getDocTypeName(), header.getDocNo() };
			//设置邮件标题
			title = MessageCache.getMessage(MessageCode.TITLE_TODO_NO_MONEY_TEMP, args);
		} else {
			//其他单据设置金额
			Object[] args = { header.getExpensorName(), header.getDocTypeName(), header.getDocNo(), header.getAmount() };
			//设置邮件标题
			title = MessageCache.getMessage(MessageCode.TITLE_TODO_TEMP, args);
		}

		OaTodo todo = new OaTodo();

		todo.setFlowname("SAP报销系统"); 			// 流程名称
		todo.setStatus(task.getTaskName()); 	// 单据状态
		todo.setPriorityType("5");
		todo.setSubject(title);
		todo.setArrivetime(DateUtil.getCurrentDateTime());
		todo.setDocid(header.getDocId());
		todo.setUnid(task.getTaskId());
		// 拼接待办URL
		todo.setUrl(taskDirect + task.getTaskId());
		StringBuilder sb = new StringBuilder();
		for (TaskOwner owner : owners) {
			sb.append(owner.getOwnerName()).append(",");
		}
		todo.setCurdealer(sb.toString());
		todo.setIsApprove(YesOrNoEnum.Y.name());
		
		todos.add(todo);
	}
	
	/**
	 * 记录审批邮件
	 * @param header
	 * @param task
	 * @param mails
	 */
	private void packageMail(FormHeader header, TaskInstance task, List<MailEntity> mails) {
		List<TaskOwner> owners = task.getOwners();
		
		if (ListUtil.isEmpty(owners)) 
			return;
		//存在机票信息则将参数设置model中，传给模板引擎进行渲染
		MailEntity mail = new MailEntity();
		//获取打开单据链接
		String url = taskDirect + task.getTaskId();
		
		Context model = new Context();
		//设置查看单据url
		model.setVariable("url", url);
		//设置邮件正文
		mail.setContent(this.getMessage("zh/todo", model));
		
		String docType = header.getDocType();
		if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM002.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM003.name().equalsIgnoreCase(docType))  {
			//差旅申请、行程变更、借款单标题不设置金额
			Object[] args = { header.getExpensorName(), header.getDocTypeName(), header.getDocNo() };
			//设置邮件标题
			mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_TODO_NO_MONEY_TEMP, args));
		} else {
			//其他单据设置金额
			Object[] args = { header.getExpensorName(), header.getDocTypeName(), header.getDocNo(), header.getAmount() };
			//设置邮件标题
			mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_TODO_TEMP, args));
		}
		//获取审批人邮箱
		String toAddress = "";
		for (TaskOwner owner : owners) {
			String mailAddress = owner.getOwnerMail();
			if (Strings.isNullOrEmpty(mailAddress)) {
				User user = userDao.findUserByUserId(owner.getOwner(), "ZH");
				
				if (user != null && !Strings.isNullOrEmpty(user.getInMail())) {
					mailAddress = user.getInMail();
				}
			}
			if (!Strings.isNullOrEmpty(mailAddress)) {
				toAddress += (owner.getOwnerMail() + ";");
			}
		}
		mail.setReceivors(toAddress);
		//设置内外网邮件
		mail.setIsOutMail("N");
		mail.setIsApprove(YesOrNoEnum.Y.name());
		mail.setTaskId(task.getTaskId());
		mail.setDocId(header.getDocId());
		mails.add(mail);
	}
	
	/**
	 * 更新员工当前信用等级到单据中
	 * @param header
	 */
	private void setUserCreditToDoc(FormHeader header, TaskInstance task) {
		//开始环节更新员工诚信等级到单据中
		if (TaskNameEnum.START.name().equalsIgnoreCase(task.getTaskName())) {
			Map<String, Object> paramMap = Maps.newHashMap();
			
			paramMap.put("userId", header.getExpensor());
			paramMap.put("indate", DateUtil.getCurrentDateTime());
			paramMap.put("lv_code", "");
			paramMap.put("lv_desc", "");
			//获取员工当前信用级别
			userDao.getCreditByEmpid(paramMap);
			//更新员工信用级别到当前当局
			formDao.setUserCreditToDoc(header.getDocId(), 
									   (String) paramMap.get("lv_code"), 
									   (String) paramMap.get("lv_desc"));
		}
	}

	/**
	 * 将参数设置到模板文件中，并且返回文件内容
	 * @param model
	 * @return
	 */
	protected final String getMessage(String tempPath, Context model) {
		return templateEngine.process(tempPath, model);
	}
}
