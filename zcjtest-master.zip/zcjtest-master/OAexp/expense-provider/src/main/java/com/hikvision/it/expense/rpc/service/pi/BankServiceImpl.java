package com.hikvision.it.expense.rpc.service.pi;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.entity.user.UserBank;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.bank.SIREIMBURSEGETBANKOUT;
import com.hikvision.it.expense.webservice.client.pi.bank.SIREIMBURSEGETBANKOUTService;
import com.hikvision.it.expense.webservice.client.pi.bank.ZIREIMBURSEGETBANK;
import com.hikvision.it.expense.webservice.client.pi.bank.ZIREIMBURSEGETBANK.ITREQ;
import com.hikvision.it.expense.webservice.client.pi.bank.ZIREIMBURSEGETBANKResponse;
import com.hikvision.it.expense.webservice.client.pi.bank.ZSREIMBURSEGETBANK;
import com.hikvision.it.expense.webservice.client.pi.bank.ZSREIMBURSEGETBANKREQ;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;

/**
 * 查询员工银行信息接口
 * <p>Title: BankServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月21日
 *
 */
@Service
public class BankServiceImpl {

	private Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${system.pi.bank.url}")
	private String url;
	@Value("${system.pi.bank.namespace}")
	private String nameSpace;
	@Value("${system.pi.bank.localpart}")
	private String localPart;
	@Value("${system.pi.user}")
	private String piUser;
	@Value("${system.pi.password}")
	private String piUserPassWord;

	@Autowired
	IUserDao userDao;
	
	/**
	 * 从sap同步员工银行账号
	 * @param userBank
	 * @return
	 */
	public UserBank synchUserBankFromSAP(UserBank userBank) {
		List<UserBank> userBanks = Lists.newArrayList(userBank);
		
		userBank = this.findUserBankFromSAP(userBanks).get(0);
		try {
			userDao.deleteUserBank(userBank);
			userDao.recordUserBank(userBank);
		} catch (Exception e) {
		}
		
		return userBank;
	}

	/**
	 * 从报销系统本地获取员工银行信息
	 * @param userBanks
	 * @return
	 */
	public List<UserBank> findUserBankFromLocal(List<UserBank> userBanks) {
		if (ListUtil.isEmpty(userBanks))
			return userBanks;
		
		userBanks = userDao.matchUserBank(userBanks);
		
		List<UserBank> unMatchUsers = Lists.newArrayList();
		List<UserBank> matchUsers = Lists.newArrayList();
		for (UserBank userBank : userBanks) {
			if (!Strings.isNullOrEmpty(userBank.getBankN())) {
				matchUsers.add(userBank);
			} else {
				unMatchUsers.add(userBank);
			}
		}
		
		if (!ListUtil.isEmpty(unMatchUsers)) {
			unMatchUsers = this.findUserBankFromSAP(unMatchUsers);
			
			try {
				userDao.batchRecordUserBank(unMatchUsers);
			} catch (Exception e) {
			}
			
			matchUsers.addAll(unMatchUsers);
			
			return matchUsers;
		} else {
			return userBanks;
		}
	}
	
	public List<UserBank> findUserBankFromSAP(List<UserBank> users) {
		if (ListUtil.isEmpty(users))
			return users;
		
		URL wsdlURL = null;
        try {
            wsdlURL = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        }

        Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
        
        SIREIMBURSEGETBANKOUTService ss = new SIREIMBURSEGETBANKOUTService(wsdlURL, new QName(nameSpace, localPart));
        SIREIMBURSEGETBANKOUT port = ss.getHTTPPort();
        
        BindingProvider bp = (BindingProvider) port;
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
		context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

        ZIREIMBURSEGETBANK param = new ZIREIMBURSEGETBANK();
        
        ITREQ itReq = new ITREQ();
        List<ZSREIMBURSEGETBANKREQ> bankReqs = itReq.getItem();
        ZSREIMBURSEGETBANKREQ req = null;
        for (UserBank bank : users) {
        	req = new ZSREIMBURSEGETBANKREQ();
        	
        	req.setBUKRS(bank.getBukrs());
        	req.setLIFNR(bank.getLifnr());
        	
        	bankReqs.add(req);
        }
        param.setITREQ(itReq);
        //调用pi接口获取银行信息
        ZIREIMBURSEGETBANKResponse response = null;
        try {
        	response = port.getBANK(param);
		} catch (Exception e) {
        	logger.error("get bank info error", e);
        	throw new ExpenseException(MessageCache.getMessage(MessageCode.WSDL_ERROR_BANK));
		}

        //进行银行账号匹配
        this.setBankToMatchUser(response, users);
        
        return users;
	}

	/**
	 * 将获取到的银行账号设置到对应员工的银行信息中
	 * @param response
	 * @param users
	 */
	private void setBankToMatchUser(ZIREIMBURSEGETBANKResponse response, List<UserBank> users) {
		String language = UserContext.getLanguage();
		List<ZSREIMBURSEGETBANK> bankRes = response.getETRETURN().getItem();
		
		if (ListUtil.isEmpty(bankRes))
			return;
		String bankN = null;
		for (UserBank user : users) {
			for (ZSREIMBURSEGETBANK bank : bankRes) {
				if (user.getLifnr().equalsIgnoreCase(bank.getLIFNR()) &&
						user.getBukrs().equalsIgnoreCase(bank.getBUKRS())) {
					user.setName1(bank.getNAME1());
					user.setBankA(bank.getBANKA());
					user.setBankL(bank.getBANKL());
					bankN = bank.getBANKN();

					User userInfo = userDao.findUserByUserId(user.getLifnr(), language);
					if (userInfo != null) {
						user.setDeptPath(userInfo.getDeptPath());
					}

					if (!Strings.isNullOrEmpty(bankN)) {
						if (bankN.length() > 8) {
							user.setBankN(bankN.substring(0, 4) + "******" + bankN.substring(bankN.length() - 4));
						} else {
							user.setBankN(bankN);
						}
					}
					
					break;
				}
			}
		}
	}
}
