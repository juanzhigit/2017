package com.hikvision.it.expense.rpc.service.plug;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.voucher.IVoucherDao;

/**
 * 判断是否需要付款
 * 
 * 判断凭证的总金额与清帐金额差额是否大于0 
 * 大于0  TO_F06
 * 否则        TO_END
 * 
 * <p>Title: JudgeNeedPayServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="judgeNeedPayService")
public class JudgeNeedPayServiceImpl implements IExecutePlugService {
	@Autowired
    IVoucherDao voucherDao;
	@Autowired
	IFormDao formDao;
	
	@Override
	public String execute(TaskObject taskObject, String docId) {
		int aboverZeroNumber = voucherDao.countPayAmountAboverZero(docId);
		String docType = formDao.getDocType(docId);
		
		if (DocTypeEnum.WEM004.name().equalsIgnoreCase(docType) || 
				aboverZeroNumber == 0) {
			return "TO_END";
		}
		
		return "TO_F06";
	}
}
