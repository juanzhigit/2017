package com.hikvision.it.expense.rpc.service.pi;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.bsik.SIREIMBURSEGETBSIKSYNOUT;
import com.hikvision.it.expense.webservice.client.pi.bsik.SIREIMBURSEGETBSIKSYNOUTService;
import com.hikvision.it.expense.webservice.client.pi.bsik.ZIREIMBURSEGETBSIK;
import com.hikvision.it.expense.webservice.client.pi.bsik.ZIREIMBURSEGETBSIKResponse;
import com.hikvision.it.expense.webservice.client.pi.bsik.ZSREIMBURSEGETBSIK;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;

/**
 * 员工未清项查询接口
 * <p>Title: BsikServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月13日
 *
 */
@Service
public class BsikServiceImpl {
	@Value("${system.pi.bsik.url}")
	private String url;
	@Value("${system.pi.bsik.namespace}")
	private String nameSpace;
	@Value("${system.pi.bsik.localpart}")
	private String localPart;
	@Value("${system.pi.user}")
	private String piUser;
	@Value("${system.pi.password}")
	private String piUserPassWord;

	public List<Bsik> getBsik(String userId, String bukrs) {
        URL wsdlURL = null;
        try {
            wsdlURL = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        }

        Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
        SIREIMBURSEGETBSIKSYNOUTService ss = new SIREIMBURSEGETBSIKSYNOUTService(wsdlURL, new QName(nameSpace, localPart));
        SIREIMBURSEGETBSIKSYNOUT port = ss.getHTTPPort();

		BindingProvider bp = (BindingProvider) port;
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
		context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

		ZIREIMBURSEGETBSIK params = new ZIREIMBURSEGETBSIK();

        params.setIBUKRS(bukrs);
        params.setILIFNR(userId);

        ZIREIMBURSEGETBSIKResponse response = port.getBSIK(params);

        return this.transToBsik(response.getETRETURN().getItem());
	}
	
	/**
	 * 将未清明细进行实体转换，转换成可序列化的实体
	 * @param rsList
	 * @return
	 */
	private List<Bsik> transToBsik(List<ZSREIMBURSEGETBSIK> rsList) {
		if (!ListUtil.isEmpty(rsList)) {
			List<Bsik> list = Lists.newArrayList();
			for (ZSREIMBURSEGETBSIK rs : rsList) {
				Bsik bsik = new Bsik();
				
				bsik.setAnln1(rs.getANLN1());
				bsik.setAnln2(rs.getANLN2());
				bsik.setAufnr(rs.getAUFNR());
				bsik.setBelnr(rs.getBELNR());
				bsik.setBlart(rs.getBLART());
				bsik.setBldat(rs.getBLDAT());
				bsik.setBschl(rs.getBSCHL());
				bsik.setBudat(rs.getBUDAT());
				bsik.setBukrs(rs.getBUKRS());
				bsik.setBuzei(rs.getBUZEI());
				bsik.setCpudt(rs.getCPUDT());
				bsik.setDmbtr(rs.getDMBTR());
				bsik.setEbeln(rs.getEBELN());
				bsik.setEbelp(rs.getEBELP());
				bsik.setGjahr(rs.getGJAHR());
				bsik.setGsber(rs.getGSBER());
				bsik.setHkont(rs.getHKONT());
				bsik.setLifnr(rs.getLIFNR());
				bsik.setMonat(rs.getMONAT());
				bsik.setMwskz(rs.getMWSKZ());
				bsik.setProjk(rs.getPROJK());
				bsik.setRebzg(rs.getREBZG());
				bsik.setSaknr(rs.getSAKNR());
				bsik.setSgtxt(rs.getSGTXT());
				bsik.setShkzg(rs.getSHKZG());
				bsik.setSkfbt(rs.getSKFBT());
				bsik.setUmskz(rs.getUMSKZ());
				bsik.setWaers(rs.getWAERS());
				bsik.setWrbtr(rs.getWRBTR());
				bsik.setXblnr(rs.getXBLNR());
				bsik.setXref1(rs.getXREF1());
				bsik.setZbd1P(rs.getZBD1P());
				bsik.setZbd1T(rs.getZBD1T());
				bsik.setZbd2P(rs.getZBD2P());
				bsik.setZbd2T(rs.getZBD2T());
				bsik.setZbd3T(rs.getZBD3T());
				bsik.setZfbdt(rs.getZFBDT());
				bsik.setZterm(rs.getZTERM());
				bsik.setZumsk(rs.getZUMSK());
				bsik.setZuonr(rs.getZUONR());
				
				list.add(bsik);
			}
			
			return list;
		}
		
		return null;
	}
}
