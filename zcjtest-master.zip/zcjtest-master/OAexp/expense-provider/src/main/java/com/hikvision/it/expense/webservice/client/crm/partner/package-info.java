@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/HIK%20Account-Partner%20For%20Finance", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.hikvision.it.expense.webservice.client.crm.partner;
