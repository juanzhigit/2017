package com.hikvision.it.expense.rpc.service.pi;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.clearing.SICLEARINGCHECKOUT;
import com.hikvision.it.expense.webservice.client.pi.clearing.SICLEARINGCHECKOUTService;
import com.hikvision.it.expense.webservice.client.pi.clearing.ZICLEARINGCHECK;
import com.hikvision.it.expense.webservice.client.pi.clearing.ZICLEARINGCHECKResponse;
import com.hikvision.it.expense.webservice.client.pi.clearing.ZSCLEARINGCHECK;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;

/**
 * 获取清帐结果pi接口
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/5/27
 * Time: 13:59
 * To change this template use File | Settings | File Templates.
 */
@Service
public class ClearingServiceImpl {
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Value("${system.pi.clearing.url}")
    private String url;
    @Value("${system.pi.clearing.namespace}")
    private String nameSpace;
    @Value("${system.pi.clearing.localpart}")
    private String localPart;
    @Value("${system.pi.user}")
    private String piUser;
    @Value("${system.pi.password}")
    private String piUserPassWord;

    /**
     * 同步获取sap付款状态
     * @param lists
     * @return
     */
    public List<CashierAudit> synchSAPPaymentStatus(List<CashierAudit> lists) {
        if (ListUtil.isEmpty(lists)) {
            return lists;
        }

        URL wsdlURL = null;
        try {
            wsdlURL = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        }

        Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));

        SICLEARINGCHECKOUTService ss = new SICLEARINGCHECKOUTService(wsdlURL, new QName(nameSpace, localPart));
        SICLEARINGCHECKOUT port = ss.getHTTPPort();

        BindingProvider bp = (BindingProvider) port;
        Map<String, Object> context = bp.getRequestContext();
        context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
        context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

        ZICLEARINGCHECK params = new ZICLEARINGCHECK();
        //设置调用参数
        ZICLEARINGCHECK.ETRETURN item = new ZICLEARINGCHECK.ETRETURN();
        List<ZSCLEARINGCHECK> items = item.getItem();

        //传入参数
        for (CashierAudit cashierItem : lists) {
            ZSCLEARINGCHECK check = new ZSCLEARINGCHECK();

            check.setPROCESSID(cashierItem.getDocId());
            check.setBELNR(cashierItem.getBelnr());
            check.setBUZEI(cashierItem.getLineNo());
            check.setBUKRS(cashierItem.getBukrs());
            check.setLIFNR(cashierItem.getExpensor());
            check.setGJAHR(cashierItem.getGjahr());

            items.add(check);
        }

        params.setETRETURN(item);
        //解析返回结果
        ZICLEARINGCHECKResponse response = port.clearingCHECK(params);
        //获取返回结果
        List<ZSCLEARINGCHECK> rsList = response.getETRETURN().getItem();
        //循环解析返回结果
        for (CashierAudit cashierItem : lists) {
            for (ZSCLEARINGCHECK check : rsList) {
                if (cashierItem.getBelnr().equalsIgnoreCase(check.getBELNR()) &&
                        cashierItem.getBukrs().equalsIgnoreCase(check.getBUKRS()) &&
                        cashierItem.getExpensor().equalsIgnoreCase(check.getLIFNR()) &&
                        cashierItem.getGjahr().equalsIgnoreCase(check.getGJAHR()) &&
                        cashierItem.getLineNo().equalsIgnoreCase(check.getBUZEI())) {
                    if (YesOrNoEnum.Y.name().equalsIgnoreCase(check.getFLAG())) {
                        cashierItem.setPayStatus(YesOrNoEnum.Y.name());
                    } else {
                        cashierItem.setPayStatus(YesOrNoEnum.N.name());
                    }

                    break;
                }
            }
        }

        return lists;
    }
}
