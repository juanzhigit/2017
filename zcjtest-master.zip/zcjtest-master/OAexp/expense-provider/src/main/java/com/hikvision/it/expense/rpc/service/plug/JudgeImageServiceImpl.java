package com.hikvision.it.expense.rpc.service.plug;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 根据单据的费用归属公司、提交日期判断提交时费用归属公司是否启用影像，是否需要进入影像审批环节
 * 
 * 已启用  return TO_P05 		下一环节进入影像审批环节
 * 未启用  return TO_DOCTYPE		下一环节进入单据判断环节
 * 	
 * <p>Title: JudgeImageService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
@Service(value="judgeImageService")
public class JudgeImageServiceImpl implements IExecutePlugService {
	@Autowired
	IFormDao formDao;
	
	/**
	 * 根据单据费用归属公司校验单据提交时费用所属公司是否启用影像  
	 * 已启用  return TO_P05 		下一环节进入影像审批环节
	 * 未启用  return TO_DOCTYPE	下一环节进入单据判断环节
	 */
	@Override
	public String execute(TaskObject taskObject, String docId) {
		FormHeader header = formDao.getFormHeader(docId);

		String docType = header.getDocType();
		if (DocTypeEnum.WEM002.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM004.name().equalsIgnoreCase(docType)) {
			//行程变更、还款单不需要影像环节
			return "TO_DOCTYPE";
		} else if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) &&
					YesOrNoEnum.N.name().equalsIgnoreCase(header.getLoanFlag())) {
			//差旅申请不含借款不需要影像环节
			return "TO_DOCTYPE";
		} else {
			int number = formDao.checkDocNeedImageWhenSubmit(docId);

			if (number != 0) {
				return "TO_P05";
			} else {
				return "TO_DOCTYPE";
			}
		}
	}
}
