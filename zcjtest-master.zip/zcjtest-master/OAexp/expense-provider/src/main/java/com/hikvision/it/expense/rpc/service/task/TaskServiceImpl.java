package com.hikvision.it.expense.rpc.service.task;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.alibaba.fastjson.JSONObject;
import com.github.pagehelper.Page;
import com.github.pagehelper.PageHelper;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.task.PendingForwardBean;
import com.hikvision.it.expense.api.entity.task.TaskConfig;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.entity.task.TodoInfo;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.enums.TaskNameEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.api.service.execute.ITaskOwnerService;
import com.hikvision.it.expense.api.service.task.ITaskService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.process.IProcessDao;
import com.hikvision.it.expense.rpc.dao.task.ITaskDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.util.PageConverter;
import com.hikvision.it.expense.rpc.util.SpringContextUtil;
import com.hikvision.it.expense.rpc.util.TaskUtil;

@Service
@Primary
public class TaskServiceImpl implements ITaskService {
    @Autowired
    ITaskDao taskDao;
    @Autowired
    IProcessDao processDao;

    @Override
    public List<TodoInfo> getTasksToApprove() {
        LoginUser user = UserContext.get();
        return taskDao.getTasksToApprove(user.getUserId(), user.getLanguage());
    }

    @Override
    public List<TodoInfo> getApprovedTasks(int pageNumber, int pageSize) {
        LoginUser user = UserContext.get();
        return taskDao.getApprovedTasks(user.getUserId(), user.getLanguage(), pageNumber, pageSize);
    }

    @Override
    @Transactional
    public HikResult<String> completeTask(String taskId, ResultEnum result, String suggest) {
        HikResult<String> rs = new HikResult<String>();
        //先校验参数是否有误
        this.checkParamValid(taskId, suggest, rs);
        if (result == null)
            rs.getErrorMsgs().add("审批失败，未传入审批结果！");

        if (rs.isSuccess()) {
            //获取任务实体
            HikResult<TaskInstance> taskRs = this.packageTaskApproveData(taskId, result, suggest, null);
            //获取成功
            if (taskRs.isSuccess()) {
                TaskInstance task = taskRs.getData();
                // 先审批
                int effectNum = taskDao.completeTask(task);
                if (effectNum == 0) {
                    rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.FAILURE_APPROVED));
                } else {
                    //流转到下一环节
                    this.flowTaskToNextStep(result, task, null);
                }
            } else {
                //错误信息添加到rs列表中
                rs.getErrorMsgs().addAll(taskRs.getErrorMsgs());
            }
        }

        return rs;
    }

    @Override
    @Transactional
    public HikResult<String> forwardTask(String taskId, String suggest, TaskReceivor receivor) {
        HikResult<String> rs = new HikResult<String>();
        //先校验参数是否有误
        this.checkParamValid(taskId, suggest, rs);
        if (receivor == null)//校验接收人是否传入
            rs.getErrorMsgs().add("审批失败，未传入接收人信息！");
        if (rs.isSuccess()) {
            //转换接收人list
            List<TaskOwner> owners = this.transReceivorToTaskOwner(Lists.newArrayList(receivor));
            //获取任务实体
            HikResult<TaskInstance> taskRs = this.packageTaskApproveData(taskId, ResultEnum.FORWARD, suggest, owners);
            //获取成功
            if (taskRs.isSuccess()) {
                TaskInstance task = taskRs.getData();
                // 先审批
                int effectNum = taskDao.forwardTask(task);
                if (effectNum == 0) {
                    rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.FAILURE_APPROVED));
                } else {
                    this.flowTaskToNextStep(ResultEnum.FORWARD, task, owners);
                }
            } else {
                //错误信息添加到rs列表中
                rs.getErrorMsgs().addAll(taskRs.getErrorMsgs());
            }
        }

        return rs;
    }

    @Override
    @Transactional
    public HikResult<String> addStep(String taskId, String suggest, List<TaskReceivor> receivors) {
        HikResult<String> rs = new HikResult<String>();
        //先校验参数是否有误
        this.checkParamValid(taskId, suggest, rs);
        if (ListUtil.isEmpty(receivors))
            rs.getErrorMsgs().add("审批失败，未传入接收人信息！");
        //转换接收人list
        List<TaskOwner> owners = this.transReceivorToTaskOwner(Lists.newArrayList(receivors));
        //获取任务实体
        HikResult<TaskInstance> taskRs = this.packageTaskApproveData(taskId, ResultEnum.ADDSTEP, suggest, owners);
        //获取成功
        if (taskRs.isSuccess()) {
            TaskInstance task = taskRs.getData();
            // 先审批
            int effectNum = taskDao.addStep(task);
            if (effectNum == 0) {
                rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.FAILURE_APPROVED));
            } else {
                this.flowTaskToNextStep(ResultEnum.ADDSTEP, task, owners);
            }
        } else {
            //错误信息添加到rs列表中
            rs.getErrorMsgs().addAll(taskRs.getErrorMsgs());
        }

        return rs;
    }

    @Override
    @Transactional
    public void startTask(ProcessInstance process) {
        if (process != null) {
            // 生成开始环节任务实例
            TaskInstance task = TaskUtil.genStartTaskInstance(process);
            // 新增任务信息
            this.insertTaskInstance(task);
            //流转任务
            taskDao.flowTask(task);
            //执行当前环节审批前服务配置
            TaskObject taskObject = new TaskObject();
            taskObject.setProcessObjectId(process.getProcessObjectId());
            taskObject.setTaskName(task.getTaskName());
            this.executeConfigServiceBeforeApprove(taskObject, process, Lists.newArrayList(task));
            //流转流程
            this.flowTaskToNextStep(ResultEnum.SUBMIT, task, null);
        } else {
            throw new ExpenseException(ExceptionCode.PROCESS_PARAM_NOT_FOUND);
        }
    }

    @Override
    public String getDocIdByTaskId(String taskId) {
        String docId = taskDao.getDocIdByTaskId(taskId);
        if (docId == null) {
            throw new ExpenseException(MessageCache.getMessage(MessageCode.DOC_NOT_FOUND));
        }
        return docId;
    }

    @Override
    public TaskInstance getTaskInstance(String taskId) {
        return taskDao.getTaskInstance(taskId, UserContext.getUserId());
    }

    /**
     * 流转任务到下一环节
     *
     * @param task
     * @param owners
     */
    private void flowTaskToNextStep(ResultEnum result, TaskInstance task, List<TaskOwner> owners) {
        List<TaskInstance> tasks = Lists.newArrayList();
        // 更新流转标识
        taskDao.flowTask(task);
        // 获取流程实例
        ProcessInstance process = processDao.selectProcess(task.getProcessId());
        //判断是否可以流转到下一环节
        if (this.checkCanFlowToNextStep(task)) {
            if (result.equals(ResultEnum.REJECT) || result.equals(ResultEnum.RETRACK)) {
                //流程回合数+1
                int effNum = processDao.updateProcessVersion_Rd(process);
                if (effNum == 0) {
                    throw new ExpenseException(ExceptionCode.PROCESS_VERSION_ERROR);
                }
            }
            if (result.equals(ResultEnum.REJECT) ||
                    result.equals(ResultEnum.REFUSE)) {
                process.setUpTime(System.currentTimeMillis());
                //如果是拒绝或者驳回，需要删除其他完成的任务
                processDao.deleteUnDoneTask(process);
            }
            String taskName = task.getTaskName();
            //加签环节应当返回给加签人所处环节
            if (result.equals(ResultEnum.AGREE) && TaskNameEnum.A02.name().equalsIgnoreCase(taskName)) {
                this.plugToParentStep(process, task);
            } else {
                // 获取下一环节配置信息
                TaskObject nextTaskObject = this.getNextTaskObject(task, process);
                if (!ResultEnum.ADDSTEP.equals(result) &&
                        !ResultEnum.FORWARD.equals(result)) {//非加签，转发环节流转
                    // 生成下一环节信息
                    TaskInstance nextTask = TaskUtil.packageManuTaskAndProcessOperator(process, nextTaskObject, owners);
                    this.plugOut(nextTaskObject, process, nextTask);
                } else {//加签或转发
                    if (ResultEnum.ADDSTEP.equals(result)) {
                        tasks.addAll(TaskUtil.genAddStepTaskInstance(process, nextTaskObject, owners, task.getTaskId()));
                        for (TaskInstance t : tasks) {//逐个保存待办信息
                            this.insertTaskInstance(t);
                        }
                    } else {
                        // 生成下一环节信息
                        TaskInstance nextTask = TaskUtil.packageManuTaskAndProcessOperator(process, nextTaskObject, owners);
                        // 设置ref_taskid为上一环节taskid
                        nextTask.setRefTaskId(task.getTaskId());
                        //设置审批组ID
                        nextTask.setGroupId(task.getGroupId());
                        nextTask.setTaskName(task.getTaskName());
                        nextTask.setOwners(owners);

                        tasks.add(nextTask);
                        // 新增任务信息和待办接收人信息
                        this.insertTaskInstance(nextTask);
                    }
                    // 更新流程当前处理人并且执行审批前服务配置
                    this.updateProcessAndExecuteBeforeService(nextTaskObject, process, tasks);
                }
            }
        }
        //获取当前环节配置
        TaskObject taskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), task.getTaskName());
        //执行当前环节审批后服务配置
        this.executeConfigServiceAfterApprove(taskObject, process, Lists.newArrayList(task));
    }

    /**
     * 流转到原始加签环节
     *
     * @param process
     * @param task
     */
    private void plugToParentStep(ProcessInstance process, TaskInstance task) {
        //获取加签任务信息
        TaskInstance parentTask = taskDao.getParentTask(task.getTaskId());

        TaskOwner owner = new TaskOwner();

        owner.setOwner(parentTask.getCompletedBy());
        owner.setOwnerName(parentTask.getCompletedByName());

        TaskObject taskObject = new TaskObject();

        taskObject.setTaskName(parentTask.getTaskName());
        taskObject.setNodeType(parentTask.getNodeType());
        taskObject.setProcessObjectId(process.getProcessObjectId());

        TaskInstance nextTask = TaskUtil.packageManuTaskAndProcessOperator(process, taskObject, Lists.newArrayList(owner));
        // 新增任务信息
        this.insertTaskInstance(nextTask);
        // 更新流程当前处理人并且执行审批前服务配置
        this.updateProcessAndExecuteBeforeService(taskObject, process, Lists.newArrayList(nextTask));
    }

    /**
     * 更新流程当前处理人并且执行审批前服务配置
     *
     * @param taskObject
     * @param process
     * @param tasks
     */
    private void updateProcessAndExecuteBeforeService(TaskObject taskObject, ProcessInstance process, List<TaskInstance> tasks) {
        // 更新当前处理人信息
        process.setUpTime(System.currentTimeMillis());
        processDao.updateProcessOperator(process);
        // 环节审批后执行审批前服务器配置
        this.executeConfigServiceBeforeApprove(taskObject, process, tasks);
    }

    /**
     * 校验是否可以流转任务到下一环节
     * <p>
     * 当当前环节的不存在未完成的组任务时，则返回true，否则返回false
     *
     * @param task
     * @return
     */
    private boolean checkCanFlowToNextStep(TaskInstance task) {
        //判断是否还存在未完成的组任务
        int unDoneTaskGroupNumbers = taskDao.countUnFlowedGroupTaskNumber(task.getProcessId(), task.getTaskId());

        return unDoneTaskGroupNumbers == 0 ? true : false;
    }

    /**
     * 流转流程环节
     *
     * @param taskObject
     * @param process
     * @param task
     * @throws ExpenseException
     */
    private void plugOut(TaskObject taskObject, ProcessInstance process, TaskInstance task) throws ExpenseException {
        if (taskObject != null) {
            if (taskObject.isAuto()) {// 流转任务到自动环节
                this.flowToAutoNode(process, taskObject);
            } else {// 流转任务到人工环节
                this.flowToManuNode(process, taskObject);
            }
        } else {
            throw new ExpenseException(ExceptionCode.TASK_NEXT_NODE_NOT_FOUND);
        }
    }

    /**
     * 流转到自动环节
     *
     * @param process
     * @param taskObject
     * @throws Exception
     */
    private void flowToAutoNode(ProcessInstance process,
                                TaskObject taskObject) throws ExpenseException {
        // 生成下一环节信息
        TaskInstance task = TaskUtil.genAutoTaskInstance(process, taskObject);
        // 新增任务信息
        this.insertTaskInstance(task);
        if (!isEndTask(taskObject)) {
            // 获取下一环节配置信息
            TaskObject nextTaskObject = this.getPlugOut(taskObject, process.getDocId());
            // 流转流程
            this.plugOut(nextTaskObject, process, task);
        } else {
            long curTime = System.currentTimeMillis();
            // 流程审批完成时
            task.setCmTime(curTime);
            task.setUpTime(curTime);
            // 先更新任务审批状态
            int statusEffectNum = taskDao.completeTask(task);
            if (statusEffectNum == 0) {
                throw new ExpenseException(ExceptionCode.TASK_COMPLETED);
            }
            // 流转完成
            taskDao.flowTask(task);
            // 更新流程状态为结束
            process.setCmTime(curTime);
            process.setUpTime(curTime);
            if (processDao.completeProcess(process) == 0) {
                throw new ExpenseException(ExceptionCode.PROCESS_COMPLETED);
            }
        }
        // 更新流程当前处理人并且执行审批前服务配置
        this.updateProcessAndExecuteBeforeService(taskObject, process, Lists.newArrayList(task));
    }

    /**
     * 流转任务到人工环节
     *
     * @param process
     * @param taskObject
     * @throws Exception
     */
    private void flowToManuNode(ProcessInstance process, TaskObject taskObject) throws ExpenseException {
        List<TaskOwner> owners = null;
        // 定义任务list
        List<TaskInstance> tasks = new ArrayList<TaskInstance>();
        // 流转到人工环节
        try {
            ITaskOwnerService approverService = SpringContextUtil.getBean(taskObject.getServiceName(), ITaskOwnerService.class);

            owners = approverService.execute(taskObject, process.getDocId());
        } catch (Exception e) {
            throw new ExpenseException(ExceptionCode.TASK_APPROVER_SERVICE_NOT_FOUND);
        }
        // 流转环节到下一步
        if (!ListUtil.isEmpty(owners)) {
            tasks.add(TaskUtil.packageManuTaskAndProcessOperator(process, taskObject, owners));
            // 生成待办信息
            for (TaskInstance task : tasks) {
                this.insertTaskInstance(task);
            }
        } else if (taskObject.isJump()) {
            // 无审批人可跳过环节处理逻辑实现
            // 获取下一环节配置信息
            TaskObject nextTaskObject = this.getPlugOut(taskObject, process.getProcessId());
            // 流转流程
            this.plugOut(nextTaskObject, process, null);
        } else {
            throw new ExpenseException(ExceptionCode.TASK_APPROVER_NOT_FOUND);
        }
        // 更新流程当前处理人并且执行审批前服务配置
        this.updateProcessAndExecuteBeforeService(taskObject, process, tasks);
    }

    /**
     * 执行审批前服务配置
     *
     * @param taskObject
     * @param process
     * @param tasks
     */
    private void executeConfigServiceBeforeApprove(TaskObject taskObject,
                                                   ProcessInstance process, List<TaskInstance> tasks) {
        //实现逻辑
        List<TaskConfig> configs = taskDao.beforeApproveTaskConfig(taskObject.getProcessObjectId(), taskObject.getTaskName());
        //执行配置服务
        this.executeConfigService(configs, process, tasks);
    }

    /**
     * 执行审批后服务配置
     *
     * @param taskObject
     * @param process
     * @param tasks
     */
    private void executeConfigServiceAfterApprove(TaskObject taskObject,
                                                  ProcessInstance process, List<TaskInstance> tasks) {
        //实现逻辑
        List<TaskConfig> configs = taskDao.afterApproveTaskConfig(taskObject.getProcessObjectId(), taskObject.getTaskName());
        //执行配置服务
        this.executeConfigService(configs, process, tasks);
    }

    /**
     * 执行配置服务
     *
     * @param configs
     * @param process
     * @param tasks
     */
    private void executeConfigService(List<TaskConfig> configs,
                                      ProcessInstance process, List<TaskInstance> tasks) {
        //判断是否存在服务配置
        if (ListUtil.isEmpty(configs)) {
            return;
        }
        for (TaskConfig config : configs) {
            String serviceName = config.getServiceName();
            if (!Strings.isNullOrEmpty(serviceName)) {
                // 获取服务接口类
                IExecuteService commonService = SpringContextUtil.getBean(serviceName, IExecuteService.class);
                if (commonService != null)
                    // 执行服务
                    commonService.execute(process, tasks);
                else
                    throw new ExpenseException(ExceptionCode.TASK_SERVICE_NOT_FOUND);
            }
        }
    }

    /**
     * 判断是否结束环节
     *
     * @param taskObject
     * @return
     */
    private boolean isEndTask(TaskObject taskObject) {
        String taskName = taskObject.getTaskName();

        if (TaskNameEnum.END.name().equalsIgnoreCase(taskName)) {
            return true;
        }

        return false;
    }

//	/**
//	 * 记录oa待办结束日志
//	 * @param taskId
//	 * @param docId
//	 */
//	private void recordOATodoEndLog(String taskId, String docId) {
//		// 结束oa待办
//		OaTodo oaTodo = new OaTodo();
//		
//		oaTodo.setUnid(taskId);
//		oaTodo.setCurdealer(null);
//		oaTodo.setSubject("结束待办");
//		oaTodo.setDocid(docId);
//		
//		sendLogDao.recordOaTodoInfo(oaTodo);
//	}

    /**
     * 新增任务实例
     *
     * @param task
     * @return
     */
    private void insertTaskInstance(TaskInstance task) {
        // 保存主任务记录
        taskDao.insertTaskInstance(task);
        List<TaskOwner> owners = task.getOwners();
        if (owners != null && owners.size() != 0) {
            taskDao.insertTaskOwners(owners);
        }
    }

    /**
     * 获取下一环节配置信息
     *
     * @param task
     * @param process
     * @return
     * @throws ExpenseException
     */
    private TaskObject getNextTaskObject(TaskInstance task, ProcessInstance process) throws ExpenseException {
        String result = task.getResult();

        TaskObject nextTaskObject = null;
        if (ResultEnum.FORWARD.name().equalsIgnoreCase(result)) {
            nextTaskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), TaskNameEnum.A03.name());
        } else if (ResultEnum.ADDSTEP.name().equalsIgnoreCase(result)) {
            nextTaskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), TaskNameEnum.A02.name());
        } else {
            if (ResultEnum.AGREE.name().equalsIgnoreCase(result) ||
                    ResultEnum.SUBMIT.name().equalsIgnoreCase(result)) {//同意、提交 else {
                //先获取当前环节
                TaskObject taskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), task.getTaskName());
                //再获取下一环节
                nextTaskObject = this.getPlugOut(taskObject, process.getDocId());
            } else if (ResultEnum.REJECT.name().equalsIgnoreCase(result) ||
                    ResultEnum.RETRACK.name().equalsIgnoreCase(result)) {//驳回、撤回
                nextTaskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), TaskNameEnum.A01.name());
            } else if (ResultEnum.REFUSE.name().equalsIgnoreCase(result) ||
                    ResultEnum.UNDO.name().equalsIgnoreCase(result)) {//拒绝、撤销
                nextTaskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), TaskNameEnum.END.name());
            }
        }

        if (nextTaskObject != null)
            return nextTaskObject;
        else
            throw new ExpenseException(ExceptionCode.TASK_NEXT_NODE_NOT_FOUND);
    }

    /**
     * 获取下一环节信息
     *
     * @param taskObject
     * @param docId
     * @return
     * @throws Exception
     */
    private TaskObject getPlugOut(TaskObject taskObject, String docId) throws ExpenseException {
        //其他环节流转
        String plugOut = taskObject.getPlugOut();
        String interfaces = taskObject.getInterfaces();
        if (StringUtil.isNotEmptyTrim(interfaces)) {
            plugOut = SpringContextUtil.getBean(taskObject.getInterfaces(), IExecutePlugService.class).execute(taskObject, docId);
        }
        TaskObject nextTaskObject = null;
        if (!Strings.isNullOrEmpty(plugOut)) {
            nextTaskObject = taskDao.getTaskObject(taskObject.getProcessObjectId(), plugOut);
        }

        if (nextTaskObject != null)
            return nextTaskObject;
        else
            throw new ExpenseException(ExceptionCode.TASK_NEXT_NODE_NOT_FOUND);
    }

    /**
     * 传入参数校验
     *

     */
    private void checkParamValid(String taskId, String suggest, HikResult<String> rs) {
        if (UserContext.get() == null)//校验登陆用户
            rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.MSG_USER_NOT_LOGON));
        if (Strings.isNullOrEmpty(taskId))//校验任务编号
            rs.getErrorMsgs().add("审批失败，未传入任务编号！");
        if (!Strings.isNullOrEmpty(suggest) && suggest.trim().length() > 500)//校验审批意见
            rs.getErrorMsgs().add(
                    MessageCache.getMessage(
                            MessageCode.FORM_FIELD_LENGTH_LIMITTED,
                            new Object[]{
                                    MessageCache.getMessage(MessageCode.TITLE_SUGGEST),
                                    500}));
    }

    /**
     * 将接收人list转换成taskowner
     *
     * @param receivors
     * @return
     */
    private List<TaskOwner> transReceivorToTaskOwner(List<TaskReceivor> receivors) {
        List<TaskOwner> taskOwners = Lists.newArrayList();
        for (TaskReceivor receivor : receivors) {
            TaskOwner owner = new TaskOwner();

            owner.setOwner(receivor.getOwner());
            owner.setOwnerName(receivor.getOwnerName());
            owner.setOwnerMail(receivor.getOwnerMail());

            taskOwners.add(owner);
        }
        return taskOwners;
    }

    /**
     * 生成审批task
     *
     * @param taskId
     * @param result
     * @param suggest
     * @param owners
     * @return
     */
    private HikResult<TaskInstance> packageTaskApproveData(String taskId,
                                                           ResultEnum result, String suggest, List<TaskOwner> owners) {
        HikResult<TaskInstance> rs = new HikResult<TaskInstance>();
        //获取登陆用户信息
        LoginUser user = UserContext.get();
        // 先获取任务任务信息
        TaskInstance task = taskDao.getTaskInstance(taskId, user.getUserId());
        if (TaskNameEnum.A02.name().equalsIgnoreCase(task.getTaskName())) {
            //加签不允许再加签或转发
            if (ResultEnum.FORWARD.equals(result) ||
                    ResultEnum.ADDSTEP.equals(result)) {
                rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.MSG_APPROVE_CANNOT_ADDSTEP));
            }
        }

        if (rs.isSuccess()) {
            //设置审批信息
            long time = System.currentTimeMillis();
            task.setCompletedBy(user.getUserId());
            task.setCompletedByName(user.getUserName());
            task.setDevice(user.getDevice().name());
            task.setResult(result.name());
            task.setSuggest(suggest);
            task.setUpTime(time);
            task.setCmTime(time);
            if (!ListUtil.isEmpty(owners)) {
                task.setReceivor(JSONObject.toJSONString(owners));
            }
            //设置返回数据
            rs.setData(task);
        }

        return rs;
    }

    @Override
    public GridData<PendingForwardBean> getPendingByUserName(String userNameOrEmpId, int pageNum, int pageSize) {

        PageHelper.startPage(pageNum, pageSize, true);
        Page<PendingForwardBean> info = taskDao.getPendingByUserName(userNameOrEmpId);
        return PageConverter.convert(info);
    }

    @Override
    public GridData<PendingForwardBean> getRecordByApplyIds(String applyIds, int pageNum, int pageSize) {

        String[] split_applyid = applyIds.split(" ");
        if (split_applyid.length == 0) {
            return null;
        }
        PageHelper.startPage(pageNum, pageSize, true);
        Page<PendingForwardBean> info = taskDao.getPendingByApplyIds(split_applyid);
        return PageConverter.convert(info);
    }

    @Override
    @Transactional
    public void updateBpmInfo(String delegatorId, String processIds, String taskIds) {
        Long uptime = System.currentTimeMillis();
        String[] taskList = taskIds.split(",");
        String[] processList = processIds.split(",");
        User receivorUser = taskDao.getUserByUserId(delegatorId, "ZH");
        int taskOwnerUpdateNum = taskDao.updateOwnerInfo(receivorUser.getUserId(), receivorUser.getUserName(), taskList);
        int processUpdateNum = taskDao.updateOperatorInfo(receivorUser.getUserName(), uptime, processList);
        /*更新条数不一样则回滚*/
        if (taskOwnerUpdateNum != processUpdateNum) {
            throw new ExpenseException("更新条数不一致,回滚事务");
        }
    }

    @Override
    public List<PendingForwardBean> getSelectUser(String searchText) {
        return taskDao.getSelectUser(searchText);
    }
}
