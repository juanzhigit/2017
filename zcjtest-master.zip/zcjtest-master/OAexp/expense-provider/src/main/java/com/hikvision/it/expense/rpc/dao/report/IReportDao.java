package com.hikvision.it.expense.rpc.dao.report;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.github.pagehelper.Page;
import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.QueryForm;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.entity.report.ForeignCurrencyLoanDetail;

/**
 * 报表dao
 * <p>Title: IReportDao.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月15日
 *
 */
public interface IReportDao {
	/**
	 * 获取借款列表
	 * @param userId
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listExpenses(@Param("userId") String userId, 
							      @Param("pageNumber") int pageNumber,
							      @Param("pageSize") int pageSize);
	/**
	 * 获取还款列表
	 * @param userId
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listLoanAndRepayments(@Param("userId") String userId, 
									       @Param("pageNumber") int pageNumber,
									       @Param("pageSize") int pageSize);
	/**
	 * 获取差旅列表（包含申请和变更）
	 * @param userId
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listTravelApplys(@Param("userId") String userId, 
								      @Param("pageNumber") int pageNumber,
								      @Param("pageSize") int pageSize);
	
	/**
	 * 获取草稿单
	 * @param userId
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listDrafts(@Param("userId") String userId, 
							    @Param("pageNumber") int pageNumber,
							    @Param("pageSize") int pageSize);

	/**
	 * 根据单号 提交日期 单据状态  查询申请单列表
	 * @param form
	 * @param userId
     * @return
     */
	Page<DocumentInfo> listDraftDoc(@Param("form")QueryForm form, @Param("userId")String userId);

	/**
	 *根据单号 提交日期 单据状态  查询申请单列表
	 * @param form
	 * @param userId
     * @return
     */
	Page<DocumentInfo> listApplyDoc(@Param("form")QueryForm form,  @Param("userId")String userId);

	/**
	 * 根据申请单号 提交日期区间 金额区间  供应商 事由 单据状态 查询申请单列表
	 * @param form
	 * @param userId
     * @return
     */
	Page<DocumentInfo> listPublicExpenseDoc(@Param("form")QueryForm form, @Param("userId") String userId);

	/**
	 *根据单号 提交日期 单据状态  查询报销单列表
	 * @param form
	 * @param userId
     * @return
     */
	Page<DocumentInfo> listPrivateExpenseDoc(@Param("form")QueryForm form,  @Param("userId")String userId);

	/**
	 *根据单号 提交日期 单据状态  查询借还款列表
	 * @param form
	 * @param userId
     * @return
     */
	Page<DocumentInfo> listLoanAndRepayDoc(@Param("form")QueryForm form,  @Param("userId")String userId);

	/**
	 * 查询预付款催收清单
	 * @param docid
	 * @param bukrsList
	 * @param expensorList
	 * @param lifnrList
	 * @param currencyList
	 * @param smaFeeList
	 * @return
	 */
	List<VendorFormHeader> listVendorAdvice(@Param("docid") String docid,
											@Param("bukrsList") List<String> bukrsList,
											@Param("expensorList") List<String> expensorList,
											@Param("lifnrList") List<String> lifnrList,
											@Param("currencyList") List<String> currencyList,
											@Param("smaFeeList") List<String> smaFeeList);
    /**
     * 查询外币借款清单
     */
	List<ForeignCurrencyLoanDetail> listForeignCurrencyLoans();

	/**
	 * 获取员工个人在途报销费用统计信息按照报销单据类别统计
	 * @param userId
	 * @return
	 */
	List<ChartData> getOnlineReimTotal(@Param("userId") String userId);
}
