
package com.hikvision.it.expense.webservice.client.crm.partner;

import javax.xml.bind.JAXBElement;
import javax.xml.bind.annotation.XmlElementDecl;
import javax.xml.bind.annotation.XmlRegistry;
import javax.xml.namespace.QName;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hikvision.it.expense.crm.webservice.client.partner package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {

    private final static QName _ListOfHikAccountPartnerForFinance_QNAME = new QName("http://www.siebel.com/xml/HIK%20Account-Partner%20For%20Finance", "ListOfHikAccountPartnerForFinance");

    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hikvision.it.expense.crm.webservice.client.partner
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link ListOfHikAccountPartnerForFinance }
     * 
     */
    public ListOfHikAccountPartnerForFinance createListOfHikAccountPartnerForFinance() {
        return new ListOfHikAccountPartnerForFinance();
    }

    /**
     * Create an instance of {@link ListOfHikAccountPartnerForFinanceTopElmt }
     * 
     */
    public ListOfHikAccountPartnerForFinanceTopElmt createListOfHikAccountPartnerForFinanceTopElmt() {
        return new ListOfHikAccountPartnerForFinanceTopElmt();
    }

    /**
     * Create an instance of {@link HikAccountPartnerForInterface }
     * 
     */
    public HikAccountPartnerForInterface createHikAccountPartnerForInterface() {
        return new HikAccountPartnerForInterface();
    }

    /**
     * Create an instance of {@link AccListInput }
     * 
     */
    public AccListInput createAccListInput() {
        return new AccListInput();
    }

    /**
     * Create an instance of {@link AccListOutput }
     * 
     */
    public AccListOutput createAccListOutput() {
        return new AccListOutput();
    }

    /**
     * Create an instance of {@link JAXBElement }{@code <}{@link ListOfHikAccountPartnerForFinance }{@code >}}
     * 
     */
    @XmlElementDecl(namespace = "http://www.siebel.com/xml/HIK%20Account-Partner%20For%20Finance", name = "ListOfHikAccountPartnerForFinance")
    public JAXBElement<ListOfHikAccountPartnerForFinance> createListOfHikAccountPartnerForFinance(ListOfHikAccountPartnerForFinance value) {
        return new JAXBElement<ListOfHikAccountPartnerForFinance>(_ListOfHikAccountPartnerForFinance_QNAME, ListOfHikAccountPartnerForFinance.class, null, value);
    }

}
