package com.hikvision.it.expense.rpc.dao.fee;

import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Component;

import com.hikvision.it.expense.api.entity.fee.FeeDetail;

@Component
public interface IFeeItemDao {

    /**
     * 新增长途交通行项目
     */
    void insertCTJT(FeeDetail fee);

    /**
     * 新增住宿费用行项目
     * @param fee
     */
    void insertSTAYS(FeeDetail fee);

    /**
     * 新增市内交通行项目
     */
    void insertSNJT(FeeDetail fee);

    /**
     * 新增业务招待行项目
     */
    void insertYWZD(FeeDetail fee);

    /**
     * 新增其他行项目
     */
    void insertOTHER(FeeDetail fee);

    /**
     * 删除ofees表行项目
     */
    @Delete("delete from z_wem_bus_travel_ofees_detail where id = #{id, jdbcType=VARCHAR}")
    void deleteOfees(@Param("id") String id);

    /**
     * 删除stays表行项目
     */
    @Delete("delete from z_wem_bus_travel_stays_detail where id = #{id, jdbcType=VARCHAR}")
    void deleteStays(@Param("id") String id);

    @Update("update z_wem_bus_travel_stays_detail set seqno = seqno + #{num} where feetype = #{feeType} and seqno > #{rn}")
    void updateStaysSeqNo(@Param("rn")int rn, @Param("num")int num, @Param("feeType")String feeType);

    /**
     * 批量删除住宿信息
     */
    @Delete("delete from z_wem_bus_travel_stays_detail where processid = #{docId, jdbcType=VARCHAR} and feetype = 'STAYS'")
    void batchDeleteStays(@Param("docId") String docId);

    /**
     * 查询OFEES表单据费用明细(市内交通,业务招待,其他)
     */
    List<FeeDetail> findOfeesAll(@Param("docId") String docId, @Param("language") String language);

    /**
     * 查询STAYS表单据费用明细(长途交通, 住宿费用)
     */
    List<FeeDetail> findStaysAll(@Param("docId") String docId, @Param("language") String language);

    /**
     * 查询OFEES表单个费用行项目
     */
    FeeDetail findOfeesOne(@Param("id") String id, @Param("language") String language);

    /**
     * 查询Stays表单个费用行项目
     */
    FeeDetail findStaysOne(@Param("id") String id, @Param("language") String language);

    @Select("select count(*) from z_wem_bus_travel_ofees_detail where processid = #{docId, jdbcType=VARCHAR} and feetype in ('SNJT', 'YWZD', 'OTHER')")
    int countOfees(@Param("docId") String docId);

}
