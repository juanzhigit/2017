package com.hikvision.it.expense.rpc.provider.behavior;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.enums.BehaviorEnum;
import com.hikvision.it.expense.api.service.behavior.IBehaviorService;

/**
 * 行为service
 * <p>Title: BehaviorProvider.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月11日
 *
 */
@Service(version= Version.VERSION_LATEST)
public class BehaviorProvider implements IBehaviorService {
	@Autowired
    IBehaviorService behaviorService;

	@Override
	public void recordSelectTripCity(TripDays tripDays) {
		behaviorService.recordSelectTripCity(tripDays);
	}

	@Override
	public void recordSelectOpt(BehaviorEnum behavior, SelectOpt opt) {
		behaviorService.recordSelectOpt(behavior, opt);
	}

	@Override
	public List<TripCity> findCommonUsedCity() {
		return behaviorService.findCommonUsedCity();
	}

	@Override
	public List<SelectOpt> findCommonUsedOpt(BehaviorEnum behavior) {
		return behaviorService.findCommonUsedOpt(behavior);
	}

}
