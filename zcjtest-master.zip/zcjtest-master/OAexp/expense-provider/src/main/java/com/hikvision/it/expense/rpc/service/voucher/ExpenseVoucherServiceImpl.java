package com.hikvision.it.expense.rpc.service.voucher;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.dept.Dept;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.api.enums.FIOrderStatus;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.service.pi.OrderServiceImpl;
import com.hikvision.it.expense.rpc.util.CalculateUtil;
import com.hikvision.it.expense.api.entity.fee.FeeType;
import com.hikvision.it.expense.rpc.util.VoucherConstant;

@Service(value="expenseVoucherServiceImpl")
public class ExpenseVoucherServiceImpl extends AbstractVoucherService {
	@Autowired
	IBaseDao baseDao;
	@Autowired
	IFormDao formDao;
	@Autowired
	OrderServiceImpl orderService;
	@Autowired
	IVoucherService voucherService;
	
	@Override
	HikResult<List<Voucher>> previewVoucher(FormHeader header, Integer refIndex) {
		HikResult<List<Voucher>> rs = new HikResult<List<Voucher>>();
		List<Voucher> vouchers = Lists.newArrayList();
		
		//计算未清统计
		HikResult<Map<String, BigDecimal>> wqRs = this.calculateBsik(header);
		if (wqRs.isSuccess()) {
			Voucher vouchBean = new Voucher();
			// 获取凭证抬头
			VoucherHeader vouchHeader = getExpVouchHeader(header , wqRs.getData(), refIndex);
			// 设置凭证抬头和凭证明细到凭证entity中
			vouchBean.setVoucherHeader(vouchHeader);
			// 生成凭证行项目
			String bukrs = header.getBukrs();
			String userId = header.getExpensor();
			String deptCode = header.getDeptCode();
			// 获取部门研发订单信息和部门类别信息
			Dept dept = baseDao.findDeptOrderInfo(bukrs, deptCode);
			String deptType = Strings.isNullOrEmpty(dept.getOrderNo()) ? "00" : "01";
			if ("01".equalsIgnoreCase(deptType) &&
					Strings.isNullOrEmpty(dept.getRlDept())) {
				rs.getErrorMsgs().add("部门" + deptCode + "在公司" + bukrs + "下未获取到实际部门，请联系66000创建或者扩展员工供应商！");
			} else if (Strings.isNullOrEmpty(dept.getCostCenter())) {
				rs.getErrorMsgs().add("部门" + deptCode + "在公司" + bukrs + "下未获取到成本中心，请联系66000创建或者扩展员工供应商！");
			}
			//获取员工内部订单
			String sapUserId = orderService.getSapOrderIdFromLocal(userId, bukrs);
			if (Strings.isNullOrEmpty(sapUserId))
				rs.getErrorMsgs().add("公司" + bukrs + "下未获取到员工(" + userId + ")的内部订单，请联系66000创建或者扩展员工供应商！");
			String docId = header.getDocId();
			//获取费用明细
			List<FeeDetail> feeDetails = formDao.matchFeeDetailSubject(docId, bukrs, deptType);
			//获取补贴
			List<FeeDetail> staysDetails = formDao.listStaysFeeDetail(docId, bukrs, deptType);
			//获取重复餐补扣款汇总
			FeeDetail feeDetail = formDao.countDuplicateFoodSubsidy(docId, bukrs, deptType);
			if (ListUtil.isEmpty(staysDetails)) {
				staysDetails = formDao.listOldStaysFeeDetail(docId, bukrs, deptType);
			}
			//补贴凭证明细
			if (!ListUtil.isEmpty(staysDetails)) {
				feeDetails.addAll(staysDetails);
			}
			//存放所有凭证明细行
			List<VoucherItem> items = vouchBean.getVoucherItems();
			// 生成借方凭证
			items.addAll(this.packageDebitVoucherItem(vouchHeader, dept, sapUserId, feeDetails));
			if (feeDetail != null) {
				//生成扣款反记账明细
				items.add(this.packageDuplicateAllowanceVoucherItem(feeDetail, items.size(), dept, sapUserId));
			}
			// 生成贷方凭证
			items.addAll(this.packageCreditVoucherItem(vouchHeader, items.size(), feeDetail));
			//添加凭证entity到凭证列表中
			vouchers.add(vouchBean);

			rs.setData(vouchers);
		} else {
			rs.getErrorMsgs().addAll(wqRs.getErrorMsgs());
		}

		return rs;
	}
	
	/**
	 * 凭证明细行生成
	 */
	private List<VoucherItem> packageCreditVoucherItem(VoucherHeader voucherHeader, 
													   int startIndex, FeeDetail subDetail) {
		//当为他人收款时设置贷方凭证
		List<VoucherItem> voucherItems = Lists.newArrayList();
		//他人收款 贷方凭证
		List<OtherReceivor> dsdfList = formDao.listOtherReceivers(voucherHeader.getDocId());
		if (ListUtil.isEmpty(dsdfList)) {
			//根据清帐金额和报销总金额生成凭证明细 非他人收款时贷方凭证
			voucherItems.addAll(getExpCreditVouchDetailNoOtherRecevior(startIndex, voucherHeader, subDetail));
		} else {
			voucherItems.addAll(this.getExpCreditVouchDetail(startIndex + voucherItems.size(), voucherHeader, dsdfList));
		}
		
		return voucherItems;
	}
	
	/**
	 * 生成贷方凭证明细
	 */
	private List<VoucherItem> getExpCreditVouchDetailNoOtherRecevior(int lineNo, VoucherHeader header, FeeDetail subDetail) {
		List<VoucherItem> list = Lists.newArrayList();
		
		String userCode = header.getUserId();
		String userName = header.getUserName();
		BigDecimal qzje = header.getClrAmount();
		BigDecimal amount = header.getAmount();
		String vouchDate = DateUtil.getCurrentDateString();
		
		if (qzje.compareTo(BigDecimal.ZERO) > 0) {
			// ------贷方(credit)凭证信息-其他应收款-----
			VoucherItem detailCr = new VoucherItem();
			
			detailCr.setHeaderId(header.getHeaderId());
			detailCr.setItemId(StringUtil.getUUID());
			detailCr.setRn(lineNo + list.size() + 1);
			// BSCHL 记账码
			detailCr.setBschl(VoucherConstant.BSCHL_39);
			// GL_ACCOUNT 总账科目
			detailCr.setGlAccount(userCode);
			//设置科目描述
			detailCr.setGlAccountName(userName);
			// SP_GL_IND 特别总账标志 O
			detailCr.setSpGlInd(VoucherConstant.SP_GL_O);
			// 到期日
			detailCr.setBlineDate(vouchDate);
			// TAX_AMT 凭证货币金额
			if (subDetail != null && subDetail.getPaymentAmount() != null) {
				detailCr.setTaxAmt(qzje.subtract(subDetail.getPaymentAmount()));
			} else {
				detailCr.setTaxAmt(qzje);
			}
			// 付款方式 C
			detailCr.setPymtMeth(VoucherConstant.PYMT_C);
			
			list.add(detailCr);
		}
		
		//应付凭证
		if (amount.compareTo(qzje) > 0) {
			BigDecimal yfje = amount.subtract(qzje);
			
			VoucherItem detailCr2 = new VoucherItem();

			detailCr2.setHeaderId(header.getHeaderId());
			detailCr2.setItemId(StringUtil.getUUID());
			detailCr2.setRn(lineNo + list.size() + 1);
			// BSCHL 记账码31
			detailCr2.setBschl(VoucherConstant.BSCHL_31);
			// GL_ACCOUNT 总账科目
			detailCr2.setGlAccount(userCode);
			//科目描述
			detailCr2.setGlAccountName(userName);
			// TAX_AMT 凭证货币金额/*费用总金额-清账金额=员工应收金额*/
			if (subDetail == null) {
				detailCr2.setTaxAmt(yfje);
			} else {
				detailCr2.setTaxAmt(yfje.subtract(subDetail.getPaymentAmount()));
			}
			// PMNTTRMS	付款条件代码
			detailCr2.setPmnttrms(VoucherConstant.PMNTTRMS_T000);
			// BLINE_DATE	到期日计算的基限日期
			detailCr2.setBlineDate(vouchDate);
			//付款方式目前写死银行转账
			detailCr2.setPymtMeth(VoucherConstant.PYMT_C);
			
			list.add(detailCr2);
		}
		
		return list;
	}
	
	/**
	 * 生成贷方凭证明细
	 * @param lineNo
	 * @param header
	 * @param dsdfList		代收代付明细
	 */
	private List<VoucherItem> getExpCreditVouchDetail(int lineNo, VoucherHeader header, 
													  List<OtherReceivor> dsdfList) {
		List<VoucherItem> list = Lists.newArrayList();
		String vouchDate = DateUtil.getCurrentDateString();
		
		//生成每个收款人的凭证行项目
		BigDecimal sjDsdfAmt = BigDecimal.ZERO;
		for (OtherReceivor dsdf : dsdfList) {
			VoucherItem detailCr2 = new VoucherItem();
			
			detailCr2.setHeaderId(header.getHeaderId());
			detailCr2.setItemId(StringUtil.getUUID());
			detailCr2.setRn(lineNo + list.size() + 1);
			// BSCHL 记账码31
			detailCr2.setBschl(VoucherConstant.BSCHL_31);
			// GL_ACCOUNT 总账科目
			detailCr2.setGlAccount(dsdf.getUserId());
			//科目描述
			detailCr2.setGlAccountName(dsdf.getUserName());
			// TAX_AMT 凭证货币金额
			detailCr2.setTaxAmt(dsdf.getPayAmount());
			// PMNTTRMS	付款条件代码
			detailCr2.setPmnttrms(VoucherConstant.PMNTTRMS_T000);
			// BLINE_DATE	到期日计算的基限日期
			detailCr2.setBlineDate(vouchDate);
			//付款方式目前写死银行转账
			detailCr2.setPymtMeth(VoucherConstant.PYMT_C);
			
			list.add(detailCr2);
			
			sjDsdfAmt = sjDsdfAmt.add(dsdf.getPayAmount());
		}
		//比较收款总金额与实际报销总金额，如果收款总金额小于实际报销总金额，需要给报销人生成一个付款项
		BigDecimal amount = header.getAmount();
		if (sjDsdfAmt.compareTo(amount) < 0) {
			BigDecimal syyf = amount.subtract(sjDsdfAmt);    //剩余应付
			BigDecimal clearAmt = header.getClrAmount();
			
			if (syyf.compareTo(clearAmt) != 1) {
				header.setClrAmount(syyf);
			}
			//获取借方明细
			list.addAll(this.getExpCreditVouchDetailNoOtherRecevior(lineNo + list.size(), header, null));
		} else {
			header.setClrAmount(BigDecimal.ZERO);
		}
		
		return list;
	}
	
	/**
	 * 生成凭证借方明细行
	 */
	private List<VoucherItem> packageDebitVoucherItem(VoucherHeader header, 
											    	  Dept dept, 
											    	  String sapUserId,
											    	  List<FeeDetail> feeDetails) {
		if (ListUtil.isEmpty(feeDetails)) {
			return Lists.newArrayList();
		}
		List<VoucherItem> rs = Lists.newArrayList();
		Map<String, VoucherItem> itemMap = Maps.newHashMap();
		
		int i = 1;
		VoucherItem item = null;
		VoucherItem taxItem = null;
		for (FeeDetail feeDetail : feeDetails) {
			String key = this.getKey(feeDetail);

			if (feeDetail.getTaxAmount() != null &&
					feeDetail.getTaxAmount().compareTo(BigDecimal.ZERO) > 0) {
				String taxKey = this.getTaxKey(feeDetail);
				//税分凭证分路生成
				if (!itemMap.containsKey(taxKey)) {
					taxItem = this.getExpDebitTaxVoucherItem(feeDetail, dept, i);
                    taxItem.setHeaderId(header.getHeaderId());
                    taxItem.setItemId(StringUtil.getUUID());

					i++;
				} else {
					taxItem = itemMap.get(taxKey);

					taxItem.setTaxAmt(taxItem.getTaxAmt().add(feeDetail.getTaxAmount()));
				}

				itemMap.put(taxKey, taxItem);
			}
			//正常费用分路
			if (!itemMap.containsKey(key)) {
				item = this.getExpDebitVoucherItem(feeDetail, dept, sapUserId, i);

				i++;
			} else {
				item = itemMap.get(key);

				item.setTaxAmt(item.getTaxAmt().add(feeDetail.getPaymentAmount()));
			}
			item.setHeaderId(header.getHeaderId());
			item.setItemId(StringUtil.getUUID());

			itemMap.put(key, item);
		}

		rs.addAll(itemMap.values());

		return rs;
	}

	/**
	 * 生成重复餐补扣款凭证明细行
	 * @param feeDetail
	 * @param itemSize
	 * @return
	 */
	private VoucherItem packageDuplicateAllowanceVoucherItem(FeeDetail feeDetail,
															 int itemSize,
															 Dept dept,
															 String sapOrderId) {
		VoucherItem item = new VoucherItem();

		item.setItemId(StringUtil.getUUID());
		item.setRn(itemSize + 1);
		item.setGlAccount(feeDetail.getSubject());
		item.setGlAccountName(feeDetail.getSubjectName());
		item.setBschl(VoucherConstant.BSCHL_50);
		// TAX_AMT 凭证货币金额
		item.setTaxAmt(feeDetail.getPaymentAmount());
		//设置税码  TAX_CODE 销售/购买税代码
		item.setTaxCode("J0");
		//设置凭证行属性
		setVoucherItemPropertiesByDeptType(item, dept, sapOrderId);

		return item;
	}

	/**
	 * 生成报销系统借方凭证明细
	 */
	private VoucherItem getExpDebitVoucherItem(FeeDetail feeDetail, 
											   Dept dept,
											   String sapUserId,
											   int lineNo) {
		BigDecimal amount = feeDetail.getPaymentAmount();
		if (feeDetail.getTaxAmount() != null) {
			amount = amount.subtract(feeDetail.getTaxAmount());
		}
		
		VoucherItem detailDr = new VoucherItem();
		// 设置会计科目以及科目的描述信息
		detailDr.setGlAccount(feeDetail.getSubject());
		detailDr.setGlAccountName(feeDetail.getSubjectName());
		// ITEMNO_ACC 会计凭证行项目编号
		detailDr.setRn(lineNo);
		// BSCHL 记帐代码
		detailDr.setBschl(VoucherConstant.BSCHL_40);
		//wbs
		String wbs = feeDetail.getWbs();
		if (!Strings.isNullOrEmpty(wbs) && 
				!"无".equalsIgnoreCase(wbs)) {
			detailDr.setWbsElement(wbs);
		}
		//设置税码  TAX_CODE 销售/购买税代码
		detailDr.setTaxCode("J0");
		// TAX_AMT 凭证货币金额
		detailDr.setTaxAmt(amount);
		//设置凭证行属性
		this.setVoucherItemPropertiesByDeptType(detailDr, dept, sapUserId);
		detailDr.setAllocNmbr(wbs);
		
		return detailDr;
	}
	
	/**
	 * 生成报销系统借方税分凭证明细
	 */
	private VoucherItem getExpDebitTaxVoucherItem(FeeDetail feeDetail, 
											      Dept dept,
											      int lineNo) {
		BigDecimal amount = feeDetail.getTaxAmount();			//调整后税额本位币金额
		
		VoucherItem detailDr = new VoucherItem();
		// 设置会计科目以及科目的描述信息
		detailDr.setGlAccount(feeDetail.getTaxSubject());
		detailDr.setGlAccountName(feeDetail.getTaxSubjectName());
		// ITEMNO_ACC 会计凭证行项目编号
		detailDr.setRn(lineNo);
		// BSCHL 记帐代码
		detailDr.setBschl(VoucherConstant.BSCHL_40);
		// TAX_AMT 凭证货币金额
		detailDr.setTaxAmt(amount);
		
		return detailDr;
	}
	
	/**
	 * 计算报销系统在途未清以及sap未清明细
	 */
	private HikResult<Map<String, BigDecimal>> calculateBsik(FormHeader header) {
		String userId = header.getExpensor();
		String bukrs = header.getBukrs();

		BigDecimal ztwqAmt = voucherService.countOnlineReim(bukrs, userId).getTotal();
		
		return this.countWQJEAndDQWQJE(userId, bukrs, ztwqAmt);
	}
	
	/**
	 * 生成报销凭证抬头
	 */
	private VoucherHeader getExpVouchHeader(FormHeader header, 
											Map<String, BigDecimal> wqMap, 
											int index) {
		VoucherHeader voucherHeader = new VoucherHeader();		//凭证抬头
		
		// -----凭证抬头-----
  		// userId 产生费用的用户
  		String userId = header.getExpensor();
  		// CURRENCY 币别
  		String currency = header.getCurrency();
  		// AMOUNT 费用总金额
  		BigDecimal amount =  CalculateUtil.setScale(header.getPayAmount());
		// BRTAMOUNT 未清项总金额
  		BigDecimal wqJe = CalculateUtil.setScale(wqMap.get(VoucherConstant.WQJE));
  		voucherHeader.setBrtAmount(wqJe);	
		//到期未清金额	
		BigDecimal dqwqje = CalculateUtil.setScale(wqMap.get(VoucherConstant.DQWQJE));
		voucherHeader.setDqwqAmount(dqwqje);		
		//清帐金额
		BigDecimal qzje = BigDecimal.valueOf(0);
		//当流程类型为非个人借款时，进行清帐金额的设置
		if (dqwqje.compareTo(BigDecimal.ZERO) > 0) {
			if (amount.compareTo(dqwqje) >= 0) {
				qzje = dqwqje;
			} else {
				qzje = amount;
			}
		} else {
			qzje = BigDecimal.ZERO;
		}
  		String docNo = header.getDocNo();// 单据号
  		String userName = header.getExpensorName();

  		voucherHeader.setHeaderId(StringUtil.getUUID());
		voucherHeader.setClrAmount(qzje);//清帐金额
  		voucherHeader.setAmount(amount);
		//设置请求中的清帐金额、未清金额
  		voucherHeader.setRn(index);
  		voucherHeader.setBukrs(header.getBukrs());
  		voucherHeader.setCurrency(currency);
		voucherHeader.setDocNo(docNo);
		voucherHeader.setDocId(header.getDocId());
		voucherHeader.setRefDocNo(getReference(docNo, index));// 凭证重复创建,值为单据号+序号（“1100000019”+ “01”：110000001901）(At August.07,2014)
		voucherHeader.setDocDate(DateUtil.getCurrentDateString()); // 凭证日期
		voucherHeader.setUserId(userId);
		voucherHeader.setUserName(userName);
		voucherHeader.setVoucherType(VoucherConstant.DOCTY_AB);
		voucherHeader.setFiOrderStatus(FIOrderStatus.F001.name());
		String twoLevelDeptName = this.getFirstTwoLevelDeptName(header.getDeptCode());
		String vouchHeader = userName + "-报销-" + twoLevelDeptName;
		voucherHeader.setHeaderTxt(vouchHeader);//凭证抬头
		
		return voucherHeader;
	}
	
	/**
	 * 获取合并key
	 */
	private String getKey(FeeDetail feeDetail) {
		String feeType = feeDetail.getFeeType();
		
		if (Strings.isNullOrEmpty(feeType) || 
				FeeType.OTHER.equalsIgnoreCase(feeType)) {
			return StringUtil.getUUID();
		} else {
			return feeDetail.getSmaFeeType() + feeDetail.getWbs();
		}
	}
	
	/**
	 * 获取合并税分key
	 */
	private String getTaxKey(FeeDetail feeDetail) {
		String taxSubject = feeDetail.getTaxSubject();
		
		if (!Strings.isNullOrEmpty(taxSubject)) {
			return taxSubject;
		} else {
			throw new ExpenseException(ExceptionCode.VOUCH_ERROR_TAX_SUBJECT_NOT_CFG);
		}
	}
}
