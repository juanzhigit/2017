package com.hikvision.it.expense.rpc.dao.user;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.hikvision.it.expense.api.entity.user.SearchUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.entity.user.UserBank;

public interface IUserDao {
	/**
	 * 根据员工登录名称、语言获取员工信息
	 * @param userShortName
	 * @param language			语言
	 * @return
	 */
	User findUserByUserShortName(@Param("userShortName") String userShortName, 
								 @Param("language") String language);
	
	/**
	 * 获取超级管理员标识
	 * @param userId
	 * @return
	 */
	String getSuperAdmin(@Param("userId") String userId);
	
	/**
	 * 根据员工编号获取员工信息
	 * @param userId
	 * @param language
	 * @return
	 */
	User findUserByUserId(@Param("userId") String userId, 
						  @Param("language") String language);
	
	/**
	 * 根据员工授权信息获取员工授权信息
	 * @param userId
	 * @param docType
	 * @param language
	 * @return
	 */
	List<User> findAuthUser(@Param("userId") String userId, 
							@Param("docType") String docType,
							@Param("language") String language);
	
	/**
	 * 过滤查询同行人列表
	 * @param filter
	 * @param language
	 * @return
	 */
	List<SearchUser> findUserToAddTripTogether(@Param("filter") String filter,
											   @Param("language") String language);
	
	/**
	 * 查询员工授权权限范围
	 * @param userId
	 * @param docType
	 * @param language
	 * @return
	 */
	List<User> findUserAuthScope(@Param("userId") String userId, 
							     @Param("docType") String docType,
							     @Param("language") String language);

	/**
	 * 查询员工信用
	 *
	 * @param paramMap
	 *  参数中包含下面属性值：empid
	 *  				  indate
	 *  				  lv_code
	 *  				  lv_desc
	 * @return
	 */
	String getCreditByEmpid(@Param("paramMap") Map<String, Object> paramMap);
	
	/**
	 * 根据索引key获取接受邮件员工信息
	 * @param key
	 * @return
	 */
	User findMailUserByKey(@Param("key") String key);
	
	/**
	 * 获取员工岗位级别
	 * @param userId
	 * @return
	 */
	@Select("select p.user_postlevel from hikepadm.z_wem_basic_person_info p "
		   + "where p.user_empid = #{userId, jdbcType=VARCHAR}")
	String getUserPostGrade(@Param("userId") String userId);
	
	/**
	 * 获取员工级别
	 * @param userId
	 * @return
	 */
	@Select("select p.pergradeid from hikepadm.z_wem_basic_person_info p "
			   + "where p.user_empid = #{userId, jdbcType=VARCHAR}")
	String getUserGrade(@Param("userId") String userId);
	
	/**
	 * 获取分总数量
	 * @param userId
	 * @return
	 */
	@Select("select count(1) from hikepadm.z_wem_basic_fgs t where t.user_empid = #{userId, jdbcType=VARCHAR}")
	int countBranchManager(@Param("userId") String userId);
	
	/**
	 * 判断分公司人员数量
	 * @param userId
	 * @return
	 */
	int countBranchUser(@Param("userId") String userId);
	
	/**
	 * 获取员工银行账号
	 * @param userBank
	 * @return
	 */
	int findUserBank(@Param("userBank") UserBank userBank);
	
	/**
	 * 删除员工银行账号
	 * @param userBank
	 * @return
	 */
	int deleteUserBank(@Param("userBank") UserBank userBank);
	
	/**
	 * 记录员工银行卡信息
	 * @param userBank
	 * @return
	 */
	int recordUserBank(@Param("userBank") UserBank userBank);
	
	/**
	 * 批量记录员工银行卡信息
	 * @param userBanks
	 * @return
	 */
	int batchRecordUserBank(@Param("userBanks") List<UserBank> userBanks);
	
	/**
	 * 匹配员工银行账号
	 * @param userBanks
	 * @return
	 */
	List<UserBank> matchUserBank(@Param("userBanks") List<UserBank> userBanks);
	
	/**
	 * 获取sap员工内部订单
	 * @param userId
	 * @param bukrs
	 * @return
	 */
	String getSAPOrderId(@Param("userId") String userId, @Param("bukrs") String bukrs);
	
	/**
	 * 删除sap员工内部订单
	 * @param userId
	 * @param bukrs
	 * @return
	 */
	String deleteSAPOrderId(@Param("userId") String userId, @Param("bukrs") String bukrs);
	
	/**
	 * 记录sap员工内部订单
	 * @param userId
	 * @param bukrs
	 * @param orderId
	 * @return
	 */
	int recordSapOrderId(@Param("userId") String userId, 
						 @Param("bukrs") String bukrs, 
						 @Param("orderId") String orderId);

	@Select("select user_empid from z_wem_basic_person_info where pergradeid = 'M5'")
    List<String> getVpUserIds();

    /**
     * 获取员工所在部门的部门代码路径
     */
	@Select("select deptcodepath from z_wem_basic_department_info d, z_wem_basic_person_info p where d.deptcode = p.user_deptcode and p.user_empid = #{userId}")
	String getDeptCodePath(String userId);

	boolean isBranch(String userId);
}
