package com.hikvision.it.expense.rpc.dao.base;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.base.Notice;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.SubBukrsFxwd;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.bukrs.Bukrs;
import com.hikvision.it.expense.api.entity.dept.Dept;

public interface IBaseDao {
	/**
	 * 获取所有节假日信息
	 * @param bukrs
	 * @param fromDate
	 * @param toDate
	 * @return
	 */
	List<HolidayWork> listHolidays(@Param("bukrs") String bukrs,
								   @Param("fromDate") Date fromDate, 
								   @Param("toDate") Date toDate);
	
	/**
	 * 根据员工、单据类别获取付款币别/
	 * @param userId
	 * @param docType
	 * @return
	 */
	List<SelectOpt> findSelectCurrencyByUser(@Param("userId") String userId,
											  @Param("docType") String docType);
	
	/**
	 * 根据过滤字段查询可选币别
	 * 
	 * 可输入国家名称、国家代码、币别、币别描述进行筛选
	 * 
	 * @param filter
	 * @param language
	 * @return
	 */
	List<SelectOpt> findSelectCurrency(@Param("filter") String filter, 
									   @Param("language") String language);

	/**
	 * 根据过滤字段查询可选科目
	 *
	 * @param filter
	 * @param language
	 * @return
	 */
	List<SelectOpt> findSelectGlAcccount(@Param("filter") String filter,
									   @Param("language") String language);
	
	/**
	 * 根据公司、单据类别获取付款币别
	 * @param bukrs
	 * @param docType
	 * @return
	 */
	List<SelectOpt> findSelectCurrencyByBukrs(@Param("bukrs") String bukrs,
											   @Param("docType") String docType);
	
	/**
	 * 根据语言获取差旅交通工具信息
	 * @param language
	 * @return
	 */
	List<SelectOpt> findTipTool(@Param("language") String language);
	
	/**
	 * 查询差旅城市列表
	 * @param filter		筛选值
	 * @param language		语言
	 * @return
	 */
	List<TripCity> findTripCity(@Param("filter") String filter, @Param("language") String language);
	
	/**
	 * 根据获取热门城市
	 * @param language
	 * @return
	 */
	List<TripCity> findHotCity(@Param("language") String language);

	/**
	 * 根据公司代码获取base地
	 * @param bukrs
	 * @return
	 */
	String getBukrsBaseCountry(@Param("bukrs") String bukrs);
	
	/**
	 * 获取单据的费用归属公司代办池启用标识
	 * @param docId
	 * @return
	 */
	String getBukrsAccountingPoolPlag(@Param("docId") String docId);
	
	/**
	 * 根据消费日期、消费币别获取兑美元汇率基数
	 * @param date
	 * @param currency
	 * @return
	 */
	BigDecimal findRateBaseValue(@Param("date") String date, 
								 @Param("currency") String currency);
	
	/**
	 * 获取现金科目
	 * @param currency
	 * @param language
	 * @return
	 */
	SelectOpt findCurrencySubject(@Param("currency") String currency,
								  @Param("language") String language);
	
	/**
	 * 获取银行存款科目
	 * @param bukrs
	 * @param currency
	 * @param language
	 * @return
	 */
	SelectOpt findBankSubjectByBukrs(@Param("bukrs") String bukrs,
									 @Param("currency") String currency,
			  						 @Param("language") String language);
	
	/**
	 * 根据公司代码、部门获取研发订单
	 * @param bukrs
	 * @param deptCode
	 * @return
	 */
	String findOrderNo(@Param("bukrs") String bukrs, 
					   @Param("deptCode") String deptCode);
	
	/**
	 * 根据公司代码、部门代码获取当前有效的研发订单配置信息和部门类别信息
	 * @param deptCode
	 * @return
	 */
	Dept findDeptOrderInfo(@Param("bukrs") String bukrs, 
					  	   @Param("deptCode") String deptCode);

	/**
	 * 分页查询公告信息
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<Notice> listNotices(@Param("pageNumber") int pageNumber,
							 @Param("pageSize") int pageSize);

	/**
	 * 根据语言、国家获取币别下拉选项
	 * @param language
	 * @param country
	 * @return
	 */
	List<SelectOpt> listCurrencyOpt(@Param("language") String language,
									@Param("country") String country);

	/**
	 * 获取市内交通工具类别
	 * @param language
	 * @return
	 */
	List<SelectOpt> listCityTraficTool(@Param("language") String language);

	/**
	 * 获取所有报销费用类别
	 * @param language
	 * @return
	 */
	List<SelectOpt> listExpenseFeeType(@Param("language") String language);
	
	/**
	 * 根据公司代码、单据类别、报销类别获取费用类别
	 * @param bukrs
	 * @param docType
	 * @param expenseType
	 * @param language
	 * @return
	 */
	List<SelectOpt> listDocExpenseFeeType(@Param("bukrs") String bukrs, 
									   	  @Param("docType") String docType, 
									   	  @Param("expenseType") String expenseType,
									   	  @Param("language") String language);

	/**
	 * 获取部门路径
	 */
	@Select("select deptpath from hikepadm.z_wem_basic_department_info where deptcode = #{deptCode, jdbcType=VARCHAR}")
    String findDeptPath(@Param("deptCode") String deptCode);
	
	/**
	 * 查询交通项目
	 * @param filter
	 * @return
	 */
	@Select("select t.traproj id, t.traprojname text "
			+ "from hikepadm.z_wem_basic_travel_project t "
			+ "where regexp_like(concat(upper(t.traproj), "
							         + "upper(t.traprojname)), "
							    + "upper(#{filter, jdbcType=VARCHAR})) "
			+ "and rownum <= 10")
	List<SelectOpt> listTrafficProject(String filter);
	
	/**
	 * 获取员工所属销售区域
	 * @param userId
	 * @return
	 */
	List<SelectOpt> listSalesArea(String userId);
	
	/**
	 * 获取公司信息
	 * @return
	 */
	List<SelectOpt> getCompanyInfo(@Param("searchText") String searchText);
	
	/**
	 * 获取行业信息
	 * @return
	 */
	@Select("select t.industid id, t.industname text from hikepadm.z_bc_indust t where t.flag = 'D' order by seqnum")
	List<SelectOpt> listIndustry();

	/**
	 * 招待方式
	 */
	@Select("select datacode id, shorttext text from hikepadm.z_wem_data_directory_view where datatype = 'D311' and language = #{language, jdbcType=VARCHAR}")
    List<SelectOpt> listEntertains(@Param("language") String language);

	/**
	 * 招待级别
	 */
	@Select("select datacode id, shorttext text from hikepadm.z_wem_data_directory_view where datatype = 'D115' and language = #{language, jdbcType=VARCHAR}")
    List<SelectOpt> listEntertainLevels(@Param("language") String language);

	@Select("select deptName from z_wem_basic_department_info where deptcode = #{deptCode, jdbcType=VARCHAR}")
    String findDeptName(@Param("deptCode") String deptCode);

	@Select("select companyname from z_wem_basic_company_info where companycode = #{bukrs, jdbcType=VARCHAR}")
    String findBukrsName(@Param("bukrs") String bukrs);
	
	/**
	 * 匹配部门的分公司分析维度权限
	 * @param deptCode
	 * @return
	 */
	List<SubBukrsFxwd> matchSubBukrsFxwd(@Param("deptCode") String deptCode);
	
	/**
	 * 根据部门代码获取是否需要商机、客户、用户
	 * (岗位序列=’营销序列’或者(岗位序列=’管理序列’并且岗位子序列=’营销管理’))并且部门路径 <>’国内营销中心->销售管理部/经销渠道部/客户管理部/市场部/业务培训部/运营部(国内营销中心，排除部分部门)
	 * @param deptCode
	 * @return
	 */
	int countBussinessOptNeedAmount(@Param("deptCode") String deptCode);
	
	/**
	 * 获取员工是否需要填写售前派工
	 * @param userId
	 * @return
	 */
	String getUserNeedSqpgFlag(@Param("userId") String userId);

	/**
	 * 根据员工获取相应城市的住宿标准
	 * @param cities
	 * @param userId
	 * @return
	 */
	List<TripCity> matchCityStayStandrand(@Param("cities") List<TripCity> cities,
										  @Param("userId") String userId);

	/**
	 * 筛选公司
	 * @param filter
	 * @param language
	 * @return
	 */
	List<Bukrs> listBukrs(@Param("filter") String filter, @Param("language") String language);

	/**
	 * 查询供应商
	 * @param filter
	 * @return
	 */
	List<SelectOpt> listLifnr(@Param("filter") String filter);

	/**
	 * 查询业务细类
	 * @param filter
	 * @return
	 */
	List<SelectOpt> listAdviceSmaFee(@Param("filter") String filter);

	/**
	 * 获取费用类别名称
	 * @param expenseType
	 * @param language
	 * @return
	 */
	@Select("select shorttext from hikepadm.z_wem_data_directory_view where datatype = 'D202' and datacode = #{expenseType, jdbcType=VARCHAR} and language = #{language, jdbcType=VARCHAR}")
	String getExpenseTypeName(@Param("expenseType") String expenseType, @Param("language") String language);
}
