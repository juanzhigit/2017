package com.hikvision.it.expense.rpc.service.pi;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.order.BAPIRETURN1;
import com.hikvision.it.expense.webservice.client.pi.order.SIREIMBURSEGETORDERIDSYNOUT;
import com.hikvision.it.expense.webservice.client.pi.order.SIREIMBURSEGETORDERIDSYNOUTService;
import com.hikvision.it.expense.webservice.client.pi.order.ZIREIMBURSEGETORDERID;
import com.hikvision.it.expense.webservice.client.pi.order.ZIREIMBURSEGETORDERIDResponse;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;
import com.hikvision.it.expense.rpc.util.VoucherConstant;

@Service(value="orderServiceImpl")
public class OrderServiceImpl {
	@Value("${system.pi.order.url}")
	private String url;
	@Value("${system.pi.order.namespace}")
	private String nameSpace;
	@Value("${system.pi.order.localpart}")
	private String localPart;
	@Value("${system.pi.user}")
	private String piUser;
	@Value("${system.pi.password}")
	private String piUserPassWord;
	
	@Autowired
	private IUserDao userDao;
	
	/**
	 * 同步sap员工内部订单
	 * @param userId
	 * @param bukrs
	 */
	public String synchSapOrderId(String userId, String bukrs) {
		String orderId = this.getSapOrderId(userId, bukrs);
		
		if (!Strings.isNullOrEmpty(orderId))
			userDao.recordSapOrderId(userId, bukrs, orderId);

		return orderId;
	}
	
	/**
	 * 从本地获取员工sap内部订单
	 * @param userId
	 * @param bukrs
	 * @return
	 */
	public String getSapOrderIdFromLocal(String userId, String bukrs) {
		String orderId = userDao.getSAPOrderId(userId, bukrs);
		
		if (Strings.isNullOrEmpty(orderId)) {
			orderId = this.getSapOrderId(userId, bukrs);
			
			if (!Strings.isNullOrEmpty(orderId)) {
				try {
					userDao.recordSapOrderId(userId, bukrs, orderId);
				} catch (Exception e) {
				}
			}
		}
		
		return orderId;
	}
	
	/**
	 * 获取员工sap内部订单
	 * @param userId
	 * @param bukrs
	 * @return
	 */
	public String getSapOrderId(String userId, String bukrs) {
		URL wsdlURL = null;
		try {
			wsdlURL = new URL(url);
		} catch (MalformedURLException e) {
			e.printStackTrace();
			return null;
		}

		Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
		SIREIMBURSEGETORDERIDSYNOUTService ss = new SIREIMBURSEGETORDERIDSYNOUTService(wsdlURL, new QName(nameSpace, localPart));
		SIREIMBURSEGETORDERIDSYNOUT port = ss.getHTTPPort();

		BindingProvider bp = (BindingProvider) port;
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
		context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

		ZIREIMBURSEGETORDERID params = new ZIREIMBURSEGETORDERID();

		params.setIBUKRS(bukrs);
		params.setILIFNR(userId);

		ZIREIMBURSEGETORDERIDResponse response = port.getORDERID(params);

		BAPIRETURN1 retMsg = response.getESMSG();

		if (retMsg != null) {
			String returnType = retMsg.getTYPE();

			if(VoucherConstant.TYPE_S.equals(returnType)
					 || VoucherConstant.TYPE_W.equals(returnType)){
				return retMsg.getMESSAGE();
			}
		}

		return null;
	}
}
