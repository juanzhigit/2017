package com.hikvision.it.expense.rpc.service.plug;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.loan.LoanDetail;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;

/**
 * 根据单据信息判断任务流转环节
 * 		1、含有借款、报销、非M4、M5级别员工的差旅申请和行程变更 return TO_B01
 * 		2、还款  return TO_F05
 * 		3、M4、M5级别员工的差旅申请和行程变更   return TO_END
 * <p>Title: JudgeDocTypeService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
@Service(value="judgeDocTypeService")
public class JudgeDocTypeServiceImpl implements IExecutePlugService {
	@Autowired
	IFormDao formDao;
	@Autowired
	IUserDao userDao;
	
	@Override
	public String execute(TaskObject taskObject, String docId) {
		FormHeader header = formDao.getFormHeader(docId);
		List<LoanDetail> loans = formDao.getLoans(docId);
		
		String docType = header.getDocType();
		String grade = header.getExpensorGrade();
		
		if (ListUtil.isEmpty(loans)) {//不包含借款
			if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) ||
					DocTypeEnum.WEM002.name().equalsIgnoreCase(docType)) {
				if (Strings.isNullOrEmpty(grade)) {
					User user = userDao.findUserByUserId(header.getExpensor(), UserContext.getLanguage());
					
					if (user != null) {
						grade = user.getGrade();
					}
				}
				//差旅申请和行程变更  M4和M5级别人员不需要审批，其他人员需要审批
				if ("M4".equalsIgnoreCase(grade) || "M5".equalsIgnoreCase(grade)) {
					return "TO_END";
				}
			} else if (DocTypeEnum.WEM004.name().equalsIgnoreCase(docType)) {
				//还款先到出纳收款
				return "TO_F05";
			}
		}
		
		
		//默认都需要到主管审批
		return "TO_B01";
	}

}
