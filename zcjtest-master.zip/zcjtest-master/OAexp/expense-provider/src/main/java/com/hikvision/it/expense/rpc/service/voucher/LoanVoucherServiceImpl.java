package com.hikvision.it.expense.rpc.service.voucher;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.loan.LoanDetail;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.api.enums.FIOrderStatus;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.util.CalculateUtil;
import com.hikvision.it.expense.rpc.util.VoucherConstant;

@Service(value="loanVoucherServiceImpl")
public class LoanVoucherServiceImpl extends AbstractVoucherService {
	@Autowired
	IFormDao formDao;
	@Autowired
    IBaseDao baseDao;
	
	@Override
	public HikResult<List<Voucher>> previewVoucher(FormHeader header, Integer refIndex) {
		//获取借款明细
		List<LoanDetail> loans = formDao.getLoans(header.getDocId());
		
		if (!ListUtil.isEmpty(loans)) {
			List<Voucher> vouchers = Lists.newArrayList();
			
			for (LoanDetail loan : loans) {
				//获取凭证抬头
				VoucherHeader vouchHeader = getLoanVouchHeader(refIndex, header, loan);
				//获取凭证明细
				List<VoucherItem> vouchDetailList = genLoanVouchDetails(vouchHeader, loan);

				Voucher vouchBean = new Voucher();

				vouchBean.getVoucherItems().addAll(vouchDetailList);
				vouchBean.setVoucherHeader(vouchHeader);

				vouchers.add(vouchBean);

				refIndex++;
			}

			return HikResult.ok(vouchers);
		} else {
			//未获取到借款明细，抛出异常
			throw new ExpenseException(ExceptionCode.VOUCH_ERROR_DOC_NOT_LOAN);
		}
	}
	
	/**
	 * 生成凭证抬头
	 * @param index
	 * @param formHeader
	 * @param loan
	 * @return
	 */
	private VoucherHeader getLoanVouchHeader(int index, FormHeader formHeader, LoanDetail loan) {
		VoucherHeader header = new VoucherHeader();		//凭证抬头
		
		// -----凭证抬头-----
  		String userId = formHeader.getExpensor();
  		String currency = loan.getLoanCurrency();
  		String docNo = formHeader.getDocNo();
  		BigDecimal amount = CalculateUtil.setScale(loan.getPaymentAmount());

  		header.setHeaderId(StringUtil.getUUID());
  		header.setAmount(amount);
  		header.setRn(index);
  		header.setBukrs(formHeader.getBukrs());
		header.setCurrency(currency);
		header.setDocNo(docNo);
		header.setDocDate(DateUtil.getCurrentDateString());	//凭证日期
		header.setDocId(formHeader.getDocId());
		header.setRefDocNo(getReference(docNo, index));// 凭证重复创建,值为单据号+序号（“1100000019”+ “01”：110000001901）(At August.07,2014)
		header.setUserId(userId);
		header.setUserName(formHeader.getExpensorName());
		header.setVoucherType(VoucherConstant.DOCTY_AB);
		header.setDqwqAmount(BigDecimal.ZERO);
		header.setBrtAmount(BigDecimal.ZERO);
		header.setClrAmount(BigDecimal.ZERO);
		header.setFiOrderStatus(FIOrderStatus.F001.name());
		String twoLevelDeptName = getFirstTwoLevelDeptName(formHeader.getDeptCode());
		String vouchHeader = formHeader.getExpensorName() + "-借款-" + twoLevelDeptName;
		header.setHeaderTxt(vouchHeader);	//凭证抬头
		
		return header;
	}	
	
	/**
	 * 根据借款明细转换成凭证明细
	 * @param formHeader
	 * @param loan
	 * @return
	 */
	private List<VoucherItem> genLoanVouchDetails(VoucherHeader voucherHeader, LoanDetail loan) {
		List<VoucherItem> vouchList = Lists.newArrayList();
		
		int lineNo = 0;
		//生成借方凭证
		vouchList.add(getLoanDebitVouchDetail(voucherHeader, loan, ++lineNo));
		//生成贷方凭证
		vouchList.add(getLoanCreditVouchDetail(voucherHeader, loan, ++lineNo));

		return vouchList;
	}
	
	/**
	 * 获取借款借方凭证明细信息
	 * @param voucherHeader
	 * @param loan
	 * @param lineNo
	 * @return
	 */
	private VoucherItem getLoanDebitVouchDetail(VoucherHeader voucherHeader, 
												LoanDetail loan, 
												int lineNo) {
		BigDecimal amount = CalculateUtil.setScale(loan.getPaymentAmount());
		// ------借方(debit)凭证信息------
		VoucherItem voucherItem = new VoucherItem();

		voucherItem.setItemId(StringUtil.getUUID());
		voucherItem.setHeaderId(voucherHeader.getHeaderId());
		voucherItem.setRn(lineNo);
		// BSCHL 记账码
		voucherItem.setBschl(VoucherConstant.BSCHL_29);
		// GL_ACCOUNT 总账科目
		voucherItem.setGlAccount(voucherHeader.getUserId());
		//科目描述
		voucherItem.setGlAccountName(voucherHeader.getUserName());
		// TAX_AMT 凭证货币金额
		voucherItem.setTaxAmt(amount);
		// PMNTTRMS	付款条件代码
		voucherItem.setPmnttrms(VoucherConstant.PMNTTRMS_T000);
		// 到期日期
		voucherItem.setBlineDate(loan.getRepaymentDate());
		// SP_GL_IND 特别总账标志 O
		voucherItem.setSpGlInd(VoucherConstant.SP_GL_O);
		
		return voucherItem;
	}
	
	/**
	 * 获取贷方凭证明细
	 * @param voucherHeader
	 * @param loan
	 * @param lineNo
	 * @return
	 */
	private VoucherItem getLoanCreditVouchDetail(VoucherHeader voucherHeader, 
												 LoanDetail loan, 
												 int lineNo) {
		BigDecimal amount = CalculateUtil.setScale(loan.getPaymentAmount());
		// ------贷方(credit)凭证信息------
		VoucherItem detailBk = new VoucherItem();

		detailBk.setItemId(StringUtil.getUUID());
		detailBk.setHeaderId(voucherHeader.getHeaderId());
		// ITEMNO_ACC 会计凭证行项目编号
		detailBk.setRn(lineNo);
		//根据付款方式设置借款的贷方记账码 
		String paymentType = loan.getPaymentType();
		String drCode = VoucherConstant.BSCHL_31;
		/**
		 * 当现金借款时设置贷50的总帐科目为现金科目否则为员工供应商
		 */
		String acctSubj = voucherHeader.getUserId();	//总账科目   
		String acctSubjNm = voucherHeader.getUserName();
		String currency = loan.getLoanCurrency();
		if (StringUtil.isNotEmptyTrim(paymentType) && 
				VoucherConstant.PYMT_M.equalsIgnoreCase(paymentType)) {//现金
			drCode = VoucherConstant.BSCHL_50;
			//现金科目
			SelectOpt xjSubject = baseDao.findCurrencySubject(currency, UserContext.getLanguage());
			if (xjSubject == null)
				throw new ExpenseException(ExceptionCode.VOUCH_ERROR_XJ_SUBJECT_NOT_CFG);
			acctSubj = xjSubject.getId();	
			//获取科目描述
			acctSubjNm = xjSubject.getText();
			detailBk.setRstgr(VoucherConstant.RSTGR_119);			//原因代码
		} else {
			//银行转账
			// PMNTTRMS 付款条件代码
			String paymentCondition = VoucherConstant.PMNTTRMS_T000;
			detailBk.setPmnttrms(paymentCondition);				//付款条件
			detailBk.setPymtMeth(paymentType);					//付款方式
		}
		detailBk.setValueDate(loan.getLoanDate());			//付款基准日期
		// GL_ACCOUNT 总账科目
		detailBk.setGlAccount(acctSubj);				//设置科目
		detailBk.setGlAccountName(acctSubjNm);			//设置科目描述
		// BSCHL 记帐代码
		detailBk.setBschl(drCode);
		// TAX_AMT 凭证货币金额
		detailBk.setTaxAmt(amount);
		
		return detailBk;
	}
}
