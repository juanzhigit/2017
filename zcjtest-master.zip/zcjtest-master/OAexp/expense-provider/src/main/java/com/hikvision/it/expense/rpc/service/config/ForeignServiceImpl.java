package com.hikvision.it.expense.rpc.service.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableList;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.flow.MailEntity;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.logs.ISendLogDao;
import com.hikvision.it.expense.rpc.dao.trip.ITripDao;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.util.FormUtil;

/**
 * 1、国际差旅需要发送邮件给国际机票专员
 * 2、含有外币借款的单据需要发送外币借款邮件
 * 
 * <p>Title: ForeignServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月29日
 *
 */
@Service(value="foreignServiceImpl")
public class ForeignServiceImpl implements IExecuteService {

	/**
	 * 需要机票的交通工具代码
	 */
	private static final ImmutableList<String> airTicketToolCodes = ImmutableList.of("0314", "0315", "0316");

	@Value("${system.doc.direct}")
	private String docDirect;
	@Value("${system.url.jwx}")
	private String jwx;
	@Autowired
    IFormDao formDao;
	@Autowired
    ITripDao tripDao;
	@Autowired
    ISendLogDao logDao;
	@Autowired
	IUserDao userDao;
	@Autowired
	IBaseDao baseDao;
	@Autowired
	TemplateEngine templateEngine;

	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		FormHeader header = formDao.getFormHeader(process.getDocId());
		//国际差旅需要发送邮件给国际机票专员
		this.recordForeignAirTicketMail(header);
		//外币借款的单据需要发送外币借款邮件
		this.recordForeignLoanMail(header);
	}

	
	/**
	 * 记录外币借款邮件日志
	 * @param header
	 */
	private void recordForeignLoanMail(FormHeader header) {
		String docType = header.getDocType();
		String docId = header.getDocId();
		String docNo = header.getDocNo();
		
		if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) || 
				DocTypeEnum.WEM003.name().equalsIgnoreCase(docType)) {
			//差旅申请或者借款时需要获取外币借款数量
			int foreignLoanNum = formDao.countForeignLoanNumbers(docId);
			//存在外币借款
			if (foreignLoanNum > 0) {
				//获取外币专员
				User mailTo = userDao.findMailUserByKey("WB_CN");
				//存在机票信息则将参数设置model中，传给模板引擎进行渲染
				MailEntity mail = new MailEntity();
				//获取打开单据链接
				String url = docDirect + docId;
				
				Context model = new Context();
				//设置查看单据url
				model.setVariable("url", url);
				model.setVariable("applyId", docNo);
				model.setVariable("WBCNFZR", mailTo.getUserName() + " (" + mailTo.getInMail() + ")");
				
				//设置邮件正文
				mail.setContent(this.getMessage("zh/wbloan", model));
				Object[] args = { docNo };
				//设置邮件标题
				mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_FOREIGN_LOAN_TEMP, args));
				//获取报销人邮箱
				String toAddress = formDao.getDocCreatorsMailAddress(docId);;
				if (!Strings.isNullOrEmpty(toAddress)) {
					mail.setReceivors(toAddress);
					//设置内外网邮件
					mail.setIsOutMail("N");
					mail.setDocId(docId);
					mail.setIsApprove(YesOrNoEnum.N.name());
					//记录邮件日志
					logDao.recordMailInfo(mail);
				}
			}
		}
	}
	
	/**
	 * 国家差旅需要发送邮件给国际差旅订票专员
	 * 交通工具存在飞机,且不是自订机票
	 * <pre>
	 * 0314	经济舱
	 * 0315	商务舱
	 * 0316	头等舱
	 * 0317	自订票
	 * </pre>
	 */
	private void recordForeignAirTicketMail(FormHeader header) {
		String language = UserContext.getLanguage();
		
		String docId = header.getDocId();
		String docType = header.getDocType();
		//差旅申请、行程变更提交后发送邮件给国家订票专员
		if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) || 
				DocTypeEnum.WEM002.name().equalsIgnoreCase(docType)) {
			List<Trip> trips = tripDao.getTrips(docId, language);
			//获取公司base地
            String baseCountry = baseDao.getBukrsBaseCountry(header.getBukrs());
			//判断是否含有国际差旅
            if (FormUtil.checkIsForeignTrip(trips, baseCountry)) {
            	this.recordJwywxMail(header);
            	// 判断是否存在符合订票的交通工具
				boolean needMail = trips.stream().filter(o -> airTicketToolCodes.contains(o.getToolType())).count() > 0;
				if (!needMail) {
					return;
				}
				//存在机票信息则将参数设置model中，传给模板引擎进行渲染
				MailEntity mail = new MailEntity();
				//获取打开单据链接
				String url = docDirect + docId;
				String userName = header.getExpensorName();
				
				Context model = new Context();
				
				model.setVariable("url", url);
				model.setVariable("tripList", trips);
				model.setVariable("userName", userName);
				//设置邮件正文
				mail.setContent(this.getMessage("zh/nationAirfare", model));
				Object[] args = { userName, header.getDocNo() };
				//设置邮件标题
				mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_AIRFARE_TEMP, args));
				//设置邮件接收人
				User tos = userDao.findMailUserByKey("ZHB_JP_ZY");
				if (tos != null) {
    				mail.setReceivors(tos.getInMail());
    				//设置内外网邮件
    				mail.setIsOutMail("N");
    				mail.setDocId(docId);
    				mail.setIsApprove(YesOrNoEnum.N.name());
    				//记录邮件日志
    				logDao.recordMailInfo(mail);
				}
            }
		}
	}

	private void recordJwywxMail(FormHeader header) {
		User user = userDao.findUserByUserId(header.getExpensor(), UserContext.getLanguage());

		if (user != null && !Strings.isNullOrEmpty(user.getInMail())) {
			MailEntity mail = new MailEntity();
			Context model = new Context();
			model.setVariable("url", jwx);
			//设置邮件正文
			mail.setContent(this.getMessage("zh/jwywx", model));
			//设置邮件标题
			mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_JWX_TEMP));
			mail.setReceivors(user.getInMail());
			//设置内外网邮件
			mail.setIsOutMail("N");
			mail.setDocId(header.getDocId());
			mail.setIsApprove(YesOrNoEnum.N.name());
			//记录邮件日志
			logDao.recordMailInfo(mail);
		}
	}

	/**
	 * 将参数设置到模板文件中，并且返回文件内容
	 * @param model
	 * @return
	 */
	protected final String getMessage(String tempPath, Context model) {
		return templateEngine.process(tempPath, model);
	}
}
