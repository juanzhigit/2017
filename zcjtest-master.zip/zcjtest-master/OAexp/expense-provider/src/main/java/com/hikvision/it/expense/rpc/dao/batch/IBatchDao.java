package com.hikvision.it.expense.rpc.dao.batch;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.batch.PayDetail;
import com.hikvision.it.expense.api.entity.batch.PayFilter;

public interface IBatchDao {
	
	/**
	 * 获取单据借款信息
	 * @param userId language filter
	 * @return
	 */
	List<PayDetail> getPayDetails(@Param("userId") String userId, @Param("language") String language, @Param("filter") PayFilter filter);
	
}
