package com.hikvision.it.expense.rpc.message;

import java.text.MessageFormat;
import java.util.ResourceBundle;

import com.hikvision.it.expense.api.enums.MessageCode;

public class MessageResource {
	private ResourceBundle rb; //资源绑定
    /**
     * 构造器
     * @param props Properties 资源绑定
     */
    public MessageResource(ResourceBundle rb) {
        this.rb = rb;
    }
    /**
     * 得到消息字符
     * @param key String 键
     * @return String
     */
    public HikMessage getString(String key) {
    	HikMessage retMsg = new HikMessage();

    	retMsg.setMsgCode(key);
		if (rb.containsKey(key)) {
			retMsg.setMsg(rb.getString(key));
		} else {
			retMsg.setMsg(rb.getString(MessageCode.MSG_NOT_FOUND.name()));
		}

		return retMsg;
    }

    /**
     * 得到消息资源
     * @param key String 键
     * @param args Object[] 可变消息
     * @return String
     */
    public String getString(String key, Object[] args) {
    	HikMessage retMsg = new HikMessage();

    	retMsg.setMsgCode(key);
		if (rb.containsKey(key)) {
			retMsg.setMsg(MessageFormat.format(rb.getString(key), args));
		} else {
			retMsg.setMsg(rb.getString(MessageCode.MSG_NOT_FOUND.name()));
		}

		return retMsg.getMsg();
    }
}
