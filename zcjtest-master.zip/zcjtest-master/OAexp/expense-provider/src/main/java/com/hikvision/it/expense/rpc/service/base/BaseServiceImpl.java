package com.hikvision.it.expense.rpc.service.base;

import java.math.BigDecimal;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.ArrayListMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.Notice;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.bukrs.Bukrs;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.service.auth.AuthServiceImpl;

@Service
@Primary
public class BaseServiceImpl implements IBaseService {
	@Autowired
	private IBaseDao baseDao;
	@Autowired
	private IUserDao userDao;
	@Autowired
	AuthServiceImpl authService;
	
	@Override
	public List<SelectOpt> findSelectCurrency(String userId, String bukrs, String docType) {
		//首先根据人员获取优先匹配规则
		List<SelectOpt> opts = baseDao.findSelectCurrencyByUser(userId, docType);
		//获取不到特殊配置，获取公司配置
		if (opts == null || opts.size() == 0) {
			opts = baseDao.findSelectCurrencyByBukrs(bukrs, docType);
		}
		
		return opts;
	}

	@Override
	public List<SelectOpt> findTipTool() {
		List<SelectOpt> values = Lists.newArrayList();
		//获取交通工具类别和座位级别
		List<SelectOpt> opts = baseDao.findTipTool(UserContext.getLanguage());
		if (opts != null && opts.size() != 0) {
			SelectOpt curOpt = null;
			//设置下拉级联
			for (SelectOpt opt : opts) {
				if (Strings.isNullOrEmpty(opt.getUpId())) {
					values.add(opt);
					curOpt = opt;
				} else {
					curOpt.getSubOpt().add(opt);
				}
			}
		}
		
		return values;
	}

	@Override
	public List<SelectOpt> listExpenseFeeType() {
		List<SelectOpt> opts = baseDao.listExpenseFeeType(UserContext.getLanguage());
        Multimap<String, SelectOpt> multimap = ArrayListMultimap.create();
        opts.stream().filter(o -> !Strings.isNullOrEmpty(o.getUpId())).forEach(o -> multimap.put(o.getUpId(), o));
        return opts.stream().filter(o -> Strings.isNullOrEmpty(o.getUpId())).map(o -> {
            o.getSubOpt().addAll(multimap.get(o.getId()));
            return o;
        }).collect(Collectors.toList());
    }

	@Override
	public List<SelectOpt> listExpenseFeeType(String bukrs, String docType, String expenseType) {
		List<SelectOpt> opts = baseDao.listDocExpenseFeeType(bukrs, docType, expenseType, UserContext.getLanguage());
		if (ListUtil.isEmpty(opts)) {
			bukrs = "*";
			opts = baseDao.listDocExpenseFeeType(bukrs, docType, expenseType, UserContext.getLanguage());
		}
        Multimap<String, SelectOpt> multimap = ArrayListMultimap.create();
        opts.stream().filter(o -> !Strings.isNullOrEmpty(o.getUpId())).forEach(o -> multimap.put(o.getUpId(), o));
        return opts.stream().filter(o -> Strings.isNullOrEmpty(o.getUpId())).map(o -> {
            o.getSubOpt().addAll(multimap.get(o.getId()));
            return o;
        }).collect(Collectors.toList());
	}

	@Override
	public List<TripCity> findTripCity(String filter) {
		return baseDao.findTripCity(filter, UserContext.getLanguage());
	}

	@Override
	public List<TripCity> findHotCity() {
		return baseDao.findHotCity(UserContext.getLanguage());
	}

	@Override
	public Rate getRates(Rate rate) {
		String currency = rate.getCurrency();
		String payCurrency = rate.getPayCurrency();
		String date = rate.getDate();
		
		if (!Strings.isNullOrEmpty(payCurrency) && !Strings.isNullOrEmpty(currency)) {
			if (payCurrency.equalsIgnoreCase(currency)) {
				//消费币别和付款币别一致 无需汇率转换 直接设置汇率为1，付款金额为消费金额
				rate.setRate(BigDecimal.valueOf(1));
				rate.setPayAmount(rate.getAmount());
			} else {
				BigDecimal rateBase = null;
				BigDecimal payRateBase = null;
				//通过美金进行中转汇率兑换
				if (!StringUtil.USD.equalsIgnoreCase(currency)) {//消费币别兑美金汇率基数
					rateBase = baseDao.findRateBaseValue(date, currency);
				} else {
					rateBase = BigDecimal.valueOf(100);
				}
				if (!StringUtil.USD.equalsIgnoreCase(payCurrency)) {//付款币别兑美金汇率基数
					payRateBase = baseDao.findRateBaseValue(date, payCurrency);
				} else {
					payRateBase = BigDecimal.valueOf(100);
				}
				
				if (rateBase == null || payRateBase == null) {
					throw new ExpenseException(ExceptionCode.EXCHANGE_RATE_NOT_FOUND);
				}
				//计算汇率
				BigDecimal exchangeRate = payRateBase.divide(rateBase, 5, BigDecimal.ROUND_HALF_UP);
				
				BigDecimal amount = rate.getAmount();
				if (amount != null) {
					//计算付款金额
					BigDecimal payAmount = amount.multiply(exchangeRate).setScale(2, BigDecimal.ROUND_HALF_UP);
					rate.setPayAmount(payAmount);
				}
				//设置汇率和付款金额返回
				rate.setRate(exchangeRate);
			}
		}
		
		return rate;
	}

	@Override
	public List<Notice> listNotices(int pageNumber, int pageSize) {
		return baseDao.listNotices(pageNumber, pageSize);
	}

	@Override
	public List<SelectOpt> listCurrencyOpt(String country) {
		String language = UserContext.getLanguage();
		
		return baseDao.listCurrencyOpt(language, country);
	}

    @Override
    public List<SelectOpt> listEntertains() {
        return baseDao.listEntertains(UserContext.getLanguage());
    }

    @Override
    public List<SelectOpt> listEntertainLevels() {
        return baseDao.listEntertainLevels(UserContext.getLanguage());
    }

    @Override
    public String getDeptName(String deptCode) {
        return baseDao.findDeptName(deptCode);
    }

    @Override
    public String getBukrsName(String bukrs) {
        return baseDao.findBukrsName(bukrs);
    }

    @Override
	public List<SelectOpt> findCityTraficTool() {
		String language = UserContext.getLanguage();
		
		return baseDao.listCityTraficTool(language);
	}

	@Override
	public List<SelectOpt> listTrafficProject(String filter) {
		return baseDao.listTrafficProject(filter);
	}

    @Override
    public List<SelectOpt> listGlAccount(String filter) {
        return baseDao.findSelectGlAcccount(filter, UserContext.getLanguage());
    }

    @Override
	public List<SelectOpt> listSalesArea(String userId) {
		boolean isPermit = authService.checkHasPermission(userId, DocTypeEnum.WEM001.name());
		
		if (isPermit) {
			return baseDao.listSalesArea(userId);
		}
		
		return null;
	}
	
	/**
	 * 获取公司信息
	 * 
	 */
	@Override
	public List<SelectOpt> getCompanyInfo(String searchText){
		return baseDao.getCompanyInfo(searchText);
	}

	@Override
	public List<SelectOpt> listIndustry() {
		return baseDao.listIndustry();
	}

	@Override
	public List<SelectOpt> findSelectCurrency(String filter) {
		String language = UserContext.getLanguage();
		
		return baseDao.findSelectCurrency(filter, language);
	}

	@Override
	public List<TripCity> getStayStandard(String userId, String filter) {
		//根据filter筛选城市信息
		List<TripCity> cities = baseDao.findTripCity(filter, UserContext.getLanguage());

		if (ListUtil.isEmpty(cities)) {
			return Lists.newArrayList();
		}
		int branceManagerNum = userDao.countBranchManager(userId);
		//分总、总部员工、分公司未维护特殊标准的住宿，按照总部标准执行
		//分公司员工 判断是否 存在特殊城市住宿标准配置，或者属于办事处
		List<TripCity> matchedCities = baseDao.matchCityStayStandrand(cities, userId);
		//匹配适用的住宿标准
		for (TripCity city : cities) {
			String cityId = city.getCityId();

			for (TripCity matchCity : matchedCities) {
				if (cityId.equalsIgnoreCase(matchCity.getCityId())) {
					city.setStayStandardAmt(matchCity.getStayStandardAmt());
					city.setCurrency(matchCity.getCurrency());
					//判断是否分公司员工（分总除外），分公司员工优先判断住宿地是否有办事处，如果有办事处，按照办事处标准执行，否则按照总部标准
					if (branceManagerNum == 0) {
						//分公司普通员工匹配到住宿标准，结束本次循环，否则匹配总部通用标准
						break;
					}
				}
			}
		}

		return cities;
	}

	@Override
	public List<Bukrs> listBukrs(String filter) {
		return baseDao.listBukrs(filter, UserContext.getLanguage());
	}

	@Override
	public List<SelectOpt> listLifnr(String filter) {
		UserContext.getLanguage();

		return baseDao.listLifnr(filter);
	}

	@Override
	public List<SelectOpt> listAdviceSmaFee(String filter) {
		List<SelectOpt> allAdviceSmaFees = baseDao.listAdviceSmaFee(filter);

		if (!ListUtil.isEmpty(allAdviceSmaFees)) {
			List<SelectOpt> rs = Lists.newArrayList();

			String lastUpId = null;
			SelectOpt parentOpt = null;
			for (SelectOpt opt : allAdviceSmaFees) {
				if (!opt.getUpId().equalsIgnoreCase(lastUpId)) {
					parentOpt = new SelectOpt();

					parentOpt.setId(opt.getUpId());
					parentOpt.setText(opt.getUpId());

					rs.add(parentOpt);
				}

				parentOpt.getSubOpt().add(opt);

				lastUpId = opt.getUpId();
			}

			return rs;
		} else {
			return Lists.newArrayList();
		}
	}

	@Override
	public String getExpenseTypeName(String expenseType) {
		return baseDao.getExpenseTypeName(expenseType, UserContext.getLanguage());
	}
}
