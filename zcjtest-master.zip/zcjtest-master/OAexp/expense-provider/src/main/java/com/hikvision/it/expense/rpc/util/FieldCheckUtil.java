package com.hikvision.it.expense.rpc.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.google.common.base.Strings;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.loan.LoanDetail;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripTogether;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.entity.check.CheckOption;
import com.hikvision.it.expense.rpc.message.MessageCache;

public class FieldCheckUtil {
	/**
	 * 校验单据抬头
	 * @param header
	 * @param checkOpt
	 * @param errors
	 */
	public static void checkFormHeader(FormHeader header, CheckOption checkOpt, List<String> errors) {
		String docType = header.getDocType();
		String expenseType = header.getExpenseType();
		String expensor = header.getExpensor();
		String creator = header.getCreatedBy();
		String deptCode = header.getDeptCode();
		String bukrs = header.getBukrs();
		String currency = header.getCurrency();
		String remark = header.getRemark();
		//先判断字段长度
		MessageCode requireCode = MessageCode.FORM_FIELD_REQUIRE_INPUT;
		MessageCode lengthCode = MessageCode.FORM_FIELD_LENGTH_LIMITTED;
		
		String titleDocType = MessageCache.getMessage(MessageCode.TITLE_DOCTYPE);
		String titleExpenseType = MessageCache.getMessage(MessageCode.TITLE_EXPENSETYPE);
		String titleApplicant =  MessageCache.getMessage(MessageCode.TITLE_APPLICANT);
		String titleCreator = MessageCache.getMessage(MessageCode.TITLE_CREATOR);
		String titleBukrs = MessageCache.getMessage(MessageCode.TITLE_BUKRS);
		String titleDept = MessageCache.getMessage(MessageCode.TITLE_DEPARTMENT);
		String titleCur = MessageCache.getMessage(MessageCode.TITLE_CURRENCY);
		String titleRemark = MessageCache.getMessage(MessageCode.TITLE_PURPOSE);
		if (Strings.isNullOrEmpty(docType)) {
			errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleDocType }));
		} else if (docType.length() > 10) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleDocType, "10" }));
		}
		if (!Strings.isNullOrEmpty(expenseType) && 
				expenseType.length() > 10) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleExpenseType, "10" }));
		}
		if (Strings.isNullOrEmpty(expensor)) {
			errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleApplicant }));
		} else if (expensor.length() > 15) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleApplicant, "15" }));
		}
		if (Strings.isNullOrEmpty(creator)) {
			errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleCreator }));
		} else if (creator.length() > 15) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleCreator, "15" }));
		}
		if (!Strings.isNullOrEmpty(deptCode) && 
				deptCode.length() > 10) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleDept, "10" }));
		}
		if (!Strings.isNullOrEmpty(bukrs) && 
				bukrs.length() > 4) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleBukrs, "4" }));
		}
		if (!Strings.isNullOrEmpty(currency) &&
				currency.length() > 3) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleCur, "3" }));
		}
		if (!Strings.isNullOrEmpty(remark) &&
				remark.length() > 500) {
			errors.add(MessageCache.getMessage(lengthCode, new Object[]{ titleRemark, "500" }));
		}
		//提交时必输字段校验
		if (checkOpt.isSubmit()) {
			if (Strings.isNullOrEmpty(expenseType)) {
				errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleExpenseType }));
			}
			if (Strings.isNullOrEmpty(deptCode)) {
				errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleDept }));
			}
			if (Strings.isNullOrEmpty(bukrs)) {
				errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleBukrs }));
			}
			if (Strings.isNullOrEmpty(currency)) {
				errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleCur }));
			}
			if (Strings.isNullOrEmpty(remark)) {
				errors.add(MessageCache.getMessage(requireCode, new Object[]{ titleRemark }));
			}
		}
	}
	
	/**
	 * 校验行程信息
	 * @param trips
	 * @param isSubmit
	 * @param errors
	 */
	public static void checkTripDetails(String docType, List<Trip> trips, boolean isSubmit, List<String> errors) {
		if (!ListUtil.isEmpty(trips)) {
		    MessageCode gridRequireCode = MessageCode.GRID_FIELD_REQUIRE_INPUT;
			MessageCode gridLengthCode = MessageCode.GRID_FIELD_LENGTH_LIMITTED;
			
			String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_TRIP);
			String titleFromDate = MessageCache.getMessage(MessageCode.TITLE_FROM_DATE);
			String titleFromCountry = MessageCache.getMessage(MessageCode.TITLE_FROM_COUNTRY);
			String titleFromCity = MessageCache.getMessage(MessageCode.TITLE_FROM_CICY);
			String titleToDate = MessageCache.getMessage(MessageCode.TITLE_TO_DATE);
			String titleToCountry = MessageCache.getMessage(MessageCode.TITLE_TO_COUNTRY);
			String titleToCity = MessageCache.getMessage(MessageCode.TITLE_TO_CICY);
			String titleTool = MessageCache.getMessage(MessageCode.TITLE_TRIFFIC_TOOL);
			String titleToolLevel = MessageCache.getMessage(MessageCode.TITLE_TRIFFIC_TOOL_LEVEL);
			int i = 1;
			Date lastToDate = null;
			String lastToPlace = null;
			Date curToDate = null;
			Date curFromDate = null;
			String firstFromCity = null;
			for (Trip trip : trips) {
				trip.setId(StringUtil.getUUID());
				String fromDate = trip.getFromDate();
				String countryFrom = trip.getCountryFrom();
				String cityFrom = trip.getPlaceFrom();
				String toDate = trip.getToDate();
				String countryTo = trip.getCountryTo();
				String cityTo = trip.getPlaceTo();
				String tool = trip.getToolType();
				String toolLevel = trip.getToolLevel();
				
				if (!Strings.isNullOrEmpty(fromDate)) {
					try {
						curFromDate = DateUtil.stringToSQLDate(fromDate);
						if (errors.size() == 0 && i == 1) {
							//赋值第一个出发城市，用于校验是否行程是否闭环
							firstFromCity = cityFrom;
						}
					} catch (Exception e) {
						errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleFromDate }));
					}
				}
				if (!Strings.isNullOrEmpty(countryFrom) &&
						countryFrom.length() > 20) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleFromCountry, 20 }));
				}
				if (!Strings.isNullOrEmpty(cityFrom) &&
						countryFrom.length() > 20) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleFromCity, 20 }));
				}
				if (!Strings.isNullOrEmpty(toDate)) {
					try {
						curToDate = DateUtil.stringToSQLDate(toDate);
					} catch (Exception e) {
						errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleToDate }));
					}
				}
				if (!Strings.isNullOrEmpty(countryTo) &&
						countryTo.length() > 20) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleToCountry, 20 }));
				}
				if (!Strings.isNullOrEmpty(cityTo) &&
						cityTo.length() > 20) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleToCity, 20 }));
				}
				if (!Strings.isNullOrEmpty(tool) &&
						tool.length() > 4) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleTool, 4 }));
				}
				if (!Strings.isNullOrEmpty(toolLevel) &&
						toolLevel.length() > 4) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleToolLevel, 4 }));
				}
				
				//提交校验
				if (isSubmit) {
					if (Strings.isNullOrEmpty(fromDate)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleFromDate }));
					}
					if (Strings.isNullOrEmpty(countryFrom)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleFromCountry }));
					}
					if (Strings.isNullOrEmpty(cityFrom)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleFromCity }));
					}
					if (Strings.isNullOrEmpty(toDate)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToDate }));
					}
					if (Strings.isNullOrEmpty(countryTo)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToCountry }));
					}
					if (Strings.isNullOrEmpty(cityTo)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToCity }));
					}
					if (Strings.isNullOrEmpty(tool) && !DocTypeEnum.WEM012.name().equals(docType)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleTool }));
					}
					if (Strings.isNullOrEmpty(toolLevel) && !DocTypeEnum.WEM012.name().equals(docType)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToolLevel }));
					}
					//日期有效性校验
					MessageCode dateScopeCode = MessageCode.GRID_DATE_SCOPE_ERROR;
					MessageCode placeSameCode = MessageCode.GRID_TRIP_PLACE_SAME_ERROR;
					if (errors.size() == 0) {
						//达到日期不能早于出发日期
						if (curToDate.compareTo(curFromDate) < 0) {
							errors.add(
									MessageCache.getMessage(
											dateScopeCode,
											new Object[] { gridName, i,
													titleToDate, i, titleFromDate }));
						}
						//多行程闭环校验
						if (cityFrom.equalsIgnoreCase(firstFromCity) &&
								i != 1) {
							errors.add(MessageCache.getMessage(MessageCode.FORM_TRIP_MULTI_CYCLE));
						}
						//出发城市与到达城市一致
						if (cityFrom.equalsIgnoreCase(cityTo)) {
							errors.add(
									MessageCache.getMessage(
											placeSameCode,
											new Object[] { gridName, i }));
						}
					}
					//出发日期不能早于上一行到达日期
					if (errors.size() == 0) {
						if (lastToDate != null) {
							//当前出发日期小于上一行到达日期
							if (curFromDate.compareTo(lastToDate) < 0) {
								errors.add(
										MessageCache.getMessage(
												dateScopeCode,
												new Object[] { gridName, i,
														titleFromDate, (i - 1), titleToDate }));
							}
						}
						
						if (!Strings.isNullOrEmpty(lastToPlace)) {
							//当前出发出发城市与上一行到达城市不一致
							if (!cityFrom.equalsIgnoreCase(lastToPlace)) {
								errors.add(
										MessageCache.getMessage(
												MessageCode.GRID_TRIP_PLACE_ERROR,
												new Object[] { gridName, i, (i - 1) }));
							}
						}
					}
				}
				
				lastToDate = curToDate;
				lastToPlace = cityTo;
				
				i++;
			}
			
			if (isSubmit && errors.size() == 0) {
				//差旅行程非闭环判断
				if (!firstFromCity.equalsIgnoreCase(lastToPlace)) {
					errors.add(MessageCache.getMessage(MessageCode.FORM_TRIP_CYCLE_ERROR));
				}
			}
		}
		
		if (isSubmit && (trips == null || trips.size() < 2)) {
			//行程条目不能少于2条
			errors.add(MessageCache.getMessage(MessageCode.GRID_LESS_DATA, new Object[]{ 2, "行程" }));
		}
	}
	
	/**
	 * 校验行程信息
	 * @param foreignCurrency true - 可以使用外币; false-不能使用外币
	 * @param loans
	 * @param isSubmit
	 * @param errors
	 */
	public static void checkLoanDetails(boolean foreignCurrency, List<LoanDetail> loans, boolean isSubmit, List<String> errors) {
		if (!ListUtil.isEmpty(loans)) {
			MessageCode gridRequireCode = MessageCode.GRID_FIELD_REQUIRE_INPUT;
			MessageCode gridLengthCode = MessageCode.GRID_FIELD_LENGTH_LIMITTED;
			
			String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_LOAN);
			String titleLoanDate = MessageCache.getMessage(MessageCode.TITLE_LOAN_DATE);
			String titleRepaymentDate = MessageCache.getMessage(MessageCode.TITLE_ESTIMATE_REPAYMENT_DATE);
			String titlePaymentMethod = MessageCache.getMessage(MessageCode.TITLE_PAYMENT_METHOD);
			String titleCurrency = MessageCache.getMessage(MessageCode.TITLE_CURRENCY);
			String titleAmount = MessageCache.getMessage(MessageCode.TITLE_AMOUNT);
			String titleRemark = MessageCache.getMessage(MessageCode.TITLE_PURPOSE);
			int i = 1;
			for (LoanDetail loan : loans) {
				loan.setId(StringUtil.getUUID());
				Date loanDate = null;
				String loanDateStr = loan.getLoanDate();
				Date repaymentDate = null;
				String repaymentDateStr = loan.getRepaymentDate();
				String paymentMethod= loan.getPaymentType();
				String currency = loan.getLoanCurrency();
				BigDecimal amount = loan.getAmount();
				String remark = loan.getRemark();

				if (!Strings.isNullOrEmpty(loanDateStr)) {
					try {
						loanDate = DateUtil.stringToSQLDate(loanDateStr);
					} catch (Exception e) {
						errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleLoanDate }));
					}
				}
				if (!Strings.isNullOrEmpty(repaymentDateStr)) {
					try {
						repaymentDate = DateUtil.stringToSQLDate(repaymentDateStr);
					} catch (Exception e) {
						errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleRepaymentDate }));
					}
				}
				if (!Strings.isNullOrEmpty(paymentMethod) &&
						paymentMethod.length() > 5) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titlePaymentMethod, 5 }));
				}
				if (!Strings.isNullOrEmpty(currency) &&
						currency.length() > 3) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleCurrency, 3 }));
				}
				if (!Strings.isNullOrEmpty(remark) &&
						remark.length() > 500) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleRemark, 500 }));
				}
				
				if (isSubmit && errors.size() == 0) {
					if (loanDate == null) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleLoanDate }));
					}
					if (repaymentDate == null) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleRepaymentDate }));
					}
					if (Strings.isNullOrEmpty(paymentMethod)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titlePaymentMethod }));
					}
					if (Strings.isNullOrEmpty(currency)) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{gridName, i, titleCurrency}));
					} else {
						//外币只能选择现金
						if (!"CNY".equalsIgnoreCase(currency)) {
							if (loan.getExchangeRate() == null) {
								errors.add("外币借款时，需要传入当天相应外币的汇率！");
							}
							if ("C".equalsIgnoreCase(paymentMethod)) {
								errors.add("外币借款付款方式错误，必须为：[现金]");
							}
						}
						if (!foreignCurrency && !"CNY".equals(currency)) {
							errors.add(MessageCache.getMessage(MessageCode.GRID_NO_FOREIGN_CURRENCY, new Object[]{gridName, i}));
						}
					}
					if (amount == null || BigDecimal.ZERO.compareTo(amount) == 0) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleAmount }));
					}
					//达到日期不能早于出发日期
					if (errors.size() == 0 && loanDate.compareTo(repaymentDate) >= 0) {
						errors.add(
								MessageCache.getMessage(
										MessageCode.GRID_DATE_SCOPE_ERROR,
										new Object[] { gridName, i,
												titleRepaymentDate, i, titleLoanDate }));
					}
				}
				
				i++;
			}
		}
	}
	
	/**
	 * 校验同行人信息
	 * @param formInfo
	 * @param errors
	 */
	public static void checkTripTogetherDetails(FormInfo formInfo, List<String> errors) {
		FormHeader header = formInfo.getFormHeader();
		//获取单据所有人
		String expensor = header.getExpensor();
		
		List<TripTogether> togethers = formInfo.getTripTogethers();
		if (!ListUtil.isEmpty(togethers)) {
		    String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_TRIP_TOGETHER);
            
            int i = 1;
            //定义map存储同行人信息，用于判断是否存在重复的同行人信息
            Map<String, TripTogether> map = Maps.newHashMap();
		    for (TripTogether together : togethers) {
		        String togetherUserId = together.getUserId();
		        
		        if (map.containsKey(togetherUserId)) {
					errors.add(MessageCache.getMessage(
                                MessageCode.RUNTIME_ERROR,
                                new Object[] { gridName + "存在重复的同行人记录，请删除第" + i + "行记录！" }));
		        } else {
		            map.put(togetherUserId, together);
		        }
		        
		        //校验同行人中是否包含自己
		        if (expensor.equalsIgnoreCase(togetherUserId)) {
					errors.add(MessageCache.getMessage(
                                        MessageCode.RUNTIME_ERROR,
                                        new Object[] { gridName + "第" + i + "行，同行人与申请人一致，请删除！" }));
		        }
		        
		        i++;
		    }
		}
	}
	
	/**
	 * 校验是否超期
	 * @param feeDate
	 * @param curDate
	 * @return
	 */
	public static boolean isCq(Date feeDate, Date curDate) {
	    int days = DateUtil.daysBetween(feeDate, curDate);
	    
	    if (days > 60) {
	        return true;
	    }
	    
	    return false;
	}

	/**
	 * 校验日期格式是否正确
	 * @param date
	 * @param checkOpt
	 * @param errors
	 * @param args
	 */
	private static void checkDateValid(String date, CheckOption checkOpt, List<String> errors, Object[] args) {
		if (!Strings.isNullOrEmpty(date)) {
			if (DateUtil.stringToSQLDate(date) == null) {
				if (checkOpt.isDateFromRequired()) {
					errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, args));
				} else if (checkOpt.isStaysDateRequired()) {
					errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, args));
				} else {
					errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, args));
				}
			}
		}
	}
	
	/**
	 * 通用费用校验
	 * @param gridName     表格名称
	 * @param fees         费用明细
	 * @param checkOpt     校验字段控制
	 * @param errors           返回结果
	 * 
	 * @return             返回超期超标标识
	 * 
	 */
	public static boolean commonFeeCheck(String gridName,
	                                      List<FeeDetail> fees, 
	                                      CheckOption checkOpt, 
	                                      List<String> errors) {
	    boolean isCqcb = false;
	    if (!ListUtil.isEmpty(fees)) {
	        MessageCode gridRequireCode = MessageCode.GRID_FIELD_REQUIRE_INPUT;
            MessageCode gridLengthCode = MessageCode.GRID_FIELD_LENGTH_LIMITTED;
            
            String titleDate = MessageCache.getMessage(MessageCode.TITLE_FEE_DATE);
            String titleCurrency = MessageCache.getMessage(MessageCode.TITLE_CURRENCY);
            String titleAmount = MessageCache.getMessage(MessageCode.TITLE_AMOUNT);
            String titleRate = MessageCache.getMessage(MessageCode.TITLE_RATE);
            String titleLocalAmt = MessageCache.getMessage(MessageCode.TITLE_LOCAL_AMT);
            String titleTripRemark = MessageCache.getMessage(MessageCode.TITLE_TRIP_REMARK);
            String titleRemark = MessageCache.getMessage(MessageCode.TITLE_REMARK);
            String titleWBS = MessageCache.getMessage(MessageCode.TITLE_WBS);
            String titleTrafficTool = MessageCache.getMessage(MessageCode.TITLE_TRIFFIC_TOOL);
			String titleTool = MessageCache.getMessage(MessageCode.TITLE_TRIFFIC_TOOL);
			String titleToolLevel = MessageCache.getMessage(MessageCode.TITLE_TRIFFIC_TOOL_LEVEL);
            String titleIndustry = MessageCache.getMessage(MessageCode.TITLE_INDUSTRY);
            String titleSalesArea = MessageCache.getMessage(MessageCode.TITLE_SALESAREA);
            String titleTrafficProject = MessageCache.getMessage(MessageCode.TITLE_TRAFFIC_PROJECT);
            String titleZdfs = MessageCache.getMessage(MessageCode.TITLE_ZDFS);
            String titleKhjb = MessageCache.getMessage(MessageCode.TITLE_KHJB);
            String titleDays = MessageCache.getMessage(MessageCode.TITLE_DAYS);
            String titlePersons = MessageCache.getMessage(MessageCode.TITLE_PERSONS);
            String titleFeeType = MessageCache.getMessage(MessageCode.TITLE_SMAFEETYPE);
            String titleSj = MessageCache.getMessage(MessageCode.TITLE_SJ);
            String titleKh = MessageCache.getMessage(MessageCode.TITLE_KH);
            String titleYh = MessageCache.getMessage(MessageCode.TITLE_YH);
            String titleTaxRate = MessageCache.getMessage(MessageCode.TITLE_TAX_RATE);
            String titleTaxAmount = MessageCache.getMessage(MessageCode.TITLE_TAX_AMOUNT);
            String titleFromDate = MessageCache.getMessage(MessageCode.TITLE_FROM_DATE);
            String titleToDate = MessageCache.getMessage(MessageCode.TITLE_TO_DATE);
            String titleFromCity = MessageCache.getMessage(MessageCode.TITLE_FROM_CICY);
            String titleToCity = MessageCache.getMessage(MessageCode.TITLE_TO_CICY);
            String titleRentFlag = MessageCache.getMessage(MessageCode.TITLE_RENT_FLAG);
            String titleStaysDate = MessageCache.getMessage(MessageCode.TITLE_STAYS_DATE);
            String titleLeaveDate = MessageCache.getMessage(MessageCode.TITLE_LEAVE_DATE);
            String titleStaysCity = MessageCache.getMessage(MessageCode.TITLE_STAYS_CITY);
            String titleRooms = MessageCache.getMessage(MessageCode.TITLE_ROOMS);
            String titleStaysRemark = MessageCache.getMessage(MessageCode.TITLE_STAYS_REMARK);
            
            int i = 1;
            //获取是否提交校验参数
            boolean isSubmit = checkOpt.isSubmit();
	        for (FeeDetail fee : fees) {
                String fromDate = fee.getFeeFromDate();
                String toDate = fee.getFeeToDate();
                String currency = fee.getCurrency();
                BigDecimal amount = fee.getAmount();
                BigDecimal rate = fee.getExchangeRate();
                BigDecimal localAmt = fee.getLocalAmount();
                String remark = fee.getRemark();
                    
                String cqFlag = fee.getOverDateFlag();
                String cbFlag = fee.getOverStandardFlag();
                //判断是否超期超标
                if (YesOrNoEnum.Y.name().equalsIgnoreCase(cqFlag) || 
                        YesOrNoEnum.Y.name().equalsIgnoreCase(cbFlag)) {
                    isCqcb = true;
                }
                
                if (!Strings.isNullOrEmpty(fromDate)) {
					if (checkOpt.isDateFromRequired()) {
						checkDateValid(fromDate, checkOpt, errors, new Object[]{ gridName, i, titleFromDate });
					} else if (checkOpt.isStaysDateRequired()) {
						checkDateValid(fromDate, checkOpt, errors, new Object[]{ gridName, i, titleStaysDate });
					} else {
						checkDateValid(fromDate, checkOpt, errors, new Object[]{ gridName, i, titleDate });
					}
                }
                
                if (!Strings.isNullOrEmpty(toDate)) {
                    try {
                        DateUtil.stringToSQLDate(toDate);
                    } catch (Exception e) {
                        if (checkOpt.isDateFromRequired()) {
							errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleToDate }));
                        } else if (checkOpt.isStaysDateRequired()) {
							errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleLeaveDate }));
                        } else {
							errors.add(MessageCache.getMessage(MessageCode.GRID_DATA_FORMAT_ERROR, new Object[]{ gridName, i, titleDate }));
                        }
                    }
                }
                if (!Strings.isNullOrEmpty(currency) &&
                        currency.length() > 3) {
					errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleCurrency, 3 }));
                }
                if (!Strings.isNullOrEmpty(remark) && 
                        remark.length() > 100) {
                    if (checkOpt.isRemarkTripRequired()) {
						errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleTripRemark, 100 }));
                    } else if (checkOpt.isStaysRemarkRequired()) {
						errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleStaysRemark, 100 }));
                    } else {
						errors.add(MessageCache.getMessage(gridLengthCode, new Object[]{ gridName, i, titleRemark, 100 }));
                    }
                }
                    
                //提交校验
                if (isSubmit) {
                    if (Strings.isNullOrEmpty(fromDate)) {
                        if (checkOpt.isDateFromRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleFromDate }));
                        } else if (checkOpt.isStaysDateRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleStaysDate }));
                        } else if (checkOpt.isFeeDateRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleDate }));
                        }
                    }
                    if (Strings.isNullOrEmpty(toDate)) {
                        if (checkOpt.isDateToRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToDate }));
                        } else if (checkOpt.isLeaveDateRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleLeaveDate }));
                        }
                    }
                    if (checkOpt.isCityFromRequired() && Strings.isNullOrEmpty(fee.getPlaceFrom())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleFromCity }));
                    }
                    if (checkOpt.isRentFlagRequired() && Strings.isNullOrEmpty(fee.getRentType())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleRentFlag }));
                    }
                    if (checkOpt.isStaysCityRequired() && Strings.isNullOrEmpty(fee.getRentCity())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleStaysCity }));
                    }
                    if (checkOpt.isRoomsRequired() && fee.getRentRooms() == 0) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleRooms }));
                    }
                    if (checkOpt.isDateToRequired() && Strings.isNullOrEmpty(fee.getFeeToDate())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToDate }));
                    }
                    if (checkOpt.isCityToRequired() && Strings.isNullOrEmpty(fee.getPlaceTo())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleToCity }));
                    }
					if (checkOpt.isAmountRequired()) {
						//如果是交通工具类别是机票，并且非自定机票无需校验
						if (!"03".equalsIgnoreCase(fee.getTrafficToolType()) || "0317".equalsIgnoreCase(fee.getTrafficToolLevel())) {
							if (Strings.isNullOrEmpty(currency)) {
								errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleCurrency }));
							}

							if (amount == null || amount.compareTo(BigDecimal.ZERO) == 0) {
								errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleAmount }));
							}
							if (rate == null || rate.compareTo(BigDecimal.ZERO) == 0) {
								errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleRate }));
							}
							if (localAmt == null || localAmt.compareTo(BigDecimal.ZERO) == 0) {
								errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleLocalAmt }));
							}
						}
					}
                    //校验招待方式
                    if (checkOpt.isEntertainRequired() && Strings.isNullOrEmpty(fee.getEntertain())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleZdfs }));
                    }
                    //校验客户级别
                    if (checkOpt.isEntertainLevelRequired() && Strings.isNullOrEmpty(fee.getEntertainLevel())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleKhjb }));
                    }
                    //校验天数
                    if (checkOpt.isDayCountsRequired() && fee.getDayCounts() == 0) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleDays }));
                    }
                    //校验人数
                    if (checkOpt.isPerCountsRequired() && fee.getPerCounts() == 0) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titlePersons }));
                    }
                    //校验费用类型
                    if (checkOpt.isSmaFeeTypeRequired() && Strings.isNullOrEmpty(fee.getSmaFeeType())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleFeeType }));
                    }
                    //校验事由、行程
                    if (Strings.isNullOrEmpty(remark)) {
                        if (checkOpt.isRemarkTripRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleTripRemark }));
                        } else if (checkOpt.isStaysRemarkRequired()) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleStaysRemark }));
						} else if (checkOpt.isRemarkRequired()) {
							errors.add(MessageCache.getMessage(gridRequireCode, gridName, i, titleRemark));
                        }
                    }
                    //校验交通工具
                    if (checkOpt.isTrafficToolRequired() && Strings.isNullOrEmpty(fee.getTrafficTool())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i,  titleTrafficTool }));
                    }
					//校验交通工具类别
					if (checkOpt.isTrafficToolTypeRequired() && Strings.isNullOrEmpty(fee.getTrafficToolType())) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i,  titleTool }));
					}
					//校验交通工具座位级别
					if (checkOpt.isTrafficToolLevelRequired() && Strings.isNullOrEmpty(fee.getTrafficToolLevel())) {
						errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i,  titleToolLevel }));
					}
                    //系统公司wbs元素必输
                    if (checkOpt.isWbsRequired() && Strings.isNullOrEmpty(fee.getWbs())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleWBS }));
                    }
                    //校验行业
                    if (checkOpt.isIndustryRequired() && Strings.isNullOrEmpty(fee.getIndustry())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleIndustry }));
                    }
                    //校验销售区域
                    if (checkOpt.isSalesAreaRequired() && Strings.isNullOrEmpty(fee.getSalesArea())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleSalesArea }));
                    }
                    //校验交通项目
                    if (checkOpt.isTrafficProjectRequired() && Strings.isNullOrEmpty(fee.getTrafficProject())) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleTrafficProject }));
                    }

                    //当商机必输时，商机、客户、用户必输其一
                    String zdfs = fee.getEntertain();
                    //招待范围:客情关系维护 不用输入商机、客户、用户  
                    if (checkOpt.isSjRequired() && 
                            !"KQGXWH".equalsIgnoreCase(fee.getEntertainRange())) {
                        //个人费用时
                        if (checkOpt.isNonTravelExpense()) {
                            //B:业务宣传品/接待用品  E:其他   
                            if (!Strings.isNullOrEmpty(zdfs) && 
                                    !"B".equalsIgnoreCase(zdfs) && 
                                    !"E".equalsIgnoreCase(zdfs)) {
                                if (Strings.isNullOrEmpty(fee.getBusinessOpportunity()) &&
                                        Strings.isNullOrEmpty(fee.getCustomer()) &&
                                        Strings.isNullOrEmpty(fee.getUsers())) {
                                    errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleSj + "或" + titleKh + "或" + titleYh }));
                                }
                            }
                        } else {
                            String entertainRange = fee.getEntertainRange();
                            //商机必输
                            if (YesOrNoEnum.Y.name().equalsIgnoreCase(fee.getHasBusinessOpportunity()) &&
                                    Strings.isNullOrEmpty(fee.getBusinessOpportunity())) {
                                errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleSj }));
                            } 
                            //客户必输
                            if ("KH".equalsIgnoreCase(entertainRange) &&
                                    Strings.isNullOrEmpty(fee.getCustomer())) {
                                errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleKh }));
                            } else if ("YH".equalsIgnoreCase(entertainRange) &&
                                    Strings.isNullOrEmpty(fee.getUsers())) {
                                //用户必输
                                errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleYh }));
                            } else if ("YHKH".equalsIgnoreCase(entertainRange)) {
                                //客户用户必输
                                if (Strings.isNullOrEmpty(fee.getCustomer())) {
                                    errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleKh }));
                                }
                                if (Strings.isNullOrEmpty(fee.getUsers())) {
                                    errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleYh }));
                                }
                            }
                            
                        }
                    }
                    //住宿税额校验
                    if ("66060302".equalsIgnoreCase(fee.getSmaFeeType()) || checkOpt.isTaxRequired()) {
                        BigDecimal taxRate = fee.getTaxRate();
                        BigDecimal taxAmount = fee.getTaxAmount();
                        
                        if (taxRate == null) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleTaxRate }));
                        }
                        if (taxAmount == null) {
                            errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleTaxAmount }));
                        }
                    }
                }
                
                i++;
	        }
	    }
	    
	    return isCqcb;
	}
	
	/**
	 * 
	 * @param otherReceivors
	 * @param isSubmit
	 * @param errors
	 * @return 返回他人收款总金额
	 */
	public static BigDecimal checkOtherReceivors(List<OtherReceivor> otherReceivors, 
    	                                        boolean isSubmit,
                                                List<String> errors) {
	    BigDecimal amount = BigDecimal.ZERO;
	    
	    if (!ListUtil.isEmpty(otherReceivors)) {
	        MessageCode gridRequireCode = MessageCode.GRID_FIELD_REQUIRE_INPUT;
	        String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_OTHER_RECEIVE);
            String titleSkr = MessageCache.getMessage(MessageCode.TITLE_SKR);
            String titleAmount = MessageCache.getMessage(MessageCode.TITLE_AMOUNT);
            int i = 1;
	        for (OtherReceivor otherReceivor : otherReceivors) {
	            String userId = otherReceivor.getUserId();
	            String bankAccount = otherReceivor.getBankAccount();
	            BigDecimal skAmount = otherReceivor.getAmount();
	            
	            if (isSubmit) {
	                if (Strings.isNullOrEmpty(userId)) {
	                    errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleSkr }));
	                }
                    if (Strings.isNullOrEmpty(bankAccount)) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, "收款人缺少银行账号信息，请联系66000咨询！" }));
                    }
                    if (skAmount == null || skAmount.compareTo(BigDecimal.ZERO) == 0) {
                        errors.add(MessageCache.getMessage(gridRequireCode, new Object[]{ gridName, i, titleAmount }));
                    } else {
                        amount = amount.add(skAmount);
                    }
	            }
	            
	            i++;
	        }
	    }
	    
	    
	    return amount;
	}
}
