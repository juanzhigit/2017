@javax.xml.bind.annotation.XmlSchema(namespace = "urn:sap-com:document:sap:rfc:functions")
package com.hikvision.it.expense.webservice.client.pi.order;
