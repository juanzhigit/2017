package com.hikvision.it.expense.rpc.dao.task;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import com.github.pagehelper.Page;
import com.hikvision.it.expense.api.entity.task.PendingForwardBean;
import com.hikvision.it.expense.api.entity.task.TaskConfig;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.entity.task.TodoInfo;
import com.hikvision.it.expense.api.entity.user.User;

public interface ITaskDao {
    /**
     * 获取下一任务环节
     *
     * @param processObjectId
     * @param plugOut
     * @return
     */
    TaskObject getTaskObject(@Param("processObjectId") String processObjectId,
                             @Param("plugOut") String plugOut);

    /**
     * 根据环节名称获取环节信息
     *
     * @param processObjectId
     * @param taskName
     * @return
     */
    TaskObject getTaskObjectByName(@Param("processObjectId") String processObjectId,
                                   @Param("taskName") String taskName);

    /**
     * 新增任务实例信息
     *
     * @param taskInstance
     */
    int insertTaskInstance(@Param("task") TaskInstance taskInstance);

    /**
     * 根据任务id和操作员工编号获取任务信息
     *
     * @param taskId
     * @param userId
     * @return
     */
    TaskInstance getTaskInstance(@Param("taskId") String taskId,
                                 @Param("userId") String userId);

    /**
     * 新增任务所有人信息
     *
     * @param owners
     * @return
     */
    int insertTaskOwners(@Param("owners") List<TaskOwner> owners);

    /**
     * 完成任务审批
     *
     * @param task
     * @return
     */
    int completeTask(@Param("task") TaskInstance task);

    /**
     * 流转任务
     *
     * @param task
     * @return
     */
    int flowTask(@Param("task") TaskInstance task);

    /**
     * 转发任务
     *
     * @param task
     * @return
     */
    int forwardTask(@Param("task") TaskInstance task);

    /**
     * 加签任务
     *
     * @param taskInstance
     * @return
     */
    int addStep(@Param("task") TaskInstance taskInstance);

    /**
     * 获取审批完成后任务环节服务配置信息
     *
     * @param processObjectId
     * @param taskName
     * @return
     */
    List<TaskConfig> afterApproveTaskConfig(@Param("processObjectId") String processObjectId,
                                            @Param("taskName") String taskName);

    /**
     * 获取审批前任务环节服务配置信息
     *
     * @param processObjectId
     * @param taskName
     * @return
     */
    List<TaskConfig> beforeApproveTaskConfig(@Param("processObjectId") String processObjectId,
                                             @Param("taskName") String taskName);

    /**
     * 获取当前回合所有删除的任务
     *
     * @param processId
     * @return
     */
    List<TaskInstance> listDeletedTasks(@Param("processId") String processId);

    /**
     * 统计组任务中未完成的任务数
     *
     * @param processId
     * @param taskId
     * @return
     */
    int countUnFlowedGroupTaskNumber(@Param("processId") String processId,
                                     @Param("taskId") String taskId);

    /**
     * 获取原始任务信息
     *
     * @param taskId
     * @return
     */
    TaskInstance getParentTask(@Param("taskId") String taskId);

    @Select("select docId from t_bpm_process_instance t, t_bpm_task_instance ti where ti.processid = t.processid and taskid = #{taskId, jdbcType=VARCHAR}")
    String getDocIdByTaskId(@Param("taskId") String taskId);

    List<String> getTaskOwnersByDocId(String docId);

    /**
     * 根据用户关键信息查询该员工下面的所有待办信息
     */
    Page<PendingForwardBean> getPendingByUserName(String userNameOrEmpId
    );

    /**
     * 根据单号批量查询待办信息
     */
    Page<PendingForwardBean> getPendingByApplyIds(@Param("applyIds") String[] applyIds);

    /**
     * 修改当前审批人数据   t_bpm_process_instance表
     **/
    int updateOperatorInfo(@Param("username") String username, @Param("uptime") long uptime, @Param("processIds") String[] processIds);

    /**
     * 修改当前审批人数据  t_bpm_task_instance_owner表
     */
    int updateOwnerInfo(@Param("userid") String userid, @Param("username") String username, @Param("taskIds") String[] taskIds);

    /**
     * 关键字搜索人员
     * @param searchText
     * @return
     */
    List<PendingForwardBean> getSelectUser(String searchText);

    User getUserByUserId(@Param("userId") String userId, @Param("language") String language);

    /**
     * 获取待审批任务列表
     * @param userId
     * @param language
     * @return
     */
    List<TodoInfo> getTasksToApprove(@Param("userId") String userId, @Param("language") String language);

    /**
     * 获取已审批任务列表
     * @param userId
     * @param language
     * @param pageNumber
     * @param pageSize
     * @return
     */
    List<TodoInfo> getApprovedTasks(@Param("userId") String userId, @Param("language") String language,
                                    @Param("pageNumber") int pageNumber, @Param("pageSize") int pageSize);
}
