package com.hikvision.it.expense.rpc.message;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.ResourceBundle;

public class MessageResourceFactory {
	private static MessageResourceFactory factory = new MessageResourceFactory();
	// 存放消息资源
	private Map<String, MessageResource> msgResourceMap = null;

	private MessageResourceFactory() {
		msgResourceMap = new HashMap<String, MessageResource>();
	}

	public static MessageResourceFactory getInstance() {
		return factory;
	}

	/**
	 * 创建消息资源
	 * 
	 * @param baseName String 消息资源文件名
	 * @param locale Locale
	 * @return MessageResource
	 */
	public MessageResource createMessageResource(String baseName, Locale locale) {
		String key = baseName + locale.toLanguageTag();
		MessageResource msgResObj = msgResourceMap.get(key);
		if (msgResObj == null) {
            ResourceBundle.Control ctrl = ResourceBundle.Control.getNoFallbackControl(ResourceBundle.Control.FORMAT_PROPERTIES);
            ResourceBundle rb = ResourceBundle.getBundle(baseName, locale, ctrl);
			MessageResource msgRes = new MessageResource(rb);
			msgResourceMap.put(key, msgRes);
			return msgRes;
		} else {
			return msgResObj;
		}
	}
}
