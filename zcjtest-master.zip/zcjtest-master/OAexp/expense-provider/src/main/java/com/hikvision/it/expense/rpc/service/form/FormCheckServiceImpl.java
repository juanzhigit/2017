package com.hikvision.it.expense.rpc.service.form;

import java.math.BigDecimal;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.base.SubBukrsFxwd;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.form.OverproofInfo;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.ExpenseType;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.fee.IFeeItemDao;
import com.hikvision.it.expense.rpc.entity.check.CheckOption;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.api.entity.fee.FeeType;
import com.hikvision.it.expense.rpc.util.FieldCheckUtil;
import com.hikvision.it.expense.rpc.util.FormUtil;

@Service
public class FormCheckServiceImpl {
    @Autowired
    private IBaseDao baseDao;

    @Autowired
    private IFeeItemDao feeItemDao;
    
    /**
     * 校验表单是否可以保存/提交
     * @param formInfo
     * @param isSubmit
     * @return
     */
    public HikResult<String> checkFormValid(FormInfo formInfo, boolean isSubmit) {
        HikResult<String> rs = new HikResult<String>();
        
        if (formInfo != null) {
            FormHeader header = formInfo.getFormHeader();
            
            if (header != null) {
                DocTypeEnum docType = DocTypeEnum.valueOf(header.getDocType());

                //获取校验字段option
                CheckOption checkOpt = this.packageCheckOption(header, isSubmit);
                switch (docType) {
                    case WEM001:
                        //差旅申请行程变更
                        this.checkWEM001(formInfo, checkOpt, rs);
                        break;
                    case WEM002:
                        //差旅申请行程变更
                        this.checkWEM002(formInfo, checkOpt, rs);
                        break;
                    case WEM003:
                        header.setExpenseType(ExpenseType.C3.name());
                        //借款
                        this.checkLoanRequest(formInfo, checkOpt, rs);
                        break;
                    case WEM004:
                        header.setExpenseType("02");
                        //还款
                        this.checkRepaymentRequest(formInfo, checkOpt, rs);
                        break;
                    case WEM006:
                    case WEM010:
                    case WEM011:
                    case WEM012:
                        //国内、国际差旅报销，市内、长途派车
                        this.checkTravelExpense(formInfo, checkOpt, rs);
                        break;
                    case WEM008:
                        checkOpt.setNonTravelExpense(true);
                        this.checkWEM008Expense(formInfo, checkOpt, rs);
                        //个人费用
                        break;
                    default:
                        break;
                }
            } else {
                rs.getErrorMsgs().add("Input param error, form header not found!");
            }
        } else {
            rs.getErrorMsgs().add("Input param error, form data not found!");
        }
        
        return rs;
    }
    
    /**
     * 校验差旅申请是否合法
     * @param formInfo
     * @param checkOpt
     * @param rs
     */
    private void checkWEM001(FormInfo formInfo, CheckOption checkOpt, HikResult<String> rs) {
        FormHeader header = formInfo.getFormHeader();

        //获取错误信息list
        List<String> errors = rs.getErrorMsgs();
        boolean isSubmit = checkOpt.isSubmit();
        //校验抬头
        FieldCheckUtil.checkFormHeader(header, checkOpt, errors);
        List<Trip> trips = formInfo.getTrips();
        //校验差旅行程明细
        FieldCheckUtil.checkTripDetails(DocTypeEnum.WEM001.name(), trips, isSubmit, errors);
        boolean cn = FormUtil.checkIsForeignTrip(trips, "CN");
        //校验借款明细
        FieldCheckUtil.checkLoanDetails(cn, formInfo.getLoans(), isSubmit, errors);
        //校验同行人
        FieldCheckUtil.checkTripTogetherDetails(formInfo, errors);

        if (isSubmit && rs.isSuccess()) {
            header.setTripFromDate(trips.get(0).getFromDate());
            header.setTripToDate(trips.get(trips.size() - 1).getToDate());
        }
    }
    
    /**
     * 校验行程变更是否合法
     * @param formInfo
     * @param checkOpt
     * @param rs
     */
    private void checkWEM002(FormInfo formInfo, CheckOption checkOpt, HikResult<String> rs) {
        FormHeader header = formInfo.getFormHeader();
        
        //获取错误信息list
        List<String> errors = rs.getErrorMsgs();
        //校验抬头
        FieldCheckUtil.checkFormHeader(header, checkOpt, errors);
        List<Trip> trips = formInfo.getTrips();
        //校验差旅行程明细
        FieldCheckUtil.checkTripDetails(DocTypeEnum.WEM002.name(), trips, checkOpt.isSubmit(), errors);

        if (checkOpt.isSubmit() && rs.isSuccess()) {
            header.setTripFromDate(trips.get(0).getFromDate());
            header.setTripToDate(trips.get(trips.size() - 1).getToDate());
        }
    }
    
    /**
     * 校验借款申请是否合法
     * @param formInfo
     * @param checkOpt
     * @param rs
     */
    private void checkLoanRequest(FormInfo formInfo, CheckOption checkOpt, HikResult<String> rs) {
        FormHeader header = formInfo.getFormHeader();

        //获取错误信息list
        List<String> errors = rs.getErrorMsgs();
        //先校验抬头
        FieldCheckUtil.checkFormHeader(header, checkOpt, errors);
        //校验借款明细
        FieldCheckUtil.checkLoanDetails(true, formInfo.getLoans(), checkOpt.isSubmit(), errors);
    }
    
    /**
     * 校验还款申请是否合法
     * @param formInfo
     * @param checkOpt
     * @param rs
     */
    private void checkRepaymentRequest(FormInfo formInfo, CheckOption checkOpt, HikResult<String> rs) {
        FormHeader header = formInfo.getFormHeader();

        //先校验抬头
        FieldCheckUtil.checkFormHeader(header, checkOpt, rs.getErrorMsgs());
    }
    
    /**
     * 校验个人费用报销是否合法
     * @param formInfo
     * @param checkOpt
     * @param rs
     */
    public void checkWEM008Expense(FormInfo formInfo, CheckOption checkOpt, HikResult<String> rs) {
        FormHeader header = formInfo.getFormHeader();
        
        //是否提交
        boolean isSubmit = checkOpt.isSubmit();
        //获取错误信息list
        List<String> errors = rs.getErrorMsgs();
        //先校验抬头
        FieldCheckUtil.checkFormHeader(header, checkOpt, errors);
        //未填写任何费用进行信息提示
        if (isSubmit && formInfo.isEmptyFee() && feeItemDao.countOfees(header.getDocId()) == 0) {
            rs.addError("请至少填写一条费用信息！");
            return;
        }

        boolean isCqcb;
        List<OverproofInfo> remarks = formInfo.getOverproofs();
//        //校验市内交通费用明细
//        isCqcb = this.checkSNJTDetail(checkOpt, formInfo.getCityTrafficFees(), errors);
//        //获取超期超标说明list
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.SNJT)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                rs.addError("请填写市内交通超期超标说明！");
//            }
//        }
//        //校验业务招待
//        isCqcb = this.checkYWZDDetail(checkOpt, formInfo.getEntertainFees(), errors);
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.YWZD)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                rs.addError("请填写业务招待超期超标说明！");
//            }
//        }
        //校验车补无需校验
        //校验生育费用报销无需校验
        //校验其他费用  住宿费用报销必须要有税率税额
//        isCqcb = this.checkOtherDetail(checkOpt, formInfo.getOtherFees(), errors);
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.OTHER)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                rs.addError("请填写其他费用超期超标说明！");
//            }
//        }
        //校验他人收款信息
        BigDecimal amount = FieldCheckUtil.checkOtherReceivors(formInfo.getOtherReceivers(), isSubmit, errors);
        BigDecimal docAmount = header.getAmount();
        if (docAmount != null && amount.compareTo(docAmount) > 0) {
            rs.addError("他人收款总金额(" + amount + ")不能超过报销总金额(" + docAmount + ")，请调减收款总金额！"); 
        }
    }
    
    /**
     * 生成校验主体option
     * @param header
     * @param isSubmit
     * @return
     */
    public CheckOption packageCheckOption(FormHeader header, boolean isSubmit) {
        CheckOption checkOpt = new CheckOption();
        
        checkOpt.setSubmit(isSubmit);
        checkOpt.setWbsRequired(this.isXtgs(header));
        checkOpt.setTrafficProjectRequired(this.isJtsjb(header.getDeptCodePath()));
        //获取费用归属部门
        String deptCode = header.getDeptCode();
        List<SubBukrsFxwd> fxwds = baseDao.matchSubBukrsFxwd(deptCode);
        if (!ListUtil.isEmpty(fxwds)) {
            SubBukrsFxwd fxwd = fxwds.get(0);
            
            if (YesOrNoEnum.Y.name().equalsIgnoreCase(fxwd.getIndustryFlag())) {
                checkOpt.setIndustryRequired(true);
            }
            if (YesOrNoEnum.Y.name().equalsIgnoreCase(fxwd.getSalesAreaFlag())) {
                checkOpt.setSalesAreaRequired(true);
            }
            if (YesOrNoEnum.Y.name().equalsIgnoreCase(fxwd.getJfpgFlag())) {
                checkOpt.setJfpgRequired(true);
            }
        }
        //判断是否需要商机、客户、用户
        int number = baseDao.countBussinessOptNeedAmount(deptCode);
        if (number > 0) {
            checkOpt.setSjRequired(true);
        }
        //判断是否需要售前派工
        String sqpgFlag = baseDao.getUserNeedSqpgFlag(header.getExpensor());
        if (YesOrNoEnum.Y.name().equalsIgnoreCase(sqpgFlag)) {
            checkOpt.setSqpgRequired(true);
        }

        return checkOpt;
    }
    
    /**
     * 判断是否交通事业部
     * @param deptCodePath
     * @return
     */
    private boolean isJtsjb(String deptCodePath) {
        if (!Strings.isNullOrEmpty(deptCodePath) &&
                deptCodePath.contains("000170")) {
            return true;
        }
        
        return false;
    }
    
    /**
     * 当费用超期或者超标时，校验是否填写超期超标说明
     * @param remarks
     * @param gridType
     * @return
     */
    private boolean checkIsFillCqcbRemark(List<OverproofInfo> remarks, String gridType) {
        boolean isFill = false;
        
        if (!ListUtil.isEmpty(remarks)) {
            for (OverproofInfo remark : remarks) {
                if (gridType.equalsIgnoreCase(remark.getType()) && 
                        !Strings.isNullOrEmpty(remark.getRemark())) {
                    isFill = true;
                }
            }
        }
        
        return isFill;
    }
    
    /**
     * 校验是否系统公司
     * @param header
     * @return
     */
    private boolean isXtgs(FormHeader header) {
        String bukrs = header.getBukrs();
        
        if (Strings.isNullOrEmpty(bukrs) || !"8200".equalsIgnoreCase(bukrs)) {
            return false;
        } else {
            return true;
        }
    }
    
    /**
     * 校验费用明细是否合法
     * @param checkOpt
     * @param fees
     * @param errors            返回超期超标标识
     */
    public boolean checkSNJTDetail(CheckOption checkOpt, List<FeeDetail> fees, List<String> errors) {
        CheckOption opt = null;
        try {
            opt = checkOpt.clone();
        } catch (CloneNotSupportedException e) {
        }
        
        if (opt != null) {
            opt.setFeeDateRequired(true);
            //行程事由必输
            opt.setRemarkTripRequired(true);
            //交通工具必输
            opt.setTrafficToolRequired(true);
            //不需要校验商机
            opt.setSjRequired(false);
            //市内交通表格名称
            String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_CITY_TRIFFIC);
            return FieldCheckUtil.commonFeeCheck(gridName, fees, opt, errors);
        }
        
        return false;
    }
    
    /**
     * 校验费用明细是否合法
     * @param checkOpt
     * @param fees
     * @param errors            返回超期超标标识
     */
    public boolean checkYWZDDetail(CheckOption checkOpt, List<FeeDetail> fees, List<String> errors) {
        CheckOption opt = null;
        try {
            opt = checkOpt.clone();
        } catch (CloneNotSupportedException e) {
        }
        
        if (opt != null) {
            opt.setFeeDateRequired(true);
            //设置招待方式必输
            opt.setEntertainRequired(true);
            //设置客户级别必输
            opt.setEntertainLevelRequired(true);
            //设置人数必输
            opt.setPerCountsRequired(true);
            //设置天数必输
            opt.setDayCountsRequired(true);
            //业务招待表格名称
            String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_YWZD);
            return FieldCheckUtil.commonFeeCheck(gridName, fees, opt, errors);
        }
        
        return false;
    }
    
    /**
     * 校验费用明细是否合法
     * @param checkOpt
     * @param fees
     * @param errors            返回超期超标标识
     */
    public boolean checkOtherDetail(CheckOption checkOpt, List<FeeDetail> fees, List<String> errors) {
        CheckOption opt = null;
        try {
            opt = checkOpt.clone();
        } catch (CloneNotSupportedException e) {
        }
        
        if (opt != null) {
            opt.setFeeDateRequired(true);
            //设置费用细类必输
            opt.setSmaFeeTypeRequired(true);
            //不需要校验商机
            opt.setSjRequired(false);
            //其他费用表格名称
            String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_OTHER);
            return FieldCheckUtil.commonFeeCheck(gridName, fees, opt, errors);
        }
        
        return false;
    }
    
    /**
     * 差旅报销是否合法
     * @param formInfo
     * @param checkOpt
     * @param rs
     */
    private void checkTravelExpense(FormInfo formInfo, CheckOption checkOpt, HikResult<String> rs) {
        FormHeader header = formInfo.getFormHeader();
        
        //是否提交
        boolean isSubmit = checkOpt.isSubmit();
        //获取错误信息list
        List<String> errors = rs.getErrorMsgs();
        //先校验抬头
        FieldCheckUtil.checkFormHeader(header, checkOpt, errors);
        if (isSubmit) {
            //报销金额不能为0
//            BigDecimal amount = header.getAmount();
//            if (amount == null || amount.compareTo(BigDecimal.ZERO) == 0) {
//                rs.addError("报销单金额必须大于0");
//            }
            //未填写任何费用进行信息提示
            if (formInfo.isEmptyFee() && feeItemDao.countOfees(header.getDocId()) == 0) {
                rs.addError("请至少填写一条费用信息！");
                return;
            }
        }

        if (!DocTypeEnum.WEM011.name().equals(header.getDocType())) {
            List<Trip> trips = Lists.newArrayList();
            for (FeeDetail detail : formInfo.getLongDistanceTrafficFees()) {
                Trip trip = new Trip();
                trip.setFromDate(detail.getFeeFromDate());
                trip.setCountryFrom(detail.getCountryFrom());
                trip.setPlaceFrom(detail.getPlaceFrom());
                trip.setToDate(detail.getFeeToDate());
                trip.setCountryTo(detail.getCountryTo());
                trip.setPlaceTo(detail.getPlaceTo());
                trip.setToolType(detail.getTrafficToolType());
                trip.setToolLevel(detail.getTrafficToolLevel());
                trips.add(trip);
            }
            FieldCheckUtil.checkTripDetails(formInfo.getFormHeader().getDocType(), trips, checkOpt.isSubmit(), errors);
        }

        boolean isCqcb;
        List<OverproofInfo> remarks = formInfo.getOverproofs();
//        //校验市内交通费用明细
//        isCqcb = this.checkSNJTDetail(checkOpt, formInfo.getCityTrafficFees(), errors);
//        //获取超期超标说明list
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.SNJT)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                errors.add("请填写市内交通超期超标说明！");
//            }
//        }
//        //校验业务招待
//        isCqcb = this.checkYWZDDetail(checkOpt, formInfo.getEntertainFees(), errors);
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.YWZD)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                errors.add("请填写业务招待超期超标说明！");
//            }
//        }
        //长途派车时，不需要校验金额
        if (DocTypeEnum.WEM012.name().equalsIgnoreCase(header.getDocType())) {
            checkOpt.setAmountRequired(false);
        }
        //校验长途交通
        isCqcb = this.checkCTJTDetail(header.getDocType(), checkOpt, formInfo.getLongDistanceTrafficFees(), errors);
        if (isCqcb && isSubmit) {
            //校验超期超标说明是否填写
            if (!this.checkIsFillCqcbRemark(remarks, FeeType.CTJT)) {
                //未填写市内交通超期超标说明，需要提示填写
                errors.add("请填写长途交通超期超标说明！");
            }
        }
        //其他费用还是需要校验金额必输的
        checkOpt.setAmountRequired(true);
//        //校验住宿费用
//        isCqcb = this.checkStaysDetails(checkOpt, formInfo.getStaysFees(), errors);
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.STAYS)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                errors.add("请填写住宿费用超期超标说明！");
//            }
//        }
//        //校验其他费用  住宿费用报销必须要有税率税额
//        isCqcb = this.checkOtherDetail(checkOpt, formInfo.getOtherFees(), errors);
//        if (isCqcb && isSubmit) {
//            //校验超期超标说明是否填写
//            if (!this.checkIsFillCqcbRemark(remarks, FeeType.OTHER)) {
//                //未填写市内交通超期超标说明，需要提示填写
//                errors.add("请填写其他费用超期超标说明！");
//            }
//        }
        //校验派工是否关联
        if (isSubmit && ListUtil.isEmpty(formInfo.getSqpgDocs())) {
            if (checkOpt.isSqpgRequired()) {
                errors.add("请关联至少一个派工单！");
            }
        }
    }
    
    /**
     * 校验长途交通费用明细
     * @param docType
     * @param checkOpt
     * @param fees
     * @param errors
     */
    private boolean checkCTJTDetail(String docType, CheckOption checkOpt, List<FeeDetail> fees, List<String> errors) {
        CheckOption opt = null;
        try {
            opt = checkOpt.clone();
        } catch (CloneNotSupportedException e) {
        }
        
        if (opt != null) {
            //出发时间必输
            opt.setDateFromRequired(true);
            //到达时间必输
            opt.setDateToRequired(true);
            //出发城市必输
            opt.setCityFromRequired(true);
            //达到城市必输
            opt.setCityToRequired(true);
            //不需要校验商机
            opt.setSjRequired(false);
            //差旅报销需要校验长途交通工具类别和座位级别
            if (DocTypeEnum.WEM006.name().equalsIgnoreCase(docType) ||
                    DocTypeEnum.WEM010.name().equalsIgnoreCase(docType)) {
                //交通工具类别必输
                opt.setTrafficToolTypeRequired(true);
                //交通工具座位级别必输
                opt.setTrafficToolLevelRequired(true);
            }
            if (DocTypeEnum.WEM006.name().equalsIgnoreCase(docType)
                    || DocTypeEnum.WEM010.name().equalsIgnoreCase(docType)
                    || DocTypeEnum.WEM012.name().equalsIgnoreCase(docType)) {
                // 行程表格事由不用填
                opt.setRemarkRequired(false);
            }
            //长途交通表格名称
            String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_CTJT);
            return FieldCheckUtil.commonFeeCheck(gridName, fees, opt, errors);
        }
        
        return false;
    }
    
    /**
     * 校验住宿费用是否合法
     * @param checkOpt
     * @param fees
     * @param errors
     * @return
     */
    private boolean checkStaysDetails(CheckOption checkOpt, List<FeeDetail> fees, List<String> errors) {
        CheckOption opt = null;
        try {
            opt = checkOpt.clone();
        } catch (CloneNotSupportedException e) {
        }
        
        if (opt != null) {
            //租住标识必输
            opt.setRentFlagRequired(true);
            //入住日期必输
            opt.setStaysDateRequired(true);
            //退房日期必输
            opt.setLeaveDateRequired(true);
            //住宿城市必输
            opt.setStaysCityRequired(true);
            //房间数必输
            opt.setRoomsRequired(true);
            //住宿情况说明必输
            opt.setStaysRemarkRequired(false);
            opt.setRemarkRequired(false);
            //税额必输
            opt.setTaxRequired(true);
            //不需要校验商机
            opt.setSjRequired(false);
            //住宿交通表格名称
            String gridName = MessageCache.getMessage(MessageCode.GRID_NAME_STAYS);
            return FieldCheckUtil.commonFeeCheck(gridName, fees, opt, errors);
        }
        
        return false;
    }
}
