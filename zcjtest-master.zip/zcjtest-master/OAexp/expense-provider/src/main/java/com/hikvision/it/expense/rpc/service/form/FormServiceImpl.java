package com.hikvision.it.expense.rpc.service.form;

import static com.hikvision.it.expense.api.entity.fee.FeeType.CLBT;
import static com.hikvision.it.expense.api.entity.fee.FeeType.CTJT;
import static com.hikvision.it.expense.api.entity.fee.FeeType.FWZL;
import static com.hikvision.it.expense.api.entity.fee.FeeType.OTHER;
import static com.hikvision.it.expense.api.entity.fee.FeeType.SNJT;
import static com.hikvision.it.expense.api.entity.fee.FeeType.SNPC;
import static com.hikvision.it.expense.api.entity.fee.FeeType.STAYS;
import static com.hikvision.it.expense.api.entity.fee.FeeType.SYBX;
import static com.hikvision.it.expense.api.entity.fee.FeeType.YWZD;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.function.Predicate;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.google.common.base.Strings;
import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.AdjustAmountBean;
import com.hikvision.it.expense.api.entity.fee.AdjustItem;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.flow.DocHeader;
import com.hikvision.it.expense.api.entity.flow.DocNumber;
import com.hikvision.it.expense.api.entity.flow.MailEntity;
import com.hikvision.it.expense.api.entity.flow.ProcessConfig;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.form.OverproofInfo;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.entity.history.ApproveHistory;
import com.hikvision.it.expense.api.entity.oa.SqpgDoc;
import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripDuplicated;
import com.hikvision.it.expense.api.entity.trip.TripTogether;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.entity.user.UserBank;
import com.hikvision.it.expense.api.enums.DocStatusEnum;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.allowance.ICalculateSubsidyService;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.process.IProcessService;
import com.hikvision.it.expense.api.service.task.ITaskService;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.attachment.IAttachmentDao;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.fee.IFeeDao;
import com.hikvision.it.expense.rpc.dao.form.IDocNumberDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.logs.ISendLogDao;
import com.hikvision.it.expense.rpc.dao.process.IProcessDao;
import com.hikvision.it.expense.rpc.dao.report.IReportDao;
import com.hikvision.it.expense.rpc.dao.subsidy.ISubsidyDao;
import com.hikvision.it.expense.rpc.dao.task.ITaskDao;
import com.hikvision.it.expense.rpc.dao.trip.ITripDao;
import com.hikvision.it.expense.rpc.dao.user.IUserDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.service.pi.BankServiceImpl;
import com.hikvision.it.expense.rpc.service.pi.BsikServiceImpl;
import com.hikvision.it.expense.rpc.util.FormUtil;

@Service
@Primary
public class FormServiceImpl implements IFormService {
    private Logger logger = LoggerFactory.getLogger(getClass());

    Predicate<? super AdjustItem> validAdjustItem = (Predicate<AdjustItem>) item -> item.getAdjustAmount() == null
            || item.getAdjustAmount().compareTo(BigDecimal.ZERO) < 0
            || item.getAdjustAmount().compareTo(item.getAmount()) > 0;

    @Autowired
    IBaseDao baseDao;
    @Autowired
    IUserDao userDao;
    @Autowired
    IDocNumberDao docNumberDao;
    @Autowired
    ISubsidyDao subsidyDao;
    @Autowired
    IFormDao formDao;
    @Autowired
    IFeeDao feeDao;
    @Autowired
    ITripDao tripDao;
    @Autowired
    IReportDao reportDao;
    @Autowired
    ITaskDao taskDao;
    @Autowired
    ISendLogDao logDao;
    @Autowired
    IAttachmentDao attachmentDao;
    @Autowired
    IProcessService processService;
    @Autowired
    IProcessDao processDao;
    @Autowired
    BsikServiceImpl bsikService;
    @Autowired
    IVoucherService voucherService;
    @Autowired
    FormCheckServiceImpl checkService;
    @Autowired
    ITaskService taskService;
    @Autowired
    BankServiceImpl bankService;
    @Autowired
    ICalculateSubsidyService calculateSubsidyService;
    @Autowired
    TemplateEngine templateEngine;


    @Override
    public HikResult<FormInfo> getFormInfo(String docId, String userId) {
        String language = UserContext.getLanguage();
        HikResult<FormInfo> rs = new HikResult<FormInfo>();
        FormInfo form = new FormInfo();

        form.setAttachNumber(attachmentDao.countAttachment(docId));

        FormHeader header = formDao.getFormHeader(docId);
        List<OverproofInfo> overproofs = formDao.getOverproof(docId);
        List<SqpgDoc> sqpgDocs = formDao.getSqpgDocs(docId);
        if (header == null) {
            throw new ExpenseException(MessageCache.getMessage(MessageCode.DOC_NOT_FOUND));
        }
        form.setFormHeader(header);
        form.setOverproofs(overproofs);
        form.setSqpgDocs(sqpgDocs);
        DocTypeEnum docType;
        try {
            docType = DocTypeEnum.valueOf(header.getDocType());
        } catch (Exception e) {
            logger.warn("error doc type {}", header.getDocType());
            rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.MSG_UNKNOWN_DOCTYPE));
            return rs;
        }

        switch (docType) {
            case WEM001:
                form.setTrips(tripDao.getTrips(docId, language));
                form.setTripTogethers(tripDao.getTripTogethers(docId));
                form.setLoans(formDao.getLoans(docId));
                break;
            case WEM002:
                form.setTrips(tripDao.getTrips(docId, language));
                break;
            case WEM003:
                form.setLoans(formDao.getLoans(docId));
                break;
            case WEM006:
                form.setTravelReport(tripDao.getTravelReport(docId));
                getFeeDetails(form, docId);
            case WEM008:
                getFeeDetails(form, docId);
                break;
            case WEM011:
                getFeeDetails(form, docId);
                break;
            case WEM012:
                getFeeDetails(form, docId);
                break;
            default:
                break;
        }

        if (rs.isSuccess()) {
            rs.setData(form);
        }

        return rs;
    }

    private void getFeeDetails(FormInfo form, String docId) {
        List<FeeDetail> list = feeDao.getFeeDetails(docId, UserContext.getLanguage());
        list.addAll(feeDao.getTravelFees(docId, UserContext.getLanguage()));
        List<FeeDetail> snpcFees = Lists.newArrayList();
        List<FeeDetail> ctjtFees = Lists.newArrayList();
        List<FeeDetail> zsfyFees = Lists.newArrayList();
        List<FeeDetail> snjtFees = Lists.newArrayList();
        List<FeeDetail> ywzdFees = Lists.newArrayList();
        List<FeeDetail> sybxFees = Lists.newArrayList();
        List<FeeDetail> clbtFees = Lists.newArrayList();
        List<FeeDetail> fwzlFees = Lists.newArrayList();
        List<FeeDetail> otherFees = Lists.newArrayList();

        for (FeeDetail detail : list) {
            if (SNJT.equals(detail.getFeeType())) {
                snjtFees.add(detail);
            } else if (YWZD.equals(detail.getFeeType())) {
                ywzdFees.add(detail);
            } else if (SYBX.equals(detail.getFeeType())) {
                sybxFees.add(detail);
            } else if (CLBT.equals(detail.getFeeType())) {
                clbtFees.add(detail);
            } else if (FWZL.equals(detail.getFeeType())) {
                fwzlFees.add(detail);
            } else if (OTHER.equals(detail.getFeeType())) {
                otherFees.add(detail);
            } else if (CTJT.equals(detail.getFeeType())) { // 长途交通
                ctjtFees.add(detail);
            } else if (STAYS.equals(detail.getFeeType())) { // 住宿
                zsfyFees.add(detail);
            } else if (SNPC.equals(detail.getFeeType())) { // 市内派车
                snpcFees.add(detail);
            } else {
                logger.warn("unknown detail, id = {}", detail.getId());
            }
        }
        form.setInsideCityDriverFees(snpcFees);
        form.setLongDistanceTrafficFees(ctjtFees);
        form.setStaysFees(zsfyFees);
        form.setCityTrafficFees(snjtFees);
        form.setEntertainFees(ywzdFees);
        form.setBirthFees(sybxFees);
        form.setCarAllowanceFees(clbtFees);
        form.setRentFees(fwzlFees);
        form.setOtherFees(otherFees);
    }

    @Override
    public boolean isReadable(String docId) {
        String userId = UserContext.getUserId();
        if (Strings.isNullOrEmpty(userId)) {
            return false;
        }
        //先校验权限，然后返回单据信息
        if (formDao.countDocNumberWithRoleCheck(docId, UserContext.getUserId()) != 0) {
            return true;
        }
        // 填单人, 报销人
        FormHeader header = formDao.getFormHeader(docId);
        if (header == null) {
            return false;
        }
        if (userId.equalsIgnoreCase(header.getExpensor()) || userId.equals(header.getCreatedBy())) {
            return true;
        }
        //超级管理员
        if (YesOrNoEnum.Y.name().equals(userDao.getSuperAdmin(userId))) {
            return true;
        }

        // 历史审批人
        List<String> owners = taskDao.getTaskOwnersByDocId(docId);
        return owners.contains(userId);
    }

    @Override
    public boolean isEditable(String docId) {
        String userId = UserContext.getUserId();
        if (Strings.isNullOrEmpty(userId)) {
            return false;
        }
        //判断单据状态
        FormHeader header = formDao.getFormHeader(docId);

        if (header == null) {
            return true;
        }
        String docStatus = header.getDocStatus();
        if (!(Strings.isNullOrEmpty(docStatus) ||
                DocStatusEnum.S001.name().equalsIgnoreCase(docStatus) ||
                DocStatusEnum.S005.name().equalsIgnoreCase(docStatus))) {
            return false;
        }
        //校验单据操作权限  报销人/创建人/者超级管理员有权限
        return userId.equalsIgnoreCase(header.getExpensor()) ||
                userId.equalsIgnoreCase(header.getCreatedBy()) ||
                YesOrNoEnum.Y.name().equalsIgnoreCase(userDao.getSuperAdmin(userId));
    }

    @Override
    @Transactional
    public HikResult<String> approve(String taskId, String suggest, ResultEnum result, List<TaskReceivor> receivers) {

        String docId = taskDao.getDocIdByTaskId(taskId);
        FormHeader formHeader = formDao.getFormHeader(docId);

        DocStatusEnum docStatus = DocStatusEnum.S003;
        // docStatus状态更新
        switch (result) {
            case ADDSTEP:
            case AGREE:
            case FORWARD:
                docStatus = DocStatusEnum.S003;
                break;
            case REFUSE:
                docStatus = DocStatusEnum.S006;
                break;
            case REJECT:
                docStatus = DocStatusEnum.S005;
                break;
            default:
                break;
        }
        formDao.updateDocStatus(docId, docStatus.name());

        if (ResultEnum.ADDSTEP == result) {
            return taskService.addStep(taskId, suggest, receivers);
        } else if (ResultEnum.FORWARD == result) {
            return taskService.forwardTask(taskId, suggest, receivers.get(0));
        } else {
            if (ResultEnum.REFUSE == result || ResultEnum.REJECT == result) {
                if (!Strings.isNullOrEmpty(formHeader.getRefDocId())) {
                    // 否决, 如果有关联单据, 把关联单据tflag改回D
                    formDao.resetReferenceDocToDefault(formHeader.getRefDocId());
                }
            }
            return taskService.completeTask(taskId, result, suggest);
        }
    }

    @Override
    @Transactional
    public HikResult<String> saveFormInfo(FormInfo form) {
        getAndPutStaysIntoForm(form);
        HikResult<String> rs = this.checkValidBeforeSave(form, false);
        if (rs.isSuccess()) {
            //保存单据信息
            this.updateFormInfo(form, false, rs);
        }

        return rs;
    }

    @Override
    @Transactional
    public HikResult<String> submitFormInfo(FormInfo form) {
        //获取公司base地
        String baseCountry = baseDao.getBukrsBaseCountry(form.getFormHeader().getBukrs());
        //国内、国际差旅设置
        this.packageTripType(form, baseCountry);
        getAndPutStaysIntoForm(form);
        //校验单据是否有效
        HikResult<String> rs = this.checkValidBeforeSave(form, true);
        if (rs.isSuccess()) {
            List<TripTogether> txrList = form.getTripTogethers();
            if (!ListUtil.isEmpty(txrList)) {
                FormHeader header = form.getFormHeader();
                for (TripTogether txr : txrList) {
                    FormHeader cloneHeader = header.clone();

                    cloneHeader.setExpensor(txr.getUserId());
                    cloneHeader.setExpensorName(txr.getUserName());
                    cloneHeader.setDeptCode(txr.getDeptCode());
                    cloneHeader.setDocId(StringUtil.getUUID());

                    FormInfo txrForm = new FormInfo();

                    txrForm.setFormHeader(cloneHeader);
                    txrForm.setTrips(form.getTrips());

                    this.updateFormInfo(txrForm, true, rs);
                }
            }
            //保存单据信息
            this.updateFormInfo(form, true, rs);
        }


        return rs;
    }

    /**
     * 更新单据信息
     */
    private void updateFormInfo(FormInfo form, boolean isSubmit, HikResult<String> rs) {
        String language = UserContext.getLanguage();

        FormHeader header = form.getFormHeader();
        //设置单据语言
        header.setLanguage(language);
        //获取单据数量
        int docNumber = formDao.countFormNumber(header.getDocId());
        if (!DocTypeEnum.WEM002.name().equals(form.getFormHeader().getDocType())) {//行程变更不生成新单号
            if (docNumber == 0) {
                //首次保存 获取单号
                this.increaseCurrentDocNumber(isSubmit, header.getBukrs(), header.getDocType(), rs);

                if (rs.isSuccess()) {
                    header.setDocNo(rs.getData());
                }
            } else if (docNumber == 1) {
                if ((Strings.isNullOrEmpty(header.getDocStatus()) ||
                        DocStatusEnum.S001.name().equals(header.getDocStatus())) && isSubmit) {
                    // 草稿箱提交
                    this.increaseCurrentDocNumber(isSubmit, header.getBukrs(), header.getDocType(), rs);
                    if (rs.isSuccess()) {
                        header.setDocNo(rs.getData());
                    }
                }
            } else if (docNumber != 1) {
                rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.SINGLE_DATA_ERROR, new Object[]{docNumber, "单据"}));
            }
        }
        //开始保存单据  判断是首次保存还是更新
        if (rs.isSuccess()) {
            long upTime = Calendar.getInstance().getTimeInMillis();
            DocTypeEnum docType = DocTypeEnum.valueOf(header.getDocType());

            header.setLoanFlag(form.getLoans() != null && form.getLoans().size() > 0 ? "Y" : "N");
            header.setTxrFlag(form.getTripTogethers() != null && form.getTripTogethers().size() > 0 ? "Y" : "N");
            header.setPayAmount(header.getAmount()); // 实际报销总金额初始化值等于报销总金额, 财务调整时单独跟新该字段

            int effNum = 0;
            if (docNumber == 0) {
                header.setDocStatus(DocStatusEnum.S001.name());
                header.setUpTime(upTime);
                effNum = formDao.insertFormHeader(header);
                formDao.insertFormTxt(header);
                formDao.insertFormFlag(header);
            } else {
                effNum = formDao.updateFormHeader(header, upTime);
                header.setUpTime(upTime);
                formDao.updateFormTxt(header);
                formDao.updateFormFlag(header);
            }

            if (effNum == 0) {
                rs.addError("单据保存失败，请确认单据是否已提交或已删除!");
            } else {
                if (ListUtil.isNotEmpty(form.getOverproofs())) {
                    formDao.deleteOverproof(header.getDocId());
                    formDao.insertOverproof(header.getDocId(), form.getOverproofs());
                }
                if (ListUtil.isNotEmpty(form.getSqpgDocs())) {
                    formDao.deleteSqpgDocs(header.getDocId());
                    formDao.insertSqpgDocs(header.getDocId(), form.getSqpgDocs());
                }
                if (!ListUtil.isEmpty(form.getOtherReceivers())) {
                    formDao.deleteOtherReceivers(header.getDocId());
                    formDao.insertOtherReceivers(header.getDocId(), form.getOtherReceivers());
                }
                if (form.getTravelReport() != null) {
                    form.getTravelReport().setUserId(UserContext.getUserId());
                    tripDao.deleteTravelReport(form.getFormHeader().getDocId());
                    tripDao.insertTravelReport(form.getTravelReport());
                }
                switch (docType) {
                    case WEM001:
                        this.saveWEM001GridInfo(form);
                        break;
                    case WEM002:
                        this.saveWEM002GridInfo(form, isSubmit);
                        break;
                    case WEM003:
                        this.saveWEM003GridInfo(form);
                        break;
                    case WEM006:

                    case WEM010:
                    case WEM012:
                        this.calculateSubsidy(form); // 计算并保存补贴信息
                        this.saveWEM006GridInfo(form);
                        break;
                    case WEM008:
                        this.saveWEM008GridInfo(form);
                        break;
                    case WEM011:
                        this.saveWEM011GridInfo(form);
                        break;
                    default:
                        break;
                }
                // 增加单据补贴金额
                formDao.addSubsidyAmount(form.getFormHeader().getDocId(), form.getFormHeader().getSubsidyAmount());

                if (isSubmit) {
                    //更新单据为已提交
                    String docStatus = header.getDocStatus();
                    if (!DocStatusEnum.S005.name().equalsIgnoreCase(docStatus)) {
                        effNum = formDao.submitForm(header);
                        if (effNum != 0) {
                            //根据单据信息匹配出适用的流程实例id
                            String processObjectId = this.regexProcessObject(header);
                            if (!Strings.isNullOrEmpty(processObjectId)) {
                                //启动流程
                                HikResult<ProcessInstance> proRs = processService.createAndStartProcess(header.getDocId(), processObjectId);

                                if (proRs.isSuccess()) {
                                    taskService.startTask(proRs.getData());
                                } else {
                                    throw new ExpenseException(ExceptionCode.PROCESS_START_FAILURE);
                                }
                            } else {
                                //适用流程未配置异常
                                throw new ExpenseException(ExceptionCode.PROCESS_NOT_CONFIG);
                            }
                        }
                    } else {
                        effNum = formDao.reSubmitForm(header);
                        if (effNum != 0) {
                            //流转流程
                            taskService.completeTask(form.getTaskId(), ResultEnum.SUBMIT, null);
                        }
                    }

                    if (effNum == 0)
                        throw new ExpenseException(ExceptionCode.DOC_HAS_CHANGED_OR_EXPENSED);
                }
            }
        }
    }

    /**
     * 补贴计算
     *
     * @param formInfo
     */
    @Override
    public void calculateSubsidy(FormInfo formInfo) {
        FormHeader header = formInfo.getFormHeader();
        List<FeeDetail> stayFees;
        List<Trip> trips;
        if (ListUtil.isNotEmpty(formInfo.getStaysFees())) {
            stayFees = formInfo.getStaysFees();
        } else {
            stayFees = Lists.newArrayList();
        }
        // 长途交通
        if (ListUtil.isNotEmpty(formInfo.getLongDistanceTrafficFees())) {
            trips = formInfo.getLongDistanceTrafficFees().stream().map(this::transferLongDistanceTrafficFeeToTrip).collect(Collectors.toList());
        } else {
            trips = Lists.newArrayList();
        }
        List<Allowance> allowances = calculateSubsidyService.calculateAllowance(header, trips);
        List<AllowanceDetail> rentAllowances = calculateSubsidyService.calculateRentAllowance(header, stayFees);

        // 将租住补贴添加到补贴汇总中, 并保存
        Map<String, Allowance> allowanceMap = allowances.stream().collect(Collectors.toMap(Allowance::getAllowanceDate, Function.identity()));
        for (AllowanceDetail rent : rentAllowances) {
            Allowance allowance;
            if (allowanceMap.containsKey(rent.getAllowanceDate())) { // 已存在, 直接更新租住补贴字段
                allowance = allowanceMap.get(rent.getAllowanceDate());
            } else { // 不存在汇总新增, 初始化信息从租住补贴额上取
                allowance = new Allowance();
                allowance.setId(StringUtil.getUUID());
                allowance.setDocId(header.getDocId());
                allowance.setDocNo(header.getDocNo());
                allowance.setCountry(rent.getCountry());
                allowance.setCity(rent.getCity());
                allowance.setCurrency(rent.getCurrency());
                allowance.setUserName(rent.getUserName());
                allowance.setAllowanceDate(rent.getAllowanceDate());
                allowance.setUserId(rent.getUserId());
                allowanceMap.put(rent.getAllowanceDate(), allowance);
            }
            allowance.setRentAllowanceAmount(rent.getPayAmount());
        }
        // 将包含租住补贴的汇总map转成list,并根据日期排序
        List<Allowance> newAllowances = allowanceMap.entrySet()
                .stream()
                .map(Map.Entry::getValue)
                .sorted(Comparator.comparing(Allowance::getAllowanceDate))
                .collect(Collectors.toList());

        subsidyDao.deleteAllowance(header.getDocId());
        if (ListUtil.isNotEmpty(newAllowances)) {
            subsidyDao.batchInsertAllowance(newAllowances);
        }
    }

    @Override
    @Transactional
    public HikResult<String> recordMail(List<VendorFormHeader> lists) {
        HikResult<String> result = new HikResult<String>();
//      将数据根据邮件接收人分组
        Map<String, List<VendorFormHeader>> groups = new HashMap<>();
        for (VendorFormHeader header : lists) {
            if (groups.containsKey(header.getMailReceivorMailAddress())) {
                groups.get(header.getMailReceivorMailAddress()).add(header);
            } else {
                List<VendorFormHeader> value = new ArrayList<>();
                value.add(header);
                groups.put(header.getMailReceivorMailAddress(), value);
            }
        }
//遍历
        String date = DateUtil.getCurrentDateString();
        try {
            for (List<VendorFormHeader> list : groups.values()) {
                MailEntity mail = this.packageMail(list, date);
                logDao.recordMailInfo(mail);
            }
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result.addError(MessageCache.getMessage(MessageCode.RUNTIME_ERROR, "批量修改邮件失败!"));
        }
        return result;
    }

    @Override
    @Transactional
    public HikResult<List<VendorFormHeader>> batchSaveVendorInvoiceMailAddress(Map<Integer, String> map) {
        HikResult<List<VendorFormHeader>> hikResult = new HikResult<>();
        List<String> errors = new ArrayList<>();
//       用于页面回显导入的excel记录
        List<VendorFormHeader> correcTheaders = new ArrayList<>();
        List<VendorFormHeader> eorrorHeaders = new ArrayList<>();
//       是否有错误记录开关
        boolean isError = false;
//      遍历验证
        for (String value : map.values()) {
//            在解析excel时就用  "    " 隔开 所有用此字符串在解析成list
            String[] list = value.split("    ");
            boolean flag = checkMailAndDocIdLegal(list[list.length - 1], list[0]);
//          防止修改单号程 12345.0这种格式


//          如果格式验证不正确 则加入到错误list中
            if (!flag) {
                isError = true;
                VendorFormHeader eorrorHeader = new VendorFormHeader();
                eorrorHeader.setDocId(list[0]);
                eorrorHeaders.add(eorrorHeader);
            }
        }
        //全部验证正确后保存
        if (!isError) {
            for (String value : map.values()) {
                String[] list = value.split("    ");
                this.saveVendorInvoiceMailAddress(list[0], list[list.length - 1]);
                VendorFormHeader newHeader = reportDao.listVendorAdvice(list[0], null, null, null, null, null).get(0);
                correcTheaders.add(newHeader);
            }
//            正确则返回正确的list用于页面显示数据
            hikResult.setData(correcTheaders);
        } else {
//            错误则返回错误list 只要单号数据就行
            hikResult.addError("excel导入错误!");
            hikResult.setData(eorrorHeaders);
        }
        return hikResult;
    }


    /**
     * 生成邮件实体
     *
     * @return
     */
    private MailEntity packageMail(List<VendorFormHeader> lists, String datestr) {
        MailEntity mail = new MailEntity();
        Context model = new Context();
        model.setVariable("lists", lists);
        model.setVariable("sysdata", datestr);
        // 设置邮件正文
        mail.setContent(this.getMessage(model));

        // 设置邮件标题
//       这一段逻辑是为了防止在通过spring job发送邮件时 不需要用户登录从而取不到用时MessageCache报错
        LoginUser user = null;
        try {
            user = UserContext.get();
            mail.setSubject(MessageCache.getMessage(MessageCode.TITLE_VENDOR_ADVICE_TEMP));
        } catch (Exception e) {
            mail.setSubject("请您关注以下未核销预付款单据");
        }
        //设置内外网邮件
        mail.setIsOutMail("N");
        mail.setDocId(lists.get(0).getDocId());
        mail.setReceivors(lists.get(0).getMailReceivorMailAddress());
        mail.setIsApprove(YesOrNoEnum.N.name());
        return mail;

    }

    /**
     * 将参数设置到模板文件中，并且返回文件内容
     *
     * @param model
     * @return
     */
    protected final String getMessage(Context model) {
        return templateEngine.process("zh/vendorAdvice", model);
    }

    private Trip transferLongDistanceTrafficFeeToTrip(FeeDetail source) {
        Trip target = new Trip();
        target.setRn(source.getRn());

        target.setFromDate(source.getFeeFromDate());
        if (!Strings.isNullOrEmpty(source.getFromTime())) {
            target.setFromTime(Integer.parseInt(source.getFromTime()));
        }
        target.setCountryFrom(source.getCountryFrom());
        target.setPlaceFrom(source.getPlaceFrom());
        target.setFromDesc(source.getPlaceFromDesc());

        target.setToDate(source.getFeeToDate());
        if (!Strings.isNullOrEmpty(source.getToTime())) {
            target.setToTime(Integer.parseInt(source.getToTime()));
        }
        target.setCountryTo(source.getCountryTo());
        target.setPlaceTo(source.getPlaceTo());
        target.setToDesc(source.getPlaceToDesc());

        target.setToolType(source.getTrafficToolType());
        target.setToolLevel(source.getTrafficToolLevel());
        target.setToolDesc(source.getTrafficToolLevelDesc());
        return target;
    }


    /**
     * 匹配适用的流程定义id
     */
    private String regexProcessObject(FormHeader header) {
        String docType = header.getDocType();
        String expenseType = header.getExpenseType();
        String bukrs = header.getBukrs();
        String deptCode = header.getDeptCode();
        //先获取单据类别所有匹配的流程配置信息
        List<ProcessConfig> configs = formDao.getProcessConfigByDocType(docType);

        if (!ListUtil.isEmpty(configs)) {
            if (configs.size() == 1) {
                return configs.get(0).getProcessObjectId();
            } else {
                return this.matchSupportedProcessConfig(configs, expenseType, deptCode, bukrs);
            }
        }

        return null;
    }

    /**
     * 先精确匹配，然后依次对部门、公司、费用类型进行模糊匹配
     *
     * @param configs
     * @param expenseType
     * @param deptCode
     * @param bukrs
     * @return
     */
    private String matchSupportedProcessConfig(List<ProcessConfig> configs,
                                               String expenseType, String deptCode, String bukrs) {
        String processObjectId = null;
        for (ProcessConfig config : configs) {
            if (config.getBukrs().equalsIgnoreCase(bukrs) &&
                    config.getDeptCode().equalsIgnoreCase(deptCode) &&
                    config.getExpenseType().equalsIgnoreCase(expenseType)) {
                processObjectId = config.getProcessObjectId();

                break;
            }
        }

        if (!Strings.isNullOrEmpty(processObjectId)) {
            return processObjectId;
        } else {
            if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(deptCode)) {
                processObjectId = this.matchSupportedProcessConfig(configs, expenseType, StringUtil.COMMON_REGEX, bukrs);
            }
            if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(bukrs)) {
                processObjectId = this.matchSupportedProcessConfig(configs, expenseType, deptCode, StringUtil.COMMON_REGEX);
            }
            if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(expenseType)) {
                processObjectId = this.matchSupportedProcessConfig(configs, StringUtil.COMMON_REGEX, deptCode, bukrs);
            }
        }

        return processObjectId;
    }

    /**
     * 保存借款表格信息
     *
     * @param form
     */
    private void saveWEM003GridInfo(FormInfo form) {
        FormHeader header = form.getFormHeader();

        String docId = header.getDocId();
        String docNo = header.getDocNo();

        formDao.softDelLoans(docId);

        if (!ListUtil.isEmpty(form.getLoans())) {
            //保存借款
            formDao.insertLoans(form.getLoans(), docId, docNo);
        }
    }

    /**
     * 差旅报销表格信息
     */
    private void saveWEM006GridInfo(FormInfo form) {
        feeDao.deleteFeeDetailsFromOfeeTable(form.getFormHeader().getDocId());
        feeDao.deleteFeeDetailsFromStaysTable(form.getFormHeader().getDocId());

        // 长途交通
        if (!ListUtil.isEmpty(form.getLongDistanceTrafficFees())) {
            setFeeType(form.getLongDistanceTrafficFees(), CTJT);
            feeDao.insertLongTrafficStaysDetails(form.getFormHeader(), form.getLongDistanceTrafficFees());
        }
        // 住宿费用
        if (!ListUtil.isEmpty(form.getStaysFees())) {
            setFeeType(form.getStaysFees(), STAYS);
            for (FeeDetail detail : form.getStaysFees()) {
                if ("Y".equals(detail.getRentType())) {
                    detail.setRentType("1");
                } else {
                    detail.setRentType("0");
                }
            }
            feeDao.insertStaysDetails(form.getFormHeader(), form.getStaysFees());
        }

    }


    /**
     * 个人费用表格信息
     */
    private void saveWEM008GridInfo(FormInfo form) {
        feeDao.deleteFeeDetailsFromOfeeTable(form.getFormHeader().getDocId());

//        // 市内交通
//        if (!ListUtil.isEmpty(form.getCityTrafficFees())) {
//            setFeeType(form.getCityTrafficFees(), SNJT);
//            feeDao.insertCityTrafficOfeeDetails(form.getFormHeader(), form.getCityTrafficFees());
//        }
//        // 业务招待
//        if (!ListUtil.isEmpty(form.getEntertainFees())) {
//            setFeeType(form.getEntertainFees(), YWZD);
//            feeDao.insertServeOfeeDetails(form.getFormHeader(), form.getEntertainFees());
//        }
//        // 其他
//        if (!ListUtil.isEmpty(form.getOtherFees())) {
//            setFeeType(form.getOtherFees(), OTHER);
//            feeDao.insertOtherOfeeDetails(form.getFormHeader(), form.getOtherFees());
//        }
        // 房租费
        if (!ListUtil.isEmpty(form.getRentFees())) {
            setFeeType(form.getRentFees(), FWZL);
            feeDao.insertRentOfeeDetails(form.getFormHeader(), form.getRentFees());
        }
        // 车辆补贴
        if (!ListUtil.isEmpty(form.getCarAllowanceFees())) {
            setFeeType(form.getCarAllowanceFees(), CLBT);
            feeDao.insertCarAllowanceOfeeDetails(form.getFormHeader(), form.getCarAllowanceFees());
        }
        // 生育费用
        if (!ListUtil.isEmpty(form.getBirthFees())) {
            setFeeType(form.getBirthFees(), SYBX);
            feeDao.insertBirthOfeeDetails(form.getFormHeader(), form.getBirthFees());
        }
    }

    /**
     * 市内派车表格信息
     */
    private void saveWEM011GridInfo(FormInfo form) {
        feeDao.deleteFeeDetailsFromStaysTable(form.getFormHeader().getDocId());
        feeDao.deleteFeeDetailsFromOfeeTable(form.getFormHeader().getDocId());
        // 市内派车
        if (!ListUtil.isEmpty(form.getInsideCityDriverFees())) {
            setFeeType(form.getInsideCityDriverFees(), SNPC);
            feeDao.insertInsideCityDriverFees(form.getFormHeader(), form.getInsideCityDriverFees());
        }
//        // 市内交通
//        if (!ListUtil.isEmpty(form.getCityTrafficFees())) {
//            setFeeType(form.getCityTrafficFees(), SNJT);
//            feeDao.insertCityTrafficOfeeDetails(form.getFormHeader(), form.getCityTrafficFees());
//        }
//        // 业务招待
//        if (!ListUtil.isEmpty(form.getEntertainFees())) {
//            setFeeType(form.getEntertainFees(), YWZD);
//            feeDao.insertServeOfeeDetails(form.getFormHeader(), form.getEntertainFees());
//        }
//        // 其他
//        if (!ListUtil.isEmpty(form.getOtherFees())) {
//            setFeeType(form.getOtherFees(), OTHER);
//            feeDao.insertOtherOfeeDetails(form.getFormHeader(), form.getOtherFees());
//        }
    }

    private void setFeeType(List<FeeDetail> details, String feeType) {
        for (FeeDetail detail : details) {
            detail.setFeeType(feeType);
            detail.setId(StringUtil.getUUID());
            if (SNJT.equals(feeType)) {
                detail.setBigFeeType("C102");
                detail.setSmaFeeType("C10201");
            } else if (YWZD.equals(feeType)) {
                detail.setBigFeeType("C103");
                detail.setSmaFeeType("C10301");
            } else if (OTHER.equals(feeType)) {
            } else if (FWZL.equals(feeType)) {
                detail.setBigFeeType("C101");
                detail.setSmaFeeType("C10101");
            } else if (CLBT.equals(feeType)) {
                detail.setBigFeeType("C104");
                detail.setSmaFeeType("C10401");
            } else if (SYBX.equals(feeType)) {
                detail.setBigFeeType("660609");
                detail.setSmaFeeType("66060905");
            } else if (CTJT.equals(feeType)) {
                detail.setBigFeeType("660603");
                detail.setSmaFeeType("66060303");
            }
        }
    }

    /**
     * 保存行程变更表格信息
     *
     * @param form
     * @param isSubmit
     */
    private void saveWEM002GridInfo(FormInfo form, boolean isSubmit) {
        FormHeader header = form.getFormHeader();

        String docId = header.getDocId();
        String docNo = header.getDocNo();
        String refDocId = header.getRefDocId();

        tripDao.softDelTrips(docId);
        if (!ListUtil.isEmpty(form.getTrips())) {
            //保存行程明细
            tripDao.insertTrips(form.getTrips(), docId, docNo);
        }

        if (isSubmit) {
            //更新关联单据为已变更
            int effNum = formDao.updateReferenceDocToChanged(refDocId, 0);
            if (effNum == 0) {
                throw new ExpenseException(ExceptionCode.DOC_HAS_CHANGED_OR_EXPENSED);
            }
        }
    }

    /**
     * 保存差旅申请表格信息
     *
     * @param form
     */
    private void saveWEM001GridInfo(FormInfo form) {
        FormHeader header = form.getFormHeader();

        String docId = header.getDocId();
        String docNo = header.getDocNo();

        tripDao.softDelTrips(docId);
        formDao.softDelLoans(docId);
        tripDao.delTripTogethers(docId);
        tripDao.delTripDays(docId);
        if (!ListUtil.isEmpty(form.getTrips()))        //保存行程明细
            tripDao.insertTrips(form.getTrips(), docId, docNo);
        if (!ListUtil.isEmpty(form.getLoans()))        //保存借款
            formDao.insertLoans(form.getLoans(), docId, docNo);
        if (!ListUtil.isEmpty(form.getTripTogethers())) //保存同行人
            tripDao.insertTripTogethers(form.getTripTogethers(), docId, docNo);
    }

    /**
     * 校验是否国际差旅，并且对差旅行程进行解析
     *
     * @param form
     * @param baseCountry
     * @return
     */
    private void packageTripType(FormInfo form, String baseCountry) {
        List<Trip> trips = form.getTrips();
        if (!ListUtil.isEmpty(trips)) {
            boolean isNationalTrip = FormUtil.checkIsForeignTrip(trips, baseCountry);

            if (!isNationalTrip) {
                form.getFormHeader().setExpenseType("A1");    //国内差旅
            } else {
                form.getFormHeader().setExpenseType("A2");    //国际差旅
            }
        }
    }

    /**
     * 保存前的校验
     *
     * @param form
     * @param isSubmit
     * @return
     */
    private HikResult<String> checkValidBeforeSave(FormInfo form, boolean isSubmit) {
        //先校验单据有效性  并且设置差旅的起始日期和截止日期
        HikResult<String> rs = checkService.checkFormValid(form, isSubmit);
        if (rs.isSuccess() && isSubmit) {
            List<TripTogether> tripTogethers = form.getTripTogethers();
            FormHeader header = form.getFormHeader();
            //对所有差旅人员进行统计
            List<String> allTripEmpolyees = Lists.newArrayList();
            allTripEmpolyees.add(header.getExpensor());
            if (!ListUtil.isEmpty(tripTogethers)) {
                for (TripTogether tripTogether : tripTogethers) {
                    allTripEmpolyees.add(tripTogether.getUserId());
                }
            }
            //校验行程是否交叉
            List<TripDuplicated> tripDups = null;
            if (DocTypeEnum.WEM001.name().equalsIgnoreCase(header.getDocType())) {
                tripDups = tripDao.getDuplicateTrip(header.getDocId(), header.getTripFromDate(), header.getTripToDate(), allTripEmpolyees);
            } else if (DocTypeEnum.WEM002.name().equalsIgnoreCase(header.getDocType())) {
                tripDups = tripDao.getDuplicateTrip(header.getRefDocId(), header.getTripFromDate(), header.getTripToDate(), allTripEmpolyees);
            }

            //校验是否存在交叉行程，并且对信息进行拼接
            this.isTripsDuplicated(tripDups, rs);

            // 还款校验
            if (DocTypeEnum.WEM004.name().equalsIgnoreCase(header.getDocType())) {
                List<Bsik> bsiks = bsikService.getBsik(header.getExpensor(), header.getBukrs());
                BigDecimal ztwqAmt = voucherService.countOnlineReim(header.getBukrs(), header.getExpensor()).getTotal();
                BigDecimal wqAmt = BigDecimal.ZERO; // 总未清金额
                HikResult<Map<String, BigDecimal>> countRs = voucherService.countWqje(bsiks, ztwqAmt);
                if (countRs.isSuccess()) {
                    wqAmt = countRs.getData().get("WQJE");
                }
                if (ListUtil.isEmpty(bsiks)) {
                    wqAmt = BigDecimal.ZERO;
                }
                BigDecimal maxRepaymentAmount = wqAmt.subtract(ztwqAmt);
                if (header.getAmount().compareTo(maxRepaymentAmount) > 0) {
                    rs.addError("还款金额[" + header.getPayAmount() + "/CNY]不能大于可还款金额[" + maxRepaymentAmount + "]");
                }
            }
        }

        return rs;
    }

    /**
     * 校验是否存在交叉的行程，并且返回校验信息
     *
     * @param duplicateTrips
     * @param rs
     * @return
     */
    private void isTripsDuplicated(List<TripDuplicated> duplicateTrips, HikResult<String> rs) {
        if (!ListUtil.isEmpty(duplicateTrips)) {
            MessageCode duplicateCode = MessageCode.FORM_TRIP_DUPLICATED_ERROR;
            for (TripDuplicated trip : duplicateTrips) {
                rs.getErrorMsgs().add(
                        MessageCache.getMessage(
                                duplicateCode,
                                new Object[]{trip.getUserName(),
                                        trip.getDocNo(),
                                        trip.getFromDate(),
                                        trip.getToDate(),
                                        trip.getFromDesc(),
                                        trip.getToDesc()}));
            }
        }
    }

    /**
     * 获取单据号
     *
     * @param isSubmit
     * @param bukrs
     * @param docType
     * @param rs
     */
    private void increaseCurrentDocNumber(boolean isSubmit, String bukrs, String docType, HikResult<String> rs) {
        //根据时区获取当前年度
        int year = DateUtil.getCurrentYearByTimeZone(null);

        String isTemp = YesOrNoEnum.Y.name();
        if (isSubmit) {
            isTemp = YesOrNoEnum.N.name();
        }
        //获取当前单据号
        HikResult<DocNumber> ruleMatch = this.getCurrentDocNumber(year, isTemp, bukrs, docType);
        if (ruleMatch.isSuccess()) {
            DocNumber curNumber = ruleMatch.getData();
            //将当前单据号+1更新到数据库中
            int effectDataNum = docNumberDao.increaseCurrentDocNumber(curNumber);

            if (effectDataNum == 0) {//当未更新成功时，循环调用至成功获取到下一个单据号
                this.increaseCurrentDocNumber(isSubmit, bukrs, docType, rs);
            }

            this.genCurDocNumber(curNumber, rs);
        } else {
            rs.getErrorMsgs().addAll(ruleMatch.getErrorMsgs());
        }
    }

    /**
     * 生成当前单据号
     *
     * @param curNumber
     * @return
     */
    private void genCurDocNumber(DocNumber curNumber, HikResult<String> rs) {
        String curNo = String.valueOf((curNumber.getCurNo() + 1));
        int length = curNumber.getDocLen();
        String prefix = curNumber.getPrefix();
        String year = String.valueOf(curNumber.getYear());

        int curLen = curNo.length();
        if (curLen <= length) {
            int fixLen = length - curLen;
            for (int i = 0; i < fixLen; i++) {
                curNo = "0" + curNo;
            }
            curNo = year.substring(2, 4) + curNo;
            if (StringUtil.isNotEmptyTrim(prefix)) {
                rs.setData(prefix + curNo);
            } else {
                rs.setData(curNo);
            }
        } else {
            rs.getErrorMsgs().add("Configuration error, expense No. too large!");
        }
    }

    /**
     * 根据传入参数匹配当前单据编号
     */
    private HikResult<DocNumber> getCurrentDocNumber(int year, String isTemp, String bukrs, String docType) {
        HikResult<DocNumber> rs = new HikResult<DocNumber>();

        List<DocNumber> docNumbers = docNumberDao.getCurrentDocNumber(year, isTemp);
        //先精确匹配
        DocNumber docNumber = this.regexDocNumber(docNumbers, bukrs, docType);
        if (docNumber == null) {
            //设置公司为模糊匹配
            bukrs = StringUtil.COMMON_REGEX;
            docNumber = this.regexDocNumber(docNumbers, bukrs, docType);
            if (docNumber == null) {
                //设置单据类别为模糊匹配
                docType = StringUtil.COMMON_REGEX;
                docNumber = this.regexDocNumber(docNumbers, bukrs, docType);
            }
        }

        if (docNumber != null) {
            rs.setData(docNumber);
        } else {
            rs.getErrorMsgs().add("Configuration error: can't match expense No. rule!");
        }

        return rs;
    }

    /**
     * 匹配出合适的当前单据号
     *
     * @param docNumbers
     * @param bukrs
     * @param docType
     * @return
     */
    private DocNumber regexDocNumber(List<DocNumber> docNumbers, String bukrs, String docType) {
        DocNumber curDocNum = null;
        if (docNumbers != null && docNumbers.size() != 0) {
            for (DocNumber docNumber : docNumbers) {
                if (docNumber.getBukrs().equalsIgnoreCase(bukrs) &&
                        docNumber.getDocType().equalsIgnoreCase(docType)) {
                    curDocNum = docNumber;

                    break;
                }
            }
        }

        return curDocNum;
    }

    @Override
    public boolean checkCanEditDoc(FormHeader header) {
        String logUser = UserContext.getUserId();

        if (!Strings.isNullOrEmpty(logUser)) {
            //判断单据状态
            String docStatus = formDao.getDocStatus(header.getDocId());

            if (Strings.isNullOrEmpty(docStatus) ||
                    DocStatusEnum.S001.name().equalsIgnoreCase(docStatus) ||
                    DocStatusEnum.S005.name().equalsIgnoreCase(docStatus)) {
                //校验单据操作权限  报销人、创建人或者超级管理员有权限
                if (logUser.equalsIgnoreCase(header.getExpensor()) ||
                        logUser.equalsIgnoreCase(header.getCreatedBy())) {
                    return true;
                } else {
                    String superAdmin = userDao.getSuperAdmin(logUser);

                    if (YesOrNoEnum.Y.name().equalsIgnoreCase(superAdmin)) {
                        return true;
                    }
                }
            }
        }

        return false;
    }

    @Override
    public List<ApproveHistory> getApproveHistories(String docId) {
        return formDao.getApproveHistories(docId);
    }

    @Override
    public HikResult<String> adjustAmount(AdjustAmountBean adjustBean) {

        HikResult<String> result = new HikResult<>();

        AdjustItem headerItem = new AdjustItem();
        BigDecimal headerAmount = BigDecimal.ZERO;

        checkAdjustItem(adjustBean.getLoanAdjustItems(), result, "借款");
        // checkAdjustItem(adjustBean.getSnpcAdjustItems(), result, "市内派车");
        checkAdjustItem(adjustBean.getCtjtAdjustItems(), result, "长途交通");
        checkAdjustItem(adjustBean.getZsfyAdjustItems(), result, "住宿费用");
        checkAdjustItem(adjustBean.getFeeAdjustItems(), result, "费用明细");
        checkAdjustItem(adjustBean.getFwzlAdjustItems(), result, "房租费");
        checkAdjustItem(adjustBean.getSybxAdjustItems(), result, "生育报销");
        checkAdjustItem(adjustBean.getClbtAdjustItems(), result, "车辆补贴");
        checkAdjustItem(adjustBean.getSkrAdjustItems(), result, "收款人");
        //
        if (adjustBean.getRepaymentAdjustItems() != null) {
            AdjustItem item = adjustBean.getRepaymentAdjustItems();
            if (item.getPaymentAmount() == null || item.getPaymentAmount().compareTo(item.getAmount()) > 0
                    || item.getPaymentAmount().compareTo(BigDecimal.ZERO) < 0) {
                result.addError("还款金额必须在 0 ~ " + item.getAmount());
            }
        }

        if (!result.isSuccess()) {
            return result;
        }

        if (ListUtil.isNotEmpty(adjustBean.getLoanAdjustItems())) {
            for (AdjustItem item : adjustBean.getLoanAdjustItems()) {
                formDao.adjustLoanAmount(item);
                // 借款的paymentAmount也是针对原币的, 计算表头金额时需要根据汇率算一遍
                headerAmount = headerAmount.add(item.getPaymentAmount().multiply(item.getExchangeRate()).setScale(2, RoundingMode.HALF_UP));
            }
        }
        // 长途交通费用
        List<AdjustItem> travelFeesAdjustItems = Lists.newArrayList();
        if (ListUtil.isNotEmpty(adjustBean.getCtjtAdjustItems())) {
            travelFeesAdjustItems.addAll(adjustBean.getCtjtAdjustItems());
        }
        if (ListUtil.isNotEmpty(adjustBean.getZsfyAdjustItems())) {
//            travelFeesAdjustItems.addAll(adjustBean.getZsfyAdjustItems());
        }
        if (ListUtil.isNotEmpty(adjustBean.getSnpcAdjustItems())) {
            travelFeesAdjustItems.addAll(adjustBean.getSnpcAdjustItems());
        }
        // 市内交通/业务招待/其他/房租费/生育报销/车辆补贴数据库调减一致,可以统一处理
        List<AdjustItem> allFeesAdjustItems = Lists.newArrayList();
        if (ListUtil.isNotEmpty(adjustBean.getFeeAdjustItems())) {
            allFeesAdjustItems.addAll(adjustBean.getFeeAdjustItems());
        }
        if (ListUtil.isNotEmpty(adjustBean.getFwzlAdjustItems())) {
            allFeesAdjustItems.addAll(adjustBean.getFwzlAdjustItems());
        }
        if (ListUtil.isNotEmpty(adjustBean.getSybxAdjustItems())) {
            allFeesAdjustItems.addAll(adjustBean.getSybxAdjustItems());
        }
        if (ListUtil.isNotEmpty(adjustBean.getClbtAdjustItems())) {
            allFeesAdjustItems.addAll(adjustBean.getClbtAdjustItems());
        }
        if (ListUtil.isNotEmpty(travelFeesAdjustItems)) {
            for (AdjustItem item : travelFeesAdjustItems) {
                feeDao.adjustTravelFeesAmount(item);
                headerAmount = headerAmount.add(item.getPaymentAmount());
            }
        }
        if (ListUtil.isNotEmpty(allFeesAdjustItems)) {
            for (AdjustItem item : allFeesAdjustItems) {
                feeDao.adjustFeeDetailsAmount(item);
                headerAmount = headerAmount.add(item.getPaymentAmount());
            }
        }

        // 收款人金额调整
        if (ListUtil.isNotEmpty(adjustBean.getSkrAdjustItems())) {
            for (AdjustItem item : adjustBean.getSkrAdjustItems()) {
                formDao.adjustDsdfAmount(item);
            }
        }
        if (adjustBean.getRepaymentAdjustItems() != null) {
            headerAmount = adjustBean.getRepaymentAdjustItems().getPaymentAmount();
        }
        // 调整表头金额, 单据明细金额+补贴金额
        BigDecimal totalSubsidyAmount = subsidyDao.sumSubsidyAmount(adjustBean.getDocId());
        headerItem.setPaymentAmount(headerAmount.add(totalSubsidyAmount));
        headerItem.setId(adjustBean.getDocId());
        formDao.adjustHeaderPayAmount(headerItem);
        return result;
    }

    private void checkAdjustItem(List<AdjustItem> items, HikResult<String> result, String tableName) {
        if (ListUtil.isEmpty(items)) {
            return;
        }
        int idx = 0;
        for (AdjustItem item : items) {
            if (validAdjustItem.test(item)) {
                result.addError(tableName + "第" + (idx + 1) + "行调减范围必须在0 ~ " + item.getAmount());
            }
            idx++;
        }
    }

    @Override
    public List<OtherReceivor> listOtherReceiver(String docId) {
        List<OtherReceivor> list = formDao.listOtherReceivers(docId);
        List<UserBank> users = list.stream().map(o -> new UserBank(o.getUserId(), o.getBukrs())).collect(Collectors.toList());
        users = bankService.findUserBankFromLocal(users);
        ImmutableMap<String, UserBank> bankMap = Maps.uniqueIndex(users, UserBank::getLifnr);

        for (OtherReceivor receiver : list) {
            UserBank userBank = bankMap.get(receiver.getUserId());
            if (userBank != null) {
                receiver.setBankCode(userBank.getBankL());
                receiver.setBankName(userBank.getBankA());
                receiver.setBankAccount(userBank.getBankN());
                receiver.setUserName(userBank.getName1());
            }
        }
        return list;
    }

    @Override
    public void addWorkingHolidays(String docId, List<String> dates) {
        formDao.deleteWorkingHolidays(docId);
        if (ListUtil.isNotEmpty(dates)) {
            formDao.addWorkingHolidays(docId, dates);
        }
    }

    @Override
    public List<HolidayWork> listWorkingHolidays(String docId, String bukrs, String minDate, String maxDate) {
        List<HolidayWork> allHolidayWork = baseDao.listHolidays(bukrs, DateUtil.stringToSQLDate(minDate), DateUtil.stringToSQLDate(maxDate));

        List<String> selectedDates = formDao.listWorkingHolidays(docId);
        for (HolidayWork o : allHolidayWork) {
            String date = DateUtil.dateToString(o.getWorkDate());
            if (selectedDates.contains(date)) {
                o.setWorkFlag(YesOrNoEnum.Y.name());
            } else {
                o.setWorkFlag(YesOrNoEnum.N.name());
            }
        }

        return allHolidayWork;
    }

    @Override
    public List<FormHeader> listApplyWithDefaultStatus() {
        String userId = UserContext.getUserId();
        String language = UserContext.getLanguage();

        return formDao.listApplyWithDefaultStatus(userId, language);
    }

    @Override
    public boolean checkSqpgRel(String userId) {
        User user = userDao.findUserByUserId(userId, "ZH");
        String flag = formDao.getUserSqpgRelFlag(userId);
        if (!Strings.isNullOrEmpty(flag)) {//员工编号有限匹配
            return "I".equals(flag);
        } else {//根据部门匹配:目前type=dept的行flag字段无用,即根据部门查到就必须关联售前派工单20150325
            flag = formDao.getDeptSqpgRelFlag(user.getDeptCode());
            return flag != null;
        }
    }

    @Override
    @Transactional
    public HikResult<String> deleteDraftDoc(String docId) {
        HikResult<String> hikResult = new HikResult<String>();
        String message = null;
        int number = 0;//用于根据删除条数判断是否删除成功
        boolean privateDoc = false;//是否对私单据
        //获取单据抬头
        //校验对公还是对私单据  目前先从长度上来判断待办是对私还是对公
        DocHeader docHeader = null;
        if (docId.length() == 32) {
            privateDoc = true;//对私
            docHeader = formDao.getDocHeader(docId);
        } else {//对公
            docHeader = formDao.getPublicDocHeader(docId);
        }
        if (docHeader != null) {
            //判断当前操作人是否是单据的创建人或者报销人
            String userId = UserContext.getUserId();
            if (userId.equalsIgnoreCase(docHeader.getCreator()) ||
                    userId.equalsIgnoreCase(docHeader.getClaimUserId())) {
                String docStatus = docHeader.getDocStatus();
                // 非提交状态的单据才能删除
                if (DocStatusEnum.S001.name().equalsIgnoreCase(docStatus)) {
                    //删除草稿单
                    try {
                        if (privateDoc) {
                            number = formDao.deletePrivateDocHeader(docId);
                        } else {
                            number = formDao.deletePublicDocHeader(docId);
                        }
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                        message = MessageCache.getMessage(MessageCode.RUNTIME_ERROR);
                        hikResult.addError(message);
                    }
                }
            }
        }
        //判断删除是否成功
        if (number != 0) {
            message = MessageCache.getMessage(MessageCode.SUCCESS_DELETE);
        } else {
            hikResult.addError(MessageCache.getMessage(MessageCode.DOC_NOT_FOUND, docId));
        }

        hikResult.setSuccessMessage(message);
        return hikResult;
    }

    /**
     * 撤回
     *
     * @param docId
     * @param userId
     * @return
     */
    @Override
    @Transactional
    public HikResult<String> retrack(String docId, String userId) {
        HikResult<String> hikResult = new HikResult<String>();
        //获取单据抬头
        DocHeader docHeader = formDao.getDocHeader(docId);
        //判断当前操作人是否是单据的创建人或者报销人
        if (docHeader != null) {
            if (userId.equalsIgnoreCase(docHeader.getCreator())
                    || userId.equalsIgnoreCase(docHeader.getClaimUserId())) {
                String docStatus = docHeader.getDocStatus();
                // 判断单据状态
                if (DocStatusEnum.S002.name().equalsIgnoreCase(docStatus)) {// 非提交状态的单据不能进行撤回
                    // 开始撤回
                    try {
                        String processId = processDao.getProcessIdByDocId(docId);
                        if (processId == null) {
                            hikResult.addError(MessageCache.getMessage(MessageCode.RUNTIME_ERROR, "未找到对应流程"));
                        } else {
                            hikResult = processService.retrackProcess(processId, userId);
                            //撤回成功更新flow状态
                            if (hikResult.isSuccess()) {
                                formDao.updateDocStatus(docId, DocStatusEnum.S005.name());
                                formDao.resetReferenceDocToDefault(docHeader.getRefDocId());
                                hikResult.setSuccessMessage(MessageCache.getMessage(MessageCode.OPER_REVOKE_SUCESS, docHeader.getApplyId()));
                            }
                        }

                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                        hikResult.addError(MessageCache.getMessage(MessageCode.RUNTIME_ERROR, "系统忙,稍后重试"));
                    }
                } else {
                    hikResult.addError(MessageCache.getMessage(MessageCode.OPER_REVOKE_FAILURE, "非提交状态单据不能撤回"));
                }
            }
        } else {
            hikResult.addError(MessageCache.getMessage(MessageCode.OPER_REVOKE_FAILURE, "未获取到单据信息"));
        }
        return hikResult;
    }

    @Override
    @Transactional
    public HikResult<String> undo(String docId, String userId) {
        HikResult<String> hikResult = new HikResult<String>();
        DocHeader docHeader = formDao.getDocHeader(docId);
        //判断当前操作人是否是单据的创建人或者报销人
        if (userId.equalsIgnoreCase(docHeader.getCreator()) ||
                userId.equalsIgnoreCase(docHeader.getClaimUserId())) {
            // 获取当前单据状态
            String docStatus = docHeader.getDocStatus();
            // 判断单据状态
            if (!DocStatusEnum.S002.name().equalsIgnoreCase(docStatus)
                    && !DocStatusEnum.S005.name().equalsIgnoreCase(docStatus)) {
                // 非提交、驳回状态的单据不能进行撤销
                hikResult.addError(MessageCache.getMessage(MessageCode.OPER_UNDO_FAILURE));
            } else {
                // 当单据类型为行程变更并且校验引用单据未正常结束时，不允许撤销单据
                String processCode = docHeader.getProcessObjectId();
                if (DocTypeEnum.WEM002.name().equalsIgnoreCase(processCode) &&
                        formDao.checkReferenceDocIsEnd(docHeader.getRefDocId()) == 0) {
                    hikResult.addError(MessageCache.getMessage(MessageCode.REF_DOC_NOT_ENDED));
                } else {
                    // 单据作废
                    try {
                        String processId = processDao.getProcessIdByDocId(docId);
                        hikResult = processService.undoProcess(processId, userId);
                        if (hikResult.isSuccess()) {
                            formDao.updateDocStatus(docId, DocStatusEnum.S100.name());
                            formDao.resetReferenceDocToDefault(docHeader.getRefDocId());
                            hikResult.setSuccessMessage(MessageCache.getMessage(MessageCode.OPER_UNDO_SUCCESS, docHeader.getApplyId()));
                        }
                    } catch (Exception e) {
                        logger.error(e.getMessage(), e);
                        hikResult.addError(MessageCache.getMessage(MessageCode.RUNTIME_ERROR, "系统忙,稍后重试"));
                    }
                }
            }
        } else {
            hikResult.addError(MessageCache.getMessage(MessageCode.OPER_UNDO_FAILURE, "当前操作人不具有该权限"));
        }
        return hikResult;
    }


    @Override
    public HikResult<String> checkTransitApplyByApplyId(String applyid, String userid) {
        HikResult<String> result = new HikResult<>();
        List<FormHeader> docs = formDao.checkTransitApplyByApplyId(applyid, userid);
        if (docs.size() != 0) {
            StringBuilder msg = new StringBuilder();
            msg.append("当前申请单已经被报销单 ");
            for (FormHeader f : docs) {
                msg.append(f.getDocNo());
                msg.append(",");
            }
//            去尾逗号
            msg.deleteCharAt(msg.length() - 1);
            msg.append(" 关联，请先作废报销单，才能作废申请单");
            result.addError(msg.toString());
        }
        return result;
    }

    @Override
    public boolean checkSnjtFee(String userId, String year, String month) {
        return feeDao.hasCarAllowance(userId, year, month);
    }

    @Override
    public FormHeader getTransitSectionByApplyId(String applyId) {
        return formDao.getTransitSectionByApplyId(applyId);
    }

    @Override
    public HikResult<String> applyUndo(String docId, String userId) {
        HikResult<String> hikResult = new HikResult<>();
        DocHeader docHeader = formDao.getDocHeader(docId);
        String applyid = docHeader.getApplyId();
//      开始作废
        hikResult = this.updateApplyUndo(docId, applyid, userId);
//      如果失败
        if (!hikResult.isSuccess()) {
            hikResult.addError(MessageCache.getMessage(MessageCode.OPER_CANCEL_FAILURE, docHeader.getApplyId()));
        }
        return hikResult;
    }

    @Override
    public List<DocumentInfo> getIsUndoOk(String docId, String userId) {
        return formDao.getIsUndoOk(docId, userId);
    }

    @Override
    @Transactional
    public HikResult<String> updateApplyUndo(String docId, String applyid, String userId) {
        //作废当前的申请单
        /*1。判断当前的申请单，是否已经被其他申请单关联更变，或者转报销 S002 S003 S004 S005 processid 关联
         *2。判断当前的申请单，是否转报销 S002 S003 S004 S005 applyid 关联
		 *3.修稿 flow 主表 成 S100
		 *4.如果是行程变更的，则要还原原来的申请单为D
		 *5.修改考勤信息:如果是变更的，则修改考勤（DATA_STATE：U,SYSCN_STATE:D），如果是申请单不是变更则，删除考勤（DATA_STATE：X,SYSCN_STATE:D）
		 * */
        HikResult<String> hikResult = new HikResult<>();

        hikResult = checkTransitApplyByApplyId(applyid, userId);
        if (!hikResult.isSuccess()) {
            return hikResult;
        }
        List<DocumentInfo> list = formDao.getIsUndoOk(docId, userId);
        if (list != null && list.size() == 1) {
            formDao.updateApplyUndo(docId, userId);
            DocumentInfo bean = list.get(0);
            if (DocTypeEnum.WEM002.name().equals(bean.getProcessCode())) {
                //如果是行程变更，要对原来关联的单据还原
                formDao.updateApplyStausYbgToD(bean.getId(), userId);//取当前单据 关联的申请单 applyproc
                //考勤处理
                //变更，作废变更的单子，要把原来的单子找出来，考勤信息用原来的申请单
                formDao.updateKqInfo(applyid, userId, bean.getTripFromDate(), bean.getTripToDate());
            } else {
                //考勤处理
                //原单据 非变更
                formDao.deleteKqInfo(applyid, userId);
            }
            hikResult.setSuccessMessage(MessageCache.getMessage(MessageCode.OPER_CANCEL_SUCCESS, applyid));
        } else {
            //查看是否有在途的申请单，或者有转报销的申请单.
            hikResult.addError(MessageCache.getMessage(MessageCode.OPER_CANCEL_FAILURE, "当前申请单异常，不能进行作废，请联系管理员！"));
        }
        return hikResult;
    }

    @Override
    @Transactional
    public HikResult<String> saveVendorInvoiceMailAddress(String docId, String mailAddress) {
        HikResult<String> rs = new HikResult<String>();

        formDao.deleteVendorInvoiceMailAddress(docId);
        formDao.insertVendorInvoiceMailAddress(docId, mailAddress);

        return rs;
    }

    /**
     * 验证邮箱格式及空格
     *
     * @param
     * @param email
     * @return
     */
    private boolean checkMailAndDocIdLegal(String email, String docid) {

//        后缀
        if (!email.endsWith("@hikvision.com.cn")) {
            return false;
        }
//        空格
        if (email.indexOf(" ") != -1) {
            return false;
        }

//        邮箱格式验证^[1-9]+[0-9]*$
        String regex = "^[1-9]+[0-9]*$";
        Pattern patternMail = Pattern.compile(regex);
        Matcher matcherMail = patternMail.matcher(docid);

        if (!matcherMail.matches()) {
            return false;
        }
        return true;
    }

    /**
     * 从数据库查询行程, 住宿信息, 并填充到单据中
     *
     * @param formInfo
     */
    private void getAndPutStaysIntoForm(FormInfo formInfo) {
        List<FeeDetail> ctjtList = Lists.newArrayList();
        List<FeeDetail> zsfyList = Lists.newArrayList();
        List<FeeDetail> fees = feeDao.getTravelFees(formInfo.getFormHeader().getDocId(), UserContext.getLanguage());
        for (FeeDetail fee : fees) {
            if (CTJT.equals(fee.getFeeType())) {
                ctjtList.add(fee);
            } else if (STAYS.equals(fee.getFeeType())) {
                zsfyList.add(fee);
            }
        }
        formInfo.setLongDistanceTrafficFees(ctjtList);
        formInfo.setStaysFees(zsfyList);
    }

}