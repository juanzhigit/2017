package com.hikvision.it.expense.rpc.service.approver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.service.execute.ITaskOwnerService;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;

/**
 * 获取单据的报销人和创建人信息
 * <p>Title: FindDocCreatorServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
@Service(value="findDocCreator")
public class FindDocCreatorServiceImpl implements ITaskOwnerService {
	@Autowired
    IApproverDao approverDao;
	
	@Override
	public List<TaskOwner> execute(TaskObject taskObject, String docId) {
		return approverDao.getDocCreator(docId, UserContext.getLanguage());
	}
}
