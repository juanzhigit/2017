package com.hikvision.it.expense.rpc.service.attachment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.attachment.Attachment;
import com.hikvision.it.expense.api.service.attachment.IAttachmentService;
import com.hikvision.it.expense.rpc.dao.attachment.IAttachmentDao;

@Service
@Primary
public class AttachmentServiceImpl implements IAttachmentService {

    @Autowired
    IAttachmentDao attachDao;

    @Override
    public void saveAttach(Attachment attach) {
        attachDao.saveAttachment(attach);
    }

    @Override
    public void deleteAttach(String attachId) {
        attachDao.deleteAttachment(attachId, UserContext.getUserId());
    }

    @Override
    public List<Attachment> getAttachByDocId(String docId) {
        return attachDao.getByDocId(docId, UserContext.getLanguage());
    }

    @Override
    public Attachment getOne(String attachId) {
        return attachDao.getOne(attachId);
    }

    @Override
    public Long countAttach(String docId) {
        return attachDao.countAttachment(docId);
    }
}
