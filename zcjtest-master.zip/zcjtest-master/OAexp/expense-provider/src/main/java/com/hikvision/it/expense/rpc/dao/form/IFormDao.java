package com.hikvision.it.expense.rpc.dao.form;

import java.math.BigDecimal;
import java.util.List;

import org.apache.ibatis.annotations.Delete;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;

import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.AdjustItem;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.flow.DocHeader;
import com.hikvision.it.expense.api.entity.flow.ProcessConfig;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.OverproofInfo;
import com.hikvision.it.expense.api.entity.history.ApproveHistory;
import com.hikvision.it.expense.api.entity.loan.LoanDetail;
import com.hikvision.it.expense.api.entity.oa.SqpgDoc;

public interface IFormDao {
    /**
     * 统计单据数量
     *
     * @param docId
     * @return
     */
    int countFormNumber(@Param("docId") String docId);

    /**
     * 新增单据抬头
     *
     * @param formHeader
     * @return
     */
    int insertFormHeader(@Param("formHeader") FormHeader formHeader);

    /**
     * 新增单据事由信息
     *
     * @param formHeader
     * @return
     */
    int insertFormTxt(@Param("formHeader") FormHeader formHeader);

    /**
     * 新增拓展信息
     */
    int insertFormFlag(@Param("formHeader") FormHeader formHeader);

    /**
     * 删除超标信息
     */
    @Delete("delete from z_wem_bus_flow_cqcb where processid = #{docId, jdbcType=VARCHAR}")
    int deleteOverproof(@Param("docId") String docId);

    /**
     * 增加超标信息
     */
    int insertOverproof(@Param("docId") String docId, @Param("items") List<OverproofInfo> list);

    /**
     * 获取超标信息
     */
    @Select("select costtype type, remark from z_wem_bus_flow_cqcb where processid = #{docId, jdbcType=VARCHAR}")
    List<OverproofInfo> getOverproof(String docId);

    /**
     * 新增借款信息
     *
     * @param loans
     * @param docId
     * @param docNo
     * @return
     */
    int insertLoans(@Param("loans") List<LoanDetail> loans,
                    @Param("docId") String docId,
                    @Param("docNo") String docNo);

    /**
     * 更新抬头信息
     *
     * @param formHeader
     * @param upTime
     * @return
     */
    int updateFormHeader(@Param("formHeader") FormHeader formHeader,
                         @Param("upTime") long upTime);

    /**
     * 更新事由信息
     *
     * @param formHeader
     * @return
     */
    int updateFormTxt(@Param("formHeader") FormHeader formHeader);

    /**
     * 更新拓展信息
     */
    int updateFormFlag(@Param("formHeader") FormHeader formHeader);

    /**
     * 提交单据
     *
     * @param formHeader
     * @return
     */
    int submitForm(@Param("formHeader") FormHeader formHeader);

    /**
     * 再次提交单据
     *
     * @param formHeader
     * @return
     */
    int reSubmitForm(@Param("formHeader") FormHeader formHeader);

    /**
     * 软删除借款信息
     *
     * @param docId
     * @return
     */
    int softDelLoans(@Param("docId") String docId);

    /**
     * 更新关联单据状态为已报销
     *
     * @param refDocId
     * @param upTime
     * @return
     */
    int updateReferenceDocToExpensed(@Param("refDocId") String refDocId,
                                     @Param("upTime") long upTime);

    /**
     * 更新关联单据状态为已变更
     *
     * @param refDocId
     * @param upTime
     * @return
     */
    int updateReferenceDocToChanged(@Param("refDocId") String refDocId,
                                    @Param("upTime") long upTime);

    /**
     * 重置关联单据状态
     *
     * @param refDocId
     * @return
     */
    int resetReferenceDocToDefault(@Param("refDocId") String refDocId);

    /**
     * 获取单据抬头信息
     *
     * @param docId
     * @return
     */
    FormHeader getFormHeader(@Param("docId") String docId);

    /**
     * 获取单据借款信息
     *
     * @param docId
     * @return
     */
    List<LoanDetail> getLoans(@Param("docId") String docId);

    /**
     * 外币借款数量
     *
     * @param docId
     * @return
     */
    int countForeignLoanNumbers(@Param("docId") String docId);

    /**
     * 根据权限获取单据数量
     *
     * @param docId
     * @param userId
     * @return
     */
    int countDocNumberWithRoleCheck(@Param("docId") String docId,
                                    @Param("userId") String userId);

    /**
     * 校验单据提交时是否需要影像
     * 需要影像    return 1
     * 不需要影像 return 0
     *
     * @param docId
     * @return
     */
    int checkDocNeedImageWhenSubmit(@Param("docId") String docId);

    /**
     * 判断是否存在自定机票
     *
     * @param docId
     * @return
     */
    int countCustomTicketNumbers(@Param("docId") String docId);

    /**
     * 查询员工核高基费用标识
     *
     * @param docId
     * @return
     */
    String findDocHGJFlag(@Param("docId") String docId);

    /**
     * 获取单据状态
     *
     * @param docId
     * @return
     */
    String getDocStatus(@Param("docId") String docId);

    /**
     * 根据单据类别获取所有流程配置
     *
     * @param docType 单据类别
     * @return
     */
    List<ProcessConfig> getProcessConfigByDocType(@Param("docType") String docType);

    /**
     * 获取单据创建人的邮箱地址
     *
     * @param docId
     * @return
     */
    String getDocCreatorsMailAddress(@Param("docId") String docId);

    /**
     * 将当前员工诚信等级设置到单据中
     *
     * @param docId
     * @param credit
     * @param creditDesc
     * @return
     */
    int setUserCreditToDoc(@Param("docId") String docId,
                           @Param("credit") String credit,
                           @Param("creditDesc") String creditDesc);

    /**
     * 更新单据状态
     *
     * @param docId
     * @param docStatus
     * @return
     */
    int updateDocStatus(@Param("docId") String docId,
                        @Param("docStatus") String docStatus);

    /**
     * 根据部门类别匹配费用科目
     *
     * @param docId
     * @param bukrs
     * @param deptType
     * @return
     */
    List<FeeDetail> matchFeeDetailSubject(@Param("docId") String docId,
                                          @Param("bukrs") String bukrs,
                                          @Param("deptType") String deptType);

    /**
     * 获取代收代付明细
     *
     * @param docId
     * @return
     */
    List<OtherReceivor> listOtherReceivers(@Param("docId") String docId);

    /**
     * 获取新单据补贴明细
     *
     * @param docId
     * @param bukrs
     * @param deptType
     * @return
     */
    List<FeeDetail> listStaysFeeDetail(@Param("docId") String docId,
                                       @Param("bukrs") String bukrs,
                                       @Param("deptType") String deptType);

    /**
     * 获取重复参数扣款汇总信息
     * @param docId
     * @param bukrs
     * @param deptType
     * @return
     */
    FeeDetail countDuplicateFoodSubsidy(@Param("docId") String docId,
                                       @Param("bukrs") String bukrs,
                                       @Param("deptType") String deptType);

    /**
     * 获取老单据长途交通、住宿以及补贴明细
     *
     * @param docId
     * @param bukrs
     * @param deptType
     * @return
     */
    List<FeeDetail> listOldStaysFeeDetail(@Param("docId") String docId,
                                          @Param("bukrs") String bukrs,
                                          @Param("deptType") String deptType);

    List<ApproveHistory> getApproveHistories(@Param("docId") String docId);

    /**
     * 增加单据补贴金额<br/>
     * 页面提交上来的金额包含上一次计算的补贴金额, 需要将上一次补贴金额减掉, 再加上本次最新的补贴金额
     */
    void addSubsidyAmount(@Param("docId") String docId, @Param("subsidyAmount") BigDecimal subsidyAmount);

    /**
     * 会计调减借款金额
     */
    void adjustLoanAmount(AdjustItem adjustItem);

    /**
     * 会计调减收款人金额
     *
     * @param adjustItem
     */
    @Update("update z_wem_bus_dsdf set accamt = #{paymentAmount, jdbcType=NUMERIC} where dsdfid = #{id, jdbcType=VARCHAR}")
    void adjustDsdfAmount(AdjustItem adjustItem);

    /**
     * 表头付款金额调减
     */
    @Update("update z_wem_bus_flow set amtnet = #{paymentAmount, jdbcType=NUMERIC} where processid = #{id, jdbcType=VARCHAR}")
    void adjustHeaderPayAmount(AdjustItem adjustItem);

    /**
     * 删除他人收款明细
     *
     * @param docId
     */
    @Delete("DELETE FROM Z_WEM_BUS_DSDF WHERE PROCESSID = #{docId, jdbcType=VARCHAR}")
    void deleteOtherReceivers(@Param("docId") String docId);

    /**
     * 新增他人收款
     */
    void insertOtherReceivers(@Param("docId") String docId, @Param("receivers") List<OtherReceivor> list);

    /**
     * 查询节假日工作情况
     */
    @Select("SELECT to_char(STARTDATE, 'yyyy-mm-dd') FROM Z_WEM_BUS_HOLI_WORK_DETAIL WHERE PROCESSID = #{docId, jdbcType=VARCHAR} ORDER BY STARTDATE")
    List<String> listWorkingHolidays(@Param("docId") String docId);

    /**
     * 新增节假日工作情况
     */
    void addWorkingHolidays(@Param("docId") String docId, @Param("dates") List<String> dates);

    @Delete("DELETE FROM Z_WEM_BUS_HOLI_WORK_DETAIL WHERE PROCESSID = #{docId, jdbcType=VARCHAR}")
    void deleteWorkingHolidays(@Param("docId") String docId);

    /**
     * 获取所有默认状态的申请单，用于行程变更或者报销
     *
     * @param userId
     * @param language
     * @return
     */
    List<FormHeader> listApplyWithDefaultStatus(@Param("userId") String userId,
                                                @Param("language") String language);

    @Select("select processcode from hikepadm.z_wem_bus_flow t where t.processid = #{docId, jdbcType=VARCHAR}")
    String getDocType(@Param("docId") String docId);

    @Select("select flag from z_wem_basic_sqpg_rel where type = 'EMP' and value = #{userId, jdbcType=VARCHAR} and (sysdate between start_date and end_date)")
    String getUserSqpgRelFlag(@Param("userId") String userId);

    @Select("SELECT T.FLAG FROM Z_WEM_BASIC_SQPG_REL T " +
            "INNER JOIN Z_WEM_BASIC_DEPARTMENT_INFO D ON T.TYPE = 'DEPT' AND D.DEPTCODEPATH LIKE '%' || T.VALUE ||'%' " +
            "WHERE (sysdate BETWEEN START_DATE AND END_DATE) AND D.DEPTCODE = #{deptCode, jdbcType=VARCHAR} ")
    String getDeptSqpgRelFlag(@Param("deptCode") String deptCode);

    /**
     * 获取售前派工单
     */
    List<SqpgDoc> getSqpgDocs(@Param("docId") String docId);

    @Update("update Z_WEM_BUS_TRAVEL_EXP_SQPG set flag = 'X' where processid = #{docId, jdbcType=VARCHAR}")
    /**
     * 软删除售前派工单
     */
    void deleteSqpgDocs(@Param("docId") String docId);

    /**
     * 新增售前派工单
     */
    void insertSqpgDocs(@Param("docId") String docId, @Param("items") List<SqpgDoc> items);

    /**
     * 获取单据抬头 对私单据
     *
     * @param docId
     * @return
     */
    DocHeader getDocHeader(String docId);

    /**
     * 获取单据抬头 对公单据
     * @param docId
     * @return
     */
    DocHeader getPublicDocHeader(String docId);

    /**
     * 删除草稿
     * @param docId
     * @return
     */
    boolean deleteDraftDoc(String docId);
    /**
     * 删除对私主单据
     * @param docId
     * @return
     */
    int deletePrivateDocHeader(String docId);

    /**
     * 删除对公主单据
     * @param docId
     * @return
     */
    int deletePublicDocHeader(String docId);

    /**
     * 校验引用单据是否正常完成
     *
     * @param processInstanceId
     * @return
     */
    int checkReferenceDocIsEnd(
            @Param("processInstanceId") String processInstanceId);

    /**
     * 统计当前员工未完成的还款单数量
     * @param userId
     * @return
     */
    @Select("select t.applyid from hikepadm.z_wem_bus_flow t where t.claimuser = #{userId, jdbcType=VARCHAR} and t.processcode = 'WEM004' and t.docstatus in ('S002', 'S003')")
    List<String> listRepaymentDocOnline(@Param("userId") String userId);
    /**
     * 判断是否有在途的报销单
     * @param applyId
     * @param userid
     * @return
     */
    List<FormHeader> checkTransitApplyByApplyId(@Param("applyId") String applyId,@Param("userid") String userid);

    /**
     * 根据applyid查询差率时间区间
     * 源数据包含变更前及变更后的记录
     * @param applyId
     * @return
     */
    FormHeader getTransitSectionByApplyId( @Param("applyId")String applyId);

    /**
     * 获取可以删除的记录
     * 主要作用:
     * 1 验证行程变更是否有在途的
     * 2 验证报销是否有在途的
     * 3 返回差率的时间区间
     * @param docId
     * @param userId
     * @return
     */
    List<DocumentInfo> getIsUndoOk(@Param("docId")String docId, @Param("userId")String userId);

    /**
     * 作废申请单
     * 1.是自己的
     * 2.已完成的，状态为D
     * 3.没有被报销点关联
     * 4.如果当前的是变更单，那么要把原来的申请单进行还原成可以形成变更或转报销的状态
     *
     * @param docId
     * @param userId
     * @return
     */
    void updateApplyUndo(@Param("docId") String docId, @Param("userId") String userId);

    /**
     * 变更后的单据作废了，要将原来的单据还原
     *
     * @param processId
     * @param userId
     */
    void updateApplyStausYbgToD(@Param("processId") String processId, @Param("userId") String userId);

    /**
     * 修改考勤信息
     *
     * @param applyid
     * @param userId
     */
    void updateKqInfo(@Param("applyid") String applyid, @Param("userId") String userId, @Param("tripFromDate") String tripFromDate, @Param("tripToDate") String tripToDate);

    /**
     * 删除考勤信息
     *
     * @param applyid
     * @param userId
     */
    void deleteKqInfo(@Param("applyid") String applyid, @Param("userId") String userId);

    /**
     * 删除对公单据发票催收邮件发送地址
     * @param docId
     * @return
     */
    int deleteVendorInvoiceMailAddress(@Param("docId") String docId);

    /**
     * 更新对公单据发票催收邮件发送地址
     * @param docId
     * @param mailAddress
     * @return
     */
    int insertVendorInvoiceMailAddress(@Param("docId") String docId, @Param("mailAddress") String mailAddress);

    /**
     * 补贴调整后更新表头补贴金额
     */
    @Update("update z_wem_bus_flow set subsidy_amount = #{subsidyAmount, jdbcType=NUMERIC} where processid = #{docId, jdbcType=VARCHAR}")
    void updateSubsidyAmount(@Param("docId") String docId, @Param("subsidyAmount") BigDecimal subsidyAmount);
}
