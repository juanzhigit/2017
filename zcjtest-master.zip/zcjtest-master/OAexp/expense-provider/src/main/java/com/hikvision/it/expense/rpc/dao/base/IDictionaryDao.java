package com.hikvision.it.expense.rpc.dao.base;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Component;

@Component
public interface IDictionaryDao {

    @Select("select shorttext from z_wem_data_directory_view where datatype = #{dataType} and datacode = #{dataCode} and language = #{language}")
    String findOne(@Param("dataType") String dataType, @Param("dataCode") String dataCode, @Param("language") String language);

}
