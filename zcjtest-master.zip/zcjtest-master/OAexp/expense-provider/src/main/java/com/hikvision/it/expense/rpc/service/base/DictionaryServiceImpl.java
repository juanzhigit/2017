package com.hikvision.it.expense.rpc.service.base;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.service.base.IDictionaryService;
import com.hikvision.it.expense.rpc.dao.base.IDictionaryDao;

@Service
public class DictionaryServiceImpl implements IDictionaryService {

    @Autowired
    IDictionaryDao dictionaryDao;

    @Override
    public String findOne(String dataType, String dataCode) {
        return this.findOne(dataType, dataCode, UserContext.getLanguage());
    }

    @Override
    public String findOne(String dataType, String dataCode, String language) {
        if (Strings.isNullOrEmpty(dataType) || Strings.isNullOrEmpty(dataCode) || Strings.isNullOrEmpty(language)) {
            return null;
        }
        return dictionaryDao.findOne(dataType, dataCode, language);
    }
}