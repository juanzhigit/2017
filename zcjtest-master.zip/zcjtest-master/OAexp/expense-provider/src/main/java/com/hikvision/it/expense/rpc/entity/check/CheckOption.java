package com.hikvision.it.expense.rpc.entity.check;


/**
 * 字段校验可选项
 * <p>Title: CheckOption.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月24日
 *
 */
public class CheckOption implements Cloneable {
    /** 是否提交校验 */
    private boolean isSubmit = false;
    /** ps项目必填 */
    private boolean wbsRequired = false;
    /** 行业必填 */
    private boolean industryRequired = false;
    /** 销售区域必填 */
    private boolean salesAreaRequired = false;
    /** 交通项目必填 */
    private boolean trafficProjectRequired = false;
    /** 商机必填 */
    private boolean sjRequired = false;
    /** 客户必填 */
    private boolean khRequired = false;
    /** 用户必填 */
    private boolean yhRequired = false;
    /** 派工单必填 */
    private boolean jfpgRequired = false;
    /** 售前派工必填 */
    private boolean sqpgRequired = false;
    /** 是否个人费用报销 */
    private boolean isNonTravelExpense = false;
    
    /** 费用日期必输 */
    private boolean feeDateRequired = false;
    /** 事由行程必填 */
    private boolean remarkTripRequired = false;
    /** 交通工具必填 */
    private boolean trafficToolRequired = false;

    /** 交通工具类别 */
    private boolean trafficToolTypeRequired;
    /** 交通工具座位级别 */
    private boolean trafficToolLevelRequired;
    
    /** 招待方式必输 */
    private boolean entertainRequired = false;
    /** 客户级别必输 */
    private boolean entertainLevelRequired = false;
    /** 人数必输 */
    private boolean perCountsRequired = false;
    /** 天数必输 */
    private boolean dayCountsRequired = false;
    
    /** 费用细类必输 */
    private boolean smaFeeTypeRequired = false;
    
    /** 出发日期必输 */
    private boolean dateFromRequired = false;
    /** 到达日期必输 */
    private boolean dateToRequired = false;
    /** 出发城市必输 */
    private boolean cityFromRequired = false;
    /** 达到城市必输 */
    private boolean cityToRequired = false;
    
    /** 是否租房标识必输 */
    private boolean rentFlagRequired = false;
    /** 入住城市必输 */
    private boolean staysCityRequired = false;
    /** 入住日期必输 */
    private boolean staysDateRequired = false;
    /** 退房日期必输 */
    private boolean leaveDateRequired = false;
    /** 房间数必输 */
    private boolean roomsRequired = false;
    /** 住宿情况说明必输 */
    private boolean staysRemarkRequired = false;
    /** 税额必输 */
    private boolean taxRequired = false;
    /** 金额必输 */
    private boolean amountRequired = true;
    /** 事由必输 */
    private boolean remarkRequired = true;

    public boolean isAmountRequired() {
        return amountRequired;
    }

    public void setAmountRequired(boolean amountRequired) {
        this.amountRequired = amountRequired;
    }

    public boolean isSubmit() {
        return isSubmit;
    }
    public void setSubmit(boolean isSubmit) {
        this.isSubmit = isSubmit;
    }
    public boolean isWbsRequired() {
        return wbsRequired;
    }
    public void setWbsRequired(boolean wbsRequired) {
        this.wbsRequired = wbsRequired;
    }
    public boolean isIndustryRequired() {
        return industryRequired;
    }
    public void setIndustryRequired(boolean industryRequired) {
        this.industryRequired = industryRequired;
    }
    public boolean isSalesAreaRequired() {
        return salesAreaRequired;
    }
    public void setSalesAreaRequired(boolean salesAreaRequired) {
        this.salesAreaRequired = salesAreaRequired;
    }
    public boolean isTrafficProjectRequired() {
        return trafficProjectRequired;
    }
    public void setTrafficProjectRequired(boolean trafficProjectRequired) {
        this.trafficProjectRequired = trafficProjectRequired;
    }
    public boolean isSjRequired() {
        return sjRequired;
    }
    public void setSjRequired(boolean sjRequired) {
        this.sjRequired = sjRequired;
    }
    public boolean isKhRequired() {
        return khRequired;
    }
    public void setKhRequired(boolean khRequired) {
        this.khRequired = khRequired;
    }
    public boolean isYhRequired() {
        return yhRequired;
    }
    public void setYhRequired(boolean yhRequired) {
        this.yhRequired = yhRequired;
    }
    public boolean isTrafficToolRequired() {
        return trafficToolRequired;
    }
    public void setTrafficToolRequired(boolean trafficToolRequired) {
        this.trafficToolRequired = trafficToolRequired;
    }
    public boolean isJfpgRequired() {
        return jfpgRequired;
    }
    public void setJfpgRequired(boolean jfpgRequired) {
        this.jfpgRequired = jfpgRequired;
    }
    public boolean isSqpgRequired() {
        return sqpgRequired;
    }
    public void setSqpgRequired(boolean sqpgRequired) {
        this.sqpgRequired = sqpgRequired;
    }
    public boolean isNonTravelExpense() {
        return isNonTravelExpense;
    }
    public void setNonTravelExpense(boolean isNonTravelExpense) {
        this.isNonTravelExpense = isNonTravelExpense;
    }
    public boolean isEntertainRequired() {
        return entertainRequired;
    }
    public void setEntertainRequired(boolean entertainRequired) {
        this.entertainRequired = entertainRequired;
    }
    public boolean isEntertainLevelRequired() {
        return entertainLevelRequired;
    }
    public void setEntertainLevelRequired(boolean entertainLevelRequired) {
        this.entertainLevelRequired = entertainLevelRequired;
    }
    public boolean isPerCountsRequired() {
        return perCountsRequired;
    }
    public void setPerCountsRequired(boolean perCountsRequired) {
        this.perCountsRequired = perCountsRequired;
    }
    public boolean isDayCountsRequired() {
        return dayCountsRequired;
    }
    public void setDayCountsRequired(boolean dayCountsRequired) {
        this.dayCountsRequired = dayCountsRequired;
    }
    public boolean isSmaFeeTypeRequired() {
        return smaFeeTypeRequired;
    }
    public void setSmaFeeTypeRequired(boolean smaFeeTypeRequired) {
        this.smaFeeTypeRequired = smaFeeTypeRequired;
    }
    public boolean isDateFromRequired() {
        return dateFromRequired;
    }
    public void setDateFromRequired(boolean dateFromRequired) {
        this.dateFromRequired = dateFromRequired;
    }
    public boolean isDateToRequired() {
        return dateToRequired;
    }
    public void setDateToRequired(boolean dateToRequired) {
        this.dateToRequired = dateToRequired;
    }
    public boolean isCityFromRequired() {
        return cityFromRequired;
    }
    public void setCityFromRequired(boolean cityFromRequired) {
        this.cityFromRequired = cityFromRequired;
    }
    public boolean isCityToRequired() {
        return cityToRequired;
    }
    public void setCityToRequired(boolean cityToRequired) {
        this.cityToRequired = cityToRequired;
    }
    public boolean isRemarkTripRequired() {
        return remarkTripRequired;
    }
    public void setRemarkTripRequired(boolean remarkTripRequired) {
        this.remarkTripRequired = remarkTripRequired;
    }
    public boolean isRentFlagRequired() {
        return rentFlagRequired;
    }
    public void setRentFlagRequired(boolean rentFlagRequired) {
        this.rentFlagRequired = rentFlagRequired;
    }
    public boolean isStaysCityRequired() {
        return staysCityRequired;
    }
    public void setStaysCityRequired(boolean staysCityRequired) {
        this.staysCityRequired = staysCityRequired;
    }
    public boolean isStaysDateRequired() {
        return staysDateRequired;
    }
    public void setStaysDateRequired(boolean staysDateRequired) {
        this.staysDateRequired = staysDateRequired;
    }
    public boolean isLeaveDateRequired() {
        return leaveDateRequired;
    }
    public void setLeaveDateRequired(boolean leaveDateRequired) {
        this.leaveDateRequired = leaveDateRequired;
    }
    public boolean isRoomsRequired() {
        return roomsRequired;
    }
    public void setRoomsRequired(boolean roomsRequired) {
        this.roomsRequired = roomsRequired;
    }
    public boolean isStaysRemarkRequired() {
        return staysRemarkRequired;
    }
    public void setStaysRemarkRequired(boolean staysRemarkRequired) {
        this.staysRemarkRequired = staysRemarkRequired;
    }
    public boolean isTaxRequired() {
        return taxRequired;
    }
    public void setTaxRequired(boolean taxRequired) {
        this.taxRequired = taxRequired;
    }
    public boolean isFeeDateRequired() {
        return feeDateRequired;
    }
    public void setFeeDateRequired(boolean feeDateRequired) {
        this.feeDateRequired = feeDateRequired;
    }

    public boolean isTrafficToolTypeRequired() {
        return trafficToolTypeRequired;
    }

    public void setTrafficToolTypeRequired(boolean trafficToolTypeRequired) {
        this.trafficToolTypeRequired = trafficToolTypeRequired;
    }

    public boolean isTrafficToolLevelRequired() {
        return trafficToolLevelRequired;
    }

    public void setTrafficToolLevelRequired(boolean trafficToolLevelRequired) {
        this.trafficToolLevelRequired = trafficToolLevelRequired;
    }

    public boolean isRemarkRequired() {
        return remarkRequired;
    }

    public void setRemarkRequired(boolean remarkRequired) {
        this.remarkRequired = remarkRequired;
    }

    @Override
    public CheckOption clone() throws CloneNotSupportedException {
        return (CheckOption) super.clone();
    }
}
