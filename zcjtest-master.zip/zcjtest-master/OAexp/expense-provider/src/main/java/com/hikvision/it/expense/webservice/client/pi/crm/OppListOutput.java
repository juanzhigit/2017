
package com.hikvision.it.expense.webservice.client.pi.crm;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="Error_spcCode" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element name="Error_spcMessage" type="{http://www.w3.org/2001/XMLSchema}string"/&gt;
 *         &lt;element ref="{http://www.siebel.com/xml/HIK%20Opty%20App%20For%20OA}ListOfHikOptyAppForOa"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {
    "errorSpcCode",
    "errorSpcMessage",
    "listOfHikOptyAppForOa"
})
@XmlRootElement(name = "OppList_Output", namespace = "http://hikcrm.com/")
public class OppListOutput {

    @XmlElement(name = "Error_spcCode", namespace = "http://hikcrm.com/", required = true)
    protected String errorSpcCode;
    @XmlElement(name = "Error_spcMessage", namespace = "http://hikcrm.com/", required = true)
    protected String errorSpcMessage;
    @XmlElement(name = "ListOfHikOptyAppForOa", required = true)
    protected ListOfHikOptyAppForOa listOfHikOptyAppForOa;

    /**
     * 获取errorSpcCode属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorSpcCode() {
        return errorSpcCode;
    }

    /**
     * 设置errorSpcCode属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorSpcCode(String value) {
        this.errorSpcCode = value;
    }

    /**
     * 获取errorSpcMessage属性的值。
     * 
     * @return
     *     possible object is
     *     {@link String }
     *     
     */
    public String getErrorSpcMessage() {
        return errorSpcMessage;
    }

    /**
     * 设置errorSpcMessage属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link String }
     *     
     */
    public void setErrorSpcMessage(String value) {
        this.errorSpcMessage = value;
    }

    /**
     * 获取listOfHikOptyAppForOa属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ListOfHikOptyAppForOa }
     *     
     */
    public ListOfHikOptyAppForOa getListOfHikOptyAppForOa() {
        return listOfHikOptyAppForOa;
    }

    /**
     * 设置listOfHikOptyAppForOa属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfHikOptyAppForOa }
     *     
     */
    public void setListOfHikOptyAppForOa(ListOfHikOptyAppForOa value) {
        this.listOfHikOptyAppForOa = value;
    }

}
