package com.hikvision.it.expense.rpc.service.allowance;

import java.math.BigDecimal;
import java.util.List;

import org.apache.xmlbeans.impl.xb.xsdschema.impl.DocumentationDocumentImpl;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.service.allowance.ISubsidyService;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.subsidy.ISubsidyDao;

@Service
@Primary
public class SubsidyServiceImpl implements ISubsidyService {
	@Autowired
    ISubsidyDao subsidyDao;

	@Autowired
	IFormDao formDao;

    @Override
	public List<Allowance> listAllowance(String docId) {
        return subsidyDao.listAllowance(docId);
	}

    @Override
    public List<AllowanceDetail> listAllowanceDetail(String docId) {
        return subsidyDao.listAllowanceDetail(docId);
    }

    @Override
    public List<AllowanceDetail> listRentAllowanceDetail(String docId) {
        return subsidyDao.listRentAllowanceDetail(docId);
    }

}
