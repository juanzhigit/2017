package com.hikvision.it.expense.rpc.service.voucher;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.dept.Dept;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.service.pi.BsikServiceImpl;
import com.hikvision.it.expense.rpc.service.pi.OrderServiceImpl;
import com.hikvision.it.expense.rpc.util.CalculateUtil;

/**
 * 凭证处理抽象类
 * <p>Title: AbstractVoucherService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月11日
 *
 */
public abstract class AbstractVoucherService {
	@Autowired
	IBaseDao baseDao;
	@Autowired
	OrderServiceImpl orderService;
	@Autowired
	BsikServiceImpl bsikService;

	/**
	 * 定义默认预制凭证生成接口方法
	 * @param header			单据抬头
	 * @param refIndex			凭证起始序列  考虑冲销后再次过账的情况
	 * @return
	 */
	abstract HikResult<List<Voucher>> previewVoucher(FormHeader header, Integer refIndex);
	
	public String getReference(String docNo, int index) {
		// 业务单据号
		if(!StringUtil.isEmptyTrim(docNo)){
			docNo = docNo.trim();
		}
		
		// 序号
		String idx = String.valueOf(index);
		if(2 > idx.length()){
			idx = "0"+idx;
		}
		
		return docNo + idx;
	}
	
	/**
	 * 根据部门路径截取前两级的部门名称
	 * @param deptCode
	 * @return
	 */
	public String getFirstTwoLevelDeptName(String deptCode) {
		String deptPath = baseDao.findDeptPath(deptCode);
		if (StringUtil.isNotEmptyTrim(deptPath)) {
			String twoLevelDeptName = null;
			if (deptPath.contains("\\")) {
				deptPath = deptPath.replaceAll("\\u005c", "/");
				String[] deptPaths = deptPath.split("/");
				
				if (deptPath.length() >= 2) {
					twoLevelDeptName = deptPaths[0] + "\\" + deptPaths[1];
				}
			} else {
				twoLevelDeptName = deptPath;
			}
			
			return twoLevelDeptName;
		}
		
		return null;
	}
	
	/**
	 * 根据员工编号、公司代码计算sap未清和在途未清
	 * @param userId
	 * @param bukrs
	 * @param ztWqJe
	 * @return
	 */
	public HikResult<Map<String, BigDecimal>> countWQJEAndDQWQJE(String userId, String bukrs, BigDecimal ztWqJe) {
		//获取未清明细
		List<Bsik> bsiks = bsikService.getBsik(userId, bukrs);
		//根据报销在途以及sap未清明细统计到期未清和未清总金额
		return CalculateUtil.countWQJEAndDQWQJE(bsiks, ztWqJe);
	}
	
	/**
	 * 根据员工编号、公司代码获取sap员工内部订单
	 * @param userId
	 * @param bukrs
	 * @return
	 */
	public String getSapOrderId(String userId, String bukrs) {
		return orderService.getSapOrderIdFromLocal(userId, bukrs);
	}
	
	/**
	 * 根据部门信息匹配部门类别
	 * 00：普通 01：研发 02：生产 03：工程
	 * @param dept
	 * @return
	 */
	public String matchDeptType(Dept dept) {
		String deptType = dept.getDeptType();
		
		if (Strings.isNullOrEmpty(deptType) ||
				"00".equalsIgnoreCase(deptType.trim()) ||
				"01".equalsIgnoreCase(deptType.trim())) {
			if (Strings.isNullOrEmpty(dept.getOrderNo())) {
				return "00";
			} else {
				return "01";
			}
		} else {
			return deptType;
		}
	}

	/**
	 * 公共设置凭证明细行属性值方法
	 * @param item
	 * @param dept
	 * @param sapOrderId
	 */
	public void setVoucherItemPropertiesByDeptType(VoucherItem item, Dept dept, String sapOrderId) {
		//根据研发标识设置订单号
		String orderId = dept.getOrderNo();
		if(Strings.isNullOrEmpty(orderId)) {
			item.setCostcenter(dept.getCostCenter());	// 设置成本中心
			item.setCopaZaufnr(null);					// 将传递的值置空
			item.setCopaAufnr(null);
			// ORDERID 订单号
			item.setOrderId(sapOrderId);					// 设置订单号为sap员工供应商编号
		} else {
			item.setCopaAufnr(null);					// 将传递的值置空
			item.setCopaZaufnr(sapOrderId);				// 研发订单 （员工）
			item.setOrderId(orderId);			// 设置订单号为员工研发订单
			item.setCopaWw012(dept.getRlDept());		// 研发实际部门
		}
	}
	
//	/**
//	 * 
//	 * @param voucherHeader
//	 * @return
//	 */
//	public String packageKidno(VoucherHeader voucherHeader) {
//		LoginUser loginUser = UserContext.get();
//		
//		if (loginUser != null && 
//				!Strings.isNullOrEmpty(loginUser.getSapAccount())) {
//			
//			return voucherHeader.getDocNo() + "@S009@" + voucherHeader.getUsnam();
//		} else {
//			throw new ExpenseException(ExceptionCode.VOUCH_ERROR_NOT_AUTH);
//		}
//	}
}
