
package com.hikvision.it.expense.webservice.client.pi.order;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>anonymous complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;all&gt;
 *         &lt;element name="ES_MSG" type="{urn:sap-com:document:sap:rfc:functions}BAPIRETURN1" minOccurs="0"/&gt;
 *       &lt;/all&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "", propOrder = {

})
@XmlRootElement(name = "Z_I_REIMBURSE_GET_ORDERID.Response")
public class ZIREIMBURSEGETORDERIDResponse {

    @XmlElement(name = "ES_MSG")
    protected BAPIRETURN1 esmsg;

    /**
     * 获取esmsg属性的值。
     * 
     * @return
     *     possible object is
     *     {@link BAPIRETURN1 }
     *     
     */
    public BAPIRETURN1 getESMSG() {
        return esmsg;
    }

    /**
     * 设置esmsg属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link BAPIRETURN1 }
     *     
     */
    public void setESMSG(BAPIRETURN1 value) {
        this.esmsg = value;
    }

}
