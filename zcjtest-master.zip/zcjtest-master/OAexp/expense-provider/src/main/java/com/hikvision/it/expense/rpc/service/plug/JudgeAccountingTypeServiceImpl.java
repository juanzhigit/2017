package com.hikvision.it.expense.rpc.service.plug;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 根据费用是否属于核高基费用，到不同的财务过账处理
 * 
 * 核高基费用到		TO_F03
 * 非核高基费用到	TO_F01
 * 
 * <p>Title: JudgeAccountingTypeServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="judgeAccountingTypeServiceImpl")
public class JudgeAccountingTypeServiceImpl implements IExecutePlugService {
	@Autowired
	IFormDao formDao;
	
	@Override
	public String execute(TaskObject taskObject, String docId) {
		String isHGJ = formDao.findDocHGJFlag(docId);
		
		if (!Strings.isNullOrEmpty(isHGJ) && 
				isHGJ.equalsIgnoreCase("Y")) {
			return "TO_F03";
		}
		
		return "TO_F01";
	}
}
