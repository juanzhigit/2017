package com.hikvision.it.expense.rpc.service.config;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.thymeleaf.TemplateEngine;
import org.thymeleaf.context.Context;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.entity.flow.MailEntity;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.NationalTrip;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.logs.ISendLogDao;
import com.hikvision.it.expense.rpc.dao.trip.ITripDao;

/**
 * 国际差旅申请通知（仅中东北非业务部）
 * 
 * 当出差国际的人员不是中东北非业务部的人员需要邮件通知行程所到国家的主管
 * 
 * <p>Title: NationalTRServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月24日
 *
 */
@Service(value="nationalTRServiceImpl")
public class NationalTRServiceImpl implements IExecuteService {
	@Autowired
	IFormDao formDao;
	@Autowired
	ITripDao tripDao;
	@Autowired
	ISendLogDao logDao;
	@Autowired
	TemplateEngine templateEngine;
	
	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		List<NationalTrip> trips = tripDao.listConfigNationalTrips(process.getDocId());
		
		if (!ListUtil.isEmpty(trips)) {
			//记录邮件日志
			this.recordMails(trips);
		}
	}
	
	/**
	 * 发送国际差旅邮件给部门主管
	 * @param trips
	 */
	private void recordMails(List<NationalTrip> trips) {
		Map<String, List<NationalTrip>> groupRecivorsMap = Maps.newHashMap();
		
		//针对国际差旅的国家所在的部门区域主管进行差旅城市分组
		for(NationalTrip trip : trips){
			String directMail = trip.getDirectMail();
			
			if(groupRecivorsMap.containsKey(directMail)){
				groupRecivorsMap.get(directMail).add(trip);
			} else {
				groupRecivorsMap.put(directMail, Lists.newArrayList(trip));
			}
		}
		MailEntity mail = null;
		
		NationalTrip nationalTrip = trips.get(0);
		String userName = nationalTrip.getUserName();
		String docNo = nationalTrip.getDocNo();
		String procedue = nationalTrip.getProcedue();
		String processresult = nationalTrip.getProcessresult();
		String suggestion = nationalTrip.getSuggestion();
		List<MailEntity> mails = Lists.newArrayList();
		for(String key: groupRecivorsMap.keySet()){
			mail = new MailEntity();
			
		    Context model = new Context();
		    
			model.setVariable("tripList", groupRecivorsMap.get(key));	
			model.setVariable("userName", userName);	
			model.setVariable("docNo", docNo);			 
			model.setVariable("report_process", procedue);				 
			model.setVariable("report_result", processresult);				 
			model.setVariable("report_suggest", suggestion);
			//组装邮件
			mail.setContent(this.getMessage(model));
			//设置邮件标题
			//获取报销人邮箱
			mail.setReceivors(key);
			//设置内外网邮件
			mail.setIsOutMail("N");
			
			mails.add(mail);
		}
		
		if (!ListUtil.isEmpty(mails)) {
			logDao.batchRecordMailInfo(mails);
		}
	}

	/**
	 * 将参数设置到模板文件中，并且返回文件内容
	 * @param model
	 * @return
	 */
	protected final String getMessage(Context model) {
		return templateEngine.process("/en/nationalAttentionMail", model);
	}
}
