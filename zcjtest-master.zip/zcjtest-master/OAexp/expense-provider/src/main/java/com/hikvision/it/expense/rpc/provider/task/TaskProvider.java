package com.hikvision.it.expense.rpc.provider.task;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.task.PendingForwardBean;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.entity.task.TodoInfo;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.service.task.ITaskService;

@Service(version = Version.VERSION_LATEST)
public class TaskProvider implements ITaskService {
    @Autowired
    ITaskService taskService;

    @Override
    public HikResult<String> completeTask(String taskId, ResultEnum result, String suggest) {
        return taskService.completeTask(taskId, result, suggest);
    }


    @Override
    public HikResult<String> forwardTask(String taskId, String suggest, TaskReceivor receivor) {
        return taskService.forwardTask(taskId, suggest, receivor);
    }


    @Override
    public HikResult<String> addStep(String taskId, String suggest, List<TaskReceivor> receivors) {
        return taskService.addStep(taskId, suggest, receivors);
    }


    @Override
    public void startTask(ProcessInstance process) {
        taskService.startTask(process);
    }

    @Override
    public String getDocIdByTaskId(String taskId) {
        return taskService.getDocIdByTaskId(taskId);
    }

    @Override
    public TaskInstance getTaskInstance(String taskId) {
        return taskService.getTaskInstance(taskId);
    }

    /**
     * 根据用户关键信息查询该员工下面的所有待办信息
     */
    @Override
    public GridData<PendingForwardBean> getPendingByUserName(String userNameOrEmpId, int pageNum, int pageSize) {
        return taskService.getPendingByUserName(userNameOrEmpId, pageNum, pageSize);
    }

    /**
     * 根据单号批量查询待办信息
     */
    @Override
    public GridData<PendingForwardBean> getRecordByApplyIds(String applyIds, int pageNum, int pageSize) {
        return taskService.getRecordByApplyIds(applyIds, pageNum, pageSize);
    }

    /**
     * 修改当前审批人数据
     */
    @Override
    public void updateBpmInfo(String delegator, String processIds, String taskIds) throws Exception {
        taskService.updateBpmInfo(delegator, processIds, taskIds);
    }

    /**
     * 根据关键字查找用户
     */
    @Override
    public List<PendingForwardBean> getSelectUser(String searchText) {
        return taskService.getSelectUser(searchText);
    }

    @Override
    public List<TodoInfo> getTasksToApprove() {
        return taskService.getTasksToApprove();
    }

    @Override
    public List<TodoInfo> getApprovedTasks(int pageNumber, int pageSize) {
        return taskService.getApprovedTasks(pageNumber, pageSize);
    }
}
