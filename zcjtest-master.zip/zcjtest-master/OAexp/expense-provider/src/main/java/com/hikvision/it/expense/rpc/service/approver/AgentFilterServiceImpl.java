package com.hikvision.it.expense.rpc.service.approver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.flow.FinalApproveConfig;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.ApproveAuth;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 审批人授权过滤service
 * 
 * 1、首先根据授权人、单据号关联出单据金额、费用归属部门与授权表匹配出满足条件的授权人
 * 2、根据单据类别、费用类别、费用归属部门路径匹配授权人的匹配度
 * 3、根据环节是否可以跳过，判断是否过滤被授权人列表将已审批过的被授权人从列表中移除
 * 
 * <p>Title: AgentFilterServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
@Service
public class AgentFilterServiceImpl {
	@Autowired
	IApproverDao approverDao;
	@Autowired
	IFormDao formDao;
	
	/**
	 * 过滤代理审批人信息
	 * @param taskObject
	 * @param owner
	 * @param docId
	 */
	public List<TaskOwner> filterAgentApprover(TaskObject taskObject, TaskOwner owner, String docId) {
		List<TaskOwner> owners = Lists.newArrayList();
		
		if (owner != null) {
			FormHeader header = formDao.getFormHeader(docId);
			//获取主管授权信息，然后匹配出符合条件的授权用户
			List<ApproveAuth> auths = approverDao.getApproverAuth(owner.getOwner(), docId, UserContext.getLanguage());
			//判断授权是否适用当前流程
			if (auths != null && auths.size() != 0) {
				int lv = 0;
				for (ApproveAuth auth : auths) {
					if (lv == 0) {
						lv = auth.getLv();
					}
					if (lv == auth.getLv()) {
						//将满足条件的授权人添加到审批人列表中
						TaskOwner approver = this.checkAgentNeedApprove(auth, header);
						
						if (approver != null) {
							//判断代理人是否是报销人，如果代理人是报销人则不能审批
							if (!approver.getOwner().equalsIgnoreCase(header.getExpensor())) {
								owners.add(approver);
							}
						}
					} else {
						break;
					}
				}
				//未匹配到合适的授权人，则由自己审批
				if (owners.size() == 0) {
					owners.add(owner);
				}
			} else {
				//未查询到授权人
				owners.add(owner);
			}
		}
		
		//过滤已审批过的被授权人
		return this.filterApprovedTaskOwners(owners, taskObject, docId);
	}
	
	/**
	 * 过滤已审批过的人员列表
	 * @param owners
	 * @param taskObject
	 * @param docId
	 * @return
	 */
	public List<TaskOwner> filterApprovedTaskOwners(List<TaskOwner> owners, TaskObject taskObject, String docId) {
		//如果环节可以跳过，需要过滤已审批人员
		String canJump = taskObject.getCanJump();
		if (!Strings.isNullOrEmpty(canJump) && 
				canJump.equalsIgnoreCase(YesOrNoEnum.Y.name())) {
			if (owners != null && owners.size() != 0) {
				//过滤已审批过的被授权人
				owners = approverDao.filterApprovedOwners(docId, owners);
			}
		}
		
		return owners;
	}
	
	/**
	 * 校验当前授权人是否需要审批当前单据，如果需要审批则返回一个审批人对象，否则返回null
	 * @param auth
	 * @param header
	 * @return
	 */
	private TaskOwner checkAgentNeedApprove(ApproveAuth auth, FormHeader header) {
		String authArea = auth.getAuthArea();
		String authBus = auth.getAuthBus();
		String authDept = auth.getAuthDept();
		
		TaskOwner approver = null;
		if (this.checkAuthAreaValid(authArea, header.getDocType()) &&
				this.checkAuthBusValid(authBus, header.getExpenseType()) &&
				this.checkAuthDeptValid(authDept, header.getDeptCodePath())) {
			//通用授权
			approver = new TaskOwner();
			
			approver.setOwner(auth.getAgent());
			approver.setOwnerName(auth.getAgentName());
			approver.setOwnerMail(auth.getAgentMail());
			approver.setAuthUser(auth.getAuthor());
			approver.setAuthUserName(auth.getAuthorName());
		} 
		
		return approver;
	}
	
	/**
	 * 校验业务类型是否匹配
	 * @param authBus
	 * @param docBusType
	 * @return
	 */
	private boolean checkAuthBusValid(String authBus, String docBusType) {
		boolean valid = false;
		
		if (StringUtil.COMMON_REGEX.equalsIgnoreCase(authBus)) {
			valid = true;
		} else {
			if (StringUtil.isNotEmptyTrim(authBus) && 
					StringUtil.isNotEmptyTrim(docBusType) && 
					docBusType.equalsIgnoreCase(authBus)) {
				valid = true;
			}
		}
		
		return valid;
	}
	
	/**
	 * 校验部门是否匹配
	 * @param authDept
	 * @param docDeptCodePath
	 * @return
	 */
	private boolean checkAuthDeptValid(String authDept, String docDeptCodePath) {
		boolean valid = false;
		
		if (StringUtil.COMMON_REGEX.equalsIgnoreCase(authDept)) {
			valid = true;
		} else {
			if (StringUtil.isNotEmptyTrim(authDept) && 
					StringUtil.isNotEmptyTrim(docDeptCodePath)) {
				if (docDeptCodePath.endsWith(authDept)) {
					valid = true;
				} else if (authDept.endsWith(StringUtil.LIKE_REGEX)) {
					//去掉结尾的%匹配开头是否包含授权部门路径
					if (docDeptCodePath.startsWith(authDept.substring(0, authDept.length() - 1))) {
						valid = true;
					}
				}
			}
		}
		
		return valid;
	}
	
	/**
	 * 校验业务范围是否匹配
	 * @param authArea
	 * @param docArea
	 * @return
	 */
	private boolean checkAuthAreaValid(String authArea, String docArea) {
		boolean valid = false;
		
		if (StringUtil.COMMON_REGEX.equalsIgnoreCase(authArea)) {
			valid = true;
		} else {
			if (StringUtil.isNotEmptyTrim(docArea) && 
					StringUtil.isNotEmptyTrim(authArea) && 
					docArea.equalsIgnoreCase(authArea)) {
				valid = true;
			}
		}
		
		return valid;
	}
	
	/**
	 * 根据单据参数信息获取审批级别
	 * 
	 * 1、先判断是否存在分级审批配置，如果不存在直接返回 null
	 * 2、如果存在1条配置，则直接返回这条配置
	 * 3、如果存在多条，首先按照费用细类、费用大类、单据类别精确匹配，然后依次按照费用细类、
	 *   费用大类进行通用匹配，匹配到一条即可返回，都匹配不到返回null
	 * 
	 * @param header
	 * @return
	 */
	public FinalApproveConfig getFinalApproveConfig(FormHeader header) {
		//先精确匹配
		List<FinalApproveConfig> configs = approverDao.matchFinalApproveConfig(header);
		//未匹配到分级终审配置
		if (ListUtil.isEmpty(configs)) {
			return null;
		}
		//获取到一条终审分级配置
		if (configs.size() == 1)
			return configs.get(0);
		
		//进行终审规则匹配
		return this.match(header, configs);
	}
	
	/**
	 * 开始匹配终审规则
	 * @param header
	 * @param configs
	 * @return
	 */
	private FinalApproveConfig match(FormHeader header, List<FinalApproveConfig> configs) {
		//解析费用类别 费用大小类
		String expenseType = header.getExpenseType();
		String docType = header.getDocType();
		String bigFeeType = null;
		String smaFeeType = null;
		FinalApproveConfig expenseDetail = approverDao.getExpenseTypeDetail(expenseType);
		if (expenseDetail != null) {
			bigFeeType = expenseDetail.getBigFeeType();
			smaFeeType = expenseDetail.getSmaFeeType();
		} else {
			bigFeeType = expenseType;
			smaFeeType = StringUtil.COMMON_REGEX;
		}
		
		//具体匹配方法
		return this.match(configs, bigFeeType, smaFeeType, docType);
	}
	
	/**
	 * 终审规则匹配迭代方法
	 * @param configs
	 * @param bigFeeType
	 * @param smaFeeType
	 * @param docType
	 * @return
	 */
	private FinalApproveConfig match(List<FinalApproveConfig> configs,
			String bigFeeType, String smaFeeType, String docType) {
		FinalApproveConfig result = null;
		for (FinalApproveConfig approveConfig : configs) {
			if (this.checkMatch(approveConfig, bigFeeType, smaFeeType, docType)) {
				result = approveConfig;
				
				break;
			}
		}
		if (result == null) {
			if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(smaFeeType)) {//通用匹配费用细类
				result = this.match(configs, bigFeeType, StringUtil.COMMON_REGEX, docType);
			}
			if (!StringUtil.COMMON_REGEX.equalsIgnoreCase(bigFeeType)) {//通用匹配费用大类、业务细类
				result = this.match(configs, StringUtil.COMMON_REGEX, StringUtil.COMMON_REGEX, docType);
			}
		}
		
		return result;
	}
	
	/**
	 * 校验终审配置是否适用当前匹配规则
	 * @param approveConfig
	 * @param bigFeeType		费用大类
	 * @param smaFeeType		费用细类
	 * @param docType			单据类别
	 * @return
	 */
	private boolean checkMatch(FinalApproveConfig approveConfig,
			String bigFeeType, String smaFeeType, String docType) {
		if (docType.equalsIgnoreCase(approveConfig.getArea()) &&
				bigFeeType.equalsIgnoreCase(approveConfig.getBigFeeType()) &&
				smaFeeType.equalsIgnoreCase(approveConfig.getSmaFeeType())) {
			return true;
		}
		return false;
	}
}
