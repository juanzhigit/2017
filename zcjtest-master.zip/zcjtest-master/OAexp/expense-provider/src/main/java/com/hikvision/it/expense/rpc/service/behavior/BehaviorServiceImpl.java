package com.hikvision.it.expense.rpc.service.behavior;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.enums.BehaviorEnum;
import com.hikvision.it.expense.api.service.behavior.IBehaviorService;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.behavior.IBehaviorDao;

@Service
@Primary
public class BehaviorServiceImpl implements IBehaviorService {
	@Autowired
	IBehaviorDao behavoirDao;
	
	@Override
	public void recordSelectTripCity(TripDays tripDays) {
		LoginUser user = UserContext.get();
		
		tripDays.setId(StringUtil.getUUID());
		tripDays.setUserId(user.getUserId());
		tripDays.setUserName(user.getUserName());
		tripDays.setUpTime(System.currentTimeMillis());
		
		try {
			int effNum = behavoirDao.updateSelectTripCityUpTime(tripDays);
			
			if (effNum == 0)
				behavoirDao.recordSelectTripCity(tripDays);
		} catch (Exception e) {
		}
	}

	@Override
	public void recordSelectOpt(BehaviorEnum behavior, SelectOpt opt) {
		LoginUser user = UserContext.get();

		opt.setBehavior(behavior.getId());
		opt.setUserId(user.getUserId());
		opt.setUserName(user.getUserName());

		behavoirDao.recordSelectOpt(opt);
	}

	@Override
	public List<TripCity> findCommonUsedCity() {
		String userId = UserContext.getUserId();
		String language = UserContext.getLanguage();
		
		return behavoirDao.findCommonUsedCity(userId, language);
	}

	@Override
	public List<SelectOpt> findCommonUsedOpt(BehaviorEnum behavior) {
		String userId = UserContext.getUserId();
		
		return behavoirDao.findCommonUserdSelect(userId, behavior.getId());
	}

}
