package com.hikvision.it.expense.rpc.service.pi;

import java.util.List;

import org.apache.cxf.jaxws.JaxWsProxyFactoryBean;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.webservice.client.crm.bussiness.HIKSpcOptySpcListSpcForSpcFinanceSpcWorkflow;
import com.hikvision.it.expense.webservice.client.crm.bussiness.HikOptyApp;
import com.hikvision.it.expense.webservice.client.crm.bussiness.OppListInput;
import com.hikvision.it.expense.webservice.client.crm.bussiness.OppListOutput;
import com.hikvision.it.expense.webservice.client.crm.partner.AccListInput;
import com.hikvision.it.expense.webservice.client.crm.partner.AccListOutput;
import com.hikvision.it.expense.webservice.client.crm.partner.HIKSpcAccountSpcPartnerSpcForSpcFinaceSpcWorkflow;
import com.hikvision.it.expense.webservice.client.crm.partner.HikAccountPartnerForInterface;

@Service
public class CrmServiceImpl {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${system.pi.crm.url}")
	private String url;
	
	/**
	 * 从CRM获取客户信息
	 * @param userInMail
	 * @param filter
	 * @return
	 */
	public List<SelectOpt> getPartnerFromCRM(String userInMail, String filter) {
        try {
        	JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();  
            factory.setServiceClass(HIKSpcAccountSpcPartnerSpcForSpcFinaceSpcWorkflow.class);  
            factory.setAddress(url);  
            HIKSpcAccountSpcPartnerSpcForSpcFinaceSpcWorkflow port = (HIKSpcAccountSpcPartnerSpcForSpcFinaceSpcWorkflow) factory.create();  
            
            AccListInput request = new AccListInput();
            StringBuffer searchBuf = new StringBuffer();
            
            searchBuf.append("[AccountPartner.Name] like '*").append(filter)
            	     .append("*' AND ([AccountPartner.MyEmailInTeam]='").append(userInMail)
            	     .append("' or [AccountPartner.HIKLeadEmailAddr]='").append(userInMail)
            	     .append("')");
            
            request.setSSearchExpr(searchBuf.toString());
            
            AccListOutput response = port.accList(request);

        	//转换接口返回数据，并且返回下拉选项list
        	return this.transPartnerResponseToSelectItem(response);
		} catch (Exception e) {
        	logger.error("get wbs info error", e);
		}
        
        return null;
	}
	
	/**
	 * 解析接口返回结果返回下拉选项列表
	 * @param response
	 * @return
	 */
	private List<SelectOpt> transPartnerResponseToSelectItem(AccListOutput response) {
		List<HikAccountPartnerForInterface> items = response.getListOfHikAccountPartnerForFinance().getHikAccountPartnerForInterface();
		List<SelectOpt> opts = Lists.newArrayList();

		SelectOpt opt = null;
		if (!ListUtil.isEmpty(items)) {
			for (HikAccountPartnerForInterface item : items) {
				//最多只返回15条数据
				if (opts.size() >= 16) {
					break;
				}

				opt = new SelectOpt();

				opt.setId(item.getId());
				opt.setText(item.getName());

				opts.add(opt);
			}
		}
		
		return opts;
	}
	
	/**
	 * 从CRM获取商机信息
	 * @param userInMail
	 * @param filter
	 * @return
	 */
	public List<SelectOpt> getBusinessOpportunityFromCRM(String userInMail, String filter) {
		try {
        	JaxWsProxyFactoryBean factory = new JaxWsProxyFactoryBean();  
            factory.setServiceClass(HIKSpcOptySpcListSpcForSpcFinanceSpcWorkflow.class);  
            factory.setAddress(url);  
            HIKSpcOptySpcListSpcForSpcFinanceSpcWorkflow port = (HIKSpcOptySpcListSpcForSpcFinanceSpcWorkflow) factory.create();  
            OppListInput request = new OppListInput();
            
           	request.setObjectSpcId("");
           	request.setKeyWord(filter);
           	request.setEmail(userInMail);
            
            OppListOutput response = port.oppList(request);

        	//转换接口返回数据，并且返回下拉选项list
        	return this.transResponseToSelectItem(response);
		} catch (Exception e) {
        	logger.error("get wbs info error", e);
		}
        
        return null;
	}
	
	/**
	 * 解析接口返回结果返回下拉选项列表
	 * @param response
	 * @return
	 */
	private List<SelectOpt> transResponseToSelectItem(OppListOutput response) {
		List<HikOptyApp> items = response.getListOfHikOptyAppForOa().getHikOptyApp();
		List<SelectOpt> opts = Lists.newArrayList();

		SelectOpt opt = null;
		if (!ListUtil.isEmpty(items)) {
			for (HikOptyApp item : items) {
				//最多只返回15条数据
				if (opts.size() >= 16) {
					break;
				}

				opt = new SelectOpt();

				opt.setId(item.getId());
				opt.setText(item.getName());

				opts.add(opt);
			}
		}

		return opts;
	}
}
