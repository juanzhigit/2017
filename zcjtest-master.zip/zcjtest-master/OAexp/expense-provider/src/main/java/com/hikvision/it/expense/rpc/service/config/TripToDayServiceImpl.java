package com.hikvision.it.expense.rpc.service.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.entity.trip.TripLine;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.trip.ITripDao;
import com.hikvision.it.expense.rpc.util.FormUtil;

/**
 * 单据提交后，将差旅行程按天拆分 并存储
 * 
 * <p>Title: TripToDayServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月29日
 *
 */
@Service(value="tripToDayServiceImpl")
public class TripToDayServiceImpl implements IExecuteService {
	@Autowired
	IFormDao formDao;
	@Autowired
	ITripDao tripDao;
	
	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		String docId = process.getDocId();
		String language = UserContext.getLanguage();
		//获取单据抬头
		FormHeader header = formDao.getFormHeader(docId);
		String docType = header.getDocType();
		
		if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM002.name().equalsIgnoreCase(docType)) {
			//先删除历史记录
			tripDao.deleteTripDayByDocNo(header.getDocNo());
			tripDao.deleteTripLineByDocNo(header.getDocNo());
			//获取行程明细
			List<Trip> trips = tripDao.getTrips(process.getDocId(), language);
			if (!ListUtil.isEmpty(trips)) {
				//记录差旅行程段以及每天差旅信息
				this.recordTripLineAndTripDays(header, trips);
//				//记录最近使用城市
//				this.recordUserTripCity(header, trips);
				trips.clear();
			}
		}
	}
	
//	/**
//	 * 保存员工最近使用城市
//	 * @param header
//	 * @param trips
//	 * @return
//	 */
//	private void recordUserTripCity(FormHeader header, List<Trip> trips) {
//		List<TripDays> tripCitys = FormUtil.packageTripDays(header, trips);
//		
//		if (!ListUtil.isEmpty(tripCitys)) {
//			//记录差旅城市
//			tripDao.insertUserTripCity(tripCitys);
//			//只保留最近的20个差旅城市
//			tripDao.deleteTripCityOutOfLatest20s(header.getExpensor());
//			tripCitys.clear();
//		}
//	}
	
	/**
	 * 记录差旅行程段以及每天的差旅明细
	 * @param header
	 * @param trips
	 */
	private void recordTripLineAndTripDays(FormHeader header, List<Trip> trips) {
		//解析获取差旅行程段
		List<TripLine> tripLines = FormUtil.packageTripLine(header, trips);
		
		if (!ListUtil.isEmpty(tripLines)) {
			List<TripDays> tripDays = Lists.newArrayList();

			for (TripLine tripLine : tripLines) {
				this.addTripDays(header, tripLine, tripDays);
			}
			if (!ListUtil.isEmpty(tripLines)) {
				//保存行程记录
				tripDao.insertTripLine(tripLines);
				tripLines.clear();
			}
			if (!ListUtil.isEmpty(tripDays)) {
				//保存每天行程明细
				tripDao.insertTripDays(tripDays);
				tripDays.clear();
			}
		}
	}
	
	/**
	 * 根据起始日期，截止日期，解析行程段，并且添加到每一天行程list中
	 * @param tripLine
	 * @param tripDays
	 */
	private void addTripDays(FormHeader header, TripLine tripLine, List<TripDays> tripDays) {
		List<TripDays> lineTripDays = FormUtil.packageLineTripDays(header, tripLine);
		
		if (!ListUtil.isEmpty(lineTripDays))
			tripDays.addAll(lineTripDays);
	}
}
