package com.hikvision.it.expense.rpc.provider.report;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.report.ForeignCurrencyLoanDetail;
import com.hikvision.it.expense.api.service.report.ILoanService;

@Service(version = Version.VERSION_LATEST)
public class LoanProvider implements ILoanService {

    @Autowired
    ILoanService loanService;

    @Override
    public List<ForeignCurrencyLoanDetail> listForeignCurrencyLoans() {
        return loanService.listForeignCurrencyLoans();
    }
}
