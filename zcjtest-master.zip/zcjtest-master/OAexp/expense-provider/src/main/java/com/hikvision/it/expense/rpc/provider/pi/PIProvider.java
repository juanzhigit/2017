package com.hikvision.it.expense.rpc.provider.pi;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.user.UserBank;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.service.pi.IPiService;

@Service(version= Version.VERSION_LATEST)
public class PIProvider implements IPiService {
	@Autowired
    private IPiService piService;

    @Override
	public List<SelectOpt> getWBSFromSap(String bukrs, String filter) {
		return piService.getWBSFromSap(bukrs, filter);
	}

	@Override
	public BigDecimal getLocalAmount(Date date, BigDecimal amount,
			String currency, String localCurreny) {
		return piService.getLocalAmount(date, amount, currency, localCurreny);
	}

	@Override
	public List<Bsik> getBsik(String userId, String bukrs) {
		return piService.getBsik(userId, bukrs);
	}

	@Override
	public List<UserBank> findUserBankFromSAP(List<UserBank> users) {
		return piService.findUserBankFromSAP(users);
	}

	@Override
	public UserBank synchUserBankFromSAP(UserBank user) {
		return piService.synchUserBankFromSAP(user);
	}


	@Override
	public List<SelectOpt> getBusinessOpportunityFromCRM(String userId, String filter) {
		return piService.getBusinessOpportunityFromCRM(userId, filter);
	}

	@Override
	public List<SelectOpt> getPartnerFromCRM(String userId, String filter) {
		return piService.getPartnerFromCRM(userId, filter);
	}

	@Override
	public List<CashierAudit> synchClearingStatus(List<CashierAudit> list) {
		return piService.synchClearingStatus(list);
	}
}
