package com.hikvision.it.expense.rpc.service.plug;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.flow.FinalApproveConfig;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.service.approver.AgentFilterServiceImpl;

/**
 * 判断流程是否需要到二级审批
 * 
 * 1、首先根据单据信息匹配出当前单据适用的终审配置信息
 * 2、获取当前审批回合直接主管审批环节的员工级别，（授权人、被授权人取级别高的）
 * 	   如果不属于授权审批，直接返回审批人的级别
 *   如果当前审批人属于授权审批，则比较背授权人与授权人的级别，返回较大的级别
 *   如果当前环节属于转发转接，则获取原始直接主管环节的审批人级别，获取逻辑同上
 * 3、如果直接主管审批环节员工已满足终审条件，则流转到判断是否是个人费用、是否含有自定机票环节  TO_FEETYPE
 * 4、不满足终审条件 流转到二级审批环节 TO_B02
 * 
 * <p>Title: JudgeNeedB02ServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月22日
 *
 */
@Service(value="judgeNeedB02Service")
public class JudgeNeedB02ServiceImpl implements IExecutePlugService {
	@Autowired
    IApproverDao approverDao;
	@Autowired
	IFormDao formDao;
	@Autowired
    AgentFilterServiceImpl agentService;
	
	@Override
	public String execute(TaskObject taskObject, String docId) {
		FormHeader header = formDao.getFormHeader(docId);
		//先从审批配置表中读取配置信息，获取逐级审批配置信息
		FinalApproveConfig config = agentService.getFinalApproveConfig(header);
		
		if (config != null ) {
			int grade = config.getGrade();
			// 获取当前审批回合直接主管审批环节的员工级别，（授权人、被授权人取级别高的）
			int directorLv = approverDao.getDirectorGradeLevel(docId);
			// 判断直接主管级别是否在当前级别之上
			if (directorLv >= grade) {
				return "TO_FEETYPE";
			} else {
				return "TO_B02";
			}
		} else {
			return "TO_FEETYPE";
		}
	}
}
