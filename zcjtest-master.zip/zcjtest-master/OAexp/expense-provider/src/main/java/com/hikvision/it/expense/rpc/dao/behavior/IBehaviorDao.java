package com.hikvision.it.expense.rpc.dao.behavior;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.trip.TripDays;

/**
 * 行为dao
 * <p>Title: IBehaviorDao.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月11日
 *
 */
public interface IBehaviorDao {
	/**
	 * 更新选择城市更新时间
	 * @param tripDays
	 * @return
	 */
	int updateSelectTripCityUpTime(@Param("tripDay") TripDays tripDays);
	
	/**
	 * 记录员工选择的差旅城市信息
	 * @param tripDays
	 */
	void recordSelectTripCity(@Param("tripDay") TripDays tripDays);
	
	/**
	 * 记录员工选择的数据
	 * @param opt
	 */
	void recordSelectOpt(@Param("opt") SelectOpt opt);
	
	/**
	 * 获取员工最近使用的城市
	 * @param userId
	 * @param language
	 * @return
	 */
	List<TripCity> findCommonUsedCity(@Param("userId") String userId, 
									  @Param("language") String language);
	
	/**
	 * 根据选择类别获取员工常用选择
	 * @param userId
	 * @param behavior
	 * @return
	 */
	List<SelectOpt> findCommonUserdSelect(@Param("userId") String userId,
										  @Param("behavior") String behavior);
}
