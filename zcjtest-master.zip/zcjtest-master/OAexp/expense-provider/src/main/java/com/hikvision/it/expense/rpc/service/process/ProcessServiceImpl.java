package com.hikvision.it.expense.rpc.service.process;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.flow.ProcessObject;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.ProcessStatusEnum;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.enums.TaskNameEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.process.IProcessService;
import com.hikvision.it.expense.api.service.task.ITaskService;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.dao.process.IProcessDao;
import com.hikvision.it.expense.rpc.dao.task.ITaskDao;
import com.hikvision.it.expense.rpc.message.MessageCache;
import com.hikvision.it.expense.rpc.util.TaskUtil;

@Service
@Primary
public class ProcessServiceImpl implements IProcessService {
	@Autowired
    IProcessDao processDao;
	@Autowired
	ITaskService taskService;
	@Autowired
	ITaskDao taskDao;

	@Override
	@Transactional
	public HikResult<ProcessInstance> createAndStartProcess(String docId, String processObjectId) {
		HikResult<ProcessInstance> rs = new HikResult<ProcessInstance>();
		
		// 获取流程定义信息，根据起始环节启动流程
		ProcessObject processObject = processDao.findProcessObject(processObjectId);
		//获取当前操作人
		LoginUser user = UserContext.get();
		if (user != null && processObject != null) {
			ProcessInstance process = this.genProcessInstance(processObjectId, docId);
			//设置流程创建人
			process.setCreatedBy(user.getUserId());
			process.setCreatedByName(user.getUserName());
			// 保存流程数据到流程主表
			processDao.createProcess(process);
			//启动流程
			this.start(process);
			//设置流程信息返回值
			rs.setData(process);
		} else {
			rs.getErrorMsgs().add(MessageCache.getMessage(MessageCode.MSG_PROCESS_NOT_CONFIG, user.getLanguage()));
		}

		return rs;
	}
	
	/**
	 * 启动流程
	 * @param process
	 * @param processObject
	 */
	private void start(ProcessInstance process) throws ExpenseException {
		// 更新流程状态为已发起
		ProcessStatusEnum start = ProcessStatusEnum.START;
		process.setProcessStatus(start.getKey());
		process.setProcessStatusDesc(start.getDesc());
		process.setUpTime(System.currentTimeMillis());
		int number = processDao.start(process);
		if (number == 0) {
			throw new ExpenseException(ExceptionCode.PROCESS_START_FAILURE);
		}
	}

	/**
	 * 创建流程实体
	 * @param processObjectId
	 * @param docId
	 * @return
	 */
	private ProcessInstance genProcessInstance(String processObjectId, String docId) {
		ProcessInstance process = new ProcessInstance();

		process.setProcessId(StringUtil.getUUID());
		process.setProcessObjectId(processObjectId);
		process.setDocId(docId);
		ProcessStatusEnum status = ProcessStatusEnum.DEFAULT;
		process.setProcessStatus(status.getKey());
		process.setProcessStatusDesc(status.getDesc());
		Long currentTime = System.currentTimeMillis();
		process.setCrTime(currentTime);
		process.setIsCompleted("N");
		process.setVersionRd(1);
		process.setUpTime(currentTime);
		process.setCurrentTime(currentTime);

		return process;
	}

	@Override
	@Transactional
	public HikResult<String> retrackProcess(String processId, String suggest) {
		return this.operateProcess(processId, ResultEnum.RETRACK, suggest);
	}

	@Override
	@Transactional
	public HikResult<String> undoProcess(String processId, String suggest) {
		return this.operateProcess(processId, ResultEnum.UNDO, suggest);
	}
	
	/**
	 * 撤回、撤销流程公共方法
	 * @param processId
	 * @param result
	 * @param suggest
	 */
	private HikResult<String> operateProcess(String processId, ResultEnum result, String suggest) {
		LoginUser user = UserContext.get();
		
		ProcessInstance process = processDao.selectProcess(processId);
		if (process == null)
			throw new ExpenseException(ExceptionCode.PROCESS_NOT_FOUND);
			
		TaskObject taskObject = null;
		if (result.equals(ResultEnum.RETRACK)) {
			taskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), TaskNameEnum.R01.name());
		} else if (result.equals(ResultEnum.UNDO)) {
			taskObject = taskDao.getTaskObjectByName(process.getProcessObjectId(), TaskNameEnum.R02.name());
		}
		if (taskObject == null)
			throw new ExpenseException(ExceptionCode.TASK_NODE_NOT_FOUND);
		//删除未完成环节
		process.setUpTime(System.currentTimeMillis());
		processDao.deleteUnDoneTask(process);
		TaskOwner taskOwner= new TaskOwner();
		taskOwner.setOwner(user.getUserId());
		taskOwner.setOwnerName(user.getUserName());
		TaskInstance task = TaskUtil.packageManuTaskAndProcessOperator(process, taskObject, Lists.newArrayList(taskOwner));
		// 创建撤回环节
		taskDao.insertTaskInstance(task);
		taskDao.insertTaskOwners(task.getOwners());
		// 完成撤回环节审批
		return taskService.completeTask(task.getTaskId(), result, suggest);
	}
}
