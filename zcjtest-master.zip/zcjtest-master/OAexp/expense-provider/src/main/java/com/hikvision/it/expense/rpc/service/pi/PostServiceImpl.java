package com.hikvision.it.expense.rpc.service.pi;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.post.SIZZFI04SYNOUT;
import com.hikvision.it.expense.webservice.client.pi.post.SIZZFI04SYNOUTService;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409.ITHEADER;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409.ITITEM;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409HEADERS;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409ITEMS;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409Response;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409Response.RETURNDATA;
import com.hikvision.it.expense.rpc.dao.voucher.IVoucherDao;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;

/**
 * 过账service
 * <p>Title: PostServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月18日
 *
 */
@Service
public class PostServiceImpl {
	@Value("${system.pi.post.url}")
	private String url;
	@Value("${system.pi.post.namespace}")
	private String nameSpace;
	@Value("${system.pi.post.localpart}")
	private String localPart;
	@Value("${system.pi.user}")
	private String piUser;
	@Value("${system.pi.password}")
	private String piUserPassWord;
	
	@Autowired
    IVoucherDao voucherDao;
	
	/**
	 * 校验预制凭证是否复核凭证规则
	 * @param vouchers
	 * @return
	 */
	public HikResult<RETURNDATA> checkPost(List<Voucher> vouchers) {
		return this.post("C", vouchers);
	}
	
	/**
	 * 凭证过账
	 * @param vouchers
	 * @return
	 */
	public HikResult<RETURNDATA> post(List<Voucher> vouchers) {
		return this.post("P", vouchers);
	}
	
	/**
	 * 实际过账或者凭证校验方法
	 * @param mode
	 * @param vouchers
	 * @return
	 */
	private HikResult<RETURNDATA> post(String mode, List<Voucher> vouchers) {
		HikResult<RETURNDATA> rs = new HikResult<RETURNDATA>();

		//凭证过账
		if (!ListUtil.isEmpty(vouchers))
			this.post(mode, vouchers, rs);
		else 
			rs.getErrorMsgs().add("过账失败，未传入预制凭证信息！");
		
		return rs;
	}
	
	private void post(String mode, List<Voucher> vouchers, HikResult<RETURNDATA> rs) {
		URL wsdlURL = null;
		try {
			wsdlURL = new URL(url);
		} catch (MalformedURLException e) {
			rs.getErrorMsgs().add(e.getMessage());
		}

		if (rs.isSuccess()) {
			Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
			SIZZFI04SYNOUTService ss = new SIZZFI04SYNOUTService(wsdlURL, new QName(nameSpace, localPart));
			SIZZFI04SYNOUT port = ss.getHTTPPort();

			BindingProvider bp = (BindingProvider) port;
			Map<String, Object> context = bp.getRequestContext();
			context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
			context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

			ZZFI0409 params = new ZZFI0409();
			ITHEADER header = new ITHEADER();
			ITITEM item = new ITITEM();

			params.setIMODE(mode);
			List<ZZFI0409HEADERS> headers = header.getItem();
			List<ZZFI0409ITEMS>   items = item.getItem();
			for (Voucher voucher : vouchers) {
				//设置凭证抬头
				headers.add(this.packagePostHeader(voucher.getVoucherHeader()));
				//设置凭证明细
				items.addAll(this.packagePostItems(voucher.getVoucherHeader(), voucher.getVoucherItems()));
			}
			params.setITHEADER(header);
			params.setITITEM(item);

			ZZFI0409Response response = port.zzfi0409(params);

			rs.setData(response.getRETURNDATA());
		}
	}
	
	/**
	 * 封装凭证行项目entity
	 * @param voucherHeader
	 * @param items
	 * @return
	 */
	private List<ZZFI0409ITEMS> packagePostItems(VoucherHeader voucherHeader, List<VoucherItem> items) {
		String kidno = voucherHeader.getDocNo() + "@S009@" + voucherHeader.getUsnam();
		List<ZZFI0409ITEMS> list = Lists.newArrayList();
		
		for (VoucherItem item : items) {
			ZZFI0409ITEMS postItem = new ZZFI0409ITEMS();
			
			String bschl = item.getBschl();
			
			postItem.setBELNR(voucherHeader.getHeaderId());
			postItem.setALLOCNMBR(item.getAllocNmbr());
			postItem.setBLINEDATE(item.getBlineDate());
			postItem.setBSCHL(bschl);
			postItem.setCOPAAUFNR(item.getCopaAufnr());
			postItem.setCOPAZAUFNR(item.getCopaZaufnr());
			postItem.setCOPAKMVKGR(item.getCopaKmvkgr());
			postItem.setCOPAPSPNR(item.getCopaPspnr());
			postItem.setCOPAVKBUR(item.getCopaVkbur());
			postItem.setCOPAVKORG(item.getCopaVkorg());
			postItem.setCOPAWW012(item.getCopaWw012());
			postItem.setCOSTCENTER(item.getCostcenter());
			postItem.setGLACCOUNT(item.getGlAccount());
			postItem.setITEMTEXT(item.getItemText());
			postItem.setITEMNOACC(item.getRn() + "");
			postItem.setORDERID(item.getOrderId());
			postItem.setPMNTBLOCK(item.getPmntBlock());
			postItem.setPMNTTRMS(item.getPmnttrms());
			postItem.setPYMTMETH(item.getPymtMeth());
			postItem.setRSTGR(item.getRstgr());
			postItem.setSPGLIND(item.getSpGlInd());
			postItem.setTAXAMT(item.getTaxAmt());
			postItem.setTAXCODE(item.getTaxCode());
			postItem.setVALUEDATE(item.getValueDate());
			postItem.setWBSELEMENT(item.getWbsElement());
			postItem.setXNEGP(item.getXnegp());
			if (bschl != null) {
				if (bschl.startsWith("2") || bschl.startsWith("3")) {
					postItem.setKIDNO(kidno);
				}
			}
			
			list.add(postItem);
		}
		
		return list;
	}
	
	/**
	 * 封装凭证抬头entity
	 * @param voucherHeader
	 * @return
	 */
	private ZZFI0409HEADERS packagePostHeader(VoucherHeader voucherHeader) {
		ZZFI0409HEADERS header = new ZZFI0409HEADERS();
		
		header.setBELNR(voucherHeader.getHeaderId());
		header.setCOMPCODE(voucherHeader.getBukrs());
		header.setCURRENCY(voucherHeader.getCurrency());
		header.setDOCDATE(voucherHeader.getDocDate());
		header.setDOCTYPE(voucherHeader.getVoucherType());
		header.setHEADERTXT(voucherHeader.getHeaderTxt());
		header.setPSTNGDATE(voucherHeader.getPstngDate());
		header.setREFDOCNO(voucherHeader.getRefDocNo());
		header.setUSNAM(voucherHeader.getUsnam());
		
		return header;
	}
}
