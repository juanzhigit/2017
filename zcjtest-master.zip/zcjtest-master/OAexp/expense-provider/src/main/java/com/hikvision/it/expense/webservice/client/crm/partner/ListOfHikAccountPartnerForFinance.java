
package com.hikvision.it.expense.webservice.client.crm.partner;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ListOfHikAccountPartnerForFinance complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ListOfHikAccountPartnerForFinance"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="HikAccountPartnerForInterface" type="{http://www.siebel.com/xml/HIK%20Account-Partner%20For%20Finance}HikAccountPartnerForInterface" maxOccurs="unbounded" minOccurs="0"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfHikAccountPartnerForFinance", propOrder = {
    "hikAccountPartnerForInterface"
})
public class ListOfHikAccountPartnerForFinance {

    @XmlElement(name = "HikAccountPartnerForInterface")
    protected List<HikAccountPartnerForInterface> hikAccountPartnerForInterface;

    /**
     * Gets the value of the hikAccountPartnerForInterface property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the hikAccountPartnerForInterface property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getHikAccountPartnerForInterface().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link HikAccountPartnerForInterface }
     * 
     * 
     */
    public List<HikAccountPartnerForInterface> getHikAccountPartnerForInterface() {
        if (hikAccountPartnerForInterface == null) {
            hikAccountPartnerForInterface = new ArrayList<HikAccountPartnerForInterface>();
        }
        return this.hikAccountPartnerForInterface;
    }

}
