
package com.hikvision.it.expense.webservice.client.crm.partner;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ListOfHikAccountPartnerForFinanceTopElmt complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ListOfHikAccountPartnerForFinanceTopElmt"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ListOfHikAccountPartnerForFinance" type="{http://www.siebel.com/xml/HIK%20Account-Partner%20For%20Finance}ListOfHikAccountPartnerForFinance"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfHikAccountPartnerForFinanceTopElmt", propOrder = {
    "listOfHikAccountPartnerForFinance"
})
public class ListOfHikAccountPartnerForFinanceTopElmt {

    @XmlElement(name = "ListOfHikAccountPartnerForFinance", required = true)
    protected ListOfHikAccountPartnerForFinance listOfHikAccountPartnerForFinance;

    /**
     * 获取listOfHikAccountPartnerForFinance属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ListOfHikAccountPartnerForFinance }
     *     
     */
    public ListOfHikAccountPartnerForFinance getListOfHikAccountPartnerForFinance() {
        return listOfHikAccountPartnerForFinance;
    }

    /**
     * 设置listOfHikAccountPartnerForFinance属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfHikAccountPartnerForFinance }
     *     
     */
    public void setListOfHikAccountPartnerForFinance(ListOfHikAccountPartnerForFinance value) {
        this.listOfHikAccountPartnerForFinance = value;
    }

}
