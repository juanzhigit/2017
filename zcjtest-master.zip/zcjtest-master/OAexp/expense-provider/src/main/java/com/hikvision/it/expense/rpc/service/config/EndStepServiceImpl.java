package com.hikvision.it.expense.rpc.service.config;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.base.WorkInfo;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.enums.DocStatusEnum;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.TaskNameEnum;
import com.hikvision.it.expense.api.service.execute.IExecuteService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.work.IWorkDao;

/**
 * 结束环节 特殊处理
 * 		更新单据状态（只更新正常流转完成的单据状态、不包含驳回、拒绝、撤回、撤销的单据状态）
 * 		差旅申请生成考勤信息，用于同步到考勤系统
 * 
 * <p>Title: EndStepServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月29日
 *
 */
@Service(value="endStepServiceImpl")
public class EndStepServiceImpl implements IExecuteService {
	@Autowired
	IFormDao formDao;
	@Autowired
	IWorkDao workDao;
	
	@Override
	public void execute(ProcessInstance process, List<TaskInstance> tasks) {
		FormHeader header = formDao.getFormHeader(process.getDocId());
		
		if (!ListUtil.isEmpty(tasks)) {
			TaskInstance task = tasks.get(0);
			//结束环节处理事项
			this.doEndStep(header, task);
		}
	}
	
	/**
	 * 结束环节处理
	 * @param header
	 */
	private void doEndStep(FormHeader header, TaskInstance task) {
		String docId = header.getDocId();
		String docType = header.getDocType();
		String docStatus = header.getDocStatus();

		if (TaskNameEnum.END.name().equalsIgnoreCase(task.getTaskName())) {
			if (DocStatusEnum.S003.name().equalsIgnoreCase(docStatus) ||
					DocStatusEnum.S002.name().equalsIgnoreCase(docStatus) ||
					DocStatusEnum.S005.name().equalsIgnoreCase(docStatus)) {
				docStatus = DocStatusEnum.S004.name();
			}
			//更新单据完成状态以及单据完成时间
			formDao.updateDocStatus(docId, docStatus);
			//如果是差旅申请或者行程变更记录考勤信息
			if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) || 
					DocTypeEnum.WEM002.name().equalsIgnoreCase(docType)) {
				//判断是否存在考勤记录
				WorkInfo workInfo = workDao.getWorkInfoByDocId(docId);
				if (workInfo != null) {
					//存在写入考勤业务表
					int workNum = workDao.getWorkNum(workInfo);
					if (workNum != 0)
						workDao.updateWorkInfo(workInfo);
					else 
						workDao.insertWorkInfo(workInfo);
				}
			}
		}
	}
}
