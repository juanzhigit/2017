package com.hikvision.it.expense.rpc.provider.attachment;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.attachment.Attachment;
import com.hikvision.it.expense.api.service.attachment.IAttachmentService;

@Service(version = Version.VERSION_LATEST)
public class AttachmentProvider implements IAttachmentService {

    @Autowired
    IAttachmentService attachmentService;

    @Override
    public void saveAttach(Attachment attach) {
        attachmentService.saveAttach(attach);
    }

    @Override
    public void deleteAttach(String attachId) {
        attachmentService.deleteAttach(attachId);
    }

    @Override
    public List<Attachment> getAttachByDocId(String docId) {
        return attachmentService.getAttachByDocId(docId);
    }

    @Override
    public Attachment getOne(String attachId) {
        return attachmentService.getOne(attachId);
    }

    @Override
    public Long countAttach(String docId) {
        return attachmentService.countAttach(docId);
    }
}
