package com.hikvision.it.expense.rpc.service.plug;

import java.math.BigDecimal;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.execute.IExecutePlugService;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 判断专业审批
 * 
 * 1、个人费用直接到P02进行专业审批
 * 2、国内、国际差旅如果包含自定机票到P12机票专员审批非自动机票到核高基判断环节
 * 3、其他情况到财务审核
 * 
 * <p>Title: JudgeProfessionalServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="judgeProfessionalServiceImpl")
public class JudgeProfessionalServiceImpl implements IExecutePlugService {
	@Autowired
    IFormDao formDao;
	
	@Override
	public String execute(TaskObject taskObject, String docId) {
		FormHeader header = formDao.getFormHeader(docId);
		
		String docType = header.getDocType();
		BigDecimal amount = header.getAmount();
		//个人费用到专业审批环节
		if (DocTypeEnum.WEM002.name().equalsIgnoreCase(docType) || amount == null || amount.compareTo(BigDecimal.ZERO) == 0) {
			return "TO_END";
		} else if (DocTypeEnum.WEM001.name().equalsIgnoreCase(docType) &&
				!YesOrNoEnum.Y.name().equalsIgnoreCase(header.getLoanFlag())) {
			return "TO_END";
		} else if (DocTypeEnum.WEM008.name().equalsIgnoreCase(docType)) {
			return "TO_P02";
		} else if (DocTypeEnum.WEM006.name().equalsIgnoreCase(docType) ||
				DocTypeEnum.WEM010.name().equalsIgnoreCase(docType)) {
			//国内、国际差旅
			int selfBookingNumber = formDao.countCustomTicketNumbers(docId);
			
			if (selfBookingNumber > 0)	//自定机票需要到机票专员审批
				return "TO_P12";
			else
				return "TO_HGJ";		//转到核高基费用判断
		}
		
		//默认到财务审核环节
		return "TO_F01";
	}
}
