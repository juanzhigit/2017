package com.hikvision.it.expense.rpc.dao.logs;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.flow.MailEntity;
import com.hikvision.it.expense.api.entity.flow.OaTodo;

public interface ISendLogDao {
	/**
	 * 记录oa待办信息
	 * @param oaInfo
	 * @return
	 */
	int recordOaTodoInfo(@Param("oaInfo") OaTodo oaInfo);
	
	/**
	 * 批量记录待办日志信息
	 * @param todos
	 * @return
	 */
	int batchRecordOaTodoInfo(@Param("todos") List<OaTodo> todos);
	
	/**
	 * 记录邮件信息
	 * @param mailInfo
	 * @return
	 */
	int recordMailInfo(@Param("mailInfo") MailEntity mailInfo);
	
	/**
	 * 批量保存邮件日志
	 * @param mailInfos
	 * @return
	 */
	int batchRecordMailInfo(@Param("mailInfos") List<MailEntity> mailInfos);

	/**
	 * 更新oa待办发送状态
	 * @param id
	 * @param status
	 * @return
	 */
	int updateOaTodoSendStatus(@Param("id") String id, @Param("status") String status);
}
