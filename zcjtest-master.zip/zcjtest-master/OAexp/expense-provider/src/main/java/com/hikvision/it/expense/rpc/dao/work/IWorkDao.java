package com.hikvision.it.expense.rpc.dao.work;

import java.sql.SQLException;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.base.WorkInfo;

public interface IWorkDao {
	/**
	 * 根据单据编号获取考勤信息
	 * @param docId
	 * @return
	 * @throws SQLException
	 */
	WorkInfo getWorkInfoByDocId(@Param("docId") String docId);
	
	/**
	 * 获取考勤条目数
	 * @param workInfo
	 * @return
	 */
	int getWorkNum(@Param("workInfo") WorkInfo workInfo);
	
	/**
	 * 新增考勤信息
	 * @param workInfo
	 */
	void insertWorkInfo(@Param("workInfo") WorkInfo workInfo);
	
	/**
	 * 更新考勤信息
	 * @param workInfo
	 */
	void updateWorkInfo(@Param("workInfo") WorkInfo workInfo);
}
