package com.hikvision.it.expense.rpc.provider.user;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.user.SearchUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.service.user.IUserService;

@Service(version= Version.VERSION_LATEST)
public class UserProvider implements IUserService {

    @Autowired
    IUserService userService;

    @Override
    public User findUserByUserShortName(String userShortName, String language) {
        return userService.findUserByUserShortName(userShortName, language);
    }

    @Override
    public List<SelectOpt> findAuthUser(String docType) {
        return userService.findAuthUser(docType);
    }

    @Override
    public List<SearchUser> findUserToAddTripTogether(String filter) {
        return userService.findUserToAddTripTogether(filter);
    }

    @Override
    public String judgeUserFormType(String userId) {
        return userService.judgeUserFormType(userId);
    }
}
