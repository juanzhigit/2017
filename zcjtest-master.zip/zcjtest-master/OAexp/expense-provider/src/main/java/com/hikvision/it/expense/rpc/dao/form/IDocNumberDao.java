package com.hikvision.it.expense.rpc.dao.form;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.flow.DocNumber;

public interface IDocNumberDao {
	/**
	 * 将当前单据编码+1
	 * @param curNumber
	 * @return
	 */
	int increaseCurrentDocNumber(@Param("curNumber") DocNumber curNumber);
	
	/**
	 * 获取当前单据编号
	 * @param year
	 * @param isTemp
	 * @return
	 */
	List<DocNumber> getCurrentDocNumber(@Param("year") int year, 
										@Param("isTemp") String isTemp);
}
