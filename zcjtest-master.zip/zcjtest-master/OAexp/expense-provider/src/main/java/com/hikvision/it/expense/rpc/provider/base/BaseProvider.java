package com.hikvision.it.expense.rpc.provider.base;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.Notice;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.bukrs.Bukrs;
import com.hikvision.it.expense.api.service.base.IBaseService;

@Service(version= Version.VERSION_LATEST)
public class BaseProvider implements IBaseService {
	@Autowired
    IBaseService baseService;

    @Override
    public List<SelectOpt> findSelectCurrency(String userId, String bukrs, String docType) {
        return baseService.findSelectCurrency(userId, bukrs, docType);
    }

    @Override
	public List<SelectOpt> findSelectCurrency(String filter) {
		return baseService.findSelectCurrency(filter);
	}

	@Override
    public List<SelectOpt> findTipTool() {
        return baseService.findTipTool();
    }

    @Override
    public List<TripCity> findTripCity(String filter) {
        return baseService.findTripCity(filter);
    }

    @Override
    public List<TripCity> findHotCity() {
        return baseService.findHotCity();
    }

	@Override
	public Rate getRates(Rate rate) {
		return baseService.getRates(rate);
	}

	@Override
	public List<Notice> listNotices(int pageNumber, int pageSize) {
		return baseService.listNotices(pageNumber, pageSize);
	}

	@Override
	public List<SelectOpt> listCurrencyOpt(String country) {
		return baseService.listCurrencyOpt(country);
	}

    @Override
    public List<SelectOpt> listEntertains() {
        return baseService.listEntertains();
    }

    @Override
    public List<SelectOpt> listEntertainLevels() {
        return baseService.listEntertainLevels();
    }

    @Override
    public String getDeptName(String deptCode) {
        return baseService.getDeptName(deptCode);
    }

    @Override
    public String getBukrsName(String bukrs) {
        return baseService.getBukrsName(bukrs);
    }

    @Override
	public List<SelectOpt> findCityTraficTool() {
		return baseService.findCityTraficTool();
	}

	@Override
	public List<SelectOpt> listExpenseFeeType() {
		return baseService.listExpenseFeeType();
	}

	@Override
	public List<SelectOpt> listTrafficProject(String filter) {
		return baseService.listTrafficProject(filter);
	}

    @Override
    public List<SelectOpt> listGlAccount(String filter) {
        return baseService.listGlAccount(filter);
    }

    @Override
	public List<SelectOpt> listSalesArea(String userId) {
		return baseService.listSalesArea(userId);
	}
	
	/**
	 * 获取公司信息
	 * @return
	 */
	@Override
	public List<SelectOpt> getCompanyInfo(String searchText){
		return baseService.getCompanyInfo(searchText);
	}

	@Override
	public List<SelectOpt> listIndustry() {
		return baseService.listIndustry();
	}

	@Override
	public List<SelectOpt> listExpenseFeeType(String bukrs, String docType, String expenseType) {
		return baseService.listExpenseFeeType(bukrs, docType, expenseType);
	}

	@Override
	public List<TripCity> getStayStandard(String userId, String filter) {
		return baseService.getStayStandard(userId, filter);
	}

	@Override
	public List<Bukrs> listBukrs(String filter) {
		return baseService.listBukrs(filter);
	}

	@Override
	public List<SelectOpt> listLifnr(String filter) {
		return baseService.listLifnr(filter);
	}

	@Override
	public List<SelectOpt> listAdviceSmaFee(String filter) {
		return baseService.listAdviceSmaFee(filter);
	}

	@Override
	public String getExpenseTypeName(String expenseType) {
		return baseService.getExpenseTypeName(expenseType);
	}
}
