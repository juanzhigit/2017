package com.hikvision.it.expense.rpc.util;

/**
 * webservice服务状态
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/5
 * Time: 10:48
 * To change this template use File | Settings | File Templates.
 */
public class WebServiceStatus {
    /** oa待办服务是否可达 */
    public static boolean OA_TODO_WEBSERVICE_REACHABLE = true;
}
