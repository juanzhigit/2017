package com.hikvision.it.expense.rpc.filter.dubbo;

import java.util.Map;

import com.alibaba.dubbo.rpc.Filter;
import com.alibaba.dubbo.rpc.Invocation;
import com.alibaba.dubbo.rpc.Invoker;
import com.alibaba.dubbo.rpc.Result;
import com.alibaba.dubbo.rpc.RpcException;
import com.google.common.base.Strings;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.enums.DeviceEnum;

public class CurrentUserFilter implements Filter {
    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws RpcException {
        Map<String, String> attachments = invocation.getAttachments();
        LoginUser user = new LoginUser();
        user.setUserId(attachments.get("userId"));
        user.setLanguage(attachments.get("language"));
        user.setUserName(attachments.get("userName"));
        user.setNotesId(attachments.get("notesId"));
        user.setSapAccount(attachments.get("sapAccount"));
        String device = attachments.get("device");
        if (!Strings.isNullOrEmpty(device)) {
            user.setDevice(DeviceEnum.valueOf(device));
        }
        UserContext.set(user);
        Result result = invoker.invoke(invocation);
        UserContext.clearContext();
        return result;
    }
}
