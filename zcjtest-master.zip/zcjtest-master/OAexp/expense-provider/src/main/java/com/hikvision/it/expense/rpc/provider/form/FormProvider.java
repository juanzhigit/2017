package com.hikvision.it.expense.rpc.provider.form;

import java.util.List;
import java.util.Map;

import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.AdjustAmountBean;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.history.ApproveHistory;
import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.service.form.IFormService;

@Service(version = Version.VERSION_LATEST)
public class FormProvider implements IFormService {

    @Autowired
    IFormService formService;

    @Override
    public HikResult<String> saveFormInfo(FormInfo form) {
        return formService.saveFormInfo(form);
    }

    @Override
    public HikResult<String> submitFormInfo(FormInfo form) {
        return formService.submitFormInfo(form);
    }

    @Override
    public HikResult<FormInfo> getFormInfo(String docId, String userId) {
        return formService.getFormInfo(docId, userId);
    }

    @Override
    public boolean isReadable(String docId) {
        return formService.isReadable(docId);
    }

    @Override
    public boolean isEditable(String docId) {
        return formService.isEditable(docId);
    }

    @Override
    public HikResult<String> approve(String taskId, String suggest, ResultEnum result, List<TaskReceivor> receivers) {
        return formService.approve(taskId, suggest, result, receivers);
    }

    @Override
    public boolean checkCanEditDoc(FormHeader header) {
        return formService.checkCanEditDoc(header);
    }

    @Override
    public List<ApproveHistory> getApproveHistories(String docId) {
        return formService.getApproveHistories(docId);
    }

    @Override
    public HikResult<String> adjustAmount(AdjustAmountBean adjustBean) {
        return formService.adjustAmount(adjustBean);
    }

    @Override
    public List<OtherReceivor> listOtherReceiver(String docId) {
        return formService.listOtherReceiver(docId);
    }

    @Override
    public void addWorkingHolidays(String docId, List<String> dates) {
        formService.addWorkingHolidays(docId, dates);
    }

    @Override
    public List<HolidayWork> listWorkingHolidays(String docId, String bukrs, String minDate, String maxDate) {
        return formService.listWorkingHolidays(docId, bukrs, minDate, maxDate);
    }

    @Override
    public List<FormHeader> listApplyWithDefaultStatus() {
        return formService.listApplyWithDefaultStatus();
    }

    @Override
    public boolean checkSqpgRel(String userId) {
        return formService.checkSqpgRel(userId);
    }

    @Override
    public HikResult<String> deleteDraftDoc(String docId) {
        return formService.deleteDraftDoc(docId);
    }

    @Override
    public HikResult<String> retrack(String docId, String userId) {
        return formService.retrack(docId, userId);
    }

    @Override
    public HikResult<String> undo(String docId, String userId) {
        return formService.undo(docId, userId);
    }

    @Override
    public HikResult<String> checkTransitApplyByApplyId(String applyid, String applyId) {
        return formService.checkTransitApplyByApplyId(applyid, applyId);
    }

    @Override
    public boolean checkSnjtFee(String userId, String year, String month) {
        return formService.checkSnjtFee(userId, year, month);
    }

    @Override
    public FormHeader getTransitSectionByApplyId(String applyId) {
        return formService.getTransitSectionByApplyId(applyId);
    }

    @Override
    public HikResult<String> applyUndo(String docId, String userId) {
        return formService.applyUndo(docId, userId);
    }

    @Override
    public List<DocumentInfo> getIsUndoOk(String docId, String userId) {
        return formService.getIsUndoOk(docId, userId);
    }

    @Override
    public HikResult<String> updateApplyUndo(String docId, String applyid, String userId) {
        return formService.updateApplyUndo(docId, applyid, userId);
    }

    @Override
    public HikResult<String> saveVendorInvoiceMailAddress(String docId, String mailAddress) {
        return formService.saveVendorInvoiceMailAddress(docId, mailAddress);
    }

    @Override
    public void calculateSubsidy(FormInfo formInfo) {
        formService.calculateSubsidy(formInfo);
    }

    @Override
    public HikResult<String> recordMail(List<VendorFormHeader> lists) {
        return formService.recordMail(lists);
    }

    @Override
    public HikResult<List<VendorFormHeader>> batchSaveVendorInvoiceMailAddress(Map<Integer, String> map)  {
        return formService.batchSaveVendorInvoiceMailAddress(map);
    }
}
