package com.hikvision.it.expense.rpc.service.approver;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.service.execute.ITaskOwnerService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.rpc.dao.approver.IApproverDao;
import com.hikvision.it.expense.rpc.dao.base.IBaseDao;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;

/**
 * 获取会计处理人
 * 
 * 1、根据单据的归属公司获取是否启用代办池
 * 2、启用代办池，根据规则获取会计池中待办数量最少的会计
 * 	    如果是VP的单据需要优先给VP单据对口会计处理
 * 	    如果是借还款的单据需要优先给借还款单据对口会计处理
 * 3、未启用代办池，根据通用审批人查询service查询审批人
 * 
 * <p>Title: FindAccountingServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月23日
 *
 */
@Service(value="findAccountingServiceImpl")
public class FindAccountingServiceImpl implements ITaskOwnerService {
	@Autowired
	FindApproverServiceImpl approverService;
	@Autowired
	IBaseDao baseDao;
	@Autowired
	IFormDao formDao;
	@Autowired
    IApproverDao approverDao;
	
	@Override
	public List<TaskOwner> execute(TaskObject taskObject, String docId) {
		List<TaskOwner> owners = Lists.newArrayList();
		//根据单据所属公司获取待办池启用标识
		String taskPoolFlag = baseDao.getBukrsAccountingPoolPlag(docId);
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(taskPoolFlag)) {
			//启用，获取会计池中所有人员中待办数量最少的人
			FormHeader header = formDao.getFormHeader(docId);
			String docType = header.getDocType();
			String language = UserContext.getLanguage();
			
			if ("M5".equalsIgnoreCase(header.getExpensorGrade())) {
				//获取标识为vp审核专员的人员任务数列表
				owners = approverDao.getVPFinancialApprovers(language);
			} else if (DocTypeEnum.WEM003.name().equalsIgnoreCase(docType) ||
						DocTypeEnum.WEM004.name().equalsIgnoreCase(docType) || 
						!ListUtil.isEmpty(formDao.getLoans(docId))) {
				//获取标识为借还款审核专员的人员任务数列表
				owners = approverDao.getLoanFinancialApprovers(language);
			} else {
				//获取会计池中任务最少的会计
				owners.add(approverDao.findAccountingWithLeastTasks(language));
			}
		} else {
			//未启用，则通过通用审批人查询逻辑查询
			owners = approverService.execute(taskObject, docId);
		}
		
		return owners;
	}
}
