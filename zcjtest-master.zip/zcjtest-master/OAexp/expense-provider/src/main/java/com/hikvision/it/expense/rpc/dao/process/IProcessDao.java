package com.hikvision.it.expense.rpc.dao.process;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.flow.ProcessObject;

public interface IProcessDao {
	/**
	 * 根据流程定义id获取流程定义信息
	 * @param processObjectId
	 * @return
	 */
	ProcessObject findProcessObject(@Param("processObjectId") String processObjectId);

	/**
	 * 创建流程
	 * @param process
	 */
	int createProcess(@Param("process") ProcessInstance process);
	
	/**
	 * 更新流程状态
	 * @param process
	 * @return
	 */
	int start(@Param("process") ProcessInstance process);
	
	/**
	 * 完成流程
	 * @param process
	 * @return
	 */
	int completeProcess(@Param("process") ProcessInstance process);
	
	/**
	 * 更新流程当前处理人信息
	 * @param process
	 * @return
	 */
	int updateProcessOperator(@Param("process") ProcessInstance process);
	
	/**
	 * 根据processId获取流程实例信息
	 * @param processId
	 * @return
	 */
	ProcessInstance selectProcess(@Param("processId") String processId);
	
	/**
	 * 删除流程所有未完成的待办任务
	 * @param process
	 * @return
	 */
	int deleteUnDoneTask(@Param("process") ProcessInstance process);
	
	/**
	 * 替换或者还原单据事由，备注
	 * @param paramMap
	 */
	void updateApplyRemark(@Param("paramMap") Map<String, Object> paramMap);

	/**
	 * 根据单据号获取流程号
	 * @param docId
	 * @return
	 */
	String getProcessIdByDocId(@Param("docId") String docId);

	/**
	 * 根据流程id将回合数+1
	 * @param process
	 * @return
	 */
	int updateProcessVersion_Rd(@Param("process") ProcessInstance process);
}
