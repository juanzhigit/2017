package com.hikvision.it.expense.rpc.util;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.allowance.SubsidyInfo;
import com.hikvision.it.expense.api.entity.allowance.WPOrSXInfo;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.trip.TripLine;
import com.hikvision.it.expense.api.enums.DeductionReasonEnum;
import com.hikvision.it.expense.api.enums.SubsidyTypeEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;

/**
 * 补贴计算util
 * <p>Title: SubsidyCalculateUtil.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月30日
 *
 */
public class CalculateUtil {
//	/**
//	 * 生成误餐补贴费用
//	 * @param allowance
//	 * @param isHYBC
//	 * @param meetingOrTrainingTrip
//	 * @param foodSubsidys
//	 * @param wpInfos
//	 */
//	private static void packageFoodSubsidy(Allowance allowance,
//										   String isHYBC,
//										   boolean meetingOrTrainingTrip,
//										   List<SubsidyInfo> foodSubsidys,
//										   List<WPOrSXInfo> wpInfos) {
//		Date subsidyDate = DateUtil.stringToSQLDate(allowance.getAllowanceDate());
//		
//		SubsidyInfo foodStandard = matchSubsidyStandard(subsidyDate, allowance.getPlaceGrade(), foodSubsidys);
//		AllowanceDetail foodSubsidy = new AllowanceDetail();
//		
//		foodSubsidy.setAllowanceType(SubsidyTypeEnum.FOOD.getCode());
//		foodSubsidy.setAllowanceDate(allowance.getAllowanceDate());
//		//匹配到补贴标准
//		if (foodStandard != null) {
//			foodSubsidy.setAllowanceAmount(foodStandard.getAmount());
//			foodSubsidy.setCurrency(foodStandard.getCurrency());
//			
//			if(YesOrNoEnum.Y.name().equalsIgnoreCase(isHYBC)) {//会议包餐无补贴
//				foodSubsidy.setDeductionAmount(foodSubsidy.getAllowanceAmount());
//				foodSubsidy.setPayAmount(BigDecimal.ZERO);
//				foodSubsidy.setDeductionReason(DeductionReasonEnum.HYBC.name());
//			} else if (meetingOrTrainingTrip) {//一会培训差旅，只有杭州地区有补贴 每天补贴20/CNY
//				if ("330100".equalsIgnoreCase(allowance.getCity())) {
//					foodSubsidy.setAllowanceAmount(BigDecimal.valueOf(20));
//					foodSubsidy.setCurrency("CNY");
//					foodSubsidy.setDeductionReason(DeductionReasonEnum.HYPX.name());
//				}
//			} else {
//				//外派计算差额补贴
//				//匹配补贴日期是否属于外派范围
//				WPOrSXInfo wp = matchExpatriateInfo(subsidyDate, wpInfos);
//				if (wp != null) {//外派差额补贴计算逻辑
//					//获取外派地的伙食补贴标准
//					SubsidyInfo wpPlaceSub = matchSubsidyStandard(subsidyDate, wp.getPlaceGrade(), foodSubsidys);
//					
//				}
//			}
//		} else {
//			foodSubsidy.setAllowanceAmount(BigDecimal.ZERO);
//			foodSubsidy.setPayAmount(BigDecimal.ZERO);
//			foodSubsidy.setDeductionReason(DeductionReasonEnum.NOMATCH.name());
//		}
//		
//		allowance.setHolidayAllance(foodSubsidy);
//	}
	
//	/**
//	 * 计算节假日补贴
//	 * @param allowance
//	 * @param holidayWork
//	 * @param holidaySubsidys
//	 * @param offWeekends
//	 */
//	private static void packageHolidaySubsidy(Allowance allowance, 
//												HolidayWork holidayWork,
//												List<SubsidyInfo> holidaySubsidys,
//												List<Date> offWeekends) {
//		Date fromDate = DateUtil.stringToSQLDate(allowance.getAllowanceDate());
//		
//		//周末
//		if (DateUtil.checkIsWeekend(fromDate) || holidayWork != null) {
//			SubsidyInfo holidaySub = matchSubsidyStandard(fromDate, holidaySubsidys);
//			
//			AllowanceDetail holidaySubsidy = new AllowanceDetail();
//			
//			holidaySubsidy.setAllowanceType(SubsidyTypeEnum.HOLI.getCode());
//			holidaySubsidy.setAllowanceDate(DateUtil.dateToString(fromDate));
//			
//			if (holidaySub != null) {
//				holidaySubsidy.setAllowanceAmount(holidaySub.getAmount());
//				holidaySubsidy.setCurrency(holidaySub.getCurrency());
//				
//				if (holidayWork != null && 
//						YesOrNoEnum.N.name().equalsIgnoreCase(holidayWork.getWorkFlag())) {
//					//节假日未工作
//					holidaySubsidy.setDeductionAmount(holidaySubsidy.getAllowanceAmount());
//					holidaySubsidy.setPayAmount(BigDecimal.ZERO);
//					holidaySubsidy.setDeductionReason(DeductionReasonEnum.HOLIDAY_NO_WORK.name());
//				} else if (checkIsOffWeekend(fromDate, offWeekends)) {
//					//是否调休判断
//					holidaySubsidy.setDeductionAmount(holidaySubsidy.getAllowanceAmount());
//					holidaySubsidy.setPayAmount(BigDecimal.ZERO);
//					holidaySubsidy.setDeductionReason(DeductionReasonEnum.OFF_WEEKEND.name());
//				}
//			} else {
//				holidaySubsidy.setAllowanceAmount(BigDecimal.ZERO);
//				holidaySubsidy.setPayAmount(BigDecimal.ZERO);
//				holidaySubsidy.setDeductionReason(DeductionReasonEnum.NOMATCH.name());
//			}
//			
//			allowance.setHolidayAllance(holidaySubsidy);
//		}
//	}
	
	/**
	 * 匹配节假日工作情况
	 * @param date
	 * @param workDays
	 * @return
	 */
	public static HolidayWork matchHoliday(Date date, List<HolidayWork> workDays) {
		if (ListUtil.isEmpty(workDays))
			return null;
		
		for (HolidayWork work : workDays) {
			//节假日工作判断
			if (date.compareTo(work.getWorkDate()) == 0) {
				return work;
			}
		}
		
		return null;
	}
	
	/**
	 * 校验是否需要发放节假日补贴
	 * @param subsidyDate
	 * @param userId
	 * @param holidayWorks
	 * @param offWeekends		调休列表
	 * @return
	 */
	public static boolean checkNeedPayHolidaySubsidy(String subsidyDate,
			String userId, List<HolidayWork> holidayWorks, List<Date> offWeekends) {
		Date date = DateUtil.stringToSQLDate(subsidyDate);
		
		if ((DateUtil.checkIsWeekend(date) && 
				!checkIsOffWeekend(date, offWeekends)) || 
				isHolidayWork(date, holidayWorks)) {
			//非调休周末或者节假日工作需要发放节假日补贴
			return true;
		}
		
		return false;
	}
	
	/**
	 * 匹配节假日工作情况
	 * @param date
	 * @param holidayWorks
	 * @return
	 */
	public static HolidayWork matchHolidayWork(Date date, List<HolidayWork> holidayWorks) {
		if (!ListUtil.isEmpty(holidayWorks)) {
			for (HolidayWork work : holidayWorks) {
				if (date.compareTo(work.getWorkDate()) == 0) {
					//节假日，并且工作
					return work;
				}
			}
		}
		
		return null;
	}
	
	/**
	 * 校验是否未工作
	 * @param date
	 * @param holidayWorks
	 * @return
	 */
	public static boolean isNoWork(Date date, List<HolidayWork> holidayWorks) {
		if (!ListUtil.isEmpty(holidayWorks)) {
			for (HolidayWork work : holidayWorks) {
				if (date.compareTo(work.getWorkDate()) == 0 && 
						YesOrNoEnum.N.name().equalsIgnoreCase(work.getWorkFlag())) {
					//节假日，并且工作
					return true;
				}
			}
		}
		
		
		return false;
	}
	
	/**
	 * 校验是否节假日工作
	 * @param date
	 * @param holidayWorks
	 * @return
	 */
	private static boolean isHolidayWork(Date date, List<HolidayWork> holidayWorks) {
		if (!ListUtil.isEmpty(holidayWorks)) {
			for (HolidayWork work : holidayWorks) {
				if (date.compareTo(work.getWorkDate()) == 0 && 
						YesOrNoEnum.Y.name().equalsIgnoreCase(work.getWorkFlag())) {
					//节假日，并且工作
					return true;
				}
			}
		}
		
		
		return false;
	}
	
	/**
	 * 校验日期是否属于调休
	 * @param date
	 * @param offWeekends
	 * @return
	 */
	public static boolean checkIsOffWeekend(Date date, List<Date> offWeekends) {
		if (ListUtil.isEmpty(offWeekends))
			return false;
		
		for (Date offWeekend : offWeekends) {
			if (date.compareTo(offWeekend) == 0)
				return true;
		}
		
		return false;
	}
	
	/**
	 * 根据国家城市匹配艰苦补贴标准
	 * @param subsidyDate
	 * @param country
	 * @param city
	 * @param subsidys
	 * @return
	 */
	public static SubsidyInfo matchHardSubsidyStandard(Date subsidyDate, 
													   String country, String city, 
													   List<SubsidyInfo> subsidys) {
		for (SubsidyInfo subsidy : subsidys) {
			if (country.equalsIgnoreCase(subsidy.getCountry()) &&
					subsidyDate.compareTo(subsidy.getValidFrom()) >= 0 && 
					subsidyDate.compareTo(subsidy.getValidTo()) <= 0) {
				if ("CN".equalsIgnoreCase(country)) {
					if (city.equalsIgnoreCase(subsidy.getCity()))
						//国内艰苦补贴需要匹配到城市
						return subsidy;
				} else {
					return subsidy;
				}
			}
		}
		
		return null;
	}
	
	/**
	 * 匹配伙食补贴标准
	 * @param subsidyDate
	 * @param subsidyLevel
	 * @param subsidys
	 * @return
	 */
	public static SubsidyInfo matchSubsidyStandard(Date subsidyDate, 
													String subsidyLevel,
													List<SubsidyInfo> subsidys) {
		for (SubsidyInfo subsidy : subsidys) {
			if (subsidyLevel.equalsIgnoreCase(subsidy.getCityGrade()) &&
					subsidyDate.compareTo(subsidy.getValidFrom()) >= 0 && 
					subsidyDate.compareTo(subsidy.getValidTo()) <= 0) {
				//匹配到适用补贴标准
				return subsidy;
			}
		}
		
		return null;
	}
	
	/**
	 * 匹配补贴日期适用的补贴标准
	 * @param subsidyDate
	 * @param subsidys
	 * @return
	 */
	public static SubsidyInfo matchSubsidyStandard(Date subsidyDate, List<SubsidyInfo> subsidys) {
		for (SubsidyInfo subsidy : subsidys) {
			if (subsidyDate.compareTo(subsidy.getValidFrom()) >= 0 && 
					subsidyDate.compareTo(subsidy.getValidTo()) <= 0) {
				//匹配到适用补贴标准
				return subsidy;
			}
		}
		
		return null;
	}
	
	/**
	 * 匹配外派记录
	 * @param subsidyDate
	 * @param wpInfos
	 * @return
	 */
	public static WPOrSXInfo matchExpatriateInfo(Date subsidyDate, List<WPOrSXInfo> wpInfos) {
		//不存在外派信息，直接返回null
		if (ListUtil.isEmpty(wpInfos)) {
			return null;
		}
		
		for (WPOrSXInfo wp : wpInfos) {
			//匹配到区间内的外派，返回wp
			if (subsidyDate.compareTo(wp.getFromDate()) >= 0 && 
					subsidyDate.compareTo(wp.getEndDate()) <= 0) {
				return wp;
			}
		}
		//默认返回null
		return null;
	}
	
	/**
	 * 判断日期是否在实习或者外派期中
	 * @param date
	 * @param sxList
	 * @return
	 */
	public static boolean isTrainee(Date date, List<WPOrSXInfo> sxList) {
		if (ListUtil.isEmpty(sxList))
			return false;
		
		for (WPOrSXInfo sxInfo : sxList) {
			if (date.compareTo(sxInfo.getFromDate()) >= 0 && 
					date.compareTo(sxInfo.getEndDate()) <= 0) {
				//匹配到适用补贴标准
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * 校验是否超过60天报销，超期无补贴
	 * @param endDate
	 * @param subDate
	 * @return
	 */
	public static boolean checkHasSubsidy(Date endDate, java.util.Date subDate) {
		long days = DateUtil.daysBetween(endDate, subDate);
		
		if (days < 0) {
			throw new ExpenseException(ExceptionCode.EXP_ERROR_TRIP_NOT_END);
		}
		
		if (days <= 60) {//60天内有补贴
			return true;
		} else {//否则无补贴
			return false;
		}
	}
	
	/**
	 * 校验租住补贴是否已付
	 * @param subsidyDate
	 * @param paidAllowances
	 * @return
	 */
	public static boolean checkSubsidyPaid(Date subsidyDate, List<AllowanceDetail> paidAllowances) {
		//不存在已付补贴信息，直接返回false
		if (ListUtil.isEmpty(paidAllowances)) {
			return false;
		}
		
		for (AllowanceDetail allowanceDetail : paidAllowances) {
			//匹配到区间内的补贴信息，返回ture
			if (subsidyDate.compareTo(DateUtil.stringToSQLDate(allowanceDetail.getAllowanceDate())) == 0) {
				return true;
			}
		}
		//默认返回false
		return false;
	}
	
	/**
	 * 生成超期无补贴明细
	 * @param formHeader
	 * @param tripLines
	 * @param allowanceMap
	 */
	public static void packageOutOfDateAllowance(FormHeader formHeader,
										   		 List<TripLine> tripLines,
										   		 Map<String, Allowance> allowanceMap) {
		String userId = formHeader.getExpensor();
		String userName = formHeader.getExpensorName();
		String docId = formHeader.getDocId();
		String docNo = formHeader.getDocNo();
		//解析行程段明细
		for (TripLine tripLine : tripLines) {
			Date fromDate = tripLine.getFromDate();
			Date toDate = tripLine.getToDate();
			String country = tripLine.getTripCountry();
			String city = tripLine.getTripCity();
			
			//开始计算补贴
			while (fromDate.compareTo(toDate) <= 0) {
				String fromDateStr = DateUtil.dateToString(fromDate);
				
				if (!allowanceMap.containsKey(fromDateStr)) {
					Allowance allowance = new Allowance(); 

					allowance.setId(StringUtil.getUUID());
					allowance.setUserId(userId);
					allowance.setUserName(userName);
					allowance.setDocId(docId);
					allowance.setDocNo(docNo);
					allowance.setAllowanceDate(fromDateStr);
					allowance.setCountry(country);
					allowance.setCity(city);
					allowance.setUserState("CQ");
					
					allowanceMap.put(fromDateStr, allowance);
				}
				//起始天数+1
				fromDate = DateUtil.addDay(fromDate);
			}
		}
	}
	
	/**
	 * 计算租住补贴
	 * @param formHeader
	 * @param startDate
	 * @param endDate
	 * @param subsidys
	 * @param sxList
	 * @param wpList
	 * @param paidAllowances
	 * @param rentAllowances
	 */
	public static void calculateRentSubsidy(FormHeader formHeader, 
											Date startDate, Date endDate, 
											List<SubsidyInfo> subsidys,
											List<WPOrSXInfo> sxList,
											List<WPOrSXInfo> wpList,
											List<AllowanceDetail> paidAllowances,
											List<AllowanceDetail> rentAllowances) {
		String subsidyType = SubsidyTypeEnum.RENT.getCode();
		String userId = formHeader.getExpensor();
		String userName = formHeader.getExpensorName();
		String docId = formHeader.getDocId();
		String docNo = formHeader.getDocNo();
		//开始计算补贴
		while (startDate.compareTo(endDate) <= 0) {
			AllowanceDetail allowanceDetail = new AllowanceDetail();
			
			allowanceDetail.setId(StringUtil.getUUID());
			allowanceDetail.setUserId(userId);
			allowanceDetail.setUserName(userName);
			allowanceDetail.setDocId(docId);
			allowanceDetail.setDocNo(docNo);
			allowanceDetail.setAllowanceType(subsidyType);
			allowanceDetail.setAllowanceDate(DateUtil.dateToString(startDate));
			//默认补贴都是0
			allowanceDetail.setAllowanceAmount(BigDecimal.ZERO);
			allowanceDetail.setDeductionAmount(BigDecimal.ZERO);
			allowanceDetail.setPayAmount(BigDecimal.ZERO);
			
			if (!CalculateUtil.isTrainee(startDate, sxList) && 
					CalculateUtil.matchExpatriateInfo(startDate, wpList) == null) {
				//非实习、外派享受租住补贴
				//获取适配的补贴标准
				SubsidyInfo subsidy = CalculateUtil.matchSubsidyStandard(startDate, subsidys);
				if (subsidy != null) {
                    allowanceDetail.setAllowanceAmount(subsidy.getAmount());
                    allowanceDetail.setCurrency(subsidy.getCurrency());
					if (CalculateUtil.checkSubsidyPaid(startDate, paidAllowances)) {//校验已付
						allowanceDetail.setDeductionReason(DeductionReasonEnum.PAID.name());
						allowanceDetail.setDeductionAmount(subsidy.getAmount());
                        allowanceDetail.setPayAmount(BigDecimal.ZERO);
					} else {
                        allowanceDetail.setPayAmount(subsidy.getAmount());
                    }
				} else {
					allowanceDetail.setDeductionReason(DeductionReasonEnum.NOMATCH.name());
				}
			} else {
				//实习、外派期间无租住补贴
				allowanceDetail.setDeductionReason(DeductionReasonEnum.SX_OR_WP_NO_SUBSIDY.name());
			}
			
			//添加到补贴明细list中
			rentAllowances.add(allowanceDetail);
			
			//起始天数+1
			startDate = DateUtil.addDay(startDate);
		}
	}
	
	/**
	 * 生成每天默认补贴汇总entity
	 * @param header
	 * @param subsidyDate
	 */
	public static Allowance packageDefaultAllowance(FormHeader header, String subsidyDate) {
		Allowance allowance = new Allowance();
		
		allowance.setId(StringUtil.getUUID());
		allowance.setAllowanceDate(subsidyDate);
		allowance.setCurrency(header.getCurrency());
		allowance.setUserId(header.getExpensor());
		allowance.setUserName(header.getExpensorName());
		allowance.setDocId(header.getDocId());
		allowance.setDocNo(header.getDocNo());
		
		return allowance;
	}
	
	/**
	 * 生成默认补贴明细
	 * @param subsidyType
	 * @param allowance
	 * @return
	 */
	public static AllowanceDetail packageSubsidy(SubsidyTypeEnum subsidyType, Allowance allowance) {
		AllowanceDetail allowanceDetail = new AllowanceDetail();
		
		allowanceDetail.setId(StringUtil.getUUID());
		allowanceDetail.setUserId(allowance.getUserId());
		allowanceDetail.setUserName(allowance.getUserName());
		allowanceDetail.setDocId(allowance.getDocId());
		allowanceDetail.setDocNo(allowance.getDocNo());
		allowanceDetail.setAllowanceDate(allowance.getAllowanceDate());
		allowanceDetail.setAllowanceType(subsidyType.getCode());
		allowanceDetail.setDeductionReason(DeductionReasonEnum.PAID.name());
		
		return allowanceDetail;
	}
	
	/**
	 * 生成补贴明细
	 * @param subsidyType
	 * @param subsidy
	 * @param subsidyDate
	 * @param rate
	 * @param header
	 * @return
	 */
	public static AllowanceDetail packageSubsidy(SubsidyTypeEnum subsidyType, 
											     SubsidyInfo subsidy, 
											     String subsidyDate,
											     BigDecimal rate,
											     FormHeader header) {
		AllowanceDetail allowanceDetail = new AllowanceDetail();
		
		BigDecimal amount = subsidy.getAmount();
		String currency = subsidy.getCurrency();
		
		allowanceDetail.setId(StringUtil.getUUID());
		allowanceDetail.setUserId(header.getExpensor());
		allowanceDetail.setUserName(header.getExpensorName());
		allowanceDetail.setDocId(header.getDocId());
		allowanceDetail.setDocNo(header.getDocNo());
		allowanceDetail.setAllowanceDate(subsidyDate);
		allowanceDetail.setAllowanceAmount(amount);
		allowanceDetail.setCurrency(currency);
		allowanceDetail.setAllowanceType(subsidyType.getCode());
		allowanceDetail.setRate(rate);
		allowanceDetail.setPayAmount(amount.multiply(rate).setScale(2, BigDecimal.ROUND_HALF_UP));
		
		return allowanceDetail;
	}
	
	/**
	 * 获取每天补贴汇总信息entity
	 * @param subsidyDate
	 * @param formHeader
	 * @param allowanceMap
	 * @return
	 */
	public static Allowance getAllowance(String subsidyDate, 
										 FormHeader formHeader, 
										 Map<String, Allowance> allowanceMap) {
		Allowance allowance = null;
		
		if (!allowanceMap.containsKey(subsidyDate)) {
			//添加默认每天汇总补贴信息到map中
			allowance = CalculateUtil.packageDefaultAllowance(formHeader, subsidyDate);
		} else {
			allowance = allowanceMap.get(subsidyDate);
		}
		
		return allowance;
	}
	
	/**
	 * 匹配里程补贴标准
	 * @param miles
	 * @param mileSubsidys
	 * @return
	 */
	public static SubsidyInfo matchLineSubsidy(BigDecimal miles, List<SubsidyInfo> mileSubsidys) {
		SubsidyInfo mileSubsidy = null;
		
		for (SubsidyInfo subsidy : mileSubsidys) {//循环取最大的补贴金额
			if (miles.compareTo(subsidy.getLineKM()) >= 0) {
				if (mileSubsidy != null) {
					if (mileSubsidy.getAmount().compareTo(subsidy.getAmount()) < 0) {
						mileSubsidy = subsidy;
					}
				} else {
					mileSubsidy = subsidy;
				}
			}
		}
		
		return mileSubsidy;
	}
	
	/**
	 * 生成补贴明细entity
	 * @param subsidyType
	 * @param subsidy
	 * @param subsidyDate
	 * @param rate
	 * @return
	 */
	public static AllowanceDetail packageSubsidy(SubsidyTypeEnum subsidyType, 
											     SubsidyInfo subsidy, 
											     String subsidyDate,
											     BigDecimal rate,
											     Allowance allowance) {
		AllowanceDetail allowanceDetail = new AllowanceDetail();

		BigDecimal amount = BigDecimal.ZERO;
		String currency = "CNY";
		if (subsidy != null) {
            amount = subsidy.getAmount();
            currency = subsidy.getCurrency();
        }

		allowanceDetail.setId(StringUtil.getUUID());
		allowanceDetail.setUserId(allowance.getUserId());
		allowanceDetail.setUserName(allowance.getUserName());
		allowanceDetail.setDocId(allowance.getDocId());
		allowanceDetail.setDocNo(allowance.getDocNo());
		allowanceDetail.setAllowanceDate(subsidyDate);
		allowanceDetail.setAllowanceAmount(amount);
		allowanceDetail.setCurrency(currency);
		allowanceDetail.setAllowanceType(subsidyType.getCode());
		allowanceDetail.setRate(rate);
		allowanceDetail.setPayAmount(amount.multiply(rate).setScale(2, BigDecimal.ROUND_HALF_UP));
		
		return allowanceDetail;
	}
	
	/**
	 * 校验是否是会议培训差旅
	 * @param expenseType
	 * @return
	 */
	public static boolean checkIsMeetingOrTrainTrip(String expenseType) {
		switch (expenseType) {
			case "F2":
				return true;
			case "B2":
				return true;
			case "F3":
				return true;
			case "B3":
				return true;
		}
		
		return false;
	}
	
	/**
	 * 设置金额有效小数位2位
	 * @param amount
	 * @return
	 */
	public static BigDecimal setScale(BigDecimal amount) {
		return amount.setScale(2, BigDecimal.ROUND_HALF_UP);
	}
	
	/**
	 * 将从sap取出的未清数据以及报销系统的在途清帐金额进行汇总，计算未清项总金额以及到期未清项金额
	 * 		
	 * 		从sap取出的未清金额需要去掉报销系统的在途清帐金额
	 * 	
	 * @param list
	 * @param ztWqJe		报销系统在途未清金额
	 * @return
	 */
	public static HikResult<Map<String, BigDecimal>> countWQJEAndDQWQJE(List<Bsik> list, BigDecimal ztWqJe) {
		HikResult<Map<String, BigDecimal>> rs = new HikResult<Map<String,BigDecimal>>();
		Map<String, BigDecimal> countMap = Maps.newHashMap();
		
		Date currentDate = DateUtil.getCurrentSqlDate();
		BigDecimal wqje = BigDecimal.valueOf(0);
		BigDecimal dqWqje = BigDecimal.valueOf(0);
		
		if (!ListUtil.isEmpty(list)) {
			for (Bsik bsik : list) {
				String umskz = bsik.getUmskz();
				//-modify by wuliangxxh1 2014-09-10 未清金额需要去掉备用金的未清项 即特别总账标识为'X'的 Umske特殊总账标识
				if (StringUtil.isEmptyTrim(umskz) || 
						!"X".equalsIgnoreCase(umskz)) {
					wqje = wqje.add(bsik.getDmbtr());
					
					Date zfbdt = DateUtil.stringToSQLDate(bsik.getZfbdt());
					String shkzg = bsik.getShkzg();
					//对于贷方的未清项，每次统计时必须计算到到期未清项中
					if (VoucherConstant.HKZG.equalsIgnoreCase(shkzg) ||
							(zfbdt != null && zfbdt.compareTo(currentDate) <= 0)) {
						dqWqje = dqWqje.add(bsik.getDmbtr());
					}
				}
			}
		}
		
		if (ztWqJe.compareTo(wqje) == 1) {
			rs.getErrorMsgs().add("报销系统在途清帐金额（" + ztWqJe + "）大于SAP未清总金额（" + wqje + "），请联系管理员进行处理！");
		} else {
			if (ztWqJe.compareTo(dqWqje) >= 1) {
				dqWqje = BigDecimal.valueOf(0);
			} else {
				dqWqje = dqWqje.subtract(ztWqJe);
			}
			wqje = wqje.subtract(ztWqJe);
			
			countMap.put(VoucherConstant.WQJE, wqje);
			countMap.put(VoucherConstant.DQWQJE, dqWqje);
			countMap.put(VoucherConstant.ZTWQJE, ztWqJe);
			
			rs.setData(countMap);
		}
		
		return rs;
	}
}
