
package com.hikvision.it.expense.webservice.client.pi.crm;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * <p>ListOfHikOptyAppForOaTopElmt complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="ListOfHikOptyAppForOaTopElmt"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ListOfHikOptyAppForOa" type="{http://www.siebel.com/xml/HIK%20Opty%20App%20For%20OA}ListOfHikOptyAppForOa"/&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "ListOfHikOptyAppForOaTopElmt", propOrder = {
    "listOfHikOptyAppForOa"
})
public class ListOfHikOptyAppForOaTopElmt {

    @XmlElement(name = "ListOfHikOptyAppForOa", required = true)
    protected ListOfHikOptyAppForOa listOfHikOptyAppForOa;

    /**
     * 获取listOfHikOptyAppForOa属性的值。
     * 
     * @return
     *     possible object is
     *     {@link ListOfHikOptyAppForOa }
     *     
     */
    public ListOfHikOptyAppForOa getListOfHikOptyAppForOa() {
        return listOfHikOptyAppForOa;
    }

    /**
     * 设置listOfHikOptyAppForOa属性的值。
     * 
     * @param value
     *     allowed object is
     *     {@link ListOfHikOptyAppForOa }
     *     
     */
    public void setListOfHikOptyAppForOa(ListOfHikOptyAppForOa value) {
        this.listOfHikOptyAppForOa = value;
    }

}
