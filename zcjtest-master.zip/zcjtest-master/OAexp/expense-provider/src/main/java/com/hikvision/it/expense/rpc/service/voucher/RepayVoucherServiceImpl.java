package com.hikvision.it.expense.rpc.service.voucher;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.api.enums.FIOrderStatus;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.rpc.service.pi.BsikServiceImpl;
import com.hikvision.it.expense.rpc.util.CalculateUtil;
import com.hikvision.it.expense.rpc.util.VoucherConstant;

@Service(value="repayVoucherServiceImpl")
public class RepayVoucherServiceImpl extends AbstractVoucherService {
	@Autowired
	BsikServiceImpl bsikService;
	@Autowired
	IVoucherService voucherService;
	
	@Override
	HikResult<List<Voucher>> previewVoucher(FormHeader header, Integer refIndex) {
		HikResult<List<Voucher>> rs = new HikResult<List<Voucher>>();
		List<Voucher> vouchers = Lists.newArrayList();
		
		String userId = header.getExpensor();
		String bukrs = header.getBukrs();
		//获取未清明细
		List<Bsik> bsiks = bsikService.getBsik(userId, bukrs);
		//计算在途未清总额
		BigDecimal ztWqJe = voucherService.countOnlineReim(bukrs, userId).getTotal();
		//根据报销在途以及sap未清明细统计到期未清和未清总金额
		HikResult<Map<String, BigDecimal>> wqRs = CalculateUtil.countWQJEAndDQWQJE(bsiks, ztWqJe);

		if (wqRs.isSuccess()) {
			//获取凭证抬头
			VoucherHeader vouchHeader = getRepayVouchHeader(header , wqRs.getData(), refIndex);
			//获取凭证明细
			VoucherItem debitItem = getRepayDebitVouchDetail(vouchHeader, header, 1);
			VoucherItem creditItem = getRepayCreditVouchDetail(vouchHeader, 2);

			Voucher vouchBean = new Voucher();
			//设置凭证抬头和凭证明细到凭证entity中
			vouchBean.getVoucherItems().add(debitItem);
			vouchBean.getVoucherItems().add(creditItem);
			vouchBean.setVoucherHeader(vouchHeader);

			vouchers.add(vouchBean);

			rs.setData(vouchers);
		} else {
			rs.getErrorMsgs().addAll(wqRs.getErrorMsgs());
		}

		return rs;
	}
	
	/**
	 * 生成凭证抬头
	 * @param formHeader
	 * @param wqMap
	 * @param index
	 * @return
	 */
	private VoucherHeader getRepayVouchHeader(FormHeader formHeader, 
											  Map<String, BigDecimal> wqMap, 
											  int index) {
		VoucherHeader header = new VoucherHeader();		//凭证抬头
		
		// -----凭证抬头-----
  		String userId = formHeader.getExpensor();
  		String currency = formHeader.getCurrency();
  		String docNo = formHeader.getDocNo();
  		BigDecimal amount =  CalculateUtil.setScale(formHeader.getPayAmount());

  		header.setHeaderId(StringUtil.getUUID());
  		header.setAmount(amount);
  		header.setRn(index);
  		header.setBukrs(formHeader.getBukrs());
		header.setCurrency(currency);
		header.setDocId(formHeader.getDocId());
		header.setDocNo(docNo);
		header.setDocDate(DateUtil.getCurrentDateString());	//凭证日期
		header.setRefDocNo(getReference(docNo, index));// 凭证重复创建,值为单据号+序号（“1100000019”+ “01”：110000001901）(At August.07,2014)
		header.setUserId(userId);
		header.setUserName(formHeader.getExpensorName());
		header.setVoucherType(VoucherConstant.DOCTY_AB);
		header.setDqwqAmount(BigDecimal.ZERO);
		// BRTAMOUNT 未清项总金额
  		BigDecimal wqJe = CalculateUtil.setScale(wqMap.get(VoucherConstant.WQJE));
  		header.setBrtAmount(wqJe);	
		header.setClrAmount(amount);
		header.setFiOrderStatus(FIOrderStatus.F001.name());
		String twoLevelDeptName = getFirstTwoLevelDeptName(formHeader.getDeptCode());
		String vouchHeader = formHeader.getExpensorName() + "-还款-" + twoLevelDeptName;
		header.setHeaderTxt(vouchHeader);	//凭证抬头
		
		return header;
	}
	
	/**
	 * 生成还款借方凭证明细信息
	 */
	private VoucherItem getRepayDebitVouchDetail(VoucherHeader voucherHeader, FormHeader header, int lineNo) {
		// AMOUNT 费用总金额
  		BigDecimal amount =  CalculateUtil.setScale(header.getPayAmount());
		//币种
		String currency = header.getCurrency();
		//公司代码
		String bukrs = header.getBukrs();
		//还款方式
		String paymentType = header.getPayType();
		String acctSubj = null;
		String acctSubjNm = null;
		//根据付款方式设置借款的总账科目
		SelectOpt glAccount = null;
		if (StringUtil.isNotEmptyTrim(paymentType) && 
				VoucherConstant.PYMT_M.equalsIgnoreCase(paymentType)) {
			//现金科目
			glAccount = baseDao.findCurrencySubject(currency, UserContext.getLanguage());
		} else {
			//银行存款进行还款 需要根据公司代码以及币种配置表查询相应的科目
			glAccount = baseDao.findBankSubjectByBukrs(bukrs, currency, UserContext.getLanguage());
		}
		if (glAccount == null)
			throw new ExpenseException(ExceptionCode.VOUCH_ERROR_XJ_SUBJECT_NOT_CFG);
		acctSubj = glAccount.getId();	
		//获取科目描述
		acctSubjNm = glAccount.getText();
		// ------借方(debit)凭证信息------
		VoucherItem detailDr = new VoucherItem();
		
		detailDr.setHeaderId(voucherHeader.getHeaderId());
		detailDr.setItemId(StringUtil.getUUID());
		detailDr.setRn(lineNo);
		//研发人员需要设置研发内部订单（人员）
		String orderId = baseDao.findOrderNo(bukrs, header.getDeptCode());
		if(Strings.isNullOrEmpty(orderId)) {
			//设置研发内部订单（人员）
			detailDr.setCopaZaufnr(header.getExpensor());
		}
		// BSCHL 记账码
		detailDr.setBschl(VoucherConstant.BSCHL_40);
		//设置原因代码
		detailDr.setRstgr(VoucherConstant.RSTGR_103);
		// GL_ACCOUNT 总账科目
		detailDr.setGlAccount(acctSubj);
		//科目描述
		detailDr.setGlAccountName(acctSubjNm);
		// TAX_AMT 凭证货币金额
		detailDr.setTaxAmt(amount);
		// BLINE_DATE	到期日计算的基限日期
		detailDr.setBlineDate(DateUtil.getCurrentDateString());
		
		return detailDr;
	}
	
	/**
	 * 生成还款贷方凭证明细
	 * @param formHeader
	 * @param lineNo
	 * @return
	 */
	private VoucherItem getRepayCreditVouchDetail(VoucherHeader voucherHeader, int lineNo) {
		// ------贷方(credit)凭证信息------
		VoucherItem detailBk = new VoucherItem();
		// ITEMNO_ACC 会计凭证行项目编号
		detailBk.setRn(lineNo);
		String drCode = VoucherConstant.BSCHL_39;
		
		detailBk.setHeaderId(voucherHeader.getHeaderId());
		detailBk.setItemId(StringUtil.getUUID());
		// BSCHL 记帐代码
		detailBk.setBschl(drCode);
		// GL_ACCOUNT 总账科目
		detailBk.setGlAccount(voucherHeader.getUserId());
		detailBk.setGlAccountName(voucherHeader.getUserName());
		// AMOUNT 费用总金额
		// TAX_AMT 凭证货币金额
		detailBk.setTaxAmt(CalculateUtil.setScale(voucherHeader.getAmount()));
		// PMNTTRMS 付款条件代码
		String paymentCondition = VoucherConstant.PMNTTRMS_T000;
		detailBk.setPmnttrms(paymentCondition);
		// SP_GL_IND 特别总账标志 O
		detailBk.setSpGlInd(VoucherConstant.SP_GL_O);
		
		return detailBk;
	}
}
