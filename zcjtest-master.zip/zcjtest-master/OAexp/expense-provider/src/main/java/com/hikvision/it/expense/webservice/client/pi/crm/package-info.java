@javax.xml.bind.annotation.XmlSchema(namespace = "http://www.siebel.com/xml/HIK%20Opty%20App%20For%20OA", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.hikvision.it.expense.webservice.client.pi.crm;
