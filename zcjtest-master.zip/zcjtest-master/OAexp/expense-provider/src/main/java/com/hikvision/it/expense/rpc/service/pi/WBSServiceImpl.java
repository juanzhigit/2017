package com.hikvision.it.expense.rpc.service.pi;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.List;
import java.util.Map;

import javax.xml.namespace.QName;
import javax.xml.ws.BindingProvider;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.wbs.SIREIMBURSEGETPOSIDSYNOUT;
import com.hikvision.it.expense.webservice.client.pi.wbs.SIREIMBURSEGETPOSIDSYNOUTService;
import com.hikvision.it.expense.webservice.client.pi.wbs.ZIREIMBURSEGETPOSID;
import com.hikvision.it.expense.webservice.client.pi.wbs.ZIREIMBURSEGETPOSIDResponse;
import com.hikvision.it.expense.webservice.client.pi.wbs.ZSREIMBURSEGETPOSID;
import com.hikvision.it.expense.rpc.util.PIAuthenticator;

/**
 * 查询sap wbs项目信息
 * <p>Title: WBSServiceImpl.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月25日
 *
 */
@Service
public class WBSServiceImpl {
	private Logger logger = LoggerFactory.getLogger(getClass());

	@Value("${system.pi.wbs.url}")
	private String url;
	@Value("${system.pi.wbs.namespace}")
	private String nameSpace;
	@Value("${system.pi.wbs.localpart}")
	private String localPart;
	@Value("${system.pi.user}")
	private String piUser;
	@Value("${system.pi.password}")
	private String piUserPassWord;
	
	/**
	 * 根据公司代码、筛选信息匹配合适的ps项目信息
	 * @param bukrs
	 * @param filter
	 * @return
	 */
	public List<SelectOpt> getWBSFromSap(String bukrs, String filter) {
		URL wsdlURL = null;
        try {
            wsdlURL = new URL(url);
        } catch (MalformedURLException e) {
            e.printStackTrace();
            return null;
        }

        Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
        SIREIMBURSEGETPOSIDSYNOUTService ss = new SIREIMBURSEGETPOSIDSYNOUTService(wsdlURL, new QName(nameSpace, localPart));
        SIREIMBURSEGETPOSIDSYNOUT port = ss.getHTTPPort();

		BindingProvider bp = (BindingProvider) port;
		Map<String, Object> context = bp.getRequestContext();
		context.put(BindingProvider.USERNAME_PROPERTY, StringUtil.decodeStr(piUser));
		context.put(BindingProvider.PASSWORD_PROPERTY, StringUtil.decodeStr(piUserPassWord));

		ZIREIMBURSEGETPOSID param = new ZIREIMBURSEGETPOSID();
        
        param.setIBUKRS(bukrs);
        param.setIPOSTU(filter);
        try {
            //调用pi接口获取wbs信息
        	ZIREIMBURSEGETPOSIDResponse response = port.getPOSID(param);
        	//转换接口返回数据，并且返回下拉选项list
        	return this.transResponseToSelectItem(response);
		} catch (Exception e) {
        	logger.error("get wbs info error", e);
		}
        
        return null;
	}
	
	/**
	 * 解析接口返回结果返回下拉选项列表
	 * @param response
	 * @return
	 */
	private List<SelectOpt> transResponseToSelectItem(ZIREIMBURSEGETPOSIDResponse response) {
		List<ZSREIMBURSEGETPOSID> items = response.getETRETURN().getItem();
		List<SelectOpt> opts = Lists.newArrayList();
		
		SelectOpt opt = new SelectOpt();
		
		opt.setId("无");
		opt.setText("无");
		//添加默认选项
		opts.add(opt);
		if (!ListUtil.isEmpty(items)) {
			for (ZSREIMBURSEGETPOSID item : items) {
				//最多只返回15条数据
				if (opts.size() >= 16) {
					break;
				}
				
				opt = new SelectOpt();
				
				opt.setId(item.getPSPID());
				opt.setText(item.getPOST1());
				
				opts.add(opt);
			}
		}
		
		return opts;
	}
}
