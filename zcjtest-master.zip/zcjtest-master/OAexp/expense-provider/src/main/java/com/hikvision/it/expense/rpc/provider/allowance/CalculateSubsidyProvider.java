package com.hikvision.it.expense.rpc.provider.allowance;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.alibaba.dubbo.config.annotation.Service;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.service.allowance.ICalculateSubsidyService;

@Service(version = Version.VERSION_LATEST)
public class CalculateSubsidyProvider implements ICalculateSubsidyService {

    @Autowired
    private ICalculateSubsidyService calculateSubsidyService;

    @Override
    public void adjustAllowances(List<Allowance> list) {
        calculateSubsidyService.adjustAllowances(list);
    }

    @Override
    public List<Allowance> calculateAllowance(FormHeader formHeader, List<Trip> trips) {
        return calculateSubsidyService.calculateAllowance(formHeader, trips);
    }

    @Override
    public List<AllowanceDetail> calculateRentAllowance(FormHeader formHeader, String fromDate, String toDate) {
        return calculateSubsidyService.calculateRentAllowance(formHeader, fromDate, toDate);
    }

    @Override
    public List<AllowanceDetail> calculateRentAllowance(FormHeader formHeader, List<FeeDetail> stayFees) {
        return calculateSubsidyService.calculateRentAllowance(formHeader, stayFees);
    }

    @Override
    public List<Trip> calculateCityCar(FormHeader formHeader, List<Trip> trips) {
        return calculateSubsidyService.calculateCityCar(formHeader, trips);
    }
}
