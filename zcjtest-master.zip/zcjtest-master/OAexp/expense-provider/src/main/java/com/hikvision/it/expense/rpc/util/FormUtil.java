package com.hikvision.it.expense.rpc.util;

import java.sql.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.entity.trip.TripLine;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;

public class FormUtil {
	/**
	 * 判断是否是会议或培训差旅
	 * @param expenseType
	 * @return
	 */
	public static boolean checkIsMeetingOrTrainingTrip(String expenseType) {
		if ("B2".equalsIgnoreCase(expenseType) ||		//分公司会议差旅
				"F2".equalsIgnoreCase(expenseType) ||	//普通会议差旅
				"B3".equalsIgnoreCase(expenseType) ||	//分公司培训差旅
				"F3".equalsIgnoreCase(expenseType)) {	//普通培训差旅
			return true;
		}
		
		
		return false;
	}
	
	/**
	 * 根据差旅行程生成行程段信息
	 * @param header
	 * @param trips
	 * @return
	 */
	public static List<TripLine> packageTripLine(FormHeader header, List<Trip> trips) {
		List<TripLine> tripLines = Lists.newArrayList();
		
		String docId = header.getDocId();
		String docNo = header.getDocNo();
		String userId = header.getExpensor();
		String userName = header.getExpensorName();

		Date lastFromDate = null;
		Date lastToDate = null;
		int i = 1;
		for (Trip trip : trips) {
			Date curFromDate = DateUtil.stringToSQLDate(trip.getFromDate());
			Date curToDate = DateUtil.stringToSQLDate(trip.getToDate());

			if (i == 1) {
				lastFromDate = curFromDate;
				lastToDate = curToDate;
			} else {
				TripLine tripLine = packageTripLine(trip);

				tripLine.setDocId(docId);
				tripLine.setDocNo(docNo);
				tripLine.setUserId(userId);
				tripLine.setUserName(userName);
				tripLine.setFromDate(lastToDate);
				tripLine.setDays(DateUtil.daysBetween(tripLine.getFromDate(), tripLine.getToDate()) + 1);

				if (i == 2) {
					tripLine.setSubsidyFrom(lastFromDate);
					tripLine.setSubsidyTo(curFromDate);
				} else {
					//第二行以后，补贴计算起始日期需要+1
					Date subsidyFrom = DateUtil.addDay(lastToDate);

					if (curToDate.compareTo(subsidyFrom) >= 0) {
						//判断日期大小
						tripLine.setSubsidyFrom(subsidyFrom);
						if (i == trips.size())
							tripLine.setSubsidyTo(curToDate);
					}
				}
				//将行程段信息添加到行程段列表中
				tripLines.add(tripLine);
			}

			lastFromDate = curFromDate;
			lastToDate = curToDate;

			i++;
		}

		return tripLines;
	}
	
	/**
	 * 根据起始日期，截止日期，解析行程段，返回行程段中每一天行程明细
	 * @param tripLine
	 * @param tripDays
	 */
	public static List<TripDays> packageLineTripDays(FormHeader header, TripLine tripLine) {
		List<TripDays> tripDays = Lists.newArrayList();
		
		Date fromDate = tripLine.getFromDate();
		Date toDate = tripLine.getToDate();
		String docId = header.getDocId();
		String docNo = header.getDocNo();
		String userId = header.getExpensor();
		String userName = header.getExpensorName();

		while (toDate.compareTo(fromDate) >= 0) {
			TripDays tripDay = new TripDays();

			tripDay.setId(StringUtil.getUUID());
			tripDay.setTripDate(fromDate);
			tripDay.setDocId(docId);
			tripDay.setDocNo(docNo);
			tripDay.setUserId(userId);
			tripDay.setUserName(userName);
			tripDay.setTripCountry(tripLine.getTripCountry());
			tripDay.setTripCity(tripLine.getTripCity());
			tripDay.setTripCityDesc(tripLine.getTripCityDesc());

			tripDays.add(tripDay);

			//起始日期+1，设置下一天差旅明细
			fromDate = DateUtil.addDay(fromDate);
		}

		return tripDays;
	}
	
	/**
	 * 解析最近使用城市
	 * @param header
	 * @param trips
	 * @return
	 */
	public static List<TripDays> packageTripDays(FormHeader header, List<Trip> trips) {
		Map<String, TripDays> cityMap = Maps.newHashMap();
		
		String userId = header.getExpensor();
		String userName = header.getExpensorName();
		long upTime = System.currentTimeMillis();

		for (Trip trip : trips) {
			String placeFrom = trip.getPlaceFrom();
			String placeTo = trip.getPlaceTo();

			if (!cityMap.containsKey(placeFrom)) {
				TripDays tripDay = new TripDays();

				tripDay.setId(StringUtil.getUUID());
				tripDay.setUserId(userId);
				tripDay.setUserName(userName);
				tripDay.setTripCountry(trip.getCountryFrom());
				tripDay.setTripCity(placeFrom);
				tripDay.setTripCityDesc(trip.getFromDesc());
				tripDay.setUpTime(upTime);

				cityMap.put(placeFrom, tripDay);
			}
			if (!cityMap.containsKey(placeTo)) {
				TripDays tripDay = new TripDays();

				tripDay.setId(StringUtil.getUUID());
				tripDay.setUserId(userId);
				tripDay.setUserName(userName);
				tripDay.setTripCountry(trip.getCountryTo());
				tripDay.setTripCity(placeTo);
				tripDay.setTripCityDesc(trip.getToDesc());
				tripDay.setUpTime(upTime);

				cityMap.put(placeTo, tripDay);
			}
		}

		if (cityMap.size() > 0) {
			return Lists.newArrayList(cityMap.values());
		}

		return null;
	}
	
	/**
	 * 通用校验是否国际差旅方法
	 * @param trips
	 * @param baseCountry
	 * @return
	 */
	public static boolean checkIsForeignTrip(List<Trip> trips, String baseCountry) {
		if (ListUtil.isEmpty(trips))
			return false;
		
		for (Trip trip : trips) {
            //只要存在非本国的行程则默认为国际差旅
            if (!baseCountry.equalsIgnoreCase(trip.getCountryFrom()) ||
                    !baseCountry.equalsIgnoreCase(trip.getCountryTo())) {
                return true;
            }
            //CN的国际差旅特殊判断，港澳台属于国际差旅
            if ("CN".equalsIgnoreCase(baseCountry)) {
                String hk = "810000";
                String am = "820000";
                String tw = "710000";
                String cityFrom = trip.getPlaceFrom();
                String cityTo = trip.getPlaceTo();
                //港澳台判断
                if ((hk.equalsIgnoreCase(cityFrom) || hk.equalsIgnoreCase(cityTo)) ||
                        (am.equalsIgnoreCase(cityFrom) || am.equalsIgnoreCase(cityTo)) ||
                        (tw.equalsIgnoreCase(cityFrom) || tw.equalsIgnoreCase(cityTo))) {
                    return true;
                }
            }
        }
		
		return false;
	}
	
	/**
	 * 生成差旅行程段信息
	 * @param trip
	 * @return
	 */
	public static TripLine packageTripLine(Trip trip) {
		TripLine tripLine = new TripLine();
		
		tripLine.setId(StringUtil.getUUID());
		tripLine.setTripCity(trip.getPlaceFrom());
		tripLine.setTripCountry(trip.getCountryFrom());
		tripLine.setTripCityDesc(trip.getFromDesc());
		tripLine.setToDate(DateUtil.stringToSQLDate(trip.getFromDate()));
		
		return tripLine;
	}
}
