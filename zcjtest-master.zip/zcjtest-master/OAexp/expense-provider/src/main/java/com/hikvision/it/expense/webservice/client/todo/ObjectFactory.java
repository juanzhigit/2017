
package com.hikvision.it.expense.webservice.client.todo;

import javax.xml.bind.annotation.XmlRegistry;


/**
 * This object contains factory methods for each 
 * Java content interface and Java element interface 
 * generated in the com.hikvision.it.expense.webservice.client.todo package. 
 * <p>An ObjectFactory allows you to programatically 
 * construct new instances of the Java representation 
 * for XML content. The Java representation of XML 
 * content can consist of schema derived interfaces 
 * and classes representing the binding of schema 
 * type definitions, element declarations and model 
 * groups.  Factory methods for each of these are 
 * provided in this class.
 * 
 */
@XmlRegistry
public class ObjectFactory {


    /**
     * Create a new ObjectFactory that can be used to create new instances of schema derived classes for package: com.hikvision.it.expense.webservice.client.todo
     * 
     */
    public ObjectFactory() {
    }

    /**
     * Create an instance of {@link CreateTodoInfoHCM }
     * 
     */
    public CreateTodoInfoHCM createCreateTodoInfoHCM() {
        return new CreateTodoInfoHCM();
    }

    /**
     * Create an instance of {@link CreateTodoInfoHCMResponse }
     * 
     */
    public CreateTodoInfoHCMResponse createCreateTodoInfoHCMResponse() {
        return new CreateTodoInfoHCMResponse();
    }

    /**
     * Create an instance of {@link UpdateTodoInfo }
     * 
     */
    public UpdateTodoInfo createUpdateTodoInfo() {
        return new UpdateTodoInfo();
    }

    /**
     * Create an instance of {@link UpdateTodoInfoResponse }
     * 
     */
    public UpdateTodoInfoResponse createUpdateTodoInfoResponse() {
        return new UpdateTodoInfoResponse();
    }

    /**
     * Create an instance of {@link GetTodoInfoList }
     * 
     */
    public GetTodoInfoList createGetTodoInfoList() {
        return new GetTodoInfoList();
    }

    /**
     * Create an instance of {@link GetTodoInfoListResponse }
     * 
     */
    public GetTodoInfoListResponse createGetTodoInfoListResponse() {
        return new GetTodoInfoListResponse();
    }

    /**
     * Create an instance of {@link GetMyTodoInfoList }
     * 
     */
    public GetMyTodoInfoList createGetMyTodoInfoList() {
        return new GetMyTodoInfoList();
    }

    /**
     * Create an instance of {@link GetMyTodoInfoListResponse }
     * 
     */
    public GetMyTodoInfoListResponse createGetMyTodoInfoListResponse() {
        return new GetMyTodoInfoListResponse();
    }

    /**
     * Create an instance of {@link CreateTodoInfo2 }
     * 
     */
    public CreateTodoInfo2 createCreateTodoInfo2() {
        return new CreateTodoInfo2();
    }

    /**
     * Create an instance of {@link CreateTodoInfo2Response }
     * 
     */
    public CreateTodoInfo2Response createCreateTodoInfo2Response() {
        return new CreateTodoInfo2Response();
    }

    /**
     * Create an instance of {@link CreateTodoInfoPLM }
     * 
     */
    public CreateTodoInfoPLM createCreateTodoInfoPLM() {
        return new CreateTodoInfoPLM();
    }

    /**
     * Create an instance of {@link CreateTodoInfoPLMResponse }
     * 
     */
    public CreateTodoInfoPLMResponse createCreateTodoInfoPLMResponse() {
        return new CreateTodoInfoPLMResponse();
    }

    /**
     * Create an instance of {@link DeleteCurdealer }
     * 
     */
    public DeleteCurdealer createDeleteCurdealer() {
        return new DeleteCurdealer();
    }

    /**
     * Create an instance of {@link DeleteCurdealerResponse }
     * 
     */
    public DeleteCurdealerResponse createDeleteCurdealerResponse() {
        return new DeleteCurdealerResponse();
    }

    /**
     * Create an instance of {@link GetTodoListByDbpath }
     * 
     */
    public GetTodoListByDbpath createGetTodoListByDbpath() {
        return new GetTodoListByDbpath();
    }

    /**
     * Create an instance of {@link GetTodoListByDbpathResponse }
     * 
     */
    public GetTodoListByDbpathResponse createGetTodoListByDbpathResponse() {
        return new GetTodoListByDbpathResponse();
    }

    /**
     * Create an instance of {@link CreateTodoInfo }
     * 
     */
    public CreateTodoInfo createCreateTodoInfo() {
        return new CreateTodoInfo();
    }

    /**
     * Create an instance of {@link CreateTodoInfoResponse }
     * 
     */
    public CreateTodoInfoResponse createCreateTodoInfoResponse() {
        return new CreateTodoInfoResponse();
    }

    /**
     * Create an instance of {@link CreateTodoInfoCRM }
     * 
     */
    public CreateTodoInfoCRM createCreateTodoInfoCRM() {
        return new CreateTodoInfoCRM();
    }

    /**
     * Create an instance of {@link CreateTodoInfoCRMResponse }
     * 
     */
    public CreateTodoInfoCRMResponse createCreateTodoInfoCRMResponse() {
        return new CreateTodoInfoCRMResponse();
    }

    /**
     * Create an instance of {@link TODOSUBMITANCAI }
     * 
     */
    public TODOSUBMITANCAI createTODOSUBMITANCAI() {
        return new TODOSUBMITANCAI();
    }

    /**
     * Create an instance of {@link TODOSUBMITANCAIResponse }
     * 
     */
    public TODOSUBMITANCAIResponse createTODOSUBMITANCAIResponse() {
        return new TODOSUBMITANCAIResponse();
    }

    /**
     * Create an instance of {@link ResetTodoListCurdealer }
     * 
     */
    public ResetTodoListCurdealer createResetTodoListCurdealer() {
        return new ResetTodoListCurdealer();
    }

    /**
     * Create an instance of {@link ResetTodoListCurdealerResponse }
     * 
     */
    public ResetTodoListCurdealerResponse createResetTodoListCurdealerResponse() {
        return new ResetTodoListCurdealerResponse();
    }

    /**
     * Create an instance of {@link GetTodListByEmpid }
     * 
     */
    public GetTodListByEmpid createGetTodListByEmpid() {
        return new GetTodListByEmpid();
    }

    /**
     * Create an instance of {@link GetTodListByEmpidResponse }
     * 
     */
    public GetTodListByEmpidResponse createGetTodListByEmpidResponse() {
        return new GetTodListByEmpidResponse();
    }

    /**
     * Create an instance of {@link ProductManager }
     * 
     */
    public ProductManager createProductManager() {
        return new ProductManager();
    }

    /**
     * Create an instance of {@link ProductManagerResponse }
     * 
     */
    public ProductManagerResponse createProductManagerResponse() {
        return new ProductManagerResponse();
    }

    /**
     * Create an instance of {@link GetTodoStatusTime }
     * 
     */
    public GetTodoStatusTime createGetTodoStatusTime() {
        return new GetTodoStatusTime();
    }

    /**
     * Create an instance of {@link GetTodoStatusTimeResponse }
     * 
     */
    public GetTodoStatusTimeResponse createGetTodoStatusTimeResponse() {
        return new GetTodoStatusTimeResponse();
    }

    /**
     * Create an instance of {@link RefreshCurdealerData }
     * 
     */
    public RefreshCurdealerData createRefreshCurdealerData() {
        return new RefreshCurdealerData();
    }

    /**
     * Create an instance of {@link RefreshCurdealerDataResponse }
     * 
     */
    public RefreshCurdealerDataResponse createRefreshCurdealerDataResponse() {
        return new RefreshCurdealerDataResponse();
    }

    /**
     * Create an instance of {@link GetTodoListByShortName }
     * 
     */
    public GetTodoListByShortName createGetTodoListByShortName() {
        return new GetTodoListByShortName();
    }

    /**
     * Create an instance of {@link GetTodoListByShortNameResponse }
     * 
     */
    public GetTodoListByShortNameResponse createGetTodoListByShortNameResponse() {
        return new GetTodoListByShortNameResponse();
    }

    /**
     * Create an instance of {@link GetTodoListByFlowName }
     * 
     */
    public GetTodoListByFlowName createGetTodoListByFlowName() {
        return new GetTodoListByFlowName();
    }

    /**
     * Create an instance of {@link GetTodoListByFlowNameResponse }
     * 
     */
    public GetTodoListByFlowNameResponse createGetTodoListByFlowNameResponse() {
        return new GetTodoListByFlowNameResponse();
    }

}
