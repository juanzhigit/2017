package com.hikvision.it.expense.rpc.service.voucher;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Primary;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.batch.PayHead;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.entity.voucher.OnLineBsik;
import com.hikvision.it.expense.api.entity.voucher.OnlineBsikSummary;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.task.ITaskService;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409HEADERS;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409ITEMS;
import com.hikvision.it.expense.webservice.client.pi.post.ZZFI0409Response.RETURNDATA;
import com.hikvision.it.expense.rpc.dao.form.IFormDao;
import com.hikvision.it.expense.rpc.dao.voucher.IVoucherDao;
import com.hikvision.it.expense.rpc.service.pi.BsikServiceImpl;
import com.hikvision.it.expense.rpc.service.pi.ClearingServiceImpl;
import com.hikvision.it.expense.rpc.service.pi.PostServiceImpl;
import com.hikvision.it.expense.rpc.service.pi.RateServiceImpl;
import com.hikvision.it.expense.rpc.util.CalculateUtil;
import com.hikvision.it.expense.rpc.util.SpringContextUtil;

@Service
@Primary
public class VoucherServiceImpl implements IVoucherService {
	@Autowired
    IFormDao formDao;
	@Autowired
    IVoucherDao voucherDao;
	@Autowired
	PostServiceImpl postService;
	@Autowired
	RateServiceImpl rateService;
    @Autowired
    BsikServiceImpl bsikService;
    @Autowired
	ClearingServiceImpl clearingService;
    @Autowired
	ITaskService taskService;
	
	@Override
	@Transactional
	public HikResult<List<Voucher>> previewVoucher(String docId) {
		HikResult<List<Voucher>> rs = null;
		
		if (UserContext.get() == null || 
				Strings.isNullOrEmpty(UserContext.get().getSapAccount())) {
			rs = new HikResult<List<Voucher>>();
			
			rs.getErrorMsgs().add("您无权进行当前操作，未获取到SAP账号！");
			
			return rs;
		}
		// 校验是否已过账
		int postedTimes = voucherDao.countDocPostedTimes(docId);
		if (postedTimes == 0) {
			rs = this.preview(docId);
			
			if (rs.isSuccess()) {
				updateVoucher(docId, rs.getData());
			}
		} else {
			rs = new HikResult<List<Voucher>>();
			
			rs.getErrorMsgs().add("当前单据已过账，请不要重复过账！");
		}
		
		return rs;
	}

    @Override
    @Transactional
    public void previewVoucher(String docId, List<Voucher> vouchers) {
        if (UserContext.get() == null || Strings.isNullOrEmpty(UserContext.get().getSapAccount())) {
            throw new ExpenseException("您无权进行当前操作，未获取到SAP账号！");
        }
        // 校验是否已过账
        int postedTimes = voucherDao.countDocPostedTimes(docId);
        if (postedTimes == 0) {
            updateVoucher(docId, vouchers);
        } else {
            throw new ExpenseException("当前单据已过账，请不要重复过账！");
        }
    }

    @Transactional
	private void updateVoucher(String docId, List<Voucher> vouchers) {
		//先删除预制凭证
		voucherDao.deleteTempVoucherItem(docId);
		voucherDao.deleteTempVoucherHeader(docId);
		//保存预制凭证信息
		List<VoucherHeader> headerList = Lists.newArrayList();
		List<VoucherItem> items = Lists.newArrayList();
		//统一保存凭证抬头和明细信息
		for (Voucher voucher : vouchers) {
			VoucherHeader header = voucher.getVoucherHeader();
			List<VoucherItem> curItems = voucher.getVoucherItems();

			if (header != null)
				headerList.add(header);
			if (!ListUtil.isEmpty(curItems))
				items.addAll(curItems);
		}
		if (!ListUtil.isEmpty(headerList))
			voucherDao.insertVoucherHeader(headerList);
		if (!ListUtil.isEmpty(items))
			voucherDao.batchInsertVoucherItem(items);
	}

	/**
	 * 预制凭证生成
	 * @param docId
	 * @return
	 */
	private HikResult<List<Voucher>> preview(String docId) {
		FormHeader header = formDao.getFormHeader(docId);
		
		String docType = header.getDocType();
		AbstractVoucherService voucherService = null;
		HikResult<List<Voucher>> rs = new HikResult<List<Voucher>>();
		List<String> repaymentDocs = null;
		switch (docType) {
			case "WEM001":		//差旅借款
			case "WEM003":		//借款
				voucherService = SpringContextUtil.getBean("loanVoucherServiceImpl", LoanVoucherServiceImpl.class);
				break;
			case "WEM004":		//还款
				voucherService = SpringContextUtil.getBean("repayVoucherServiceImpl", RepayVoucherServiceImpl.class);
				break;
			case "WEM008":		//个人费用
			case "WEM006":		//国内差旅
			case "WEM010":		//国际差旅
			case "WEM011":		//市内派车
			case "WEM012":		//长途派车
				voucherService = SpringContextUtil.getBean("expenseVoucherServiceImpl", ExpenseVoucherServiceImpl.class);
				repaymentDocs = formDao.listRepaymentDocOnline(header.getExpensor());
			default:
				break;
		}
		
		if (voucherService != null) {
			//判断是否存在流程未走完的还款单
			if (ListUtil.isEmpty(repaymentDocs)) {
				//获取冲销次数
				int writeOffTimes = voucherDao.countDocWirteOffTimes(docId);
				//调用具体预制凭证生成service  writeOffTimes需要+1
				rs = voucherService.previewVoucher(header, ++writeOffTimes);
			} else {
				//存在还款单流程未走完，需要先审批还款流程
				StringBuffer msgBuf = new StringBuffer();

				msgBuf.append("还款单(");
				int i = 0;
				for (String docNo : repaymentDocs) {
					if (i != 0) {
						msgBuf.append(",");
					}
					msgBuf.append(docNo);
					i++;
				}
				msgBuf.append(")尚未审批完成，请先审批完还款单，再进行报销单过账！");

				rs.addError(msgBuf.toString());
			}
		} else {
			rs.addError("未知的单据类别，请联系管理员！");
		}
		
		return rs;
	}
	
	@Override
	public HikResult<String> checkPreVoucher(String docId) {
		HikResult<String> rs = new HikResult<String>();
		
		if (UserContext.get() == null || 
				Strings.isNullOrEmpty(UserContext.get().getSapAccount())) {
			rs.getErrorMsgs().add("您无权进行当前操作，未获取到SAP账号！");
			
			return rs;
		}
		
		List<VoucherHeader> voucherHeaders = voucherDao.getTempVoucherHeaderByDocId(docId);
		if (!ListUtil.isEmpty(voucherHeaders)) {
			//获取过账期间
			String postPeriod = DateUtil.dateToString6(Calendar.getInstance().getTime());
			List<Voucher> vouchers = Lists.newArrayList();
			for (VoucherHeader header : voucherHeaders) {
				//设置过账方式，过账期间以及过账人
				header.setAcctMethod("A");
				header.setPostPeriod(postPeriod);
				header.setPstngDate(DateUtil.dateToString(new Date(), "yyyyMMdd"));
				header.setUsnam(UserContext.get().getSapAccount());
				
				List<VoucherItem> items = voucherDao.getTempVoucherItemsByHeaderId(header.getHeaderId());
				
				if (!ListUtil.isEmpty(items)) {
					Voucher voucher = new Voucher();
					
					voucher.setVoucherHeader(header);
					voucher.setVoucherItems(items);
					
					vouchers.add(voucher);
				} else {
					rs.getErrorMsgs().add("未获取到预制凭证行项目信息，请联系管理员！");
				}
			}
			//校验预制凭证
			HikResult<RETURNDATA> postRs = postService.checkPost(vouchers);
			if (postRs.isSuccess()) {
				List<ZZFI0409HEADERS> postedHeaders = postRs.getData().getITHEADER().getItem();
				List<ZZFI0409ITEMS> postedItems = postRs.getData().getITITEM().getItem();
				//更新凭证过账后的凭证信息
				for (VoucherHeader header : voucherHeaders) {
					for (ZZFI0409HEADERS postedHeader : postedHeaders) {
						if (postedHeader.getREFDOCNO().equalsIgnoreCase(header.getRefDocNo())) {
							if ("X".equalsIgnoreCase(postedHeader.getFFLAG())) {
								rs.getErrorMsgs().add(postedHeader.getREFDOCNO() + "凭证校验失败，原因：" + postedHeader.getMSG());
							}
						}
					}
				}
				for (ZZFI0409ITEMS postedItem : postedItems) {
					if ("X".equalsIgnoreCase(postedItem.getFFLAG())) {
						rs.getErrorMsgs().add(postedItem.getBELNR() + "凭证校验失败，原因：" + postedItem.getMSG());
					}
				}
			} else {
				rs.getErrorMsgs().addAll(postRs.getErrorMsgs());
			}
		} else {
			rs.getErrorMsgs().add("未获取到预制凭证抬头信息，请联系管理员！");
		}
		
		return rs;
	}

	@Override
	@Transactional
	public HikResult<String> postVoucher(String docId, boolean manual) {
		HikResult<String> rs = new HikResult<String>();
		
		if (UserContext.get() == null || 
				Strings.isNullOrEmpty(UserContext.get().getSapAccount())) {
			rs.getErrorMsgs().add("您无权进行当前操作，未获取到SAP账号！");
			
			return rs;
		}
		
		List<VoucherHeader> voucherHeaders = voucherDao.getTempVoucherHeaderByDocId(docId);
		if (!ListUtil.isEmpty(voucherHeaders)) {
			//获取过账期间
			String postPeriod = DateUtil.dateToString6(Calendar.getInstance().getTime());
			List<Voucher> vouchers = Lists.newArrayList();
			for (VoucherHeader header : voucherHeaders) {
				//设置过账方式，过账期间以及过账人
				header.setAcctMethod(manual ? "M" : "A");
				header.setPostPeriod(postPeriod);
				header.setPstngDate(DateUtil.dateToString(new Date(), "yyyyMMdd"));
				header.setUsnam(UserContext.get().getSapAccount());
				header.setPstngUserId(UserContext.getUserId());
				
				List<VoucherItem> items = voucherDao.getTempVoucherItemsByHeaderId(header.getHeaderId());
				
				if (!ListUtil.isEmpty(items)) {
					Voucher voucher = new Voucher();
					
					voucher.setVoucherHeader(header);
					voucher.setVoucherItems(items);
					
					vouchers.add(voucher);
				} else {
					rs.getErrorMsgs().add("未获取到预制凭证行项目信息，请联系管理员！");
				}
			}

			if (manual) {
                for (VoucherHeader header : voucherHeaders) {
                    voucherDao.postSuccess(header);
                }
                rs.setData("单据已手动过账");
            } else {
                //凭证过账
                HikResult<RETURNDATA> postRs = postService.post(vouchers);
                if (postRs.isSuccess()) {
                    List<ZZFI0409HEADERS> postedHeaders = postRs.getData().getITHEADER().getItem();
                    List<ZZFI0409ITEMS> postedItems = postRs.getData().getITITEM().getItem();
                    //更新凭证过账后的凭证信息
                    StringBuffer belnrBuf = new StringBuffer();
                    int i = 0;
                    for (VoucherHeader header : voucherHeaders) {
                        for (ZZFI0409HEADERS postedHeader : postedHeaders) {
                            if (postedHeader.getREFDOCNO().equalsIgnoreCase(header.getRefDocNo())) {
                                if ("X".equalsIgnoreCase(postedHeader.getFFLAG())) {
                                    String msg = postedHeader.getMSG();
                                    if (!Strings.isNullOrEmpty(msg)) {
                                        rs.getErrorMsgs().add(postedHeader.getREFDOCNO() + "凭证过账失败，原因：" + msg);
                                    } else {
                                        rs.getErrorMsgs().add(postedHeader.getREFDOCNO() + "凭证过账失败");
                                    }
                                } else {
                                    belnrBuf.append(postedHeader.getPSTNGDATE().substring(0, 4))
                                            .append("-凭证[").append(postedHeader.getMSG())
                                            .append("]已记账到公司代码[")
                                            .append(postedHeader.getCOMPCODE()).append("]");
                                    if (i != 0) {
                                        belnrBuf.append(",");
                                    }
                                    header.setBelnr(postedHeader.getMSG());

                                    voucherDao.postSuccess(header);
                                    i++;
                                }
                            }
                        }
                    }
                    for (ZZFI0409ITEMS postedItem : postedItems) {
                        if ("X".equalsIgnoreCase(postedItem.getFFLAG())) {
                            rs.getErrorMsgs().add(postedItem.getBELNR() +
                                                  "-行项目[" + postedItem.getITEMNOACC() +
                                                  "]" + postedItem.getMSG());
                        }
                    }
                    rs.setData(belnrBuf.toString());
                } else {
                    rs.getErrorMsgs().addAll(postRs.getErrorMsgs());
                }
            }

		} else {
			rs.getErrorMsgs().add("未获取到预制凭证抬头信息，请联系管理员！");
		}
		
		return rs;
	}
	
	/**
	 * 付款确认
	 * @param heads
	 * @return
	 */
	@Override
	@Transactional
	public HikResult<String> paySure(List<PayHead> heads) {
		HikResult<String> rs = new HikResult<String>();
		for (PayHead head : heads) {
			String status = head.getStatus();
			if (!Strings.isNullOrEmpty(status)) {
				if (!status.equalsIgnoreCase("Y")) {
					throw new RuntimeException("付款状态为无效的不能进行付款确认！");
				}
			}
			//1、更新凭证抬头表（Z_WEM_BUS_VOUCH_HEADERS）的状态为'F005',付款状态为'Y'
			voucherDao.updateFkStatus(head.getDocId());
			//2、结束任务信息
			taskService.completeTask(head.getTaskId(), ResultEnum.AGREE, "同意");
		}
		return rs;
	}

	@Override
	public OnlineBsikSummary countOnlineReim(String bukrs, String userId) {
		OnlineBsikSummary summary = new OnlineBsikSummary();
		//获取报销系统在途未清
		List<OnLineBsik> reimBsiks = voucherDao.listReimOnLineBsik(userId, bukrs);
		
		if (!ListUtil.isEmpty(reimBsiks)) {
			for (OnLineBsik ztjeBean : reimBsiks) {
				String drCode = ztjeBean.getDrCode();
				BigDecimal localAmount = rateService.getLocalAmount(
						ztjeBean.getPostDate(), ztjeBean.getAmount(),
						ztjeBean.getCurrency(), ztjeBean.getLocalCurrency());

				if (localAmount != null && StringUtil.isNotEmptyTrim(drCode)) {
					drCode = ztjeBean.getDrCode();

					if ("29".equalsIgnoreCase(drCode)) {
					    summary.add(ztjeBean.getCurrency(), ztjeBean.getAmount().negate());
					    summary.addTotal(localAmount.negate().multiply(ztjeBean.getAmount()).setScale(2, RoundingMode.HALF_UP));
					} else {
					    summary.add(ztjeBean.getCurrency(), ztjeBean.getAmount());
					    summary.addTotal(localAmount.multiply(ztjeBean.getAmount().setScale(2, RoundingMode.HALF_UP)));
					}
				}
			}
		}
		
		return summary;
	}

	@Override
	public HikResult<Map<String, BigDecimal>> countWqje(List<Bsik> bsiks, BigDecimal ztwqje) {
		//根据报销在途以及sap未清明细统计到期未清和未清总金额
		return CalculateUtil.countWQJEAndDQWQJE(bsiks, BigDecimal.ZERO);
	}

    @Override
    public boolean checkAllVoucherPosted(String docId) {
        List<VoucherHeader> list = voucherDao.getVoucherHeaderByDocId(docId);
        return !ListUtil.isEmpty(list) &&
                list.stream().filter(o -> "F001".equals(o.getFiOrderStatus()) || "F002".equals(o.getFiOrderStatus())).count() == 0;
    }

	@Override
	public List<CashierAudit> getDocsToPayment(String docNo, String postUser, String bukrs) {
		LoginUser user = UserContext.get();
		if (null == user) {
			return Lists.newArrayList();
		}
		//获取未清帐的凭证明细
		List<CashierAudit> list = voucherDao.getDocsToPayment(user.getUserId(), docNo, postUser, bukrs);
		if (ListUtil.isEmpty(list)) {
			return Lists.newArrayList();
		}
		//先同步未清帐的明细列表
		List<CashierAudit> rtList = clearingService.synchSAPPaymentStatus(list);
		//获取已清帐list
		List<CashierAudit> clearedList = this.getClearedList(rtList);
		//将清帐状态更新到凭证明细行
		voucherDao.updateVoucherClearingFlag(clearedList);
		//返回可以付款的所有报销单据
		return voucherDao.listItemToPayment(user.getUserId(), docNo, postUser, bukrs);
	}

	/**
	 * 获取已清帐的明细清单
	 * @param rtList
	 * @return
	 */
	private List<CashierAudit> getClearedList(List<CashierAudit> rtList) {
		List<CashierAudit> clearedList = Lists.newArrayList();

		for (CashierAudit item : rtList) {
			if (YesOrNoEnum.Y.name().equalsIgnoreCase(item.getPayStatus())) {
				clearedList.add(item);
			}
		}

		return clearedList;
	}
}
