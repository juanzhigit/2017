package com.hikvision.it.expense.rpc.util;

import java.util.ArrayList;

import com.github.pagehelper.Page;
import com.hikvision.it.expense.api.entity.base.GridData;

/**
 * PageHelper Page转换器
 */
public class PageConverter {

    public static <E> GridData<E> convert(Page<E> info) {
        return new GridData<>(info.getPages(), info.getPageNum(), info.getTotal(), new ArrayList<>(info.getResult()));
    }
}
