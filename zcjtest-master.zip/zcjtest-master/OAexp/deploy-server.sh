#!/bin/bash

#if [ -d "hikvision-provider-0.0.1" ]; then
#    echo 'exist'
#fi

project=$1
webapps=/root/tomcat/webapps

if [ "$project" != "web" -a "$project" != "rpc" ]; then
    echo 'Usage: ./deploy.sh web|rpc'
    exit
fi

process_name=unknown
source_dir=unknown
target_dir=unknown
service_name=unknown
log_file=unknown
if [ ${project} == 'web' ]; then
    process_name=node-expense-web
    source_dir=/root/expense-web
    target_dir=${webapps}/expense-web
    service_name=tomcat-expense-web
    log_file=/root/tomcat/node-expense-web/logs/catalina.out
else
    process_name=node-expense-rpc
    source_dir=/root/expense-rpc
    target_dir=${webapps}/expense-rpc
    service_name=tomcat-rpc
    log_file=/root/tomcat/node-expense-rpc/logs/catalina.out
fi

#find pid and kill
ps -ef | grep ${process_name} | grep -v grep | awk '{print $2}' | xargs kill -9
echo ${process_name}' killed'

#backup webapp directory
rm -rf ${target_dir}-bak
mv ${target_dir} ${target_dir}-bak
cp -R ${source_dir} ${target_dir}
rm -rf ${source_dir}

echo 'restart service'
systemctl start ${service_name}
tail -f ${log_file}
