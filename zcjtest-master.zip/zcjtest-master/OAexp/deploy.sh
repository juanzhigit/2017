#!/bin/bash

profile=$1

dir_common=expense-common
dir_api=expense-api
dir_rpc=expense-provider
dir_web=expense-web
dir_webservice=expense-webservice
profile=unknown
module=unknown
server_ip=10.1.48.183

# 服务器ip配置
prd_rpc_ip=("10.1.46.203")
prd_web_ip=("10.1.46.201" "10.1.46.202")
qas_rpc_ip=("10.1.48.183")
qas_web_ip=("10.1.48.183")
qas_webservice_ip=("10.1.48.184")

function inputProfile() {
	until [ ${profile} == 'qas' -o ${profile} == 'prd' ]
	do
		echo '请选择profile: [qas, prd]'
		read profile
	done
}

function inputModule() {
	until [ ${module} == 'all' -o ${module} == 'rpc' -o ${module} == 'web' -o ${module} == 'webservice' ]
	do
		echo '选择打包模块:[all, rpc, web, webservice]'
		read module
	done
}

function copyRpcToServer() {
    if [ ${profile} == 'qas' ]; then # qas
	    for v in ${qas_rpc_ip[*]}; do
	    	scp -r ${dir_rpc}/target/ExpenseRpc.jar root@${v}:~
	    done
    else #prd
	    for v in ${prd_rpc_ip[*]}; do
	    	scp -r ${dir_rpc}/target/ExpenseRpc.jar root@${v}:~
	    done
    fi
}

function copyWebToServer() {
    if [ ${profile} == 'qas' ]; then # qas
	    for v in ${qas_web_ip[*]}; do
    		scp -r ${dir_web}/target/expense-web-0.0.1 root@${v}:~/expense-web
	    done
    else #prd
	    for v in ${prd_web_ip[*]}; do
    		scp -r ${dir_web}/target/expense-web-0.0.1 root@${v}:~/expense-web
	    done
    fi
}

function copyWebserviceToServer() {
    if [ ${profile} == 'qas' ]; then # qas
	    for v in ${qas_webservice_ip[*]}; do
    		scp -r ${dir_webservice}/target/expense-webservice-0.0.1 root@${v}:~/webservice
	    done
    else #prd
	    for v in ${prd_webservice_ip[*]}; do
    		scp -r ${dir_webservice}/target/expense-webservice-0.0.1 root@${v}:~/webservice
	    done
    fi
}

inputProfile
inputModule

echo '开始打包'

if [ ${module} == 'all' ]; then
	mvn clean install -Dmaven.test.skip=true -P${profile}
	copyWebToServer
	copyRpcToServer
elif [ ${module} == 'rpc' ]; then
	cd ${dir_api}
	mvn clean install -Dmaven.test.skip=true
	cd ../${dir_common}
	mvn clean install -Dmaven.test.skip=true
	cd ../${dir_rpc}
	mvn clean install -Dmaven.test.skip=true
	cd ..
	copyRpcToServer
elif [ ${module} == 'webservice' ]; then
	cd ${dir_api}
	mvn clean install -Dmaven.test.skip=true
	cd ../${dir_common}
	mvn clean install -Dmaven.test.skip=true
	cd ../${dir_webservice}
	mvn clean install -Dmaven.test.skip=true
	cd ..
	copyWebserviceToServer
else
	cd ${dir_api}
	mvn clean install -Dmaven.test.skip=true -P${profile}
    cd ../${dir_common}
	mvn clean install -Dmaven.test.skip=true -P${profile}
	cd ../${dir_web}
	mvn clean install -Dmaven.test.skip=true -P${profile}
	cd ..
	copyWebToServer
fi

echo '请到相应服务器继续操作'
