#!/bin/bash

#if [ -d "hikvision-provider-0.0.1" ]; then
#    echo 'exist'
#fi

project=$1
webapps=/root/tomcat/webapps

if [ "$project" != "webservice"]; then
    echo 'Usage: ./deploy.sh webservice'
    exit
fi

process_name=unknown
source_dir=unknown
target_dir=unknown
service_name=unknown
log_file=unknown
if [ ${project} == 'web' ]; then
    process_name=webservice-node1
    source_dir=/root/webservice
    target_dir=${webapps}/webservice
    service_name=tomcat-ws-node1
    log_file=/root/tomcat/webservice-node1/logs/catalina.out
fi

#find pid and kill
ps -ef | grep ${process_name} | grep -v grep | awk '{print $2}' | xargs kill -9
echo ${process_name}' killed'

#backup webapp directory
rm -rf ${target_dir}-bak
mv ${target_dir} ${target_dir}-bak
cp -R ${source_dir} ${target_dir}
rm -rf ${source_dir}

echo 'restart service'
systemctl start ${service_name}
tail -f ${log_file}
