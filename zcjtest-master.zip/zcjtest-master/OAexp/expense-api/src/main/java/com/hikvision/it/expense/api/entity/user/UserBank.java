package com.hikvision.it.expense.api.entity.user;

import java.io.Serializable;

/**
 * 员工银行信息
 * <p>Title: UserBank.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月21日
 *
 */
public class UserBank implements Serializable {
	private static final long serialVersionUID = 4788222500998553127L;
	private String bukrs;		//公司代码
	private String lifnr;		//员工编号
	private String bankL;		//银行编号
	private String bankA;		//银行名称
	private String bankN;		//银行帐户号码
	private String name1;		//NAME1 名称

    private String deptPath;    // 部门路径

	public UserBank() {}

	public UserBank(String lifnr, String bukrs) {
		this.lifnr = lifnr;
		this.bukrs = bukrs;
	}

	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getLifnr() {
		return lifnr;
	}
	public void setLifnr(String lifnr) {
		this.lifnr = lifnr;
	}
	public String getBankL() {
		return bankL;
	}
	public void setBankL(String bankL) {
		this.bankL = bankL;
	}
	public String getBankA() {
		return bankA;
	}
	public void setBankA(String bankA) {
		this.bankA = bankA;
	}
	public String getBankN() {
		return bankN;
	}
	public void setBankN(String bankN) {
		this.bankN = bankN;
	}
	public String getName1() {
		return name1;
	}
	public void setName1(String name1) {
		this.name1 = name1;
	}

    public String getDeptPath() {
        return deptPath;
    }

    public void setDeptPath(String deptPath) {
        this.deptPath = deptPath;
    }
}
