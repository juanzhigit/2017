package com.hikvision.it.expense.api.entity.bukrs;

import java.io.Serializable;
import java.math.BigDecimal;

public class Bukrs implements Serializable {
	private static final long serialVersionUID = 2123574422214560332L;
	
	private String bukrs;						//公司代码
	private String bukrsName;					//公司名称
	private String shortName;					//简称
	private String defaultPayCur;				//默认付款币别
	private String status;						//公司状态 0：删除  1：正常
	private String sapFlag;						//是否启用sap
	private BigDecimal perMile;					//里程补贴标准，根据各国家里程度量单位配置
	private String taxCode;						//税码
	private String payMethod;					//付款方式
	private String baseCountry;					//公司所在国家
	private String agentMailAddress;			//国内旅行社邮箱地址
	private String imageFlag;					//是否启用影像
	private String nationalAgentMailAddress;	//国际旅行社邮箱地址
	private String oaBukrsName;					//oa公司名称
	
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getBukrsName() {
		return bukrsName;
	}
	public void setBukrsName(String bukrsName) {
		this.bukrsName = bukrsName;
	}
	public String getShortName() {
		return shortName;
	}
	public void setShortName(String shortName) {
		this.shortName = shortName;
	}
	public String getDefaultPayCur() {
		return defaultPayCur;
	}
	public void setDefaultPayCur(String defaultPayCur) {
		this.defaultPayCur = defaultPayCur;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getSapFlag() {
		return sapFlag;
	}
	public void setSapFlag(String sapFlag) {
		this.sapFlag = sapFlag;
	}
	public BigDecimal getPerMile() {
		return perMile;
	}
	public void setPerMile(BigDecimal perMile) {
		this.perMile = perMile;
	}
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getPayMethod() {
		return payMethod;
	}
	public void setPayMethod(String payMethod) {
		this.payMethod = payMethod;
	}
	public String getBaseCountry() {
		return baseCountry;
	}
	public void setBaseCountry(String baseCountry) {
		this.baseCountry = baseCountry;
	}
	public String getAgentMailAddress() {
		return agentMailAddress;
	}
	public void setAgentMailAddress(String agentMailAddress) {
		this.agentMailAddress = agentMailAddress;
	}
	public String getImageFlag() {
		return imageFlag;
	}
	public void setImageFlag(String imageFlag) {
		this.imageFlag = imageFlag;
	}
	public String getNationalAgentMailAddress() {
		return nationalAgentMailAddress;
	}
	public void setNationalAgentMailAddress(String nationalAgentMailAddress) {
		this.nationalAgentMailAddress = nationalAgentMailAddress;
	}
	public String getOaBukrsName() {
		return oaBukrsName;
	}
	public void setOaBukrsName(String oaBukrsName) {
		this.oaBukrsName = oaBukrsName;
	}
}
