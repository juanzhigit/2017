package com.hikvision.it.expense.api.entity.allowance;

import java.io.Serializable;
import java.sql.Date;

/**
 * 外派信息
 * <p>Title: ExpatriateInfo.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月30日
 *
 */
public class WPOrSXInfo implements Serializable {
	private static final long serialVersionUID = -6636702226109664301L;
	
	private String userId;		//员工编号
	private Date fromDate;		//外派起始日期
	private Date endDate;		//外派截止日期
	private String country;		//外派国家
	private String city;		//外派城市
	private String placeGrade;	//外派地补贴级别
	
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPlaceGrade() {
		return placeGrade;
	}
	public void setPlaceGrade(String placeGrade) {
		this.placeGrade = placeGrade;
	}
}
