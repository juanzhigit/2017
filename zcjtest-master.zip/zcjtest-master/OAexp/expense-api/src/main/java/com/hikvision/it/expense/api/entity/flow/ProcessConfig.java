package com.hikvision.it.expense.api.entity.flow;

import java.io.Serializable;

public class ProcessConfig implements Serializable {
	private static final long serialVersionUID = -8006580020971990643L;
	
	private String processObjectId;
	private String bukrs;
	private String deptCode;
	private String expenseType;
	public String getProcessObjectId() {
		return processObjectId;
	}
	public void setProcessObjectId(String processObjectId) {
		this.processObjectId = processObjectId;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
}
