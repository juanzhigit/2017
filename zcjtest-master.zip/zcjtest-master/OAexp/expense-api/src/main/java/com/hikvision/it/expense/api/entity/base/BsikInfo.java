package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.hikvision.it.expense.api.entity.voucher.OnlineBsikSummary;

/**
 * 未清统计信息entity
 * <p>Title: BsikInfo.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月11日
 *
 */
public class BsikInfo implements Serializable {
	private static final long serialVersionUID = 6435767707596496783L;
	private BigDecimal bsikAmount;				//总未清金额
	private BigDecimal onlineBsikAmount;		//在途未清金额
	private OnlineBsikSummary onlineBsikSummary;//在途未清金额(按币别汇总)
	private List<Bsik> bsiks;					//sap未清明细
	
	public BigDecimal getBsikAmount() {
		return bsikAmount;
	}
	public void setBsikAmount(BigDecimal bsikAmount) {
		this.bsikAmount = bsikAmount;
	}
	public BigDecimal getOnlineBsikAmount() {
		return onlineBsikAmount;
	}
	public void setOnlineBsikAmount(BigDecimal onlineBsikAmount) {
		this.onlineBsikAmount = onlineBsikAmount;
	}

	public OnlineBsikSummary getOnlineBsikSummary() {
		return onlineBsikSummary;
	}

	public void setOnlineBsikSummary(OnlineBsikSummary onlineBsikSummary) {
		this.onlineBsikSummary = onlineBsikSummary;
	}

	public List<Bsik> getBsiks() {
		return bsiks;
	}
	public void setBsiks(List<Bsik> bsiks) {
		this.bsiks = bsiks;
	}
}
