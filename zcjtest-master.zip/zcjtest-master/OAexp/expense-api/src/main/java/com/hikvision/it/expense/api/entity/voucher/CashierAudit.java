package com.hikvision.it.expense.api.entity.voucher;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 出纳付款entity
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/5/27
 * Time: 16:09
 * To change this template use File | Settings | File Templates.
 */
public class CashierAudit implements Serializable {
    private static final long serialVersionUID = 6997288545425012253L;
    /** 任务id */
    private String taskId;
    /** 单据编号 */
    private String docId;
    /** 申请单号 */
    private String docNo;
    /** 过账会计姓名 */
    private String postUserName;
    /** 报销人 */
    private String expensor;
    /** 报销人姓名 */
    private String expensorName;
    /** 费用归属公司 */
    private String bukrs;
    /** 公司名称 */
    private String bukrsName;
    /** 会计凭证编号 */
    private String belnr;
    /** 凭证行项目编号 */
    private String voucherItemId;
    /** 凭证行项目号 */
    private String lineNo;
    /** 会计年度 */
    private String gjahr;
    /** 过账日期 */
    private String postDate;
    /** 过账币别 */
    private String currency;
    /** 付款状态 */
    private String payStatus;
    /** 过账金额 */
    private BigDecimal amount;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    public String getPostUserName() {
        return postUserName;
    }

    public void setPostUserName(String postUserName) {
        this.postUserName = postUserName;
    }

    public String getExpensor() {
        return expensor;
    }

    public void setExpensor(String expensor) {
        this.expensor = expensor;
    }

    public String getExpensorName() {
        return expensorName;
    }

    public void setExpensorName(String expensorName) {
        this.expensorName = expensorName;
    }

    public String getBukrs() {
        return bukrs;
    }

    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }

    public String getBukrsName() {
        return bukrsName;
    }

    public void setBukrsName(String bukrsName) {
        this.bukrsName = bukrsName;
    }

    public String getBelnr() {
        return belnr;
    }

    public void setBelnr(String belnr) {
        this.belnr = belnr;
    }

    public String getGjahr() {
        return gjahr;
    }

    public void setGjahr(String gjahr) {
        this.gjahr = gjahr;
    }

    public String getPostDate() {
        return postDate;
    }

    public void setPostDate(String postDate) {
        this.postDate = postDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getLineNo() {
        return lineNo;
    }

    public String getVoucherItemId() {
        return voucherItemId;
    }

    public void setVoucherItemId(String voucherItemId) {
        this.voucherItemId = voucherItemId;
    }

    public String getPayStatus() {
        return payStatus;
    }

    public void setPayStatus(String payStatus) {
        this.payStatus = payStatus;
    }

    public void setLineNo(String lineNo) {
        this.lineNo = lineNo;
    }
}
