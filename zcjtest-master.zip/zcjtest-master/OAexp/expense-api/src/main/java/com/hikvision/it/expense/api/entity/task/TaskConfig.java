package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;

public class TaskConfig implements Serializable {
	private static final long serialVersionUID = -9150222119725336534L;

	private String processObjectId;		//流程编码
	private String taskName;			//任务名称
	private String msgType;				//消息类型
	private String serviceName;			//服务名称
	
	public String getProcessObjectId() {
		return processObjectId;
	}
	public void setProcessObjectId(String processObjectId) {
		this.processObjectId = processObjectId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getMsgType() {
		return msgType;
	}
	public void setMsgType(String msgType) {
		this.msgType = msgType;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
