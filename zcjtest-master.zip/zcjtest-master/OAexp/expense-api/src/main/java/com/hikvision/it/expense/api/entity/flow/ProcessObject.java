package com.hikvision.it.expense.api.entity.flow;

import java.io.Serializable;

public class ProcessObject implements Serializable {
	private static final long serialVersionUID = -8326076889112772387L;
	
	private String processObjectId;			//流程定义编号
	private String processType;				//流程大类
	private String subType;					//流程小类
	private String processName;				//流程名称
	private String status;					//是否启用
	private String startUp;					//启动环节名称
	private String isTimer;				//是否实时流程
	
	public String getProcessObjectId() {
		return processObjectId;
	}
	public void setProcessObjectId(String processObjectId) {
		this.processObjectId = processObjectId;
	}
	public String getProcessType() {
		return processType;
	}
	public void setProcessType(String processType) {
		this.processType = processType;
	}
	public String getSubType() {
		return subType;
	}
	public void setSubType(String subType) {
		this.subType = subType;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getStartUp() {
		return startUp;
	}
	public void setStartUp(String startUp) {
		this.startUp = startUp;
	}
	public String getIsTimer() {
		return isTimer;
	}
	public void setIsTimer(String isTimer) {
		this.isTimer = isTimer;
	}
}
