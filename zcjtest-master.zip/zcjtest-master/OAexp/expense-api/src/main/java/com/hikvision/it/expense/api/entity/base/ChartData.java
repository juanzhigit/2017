package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 图形展示数据公共实体
 * <p>Title: ChartData.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月19日
 *
 */
public class ChartData implements Serializable {
	private static final long serialVersionUID = -7157384908098983967L;
	
	private String feeType;			//费用类别
	private String feeTypeName;		//费用类别描述
	private BigDecimal amount;		//金额
	
	public String getFeeType() {
		return feeType;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public String getFeeTypeName() {
		return feeTypeName;
	}
	public void setFeeTypeName(String feeTypeName) {
		this.feeTypeName = feeTypeName;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
}
