package com.hikvision.it.expense.api.entity.voucher;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 凭证行项目entity
 * <p>Title: VoucherItem.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class VoucherItem implements Serializable {
	private static final long serialVersionUID = 9096759854617965876L;

	private String itemId; 				// 行项目唯一编号
	private String headerId; 			// 凭证抬头唯一编号

	private Integer rn; 				// 行项目序列
	private String bschl; 				// 记帐代码
	private String glAccount; 			// 总账科目
	private String glAccountName; 		// 总账科目名称
	private String spGlInd; 			// 特殊总分类帐标志
	private BigDecimal taxAmt; 			// 凭证货币金额
	private String taxCode; 			// 销售/购买税代码
	private String costcenter; 			// 成本中心
	private String orderId; 			// 订单号
	private String wbsElement; 			// 工作分解结构元素 (WBS 元素) hidden
	private String allocNmbr; 			// 分配号
	private String itemText; 			// 项目文本
	private String rstgr; 				// 付款原因代码
	private String xnegp; 				// 标识: 反记帐 hidden
	private String valueDate;			// 起息日
	private String blineDate;			// 到期日计算的基限日期
	private String pymtMeth; 			// 收付方式
	private String pmnttrms; 			// 付款条件代码

	private String pmntBlock; 			// 收付冻结码
	private String copaVkorg; 			// 销售机构
	private String copaVkbur; 			// 销售部门
	private String copaKmvkgr; 			// 销售组

	private String copaWw012; 			// 实际部门
	private String copaZaufnr; 			// 研发内部订单（人员） hidden
	private String copaAufnr; 			// 订单号 hidden
	private String copaPspnr; 			// 获利能力段-WBS
	private String kidNo; 				// 付款参考 hidden

	private String fflag; 				// 状态标识 hidden
	private String msg; 				// 消息返回 hidden
	
	public String getItemId() {
		return itemId;
	}
	public void setItemId(String itemId) {
		this.itemId = itemId;
	}
	public String getHeaderId() {
		return headerId;
	}
	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}
	public Integer getRn() {
		return rn;
	}
	public void setRn(Integer rn) {
		this.rn = rn;
	}
	public String getBschl() {
		return bschl;
	}
	public void setBschl(String bschl) {
		this.bschl = bschl;
	}
	public String getGlAccount() {
		return glAccount;
	}
	public void setGlAccount(String glAccount) {
		this.glAccount = glAccount;
	}
	public String getGlAccountName() {
		return glAccountName;
	}
	public void setGlAccountName(String glAccountName) {
		this.glAccountName = glAccountName;
	}
	public String getSpGlInd() {
		return spGlInd;
	}
	public void setSpGlInd(String spGlInd) {
		this.spGlInd = spGlInd;
	}
	public BigDecimal getTaxAmt() {
		return taxAmt;
	}
	public void setTaxAmt(BigDecimal taxAmt) {
		this.taxAmt = taxAmt;
	}
	public String getTaxCode() {
		return taxCode;
	}
	public void setTaxCode(String taxCode) {
		this.taxCode = taxCode;
	}
	public String getCostcenter() {
		return costcenter;
	}
	public void setCostcenter(String costcenter) {
		this.costcenter = costcenter;
	}
	public String getOrderId() {
		return orderId;
	}
	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}
	public String getWbsElement() {
		return wbsElement;
	}
	public void setWbsElement(String wbsElement) {
		this.wbsElement = wbsElement;
	}
	public String getAllocNmbr() {
		return allocNmbr;
	}
	public void setAllocNmbr(String allocNmbr) {
		this.allocNmbr = allocNmbr;
	}
	public String getItemText() {
		return itemText;
	}
	public void setItemText(String itemText) {
		this.itemText = itemText;
	}
	public String getRstgr() {
		return rstgr;
	}
	public void setRstgr(String rstgr) {
		this.rstgr = rstgr;
	}
	public String getXnegp() {
		return xnegp;
	}
	public void setXnegp(String xnegp) {
		this.xnegp = xnegp;
	}
	public String getValueDate() {
		return valueDate;
	}
	public void setValueDate(String valueDate) {
		this.valueDate = valueDate;
	}
	public String getBlineDate() {
		return blineDate;
	}
	public void setBlineDate(String blineDate) {
		this.blineDate = blineDate;
	}
	public String getPymtMeth() {
		return pymtMeth;
	}
	public void setPymtMeth(String pymtMeth) {
		this.pymtMeth = pymtMeth;
	}
	public String getPmnttrms() {
		return pmnttrms;
	}
	public void setPmnttrms(String pmnttrms) {
		this.pmnttrms = pmnttrms;
	}
	public String getPmntBlock() {
		return pmntBlock;
	}
	public void setPmntBlock(String pmntBlock) {
		this.pmntBlock = pmntBlock;
	}
	public String getCopaVkorg() {
		return copaVkorg;
	}
	public void setCopaVkorg(String copaVkorg) {
		this.copaVkorg = copaVkorg;
	}
	public String getCopaVkbur() {
		return copaVkbur;
	}
	public void setCopaVkbur(String copaVkbur) {
		this.copaVkbur = copaVkbur;
	}
	public String getCopaKmvkgr() {
		return copaKmvkgr;
	}
	public void setCopaKmvkgr(String copaKmvkgr) {
		this.copaKmvkgr = copaKmvkgr;
	}
	public String getCopaWw012() {
		return copaWw012;
	}
	public void setCopaWw012(String copaWw012) {
		this.copaWw012 = copaWw012;
	}
	public String getCopaZaufnr() {
		return copaZaufnr;
	}
	public void setCopaZaufnr(String copaZaufnr) {
		this.copaZaufnr = copaZaufnr;
	}
	public String getCopaAufnr() {
		return copaAufnr;
	}
	public void setCopaAufnr(String copaAufnr) {
		this.copaAufnr = copaAufnr;
	}
	public String getCopaPspnr() {
		return copaPspnr;
	}
	public void setCopaPspnr(String copaPspnr) {
		this.copaPspnr = copaPspnr;
	}
	public String getKidNo() {
		return kidNo;
	}
	public void setKidNo(String kidNo) {
		this.kidNo = kidNo;
	}
	public String getFflag() {
		return fflag;
	}
	public void setFflag(String fflag) {
		this.fflag = fflag;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
}
