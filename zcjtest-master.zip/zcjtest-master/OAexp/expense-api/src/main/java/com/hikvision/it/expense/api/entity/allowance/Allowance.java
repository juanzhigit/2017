package com.hikvision.it.expense.api.entity.allowance;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 每天补贴汇总entity
 * <p>Title: Allowance.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class Allowance implements Serializable {
	private static final long serialVersionUID = 3928049937697596599L;
	
	private String id;							//唯一编号
	private String docId;						//单据编号
	private String docNo;						//单据号
	private String userId;						//员工id
	private String userName;					//员工姓名
	private String allowanceDate;				//补贴日期
	private String country;						//国家
	private String city;						//城市
	private String placeGrade;					//城市or国家级别
	private String currency;					//币别
	private BigDecimal foodAllowanceAmount = BigDecimal.ZERO;		//误餐补贴
	private BigDecimal holidayAllowanceAmount = BigDecimal.ZERO;		//节假日补贴
	private BigDecimal hardAllowanceAmount = BigDecimal.ZERO;		//艰苦补贴
	private BigDecimal amAllowanceAmount = BigDecimal.ZERO;			//早晚补贴
	private BigDecimal pmAllowanceAmount = BigDecimal.ZERO;			//早晚补贴
	private BigDecimal lineAllowanceAmount = BigDecimal.ZERO;		//里程补贴
	private BigDecimal rentAllowanceAmount = BigDecimal.ZERO;		//租住补贴金额

	private BigDecimal foodPayAmount 	= BigDecimal.ZERO; // 伙食补贴付款金额
	private BigDecimal holidayPayAmount = BigDecimal.ZERO; // 节假日补贴付款金额
	private BigDecimal hardPayAmount 	= BigDecimal.ZERO; // 艰苦补贴付款金额
	private BigDecimal amPayAmount 		= BigDecimal.ZERO; // 早补贴付款金额
	private BigDecimal pmPayAmount 		= BigDecimal.ZERO; // 晚补贴付款金额
	private BigDecimal linePayAmount 	= BigDecimal.ZERO; // 里程补贴付款金额
	private BigDecimal rentPayAmount 	= BigDecimal.ZERO; // 租住补贴付款金额

	private String userState;					//员工状态 WP or SX
	private List<AllowanceDetail> subsidyDetails = Lists.newArrayList();		//补贴明细
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAllowanceDate() {
		return allowanceDate;
	}
	public void setAllowanceDate(String allowanceDate) {
		this.allowanceDate = allowanceDate;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getPlaceGrade() {
		return placeGrade;
	}
	public void setPlaceGrade(String placeGrade) {
		this.placeGrade = placeGrade;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BigDecimal getFoodAllowanceAmount() {
		return foodAllowanceAmount;
	}
	public void setFoodAllowanceAmount(BigDecimal foodAllowanceAmount) {
		this.foodAllowanceAmount = foodAllowanceAmount;
	}
	public BigDecimal getHolidayAllowanceAmount() {
		return holidayAllowanceAmount;
	}
	public void setHolidayAllowanceAmount(BigDecimal holidayAllowanceAmount) {
		this.holidayAllowanceAmount = holidayAllowanceAmount;
	}
	public BigDecimal getHardAllowanceAmount() {
		return hardAllowanceAmount;
	}
	public void setHardAllowanceAmount(BigDecimal hardAllowanceAmount) {
		this.hardAllowanceAmount = hardAllowanceAmount;
	}
	public BigDecimal getAmAllowanceAmount() {
		return amAllowanceAmount;
	}
	public void setAmAllowanceAmount(BigDecimal amAllowanceAmount) {
		this.amAllowanceAmount = amAllowanceAmount;
	}
	public BigDecimal getPmAllowanceAmount() {
		return pmAllowanceAmount;
	}
	public void setPmAllowanceAmount(BigDecimal pmAllowanceAmount) {
		this.pmAllowanceAmount = pmAllowanceAmount;
	}
	public BigDecimal getLineAllowanceAmount() {
		return lineAllowanceAmount;
	}
	public void setLineAllowanceAmount(BigDecimal lineAllowanceAmount) {
		this.lineAllowanceAmount = lineAllowanceAmount;
	}

	public BigDecimal getRentAllowanceAmount() {
		return rentAllowanceAmount;
	}

	public void setRentAllowanceAmount(BigDecimal rentAllowanceAmount) {
		this.rentAllowanceAmount = rentAllowanceAmount;
	}

	public List<AllowanceDetail> getSubsidyDetails() {
		return subsidyDetails;
	}
	public String getUserState() {
		return userState;
	}
	public void setUserState(String userState) {
		this.userState = userState;
	}
	public void setSubsidyDetails(List<AllowanceDetail> subsidyDetails) {
		this.subsidyDetails = subsidyDetails;
	}

    public BigDecimal getFoodPayAmount() {
        return foodPayAmount;
    }

    public void setFoodPayAmount(BigDecimal foodPayAmount) {
        this.foodPayAmount = foodPayAmount;
    }

    public BigDecimal getHolidayPayAmount() {
        return holidayPayAmount;
    }

    public void setHolidayPayAmount(BigDecimal holidayPayAmount) {
        this.holidayPayAmount = holidayPayAmount;
    }

    public BigDecimal getHardPayAmount() {
        return hardPayAmount;
    }

    public void setHardPayAmount(BigDecimal hardPayAmount) {
        this.hardPayAmount = hardPayAmount;
    }

    public BigDecimal getAmPayAmount() {
        return amPayAmount;
    }

    public void setAmPayAmount(BigDecimal amPayAmount) {
        this.amPayAmount = amPayAmount;
    }

    public BigDecimal getPmPayAmount() {
        return pmPayAmount;
    }

    public void setPmPayAmount(BigDecimal pmPayAmount) {
        this.pmPayAmount = pmPayAmount;
    }

    public BigDecimal getLinePayAmount() {
        return linePayAmount;
    }

    public void setLinePayAmount(BigDecimal linePayAmount) {
        this.linePayAmount = linePayAmount;
    }

    public BigDecimal getRentPayAmount() {
        return rentPayAmount;
    }

    public void setRentPayAmount(BigDecimal rentPayAmount) {
        this.rentPayAmount = rentPayAmount;
    }
}
