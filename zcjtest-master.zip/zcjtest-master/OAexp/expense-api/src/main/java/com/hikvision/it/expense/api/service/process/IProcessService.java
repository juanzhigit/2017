package com.hikvision.it.expense.api.service.process;

import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;

public interface IProcessService {
	/**
	 * 创建流程  成功返回流程实例 失败返回错误信息
	 * @param docId				//单据编号
	 * @param processObjectId	//启动流程ID
	 * @param creator			//创建人
	 * @param language 			//语言
	 * @return
	 */
	HikResult<ProcessInstance> createAndStartProcess(String docId, String processObjectId);
	
	/**
	 * 撤回流程
	 * @param processId
	 * @param suggest
	 */
	HikResult<String> retrackProcess(String processId, String suggest);
	
	/**
	 * 撤销流程
	 * @param processId
	 * @param suggest
	 */
	HikResult<String> undoProcess(String processId, String suggest);
}
