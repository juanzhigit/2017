package com.hikvision.it.expense.api.enums;

public enum YesOrNoEnum {
	Y,N;
}
