package com.hikvision.it.expense.api.service.allowance;

import java.util.List;

import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.trip.Trip;

public interface ICalculateSubsidyService {

	/**
	 * 补贴汇总调整
	 */
	void adjustAllowances(List<Allowance> list);

	/**
	 * <p>计算某一区间段内员工补贴明细</p>
	 * 1、获取区间段内每天行程明细以及每天已付补贴明细<br>
	 * 2、根据行程国家、城市获取所有匹配的伙食补贴、艰苦补贴标准<br>
	 * 3、根据公司获取节假日补贴标准<br>
	 * 4、进行补贴计算，每一天默认都给补贴，然后根据扣减规则进行补贴扣减<br>
	 * 5、获取实习生配置（实习生无任何补贴）<br>
	 *   节假日工作情况，节假日工作有补贴，未工作无补贴<br>
	 * 6、根据传入的节假日工作信息，将未工作的日期的所有补贴置0<br>
	 * 7、外派人员的差旅，外派期间内的所有伙食补贴置0，艰苦补贴为max(0, (差旅目的地艰苦补贴金额 - 外派地艰苦补贴金额)) <br>
	 *    设置扣减原因 DeductionReasonEnum.WP_SUB.name()  如果补贴是外币，需要折算成本位币计算差额<br>
	 * 8、国际差旅节假日补贴置0 扣减原因为DeductionReasonEnum.GJ_NO_BT.name()<br>
	 * 9、会议包餐，无伙食补贴，扣减原因为DeductionReasonEnum.HYBC.name()<br>
	 * 10、来杭州培训差旅、会议差旅不包餐，伙食补贴20/天，其他地区无补贴，设置扣减金额为补贴标准 - 20 设置扣减原因 DeductionReasonEnum.HYPX.name()<br>
	 * 11、超过60天未报销无补贴（提单日期跟差旅行程结束日期之间的日期间隔）
	 * 
	 * 如果当天属于外派，则扣减掉租住补贴，设置扣减原因为 		DeductionReasonEnum.WP.name()<br>
	 * 如果当天已享受租住补贴，则口减掉租住补贴，设置扣减原因为	DeductionReasonEnum.PAID.name()<br>
	 * 如果未维护补贴，则设置补贴金额为0，设置扣减原因为 DeductionReasonEnum.NOMATCH.name()
	 * @param formHeader
	 * @param trips
	 * @return 补贴汇总信息
	 */
	List<Allowance> calculateAllowance(FormHeader formHeader, List<Trip> trips);
	
	/**
	 * <p>计算某一区间段内员工租住补贴补贴明细</p>
	 * 1、租住天数 >= 14天才有租住补贴
	 * 2、获取区间范围内的所有外派记录信息<br>
	 * 3、获取区间范围内的所有租住补贴信息<br>
	 * 4、根据公司代码获取补贴标准<br>
	 * 5、按天解析每天的租住补贴<br>
	 * 如果当天属于外派或实习，则扣减掉租住补贴，设置扣减原因为 		DeductionReasonEnum.WP_OR_SX.name()<br>
	 * 如果当天已享受租住补贴，则扣减掉租住补贴，设置扣减原因为	DeductionReasonEnum.PAID.name()<br>
	 * 如果未维护补贴，则设置补贴金额为0，设置扣减原因为 DeductionReasonEnum.NOMATCH.name()
	 * 
	 * @param formHeader
	 * @param fromDate
	 * @param toDate
	 * @return 租住补贴明细
	 */
	List<AllowanceDetail> calculateRentAllowance(FormHeader formHeader, String fromDate, String toDate);

	/**
	 * @param stayFees 住宿明细
	 * @return
	 */
	List<AllowanceDetail> calculateRentAllowance(FormHeader formHeader, List<FeeDetail> stayFees);

	/**
	 * 市内派车早晚补贴计算
	 * 
	 * @param formHeader
	 * @param trips  		市内派车行程明细
	 * @return
	 */
	List<Trip> calculateCityCar(FormHeader formHeader, List<Trip> trips);
}
