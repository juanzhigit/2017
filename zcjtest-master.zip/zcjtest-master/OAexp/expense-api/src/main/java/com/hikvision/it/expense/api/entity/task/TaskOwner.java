package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;

public class TaskOwner implements Serializable {
	private static final long serialVersionUID = -6424105781340047733L;

	private String taskId;			//任务id
	private String owner;			//任务所有人
	private String ownerName;		//任务所有人姓名
	private String ownerMail;		//任务所有人邮箱
	private int    grade;			//审批人级别
	private String authUser;		//授权人
	private String authUserName;	//授权人姓名
	private int    taskNumber;		//待办任务数
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getOwnerMail() {
		return ownerMail;
	}
	public void setOwnerMail(String ownerMail) {
		this.ownerMail = ownerMail;
	}
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public String getAuthUser() {
		return authUser;
	}
	public void setAuthUser(String authUser) {
		this.authUser = authUser;
	}
	public String getAuthUserName() {
		return authUserName;
	}
	public void setAuthUserName(String authUserName) {
		this.authUserName = authUserName;
	}
	public int getTaskNumber() {
		return taskNumber;
	}
	public void setTaskNumber(int taskNumber) {
		this.taskNumber = taskNumber;
	}
}
