package com.hikvision.it.expense.api.entity.dept;

import java.io.Serializable;

/**
 * 部门entity
 * <p>Title: Dept.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月17日
 *
 */
public class Dept implements Serializable {
	private static final long serialVersionUID = -1125159182138635552L;
	private String deptCode;			//部门代码
	private String deptname;			//部门名称
	private String deptCodePath;		//部门代码路径
	private String deptPath;			//部门路径
	private String deptLevel;			//部门路径级别
	private String deptBase;			//部门base地
	private String deptManager;			//部门主管
	private String deptManagerName;		//部门主管姓名
	private String deptType;			//部门类别
	private String orderNo;				//研发订单
	private String orderDesc;			//研发订单描述
	private String costCenter;			//成本中心代码
	private String costCenterName;		//成本中心名称
	private String rlDept;				//实际部门代码
	private String rlDeptName;			//实际部门描述
	private String status;				//部门状态
	
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptname() {
		return deptname;
	}
	public void setDeptname(String deptname) {
		this.deptname = deptname;
	}
	public String getDeptCodePath() {
		return deptCodePath;
	}
	public void setDeptCodePath(String deptCodePath) {
		this.deptCodePath = deptCodePath;
	}
	public String getDeptPath() {
		return deptPath;
	}
	public void setDeptPath(String deptPath) {
		this.deptPath = deptPath;
	}
	public String getDeptLevel() {
		return deptLevel;
	}
	public void setDeptLevel(String deptLevel) {
		this.deptLevel = deptLevel;
	}
	public String getDeptBase() {
		return deptBase;
	}
	public void setDeptBase(String deptBase) {
		this.deptBase = deptBase;
	}
	public String getDeptManager() {
		return deptManager;
	}
	public void setDeptManager(String deptManager) {
		this.deptManager = deptManager;
	}
	public String getDeptManagerName() {
		return deptManagerName;
	}
	public void setDeptManagerName(String deptManagerName) {
		this.deptManagerName = deptManagerName;
	}
	public String getDeptType() {
		return deptType;
	}
	public void setDeptType(String deptType) {
		this.deptType = deptType;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getOrderDesc() {
		return orderDesc;
	}
	public void setOrderDesc(String orderDesc) {
		this.orderDesc = orderDesc;
	}
	public String getCostCenter() {
		return costCenter;
	}
	public void setCostCenter(String costCenter) {
		this.costCenter = costCenter;
	}
	public String getCostCenterName() {
		return costCenterName;
	}
	public void setCostCenterName(String costCenterName) {
		this.costCenterName = costCenterName;
	}
	public String getRlDept() {
		return rlDept;
	}
	public void setRlDept(String rlDept) {
		this.rlDept = rlDept;
	}
	public String getRlDeptName() {
		return rlDeptName;
	}
	public void setRlDeptName(String rlDeptName) {
		this.rlDeptName = rlDeptName;
	}
}
