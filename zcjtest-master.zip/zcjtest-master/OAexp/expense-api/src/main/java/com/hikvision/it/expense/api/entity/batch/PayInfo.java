package com.hikvision.it.expense.api.entity.batch;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class PayInfo extends PayHead implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1340451883670188990L;

	private List<PayDetail> details = new ArrayList<PayDetail>();

	public List<PayDetail> getDetails() {
		return details;
	}

	public void setDetails(List<PayDetail> details) {
		this.details = details;
	}

}
