package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;

public class TaskReceivor implements Serializable {
	private static final long serialVersionUID = 4912586727222322163L;

	private String owner;			//任务所有人
	private String ownerName;		//任务所有人姓名
	private String ownerMail;		//任务所有人邮箱
	
	public String getOwner() {
		return owner;
	}
	public void setOwner(String owner) {
		this.owner = owner;
	}
	public String getOwnerName() {
		return ownerName;
	}
	public void setOwnerName(String ownerName) {
		this.ownerName = ownerName;
	}
	public String getOwnerMail() {
		return ownerMail;
	}
	public void setOwnerMail(String ownerMail) {
		this.ownerMail = ownerMail;
	}
}
