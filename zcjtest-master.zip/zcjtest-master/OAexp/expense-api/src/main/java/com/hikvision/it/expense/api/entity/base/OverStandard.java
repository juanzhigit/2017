package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 超标标准entity
 * <p>Title: OverStandard.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月26日
 *
 */
public class OverStandard implements Serializable {
	private static final long serialVersionUID = 4808849094093420329L;
	
	private String feeType;				//费用类别
	private String userGrade;			//员工级别
	private String placeGrade;			//国家、城市级别
	private String serveType;			//招待方式
	private String serveGrade;			//招待级别
	private String payCurrency;			//消费币别
	private String payAmount;			//消费金额
	private BigDecimal exchangeRate;	//汇率
	private String standardCurrency;	//标准货币
	private BigDecimal standardAmount;	//标准
	private boolean overStandard;		//是否超标
	private boolean overDate;			//是否超期
	
	public String getFeeType() {
		return feeType;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public String getUserGrade() {
		return userGrade;
	}
	public void setUserGrade(String userGrade) {
		this.userGrade = userGrade;
	}
	public String getPlaceGrade() {
		return placeGrade;
	}
	public void setPlaceGrade(String placeGrade) {
		this.placeGrade = placeGrade;
	}
	public String getServeType() {
		return serveType;
	}
	public void setServeType(String serveType) {
		this.serveType = serveType;
	}
	public String getServeGrade() {
		return serveGrade;
	}
	public void setServeGrade(String serveGrade) {
		this.serveGrade = serveGrade;
	}
	public String getPayCurrency() {
		return payCurrency;
	}
	public void setPayCurrency(String payCurrency) {
		this.payCurrency = payCurrency;
	}
	public String getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(String payAmount) {
		this.payAmount = payAmount;
	}
	public String getStandardCurrency() {
		return standardCurrency;
	}
	public void setStandardCurrency(String standardCurrency) {
		this.standardCurrency = standardCurrency;
	}
	public BigDecimal getStandardAmount() {
		return standardAmount;
	}
	public void setStandardAmount(BigDecimal standardAmount) {
		this.standardAmount = standardAmount;
	}
	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public boolean isOverStandard() {
		return overStandard;
	}
	public void setOverStandard(boolean overStandard) {
		this.overStandard = overStandard;
	}
	public boolean isOverDate() {
		return overDate;
	}
	public void setOverDate(boolean overDate) {
		this.overDate = overDate;
	}
}
