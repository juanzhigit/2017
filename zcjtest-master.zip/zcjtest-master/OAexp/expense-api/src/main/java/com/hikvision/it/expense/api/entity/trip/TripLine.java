package com.hikvision.it.expense.api.entity.trip;

import java.io.Serializable;
import java.sql.Date;

public class TripLine implements Serializable {
	private static final long serialVersionUID = -230816244137598378L;

	private String id;						//数据唯一编号
	private String docId;					//申请单唯一编号
	private String docNo;					//申请单号
	private String userId;					//员工编号
	private String userName;				//员工姓名
	private String tripCountry;				//国家代码
	private String tripCity;				//城市代码
	private String tripCityDesc;			//城市描述
	private String placeGrade;				//城市or国家级别
	private Date   fromDate;				//到达日期
	private Date   toDate;					//离开日期
	private Date   subsidyFrom;				//补贴起始日期
	private Date   subsidyTo;				//补贴截止日期
	private int    days;					//差旅天数
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getTripCountry() {
		return tripCountry;
	}
	public void setTripCountry(String tripCountry) {
		this.tripCountry = tripCountry;
	}
	public String getTripCity() {
		return tripCity;
	}
	public void setTripCity(String tripCity) {
		this.tripCity = tripCity;
	}
	public String getTripCityDesc() {
		return tripCityDesc;
	}
	public void setTripCityDesc(String tripCityDesc) {
		this.tripCityDesc = tripCityDesc;
	}
	public String getPlaceGrade() {
		return placeGrade;
	}
	public void setPlaceGrade(String placeGrade) {
		this.placeGrade = placeGrade;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public Date getSubsidyFrom() {
		return subsidyFrom;
	}
	public void setSubsidyFrom(Date subsidyFrom) {
		this.subsidyFrom = subsidyFrom;
	}
	public Date getSubsidyTo() {
		return subsidyTo;
	}
	public void setSubsidyTo(Date subsidyTo) {
		this.subsidyTo = subsidyTo;
	}
	public int getDays() {
		return days;
	}
	public void setDays(int days) {
		this.days = days;
	}
}
