package com.hikvision.it.expense.api.enums;

public enum TaskNameEnum {
	/** 驳回填单 */
	A01,
	/** 加签 */
	A02,
	/** 转发 */
	A03,
	/** 开始 */
	START,
	/** 结束 */
	END,
	/** 财务过账 */
	F02,
	/** 财务过账 */
	F04,
	/** 撤回 */
	R01,
	/** 撤销 */
	R02
}
