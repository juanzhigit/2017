package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 待办信息
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/5
 * Time: 9:35
 * To change this template use File | Settings | File Templates.
 */
public class TodoInfo implements Serializable {
    private static final long serialVersionUID = 4060406103528991898L;
    /** 任务id */
    private String taskId;
    /** 任务名称 */
    private String taskName;
    /** 任务描述 */
    private String taskDesc;
    /** 单据id */
    private String docId;
    /** 单据号 */
    private String docNo;
    /** 提交日期 */
    private String submitDate;
    /** 事由 */
    private String remark;
    /** 单据类别 */
    private String docType;
    /** 单据类别名称 */
    private String docTypeName;
    /** 报销类别 */
    private String expenseType;
    /** 申请人 */
    private String userId;
    /** 申请人姓名 */
    private String userName;
    /** 单据状态 */
    private String docStatus;
    /** 单据状态名称 */
    private String docStatusName;
    /** 金额 */
    private BigDecimal amount;
    /** 币别 */
    private String currency;
    /** 当前处理人 */
    private String operators;

    public String getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(String expenseType) {
        this.expenseType = expenseType;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public String getTaskName() {
        return taskName;
    }

    public void setTaskName(String taskName) {
        this.taskName = taskName;
    }

    public String getTaskDesc() {
        return taskDesc;
    }

    public void setTaskDesc(String taskDesc) {
        this.taskDesc = taskDesc;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    public String getSubmitDate() {
        return submitDate;
    }

    public void setSubmitDate(String submitDate) {
        this.submitDate = submitDate;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDocType() {
        return docType;
    }

    public void setDocType(String docType) {
        this.docType = docType;
    }

    public String getDocTypeName() {
        return docTypeName;
    }

    public void setDocTypeName(String docTypeName) {
        this.docTypeName = docTypeName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDocStatus() {
        return docStatus;
    }

    public void setDocStatus(String docStatus) {
        this.docStatus = docStatus;
    }

    public String getDocStatusName() {
        return docStatusName;
    }

    public void setDocStatusName(String docStatusName) {
        this.docStatusName = docStatusName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getOperators() {
        return operators;
    }

    public void setOperators(String operators) {
        this.operators = operators;
    }
}
