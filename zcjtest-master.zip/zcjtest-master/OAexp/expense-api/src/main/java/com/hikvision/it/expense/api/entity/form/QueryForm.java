package com.hikvision.it.expense.api.entity.form;

import com.google.common.base.Strings;


import java.io.Serializable;
import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

/**
 * 复合查询表单查询条件
 * 
 * @author liangdong5
 *
 */
public class QueryForm implements Serializable {

	private static final long serialVersionUID = 895893138596371627L;

	private String applyId; 			//单据号
	private String expenseType;         //业务细类
	private String userIdOrName; 		//申请人/供应商
	private String docMinDate; 			//单据创建最小时间
	private String docMaxDate; 			//单据创建最大时间
	private String completeMinDate; 	//最小完成时间
	private String completeMaxDate; 	//最大完成时间
	private BigDecimal docMinAmt; 		//单据最小金额
	private BigDecimal docMaxAmt; 		//单据最大金额
	private BigDecimal tzMinAmt; 		//调整最小金额
	private BigDecimal tzMaxAmt; 		//调整最大金额
	private List<String> companyCode; 	//公司代码
	private List<String> deptCode; 		//部门代码
	private List<String> docStatus; 	//单据状态
	private List<String> processCode; 	//流程代码

	private Date docStartDate;			//单据创建最小时间
	private Date docEndDate;			//单据创建最大时间
	private Date completeStartDate;		//最小完成时间
	private Date completeEndDate;		//最大完成时间
	
	private String yfkj;				//应付会计
	private String yfkjMinDate;			//应付会计审核起始时间str
	private String yfkjMaxDate;			//应付会计审核截止时间str
	private String fkkj;				//付款会计
	private String fkkjMinDate;			//付款会计审核起始时间str
	private String fkkjMaxDate;			//付款会计审核截止时间str
	
	private Date   yfkjStartDate;		//应付会计审核起始时间
	private Date   yfkjEndDate;			//应付会计审核截止时间
	private Date   fkkjStartDate;		//付款会计审核起始时间
	private Date   fkkjEndDate;			//付款会计审核截止时间
	
	private String roleArea;			//权限范围
	private String remark;				//事由
	
	private String year;//年份
	private String month;//月份
	private String stayct;//住宿城市id
	private String stayct_desc;//住宿城市描述
	
	private String issc;//是否出差 Y出差
	
	private String m3;//M3住宿标准
	private String m4;//m4住宿标准
	
	
	private String bukrs;//付款公司代码
	
	
	public String getBukrs() {
		return bukrs;
	}

	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}


	public String getIssc() {
		return issc;
	}

	public void setIssc(String issc) {
		this.issc = issc;
	}

	public String getStayct_desc() {
		return stayct_desc;
	}

	public void setStayct_desc(String stayct_desc) {
		this.stayct_desc = stayct_desc;
	}

	public String getM3() {
		return m3;
	}

	public void setM3(String m3) {
		this.m3 = m3;
	}

	public String getM4() {
		return m4;
	}

	public void setM4(String m4) {
		this.m4 = m4;
	}

	public String getYear() {
		return year;
	}

	public void setYear(String year) {
		this.year = year;
	}

	public String getMonth() {
		return month;
	}

	public void setMonth(String month) {
		this.month = month;
	}

	public String getStayct() {
		return stayct;
	}

	public void setStayct(String stayct) {
		this.stayct = stayct;
	}

	public String getUserIdOrName() {
		return userIdOrName;
	}

	public void setUserIdOrName(String userIdOrName) {
		this.userIdOrName = userIdOrName;
	}

	public Date getDocStartDate() {
		if (!Strings.isNullOrEmpty(this.docMinDate)) {
			this.docStartDate = stringToTime(docMinDate + " 00:00:00");
		}
		return docStartDate;
	}

	public void setDocStartDate(Date docStartDate) {
		this.docStartDate = docStartDate;
	}

	public Date getDocEndDate() {
		if (!Strings.isNullOrEmpty(this.docMaxDate)) {
			this.docEndDate = stringToTime(docMaxDate + " 23:59:59");
		}
		return docEndDate;
	}

	public void setDocEndDate(Date docEndDate) {
		this.docEndDate = docEndDate;
	}

	public Date getCompleteStartDate() {
		if (!Strings.isNullOrEmpty(this.completeMinDate)) {
			this.completeStartDate =stringToTime(completeMinDate + " 00:00:00");
		}
		return completeStartDate;
	}

	public void setCompleteStartDate(Date completeStartDate) {
		this.completeStartDate = completeStartDate;
	}

	public Date getCompleteEndDate() {
		if (!Strings.isNullOrEmpty(this.completeMaxDate)) {
			this.completeEndDate = stringToTime(completeMaxDate + " 23:59:59");
		}
		return completeEndDate;
	}

	public void setCompleteEndDate(Date completeEndDate) {
		this.completeEndDate = completeEndDate;
	}

	public List<String> getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(List<String> companyCode) {
		this.companyCode = companyCode;
	}

	public List<String> getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(List<String> deptCode) {
		this.deptCode = deptCode;
	}

	public String getApplyId() {
		return applyId;
	}

	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}

	public String getDocMinDate() {
		return docMinDate;
	}

	public void setDocMinDate(String docMinDate) {
		this.docMinDate = docMinDate;
	}

	public String getDocMaxDate() {
		return docMaxDate;
	}

	public void setDocMaxDate(String docMaxDate) {
		this.docMaxDate = docMaxDate;
	}

	public String getCompleteMinDate() {
		return completeMinDate;
	}

	public void setCompleteMinDate(String completeMinDate) {
		this.completeMinDate = completeMinDate;
	}

	public String getCompleteMaxDate() {
		return completeMaxDate;
	}

	public void setCompleteMaxDate(String completeMaxDate) {
		this.completeMaxDate = completeMaxDate;
	}

	public String getYfkj() {
		return yfkj;
	}

	public void setYfkj(String yfkj) {
		this.yfkj = yfkj;
	}

	public String getYfkjMinDate() {
		return yfkjMinDate;
	}

	public void setYfkjMinDate(String yfkjMinDate) {
		this.yfkjMinDate = yfkjMinDate;
	}

	public String getYfkjMaxDate() {
		return yfkjMaxDate;
	}

	public void setYfkjMaxDate(String yfkjMaxDate) {
		this.yfkjMaxDate = yfkjMaxDate;
	}

	public String getFkkj() {
		return fkkj;
	}

	public void setFkkj(String fkkj) {
		this.fkkj = fkkj;
	}

	public String getFkkjMinDate() {
		return fkkjMinDate;
	}

	public void setFkkjMinDate(String fkkjMinDate) {
		this.fkkjMinDate = fkkjMinDate;
	}

	public String getFkkjMaxDate() {
		return fkkjMaxDate;
	}

	public void setFkkjMaxDate(String fkkjMaxDate) {
		this.fkkjMaxDate = fkkjMaxDate;
	}

	public Date getYfkjStartDate() {
		if (!Strings.isNullOrEmpty(this.yfkjMinDate)) {
			this.yfkjStartDate = stringToTime(yfkjMinDate + " 00:00:00");
		}
		return yfkjStartDate;
	}

	public void setYfkjStartDate(Date yfkjStartDate) {
		this.yfkjStartDate = yfkjStartDate;
	}

	public Date getYfkjEndDate() {
		if (!Strings.isNullOrEmpty(this.yfkjMaxDate)) {
			this.yfkjEndDate = stringToTime(yfkjMaxDate + " 23:59:59");
		}
		return yfkjEndDate;
	}

	public void setYfkjEndDate(Date yfkjEndDate) {
		this.yfkjEndDate = yfkjEndDate;
	}

	public Date getFkkjStartDate() {
		if (!Strings.isNullOrEmpty(this.fkkjMinDate)) {
			this.fkkjStartDate = stringToTime(fkkjMinDate + " 00:00:00");
		}
		return fkkjStartDate;
	}

	public void setFkkjStartDate(Date fkkjStartDate) {
		this.fkkjStartDate = fkkjStartDate;
	}

	public Date getFkkjEndDate() {
		if (!Strings.isNullOrEmpty(this.fkkjMaxDate)) {
			this.fkkjEndDate = stringToTime(fkkjMaxDate + " 23:59:59");
		}
		return fkkjEndDate;
	}

	public void setFkkjEndDate(Date fkkjEndDate) {
		this.fkkjEndDate = fkkjEndDate;
	}

	public BigDecimal getDocMinAmt() {
		return docMinAmt;
	}

	public void setDocMinAmt(BigDecimal docMinAmt) {
		this.docMinAmt = docMinAmt;
	}

	public BigDecimal getDocMaxAmt() {
		return docMaxAmt;
	}

	public void setDocMaxAmt(BigDecimal docMaxAmt) {
		this.docMaxAmt = docMaxAmt;
	}

	public BigDecimal getTzMinAmt() {
		return tzMinAmt;
	}

	public void setTzMinAmt(BigDecimal tzMinAmt) {
		this.tzMinAmt = tzMinAmt;
	}

	public BigDecimal getTzMaxAmt() {
		return tzMaxAmt;
	}

	public void setTzMaxAmt(BigDecimal tzMaxAmt) {
		this.tzMaxAmt = tzMaxAmt;
	}

	public List<String> getDocStatus() {
		return docStatus;
	}

	public void setDocStatus(List<String> docStatus) {
		this.docStatus = docStatus;
	}

	public List<String> getProcessCode() {
		return processCode;
	}

	public void setProcessCode(List<String> processCode) {
		this.processCode = processCode;
	}

	public String getRoleArea() {
		return roleArea;
	}

	public void setRoleArea(String roleArea) {
		this.roleArea = roleArea;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getExpenseType() {
		return expenseType;
	}

	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}




	/**
	 * 由yyyy-MM-dd HH:mm:ss格式的字符串返回日期时间
	 *
	 * @param
	 *
	 * @return
	 */
	public static Date stringToTime(String string) {
		if (string == null)
			return null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");

		try {
			return simpleDateFormat.parse(string);
		} catch (ParseException e) {
			e.printStackTrace();
		}

		return null;
	}

}
