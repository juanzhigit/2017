package com.hikvision.it.expense.api.service.form;

import java.util.List;
import java.util.Map;

import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.AdjustAmountBean;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.entity.history.ApproveHistory;
import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.enums.ResultEnum;

public interface IFormService {
	/**
	 * 保存单据信息，成功返回临时单号，失败返回失败信息
	 * @param form
	 * @return
	 */
	HikResult<String> saveFormInfo(FormInfo form);

	/**
	 * 提交单据，成功返回正式单号，失败返回失败信息
	 * @param form
	 * @return
	 */
	HikResult<String> submitFormInfo(FormInfo form);

	/**
	 * 查询单据信息
	 * @param docId 单据id
	 * @param userId  	查看人员
	 * @return
	 */
	HikResult<FormInfo> getFormInfo(String docId, String userId);

	/**
	 * 判断单据是否可读取
	 */
	boolean isReadable(String docId);

	/**
	 * 判断单据是否可编辑
	 * @param docId
	 * @return
	 */
	boolean isEditable(String docId);

	/**
	 * 单据审批
	 */
	HikResult<String> approve(String taskId, String suggest, ResultEnum result, List<TaskReceivor> receivers);


	/**
	 * 校验是否可以编辑单据
	 * @param header
	 * @return
	 */
	boolean checkCanEditDoc(FormHeader header);

	List<ApproveHistory> getApproveHistories(String docId);

	/**
	 * 金额调整
	 */
	HikResult<String> adjustAmount(AdjustAmountBean adjustBean);

	/**
	 * 获取他人收款列表
	 */
	List<OtherReceivor> listOtherReceiver(String docId);

	/**
	 * 增加节假日工作记录
	 */
	void addWorkingHolidays(String docId, List<String> dates);
	/**
	 * 获取节假日列表
	 */
	List<HolidayWork> listWorkingHolidays(String docId, String bukrs, String minDate, String maxDate);

	/**
	 * 获取所有默认状态的申请单，用于行程变更或者报销
	 * @return
	 */
	List<FormHeader> listApplyWithDefaultStatus();

    /**
     * 检查售前派工单
     */
	boolean checkSqpgRel(String userId);

	/**
	 * 删除草稿箱
	 * @param docId
     * @return
     */
	HikResult<String> deleteDraftDoc(String docId);

	/**
	 * 撤回
	 * @param docId
	 * @param userId
     * @return
     */
	HikResult<String> retrack(String docId, String userId);

	/**
	 * 作废
	 * @param docId
	 * @param userId
     * @return
     */
	HikResult<String> undo(String docId, String userId);

	/**
	 * 判断是否有在途的报销单
	 * 当前的申请单关联的单据有没有被在途（S002 S003 S005 S004）报销单
	 *
	 * @param applyid
	 * @param userid
     * @return
     */
	HikResult<String> checkTransitApplyByApplyId(String applyid, String userid);

	/**
	 * 校验用户能否报市内交通费用
	 */
    boolean checkSnjtFee(String userId, String year, String month);

	/**
	 * 根据applyid查询差率时间区间
	 * 源数据包含变更前及变更后的记录
	 * @param applyId
     * @return
     */
	FormHeader getTransitSectionByApplyId(String applyId);

	/**
	 * 作废申请单 主要是一些验证
	 * @param docId
	 * @param userId
     * @return
     */
	HikResult<String> applyUndo(String docId, String userId);

	/**
	 * 获取可以删除的记录
	 * @param docId
	 * @param userId
     * @return
     */
	List<DocumentInfo> getIsUndoOk(String docId, String userId);

	/**
	 * 作废申请单具体操作
	 * @param docId
	 * @param applyid
	 * @param userId
     * @return
     */
	HikResult<String> updateApplyUndo(String docId, String applyid, String userId);

	/**
	 * 保存收件箱地址
	 * @param docId
	 * @param mailAddress
	 * @return
	 */
	HikResult<String> saveVendorInvoiceMailAddress(String docId, String mailAddress);

    /**
     * 计算补贴
     */
    void calculateSubsidy(FormInfo formInfo);

	/**
	 * 保存修改后的催收报表邮件
	 * @param lists
	 * @return
     */
	HikResult<String> recordMail(List<VendorFormHeader> lists);

	/**
	 * 逐条保存根据收件人邮箱分组的map 信息 若有一条出错全部回滚
	 * @param map
	 * @return
     */
	HikResult<List<VendorFormHeader>> batchSaveVendorInvoiceMailAddress(Map<Integer, String> map);
}
