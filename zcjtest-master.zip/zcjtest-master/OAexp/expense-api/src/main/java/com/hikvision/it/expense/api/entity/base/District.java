package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;

/**
 * 城市区域等级
 */
public class District implements Serializable {
    private static final long serialVersionUID = -1680436995437167813L;
    private String countryId;
    private String cityId;
    private String cityLevel;
    private String belongsBukrs;

    public String getCountryId() {
        return countryId;
    }

    public void setCountryId(String countryId) {
        this.countryId = countryId;
    }

    public String getCityId() {
        return cityId;
    }

    public void setCityId(String cityId) {
        this.cityId = cityId;
    }

    public String getCityLevel() {
        return cityLevel;
    }

    public void setCityLevel(String cityLevel) {
        this.cityLevel = cityLevel;
    }

    public String getBelongsBukrs() {
        return belongsBukrs;
    }

    public void setBelongsBukrs(String belongsBukrs) {
        this.belongsBukrs = belongsBukrs;
    }
}
