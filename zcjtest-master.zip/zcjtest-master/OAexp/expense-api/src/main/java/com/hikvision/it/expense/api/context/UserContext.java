package com.hikvision.it.expense.api.context;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.exception.ExceptionCode;
import com.hikvision.it.expense.api.exception.ExpenseException;

public class UserContext {

    private static final ThreadLocal<LoginUser> LOCAL = new ThreadLocal<LoginUser>();

    public static LoginUser get() {
    	LoginUser user = LOCAL.get();
    	if (user == null)
			throw new ExpenseException(ExceptionCode.OPRATOR_USER_NOT_FOUND);
        return user;
    }

    public static void set(LoginUser loginUser) {
        LOCAL.set(loginUser);
    }

    public static void set(String userId, String language) {
    	LoginUser loginUser = new LoginUser();

    	loginUser.setUserId(userId);
    	loginUser.setLanguage(language);
		
        LOCAL.set(loginUser);
    }

    public static String getUserId() {
        return LOCAL.get().getUserId();
    }

    public static String getUserName() {
        return LOCAL.get().getUserName();
    }

    public static String getLanguage() {
		String language = UserContext.get().getLanguage();
		if (Strings.isNullOrEmpty(language))
			language = "ZH";
        return language;
    }

    public static void clearContext() {
        LOCAL.remove();
    }
}
