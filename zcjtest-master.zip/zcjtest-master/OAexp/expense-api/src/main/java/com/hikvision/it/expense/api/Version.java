package com.hikvision.it.expense.api;

public interface Version {

    String VERSION_1_0_0 = "1.0.0";
    String VERSION_LATEST = VERSION_1_0_0;

}
