package com.hikvision.it.expense.api.service.voucher;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.batch.PayHead;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;
import com.hikvision.it.expense.api.entity.voucher.OnlineBsikSummary;
import com.hikvision.it.expense.api.entity.voucher.Voucher;

/**
 * 凭证接口，用于凭证预览，凭证过账
 * <p>Title: IVouchService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月10日
 *
 */
public interface IVoucherService {
	/**
	 * 加载单据凭证预览信息
	 * @param docId
	 * @return
	 */
	HikResult<List<Voucher>> previewVoucher(String docId);

	/**
	 * 更新单据凭证预览信息
	 */
	void previewVoucher(String docId, List<Voucher> vouchers);

	/**
	 * 凭证过账
	 * @param docId
	 * @return
	 */
	HikResult<String> postVoucher(String docId, boolean manual);
	
	/**
	 * 付款确认
	 * @param docId
	 * @return
	 */
	HikResult<String> paySure(List<PayHead> heads);
	
	/**
	 * 校验预制凭证是否有效
	 * @param docId
	 * @return
	 */
	HikResult<String> checkPreVoucher(String docId);
	
	/**
	 * 统计在途未清金额
	 * @param bukrs
	 * @param userId
	 * @return
	 */
	OnlineBsikSummary countOnlineReim(String bukrs, String userId);
	
	/**
	 * 获取未清金额
	 * @param bsiks
	 * @param ztwqje
	 * @return
	 */
	HikResult<Map<String, BigDecimal>> countWqje(List<Bsik> bsiks, BigDecimal ztwqje);

	/**
	 * 校验所有凭证都已过账
	 * @param docId
	 * @return
	 */
	boolean checkAllVoucherPosted(String docId);

	/**
	 * 根据当前登陆人员 获取可以付款的报销单据
	 * @param docNo         申请单号
	 * @param postUser      过账会计
	 * @param bukrs         公司代码
	 * @return
	 */
	List<CashierAudit> getDocsToPayment(String docNo, String postUser, String bukrs);
}
