package com.hikvision.it.expense.api.exception;

/**
 * 错误码, 错误码对应消息国际化
 */
public class ExceptionCode {
	/** 克隆对象出错 */
	public static final int POJO_CLONE_ERROR = 1;
	/** 未查询到员工直接主管 */
	public static final int USER_DIRECTOR_NOT_FOUND = 2;
	/** 登陆人员未获取到 */
	public static final int OPRATOR_USER_NOT_FOUND = 404;
	/** 未获取到汇率信息 */
	public static final int EXCHANGE_RATE_NOT_FOUND = 3;
	
	/** 单据已变更或已报销 */
	public static final int DOC_HAS_CHANGED_OR_EXPENSED = 1000;
	/** 未被支持的单据类别 */
	public static final int DOC_NOT_SUPPORTED = 1001;
	
	/** 流程启动失败 */
	public static final int PROCESS_START_FAILURE = 2000;
	/** 未获取到流程输入参数 */
	public static final int PROCESS_PARAM_NOT_FOUND = 2001;
	/** 未查询到流程 */
	public static final int PROCESS_NOT_FOUND = 2404;
	/** 未匹配到适用流程 */
	public static final int PROCESS_NOT_CONFIG = 2405;
	/** 流程已结束 */
	public static final int PROCESS_COMPLETED = 2002;
	/** 流程版本错误 */
	public static final int PROCESS_VERSION_ERROR = 2003;
	
	/** 未查询到下一环节配置信息，请联系管理员 */
	public static final int TASK_NEXT_NODE_NOT_FOUND = 3000;
	/** 未查询到流程环节 */
	public static final int TASK_NODE_NOT_FOUND = 3001;
	/** 任务已审批 */
	public static final int TASK_COMPLETED = 3002;
	/** 未获取到任务服务 */
	public static final int TASK_SERVICE_NOT_FOUND = 3003;
	/** 未配置审批人查询service */
	public static final int TASK_APPROVER_SERVICE_NOT_FOUND = 3004;
	/** 未查询到审批人 */
	public static final int TASK_APPROVER_NOT_FOUND = 3005;
	
	/** 差旅行程未结束，不能报销 */
	public static final int EXP_ERROR_TRIP_NOT_END = 4001;
	/** 伙食补贴标准未维护 */
	public static final int SUBSIDY_NOT_FOUND_ERROR_FOOD = 5001;
	/** 外派地伙食补贴标准未维护 */
	public static final int SUBSIDY_NOT_FOUND_ERROR_FOOD_WP = 5002;
	/** 艰苦补贴标准未维护 */
	public static final int SUBSIDY_NOT_FOUND_ERROR_HARD = 5003;
	/** 外派艰苦补贴标准未维护 */
	public static final int SUBSIDY_NOT_FOUND_ERROR_HARD_WP = 5004;
	/** 早晚补贴标准未维护 */
	public static final int SUBSIDY_NOT_FOUND_ERROR_ZW = 5005;
	/** 补贴数据发生变更，请重新计算 */
	public static final int SUBSIDY_ERROR_NEED_CALCULATE_AGAIN = 5006;
	
	/** 凭证生成失败，未获取到借款明细 */
	public static final int VOUCH_ERROR_DOC_NOT_LOAN = 6001;
	/** 凭证生成失败，现金科目未配置 */
	public static final int VOUCH_ERROR_XJ_SUBJECT_NOT_CFG = 6002;
	/** 凭证生成失败，税分科目未配置 */
	public static final int VOUCH_ERROR_TAX_SUBJECT_NOT_CFG = 6004;
	/** 无权进行凭证操作 */
	public static final int VOUCH_ERROR_NOT_AUTH = 6003;
}
