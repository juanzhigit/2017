package com.hikvision.it.expense.api.enums;

public enum FIOrderStatus {

    /**
     * 初始
     */
    F001,
    /**
     * 已变更
     */
    F002,
    /**
     * 已过账
     */
    F003,
    /**
     * 付款中
     */
    F004,
    /**
     * 已付款
     */
    F005,
    /**
     * 错误
     */
    F006,
    /**
     * 标记删除
     */
    F007
}
