package com.hikvision.it.expense.api.service.execute;

import java.util.List;

import com.hikvision.it.expense.api.entity.task.TaskObject;
import com.hikvision.it.expense.api.entity.task.TaskOwner;


/**
 * 查询任务所有人接口
 * <p>Title: IFindTaskOwnerService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月17日
 *
 */
public interface ITaskOwnerService {
	/**
	 * 根据任务配置信息、单据id获取审批人列表
	 * @param taskObject
	 * @param docId
	 * @return
	 */
	List<TaskOwner> execute(TaskObject taskObject, String docId);
}
