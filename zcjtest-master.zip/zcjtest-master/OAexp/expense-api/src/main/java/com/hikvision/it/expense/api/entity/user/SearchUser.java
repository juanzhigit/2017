package com.hikvision.it.expense.api.entity.user;

import java.io.Serializable;

/**
 * 员工查询返回对象
 */
public class SearchUser implements Serializable {
    private static final long serialVersionUID = -4920703877460204076L;
    private String userId;		//同行人员工编号
    private String userName;	//同行人姓名
    private String deptPath;	//部门路径
    private String deptCode;	//部门代码
    private String userInMail;  //员工内部邮箱

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDeptPath() {
        return deptPath;
    }

    public void setDeptPath(String deptPath) {
        this.deptPath = deptPath;
    }

    public String getUserInMail() {
        return userInMail;
    }

    public void setUserInMail(String userInMail) {
        this.userInMail = userInMail;
    }

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }
}
