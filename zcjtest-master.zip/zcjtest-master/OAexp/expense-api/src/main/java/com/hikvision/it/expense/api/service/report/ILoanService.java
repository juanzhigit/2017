package com.hikvision.it.expense.api.service.report;

import java.util.List;

import com.hikvision.it.expense.api.entity.report.ForeignCurrencyLoanDetail;

/**
 * 借款相关报表接口
 */
public interface ILoanService {

    /**
     * 查询外币借款清单
     */
    List<ForeignCurrencyLoanDetail> listForeignCurrencyLoans();

}
