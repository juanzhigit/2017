package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.math.BigDecimal;

public class TripCity implements Serializable {
	private static final long serialVersionUID = 1762490489347496008L;
	
	private String cityId;			//城市ID
	private String cityName;		//城市名称
	private String countryId;		//国家id
	private String countryName;		//国家名称
	private Integer lv;				//优先级
	private String currency;			//标准币别
	private BigDecimal stayStandardAmt;	//住宿标准
	
	public String getCityId() {
		return cityId;
	}
	public void setCityId(String cityId) {
		this.cityId = cityId;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCountryId() {
		return countryId;
	}
	public void setCountryId(String countryId) {
		this.countryId = countryId;
	}
	public String getCountryName() {
		return countryName;
	}
	public void setCountryName(String countryName) {
		this.countryName = countryName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public BigDecimal getStayStandardAmt() {
		return stayStandardAmt;
	}

	public void setStayStandardAmt(BigDecimal stayStandardAmt) {
		this.stayStandardAmt = stayStandardAmt;
	}

	public Integer getLv() {
		return lv;
	}

	public void setLv(Integer lv) {
		this.lv = lv;
	}
}
