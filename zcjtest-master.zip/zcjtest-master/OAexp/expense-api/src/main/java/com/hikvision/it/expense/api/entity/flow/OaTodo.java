package com.hikvision.it.expense.api.entity.flow;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OaTodo implements Serializable {
	private static final long serialVersionUID = -5460954939370711791L;
	
	/** 唯一id */
	private String id;
	/**  taskId 主键 */
	private String unid;
	/**  当前处理人 */
	private String curdealer;
	/**  服务器名称 */
	private String servername;
	/**  数据库路径 */
	private String dbfilepath;
	/**  应用名称 */
	private String appname;
	/**  流程名称 */
	private String flowname;
	/**  流程文档ID */
	private String docid;
	/**  当前状态 */
	private String status;
	/**  上一步提交时间 */
	private String arrivetime;
	/**  上一步处理人 */
	private String predealer;
	/**  文档标题/主题 */
	private String subject;
	/**  流程优先级 */
	private String priority;
	/**  WEB域名 */
	private String webdns;
	/**  目标文档地址 */
	private String url;
	private String priorityType;
	/**  流程单号 */
	private String flowid;
	/**  申请人 */
	private String proposer;
	private String isApprove = "N";		//是否审批待办
	private List<String>  listEmpId = new ArrayList<String>();
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<String> getListEmpId() {
		return listEmpId;
	}
	public String getUnid() {
		return unid;
	}
	public void setUnid(String unid) {
		this.unid = unid;
	}
	public String getCurdealer() {
		return curdealer;
	}
	public void setCurdealer(String curdealer) {
		this.curdealer = curdealer;
	}
	public String getServername() {
		return servername;
	}
	public void setServername(String servername) {
		this.servername = servername;
	}
	public String getDbfilepath() {
		return dbfilepath;
	}
	public void setDbfilepath(String dbfilepath) {
		this.dbfilepath = dbfilepath;
	}
	public String getAppname() {
		return appname;
	}
	public void setAppname(String appname) {
		this.appname = appname;
	}
	public String getFlowname() {
		return flowname;
	}
	public void setFlowname(String flowname) {
		this.flowname = flowname;
	}
	public String getDocid() {
		return docid;
	}
	public void setDocid(String docid) {
		this.docid = docid;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getArrivetime() {
		return arrivetime;
	}
	public void setArrivetime(String arrivetime) {
		this.arrivetime = arrivetime;
	}
	public String getPredealer() {
		return predealer;
	}
	public void setPredealer(String predealer) {
		this.predealer = predealer;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getPriority() {
		return priority;
	}
	public void setPriority(String priority) {
		this.priority = priority;
	}
	public String getWebdns() {
		return webdns;
	}
	public void setWebdns(String webdns) {
		this.webdns = webdns;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getPriorityType() {
		return priorityType;
	}
	public void setPriorityType(String priorityType) {
		this.priorityType = priorityType;
	}
	public String getFlowid() {
		return flowid;
	}
	public void setFlowid(String flowid) {
		this.flowid = flowid;
	}
	public String getProposer() {
		return proposer;
	}
	public void setProposer(String proposer) {
		this.proposer = proposer;
	}
	public String getIsApprove() {
		return isApprove;
	}
	public void setIsApprove(String isApprove) {
		this.isApprove = isApprove;
	}
}
