package com.hikvision.it.expense.api.enums;

public enum ResultEnum {
	/**
	 * 提单
	 */
	SUBMIT("OK", "提单"),
	/**
	 * 同意
	 */
	AGREE("OK", "同意"),
	/**
	 * 拒绝
	 */
	REFUSE("REFUSE", "拒绝"),
	/**
	 * 驳回
	 */
	REJECT("REJECT", "驳回"),
	/**
	 * 加签
	 */
	ADDSTEP("ADDSTEP", "加签"),
	/**
	 * 转发
	 */
	FORWARD("FORWARD", "转发"),
	/**
	 * 撤销
	 */
	UNDO("REFUSE", "撤销"),
	/**
	 * 撤回
	 */
	RETRACK("REJECT", "撤回"),
	/** 
	 * 删除 
	 */
	DELETE("DELETE", "删除");
	
	private String code;
	private String desc;
	
	private ResultEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
