package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

public class HikResult<T> implements Serializable {
	private static final long serialVersionUID = -1568048151093231781L;

	private boolean success = false;		//true 成功；false 失败
	private T data;							//返回结果
	private List<String> errorMsgs;			//错误信息列表
    private int errorCode;
	private String successMessage;


	public HikResult() {
    }

    public HikResult(int errorCode) {
        this.success = false;
        this.errorCode = errorCode;
    }

    public HikResult(String errorMsg) {
        this.success = false;
        this.errorMsgs = Lists.newArrayList(errorMsg);
    }

    public HikResult(List<String> errorMsgs) {
        this.success = false;
        this.errorMsgs = errorMsgs;
    }

	public String getSuccessMessage() {
		return successMessage;
	}

	public void setSuccessMessage(String successMessage) {
		this.successMessage = successMessage;
	}

	public boolean isSuccess() {
		if (errorMsgs != null && errorMsgs.size() > 0) {
			this.success = false;
		} else {
			this.success = true;
		}
		
		return success;
	}
	public void setSuccess(boolean success) {
		this.success = success;
	}
	public T getData() {
		return data;
	}
	public void setData(T data) {
		this.data = data;
	}
	public List<String> getErrorMsgs() {
		if (errorMsgs == null) {
			errorMsgs = Lists.newArrayList();
		}
		return errorMsgs;
	}
	public void setErrorMsgs(List<String> errorMsgs) {
		this.errorMsgs = errorMsgs;
	}
	
	public static <T> HikResult<T> ok(T t) {
		HikResult<T> rs = new HikResult<T>();
		
		rs.setData(t);
		
		return rs;
	}

	public void addError(String msg) {
		if (errorMsgs == null) {
			errorMsgs = Lists.newArrayList();
		}
		errorMsgs.add(msg);
	}

    public int getErrorCode() {
        return errorCode;
    }

    public void setErrorCode(int errorCode) {
        this.errorCode = errorCode;
    }
}
