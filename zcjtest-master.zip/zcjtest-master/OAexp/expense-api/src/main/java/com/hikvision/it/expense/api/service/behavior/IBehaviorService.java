package com.hikvision.it.expense.api.service.behavior;

import java.util.List;

import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.enums.BehaviorEnum;

/**
 * 差旅行程service
 * <p>Title: ITripService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月11日
 *
 */
public interface IBehaviorService {
	/**
	 * 记录员工选择的差旅城市信息
	 * @param tripDays
	 */
	void recordSelectTripCity(TripDays tripDays);
	
	/**
	 * 记录员工选择的数据
	 * @param behavior
	 * @param opt
	 */
	void recordSelectOpt(BehaviorEnum behavior, SelectOpt opt);
	
	/**
	 * 获取员工最近使用的城市
	 * @return
	 */
	List<TripCity> findCommonUsedCity();
	
	/**
	 * 获取员工最近使用的选项
	 * @param behavior
	 * @return
	 */
	List<SelectOpt> findCommonUsedOpt(BehaviorEnum behavior);
}
