package com.hikvision.it.expense.api.entity.loan;

import java.io.Serializable;
import java.math.BigDecimal;

public class LoanDetail implements Serializable {
	private static final long serialVersionUID = 4120639758964912365L;

	private String id;				//借款明细唯一编号
	private Integer rn;				//序号
	private String loanDate;		//借款日期
	private String repaymentDate;	//到期日期
	private String paymentType;		//付款方式
	private String paymentTypeName;	//付款方式描述
	private String loanCurrency;	//借款币别
	private String loanCurrencyDesc;//借款币别描述
	private String remark;			//备注
	private String updateTime;		//更新时间
	private String applyNo;				//申请单号
	private BigDecimal amount;			//借款金额
	private BigDecimal adjustedAmount;	//会计调整金额
	private BigDecimal paymentAmount;	//付款 金额
	private BigDecimal exchangeRate;	//汇率
	private BigDecimal localAmount;		//本位币金额
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getRn() {
		return rn;
	}
	public void setRn(Integer rn) {
		this.rn = rn;
	}
	public String getLoanDate() {
		return loanDate;
	}
	public void setLoanDate(String loanDate) {
		this.loanDate = loanDate;
	}
	public String getRepaymentDate() {
		return repaymentDate;
	}
	public void setRepaymentDate(String repaymentDate) {
		this.repaymentDate = repaymentDate;
	}
	public String getPaymentType() {
		return paymentType;
	}
	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}
	public String getPaymentTypeName() {
		return paymentTypeName;
	}
	public void setPaymentTypeName(String paymentTypeName) {
		this.paymentTypeName = paymentTypeName;
	}
	public String getLoanCurrency() {
		return loanCurrency;
	}
	public void setLoanCurrency(String loanCurrency) {
		this.loanCurrency = loanCurrency;
	}

	public String getLoanCurrencyDesc() {
		return loanCurrencyDesc;
	}

	public void setLoanCurrencyDesc(String loanCurrencyDesc) {
		this.loanCurrencyDesc = loanCurrencyDesc;
	}

	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getUpdateTime() {
		return updateTime;
	}
	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}
	public String getApplyNo() {
		return applyNo;
	}
	public void setApplyNo(String applyNo) {
		this.applyNo = applyNo;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getAdjustedAmount() {
		return adjustedAmount;
	}
	public void setAdjustedAmount(BigDecimal adjustedAmount) {
		this.adjustedAmount = adjustedAmount;
	}
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public BigDecimal getLocalAmount() {
		return localAmount;
	}
	public void setLocalAmount(BigDecimal localAmount) {
		this.localAmount = localAmount;
	}
}
