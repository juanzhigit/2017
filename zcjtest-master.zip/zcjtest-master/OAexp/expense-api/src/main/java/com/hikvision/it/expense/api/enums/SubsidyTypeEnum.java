package com.hikvision.it.expense.api.enums;

public enum SubsidyTypeEnum {
	/** 租住补贴*/
	RENT("011", "租住补贴"),
	/** 误餐补贴 */
	FOOD("008", "误餐补贴"),
	/** 艰苦补贴 */
	HARD("010", "艰苦补贴"),
	/** 里程补贴 */
	LINE("014", "里程补贴"),
	/** 节假日补贴 */
	HOLI("003", "节假日补贴"),
	/** 早补贴 */
	AM("012", "早补贴"),
	/** 晚补贴 */
	PM("013", "晚补贴");
	
	private String code;
	private String desc;
	
	private SubsidyTypeEnum(String code, String desc) {
		this.code = code;
		this.desc = desc;
	}

	public String getCode() {
		return code;
	}

	public String getDesc() {
		return desc;
	}
}
