package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;
import java.util.List;

public class TaskInstance implements Cloneable, Serializable {
	private static final long serialVersionUID = -7139382436709600092L;

	private String taskId;				//任务实例编号
	private String processId;			//流程实例编号
	private String taskName;			//任务名称
	private String nodeType;			//节点类型(MANU：一般节点；LOOP：汇签环节；AUTO:自动)
	private int    versionRd;			//回合数
	private String completedBy;			//处理人
	private String completedByName;		//处理人姓名
	private String result;				//处理结果
	private String suggest;				//处理意见
	private String receivor;			//转发或者加签任务接收人 以逗号分割
	private String device;				//审批终端类型
	private String refTaskId;			//引用任务实例编号
	private String groupId;				//审批组 汇签环节的审批组id一致，其他环节审批组id不同
	private String status = "N";		//任务状态（Y：已审批；N：未审批）
	private String isFlow = "N";		//已流转（Y：已流转；N：未流转）
	private String isFrozen = "N";		//已冻结（Y：冻结；N：未冻结）
	private Long   crTime;				//创建时间毫秒
	private Long   cmTime;				//完成时间毫秒
	private Long   upTime;				//最后更新时间
	private String bpmTaskId;			//bpm任务id
	private List<TaskOwner> owners;		//任务所有人
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getProcessId() {
		return processId;
	}
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public int getVersionRd() {
		return versionRd;
	}
	public void setVersionRd(int versionRd) {
		this.versionRd = versionRd;
	}
	public String getCompletedBy() {
		return completedBy;
	}
	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}
	public String getCompletedByName() {
		return completedByName;
	}
	public void setCompletedByName(String completedByName) {
		this.completedByName = completedByName;
	}
	public String getResult() {
		return result;
	}
	public void setResult(String result) {
		this.result = result;
	}
	public String getSuggest() {
		return suggest;
	}
	public void setSuggest(String suggest) {
		this.suggest = suggest;
	}
	public String getReceivor() {
		return receivor;
	}
	public void setReceivor(String receivor) {
		this.receivor = receivor;
	}
	public String getDevice() {
		return device;
	}
	public void setDevice(String device) {
		this.device = device;
	}
	public String getRefTaskId() {
		return refTaskId;
	}
	public void setRefTaskId(String refTaskId) {
		this.refTaskId = refTaskId;
	}
	public String getGroupId() {
		return groupId;
	}
	public void setGroupId(String groupId) {
		this.groupId = groupId;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getIsFlow() {
		return isFlow;
	}
	public void setIsFlow(String isFlow) {
		this.isFlow = isFlow;
	}
	public String getIsFrozen() {
		return isFrozen;
	}
	public void setIsFrozen(String isFrozen) {
		this.isFrozen = isFrozen;
	}
	public Long getCrTime() {
		return crTime;
	}
	public void setCrTime(Long crTime) {
		this.crTime = crTime;
	}
	public Long getCmTime() {
		return cmTime;
	}
	public void setCmTime(Long cmTime) {
		this.cmTime = cmTime;
	}
	public Long getUpTime() {
		return upTime;
	}
	public void setUpTime(Long upTime) {
		this.upTime = upTime;
	}
	public String getBpmTaskId() {
		return bpmTaskId;
	}
	public void setBpmTaskId(String bpmTaskId) {
		this.bpmTaskId = bpmTaskId;
	}
	public List<TaskOwner> getOwners() {
		return owners;
	}
	public void setOwners(List<TaskOwner> owners) {
		this.owners = owners;
	}

	@Override
	public TaskInstance clone() throws CloneNotSupportedException {
		return (TaskInstance) super.clone();
	}
}
