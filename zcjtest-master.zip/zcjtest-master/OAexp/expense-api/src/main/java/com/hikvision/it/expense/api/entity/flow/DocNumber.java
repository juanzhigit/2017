package com.hikvision.it.expense.api.entity.flow;

public class DocNumber {
	private int 	year;		//年度
	private String 	isTemp;	//是否临时单号
	private int 	curNo;		//当前单号
	private int 	docLen;	//单号长度
	private String 	bukrs;		//公司代码
	private String 	docType;	//单据类别
	private String 	prefix;		//单号前缀
	
	public int getYear() {
		return year;
	}
	public void setYear(int year) {
		this.year = year;
	}
	public String getIsTemp() {
		return isTemp;
	}
	public void setIsTemp(String isTemp) {
		this.isTemp = isTemp;
	}
	public int getCurNo() {
		return curNo;
	}
	public void setCurNo(int curNo) {
		this.curNo = curNo;
	}
	public int getDocLen() {
		return docLen;
	}
	public void setDocLen(int docLen) {
		this.docLen = docLen;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getPrefix() {
		return prefix;
	}
	public void setPrefix(String prefix) {
		this.prefix = prefix;
	}
}
