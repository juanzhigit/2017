package com.hikvision.it.expense.api.service.pi;

import java.math.BigDecimal;
import java.sql.Date;
import java.util.List;

import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.user.UserBank;
import com.hikvision.it.expense.api.entity.voucher.CashierAudit;

/**
 * pi接口调用接口类
 * <p>Title: IPiService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public interface IPiService {
    /**
     * 批量根据员工编号、公司代码获取员工在该公司下的银行账号信息
     * @param users
     * @return
     */
    List<UserBank> findUserBankFromSAP(List<UserBank> users);
    
    /**
     * 批量根据员工编号、公司代码同步员工在该公司下的银行账号信息
     * @param user
     * @return
     */
    UserBank synchUserBankFromSAP(UserBank user);

    /**
     * 根据员工编号，公司代码获取员工未清明细
     * @param userId
     * @param bukrs
     * @return
     */
    List<Bsik> getBsik(String userId, String bukrs);

    /**
     * 调用接口获取sap平均汇率返回本位币金额
     * @param date
     * @param amount
     * @param currency
     * @param localCurreny
     * @return
     */
    BigDecimal getLocalAmount(Date date, BigDecimal amount, String currency, String localCurreny);

    /**
     * 从sap获取wbs项目
     * @param bukrs
     * @param filter
     * @return
     */
    List<SelectOpt> getWBSFromSap(String bukrs, String filter);

    /**
     * 获取商机接口
     * @param userId
     * @param filter
     * @return
     */
    List<SelectOpt> getBusinessOpportunityFromCRM(String userId, String filter);

    /**
     * 获取客户用户接口
     * @param userId
     * @param filter
     * @return
     */
    List<SelectOpt> getPartnerFromCRM(String userId, String filter);

    /**
     * 同步清帐状态
     * @param list
     * @return
     */
    List<CashierAudit> synchClearingStatus(List<CashierAudit> list);
}