package com.hikvision.it.expense.api.enums;

public enum NodeTypeEnum {
	/** 人工 */
	MANU,
	/** 汇签 */
	LOOP,
	/** 自动 */
	AUTO;
}
