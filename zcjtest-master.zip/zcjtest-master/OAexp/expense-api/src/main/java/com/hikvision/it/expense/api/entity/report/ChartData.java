package com.hikvision.it.expense.api.entity.report;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 图形显示数据统计entity
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/29
 * Time: 10:27
 * To change this template use File | Settings | File Templates.
 */
public class ChartData implements Serializable {
    private static final long serialVersionUID = -3880734128659433193L;
    /** 数据代码 */
    private String dataCode;
    /** 数据描述 */
    private String dataText;
    /** 数据值 */
    private BigDecimal value;

    public String getDataCode() {
        return dataCode;
    }

    public void setDataCode(String dataCode) {
        this.dataCode = dataCode;
    }

    public String getDataText() {
        return dataText;
    }

    public void setDataText(String dataText) {
        this.dataText = dataText;
    }

    public BigDecimal getValue() {
        return value;
    }

    public void setValue(BigDecimal value) {
        this.value = value;
    }
}
