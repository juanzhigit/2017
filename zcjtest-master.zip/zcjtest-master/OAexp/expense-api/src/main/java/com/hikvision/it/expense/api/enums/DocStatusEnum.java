package com.hikvision.it.expense.api.enums;

public enum DocStatusEnum {
	/** 草稿 */
	S001,
	/** 提交 */
	S002,
	/** 审批中 */
	S003,
	/** 已完成 */
	S004,
	/** 驳回 */
	S005,
	/** 拒绝 */
	S006,
	/** 撤销 */
	S100,
	/** 删除 */
	S099
}
