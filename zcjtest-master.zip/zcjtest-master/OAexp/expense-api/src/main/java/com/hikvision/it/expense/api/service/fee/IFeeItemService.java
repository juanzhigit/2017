package com.hikvision.it.expense.api.service.fee;

import java.util.List;

import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;

/**
 * 费用行项目接口
 */
public interface IFeeItemService {

    /**
     * 行项目合法校验
     * @return 错误消息列表
     */
    List<String> checkItem(FormHeader header, FeeDetail fee);

    /**
     * 查询所有行项目
     * @param docId 单据id
     * @param type stays | ofees
     */
    List<FeeDetail> findAll(String docId, String type);

    FeeDetail findOne(String id, String type);

    /**
     * 保存费用行项目
     */
    FeeDetail save(FeeDetail fee);

    /**
     * 批量保存行项目
     */
    List<FeeDetail> save(List<FeeDetail> feeList);

    /**
     * 删除行项目
     * @param id 行项目id
     * @param type stays | ofees
     */
    void delete(String id, String type);

    /**
     * 更新行项目
     * @return 新行项目
     */
    FeeDetail update(FeeDetail fee);

    /**
     * 通过行程生成住宿信息
     * @return 住宿信息
     */
    List<FeeDetail> initStaysDetail(String docId, List<FeeDetail> ctjtList);
}
