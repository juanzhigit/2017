package com.hikvision.it.expense.api.entity.dsdf;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 他人收款entity
 * <p>Title: OtherReceivor.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class OtherReceivor implements Serializable {
	private static final long serialVersionUID = -2034764891567328255L;
	
	private String id;					//唯一编号
	private String docId;				//关联单据编号
	private String docNo;				//关联单据申请号
	private String userId;				//员工编号
	private String userName;			//员工姓名
	private String bukrs;				//公司代码
	private String bukrsName;			//公司名称
	private String deptPath;			//部门路径
	private BigDecimal amount;			//金额
	private BigDecimal payAmount;		//付款金额

	// sap银行账号字段
	private String bankCode;
	private String bankName;
	private String bankAccount;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getBukrsName() {
		return bukrsName;
	}
	public void setBukrsName(String bukrsName) {
		this.bukrsName = bukrsName;
	}
	public String getDeptPath() {
		return deptPath;
	}
	public void setDeptPath(String deptPath) {
		this.deptPath = deptPath;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}

	public String getBankCode() {
		return bankCode;
	}

	public void setBankCode(String bankCode) {
		this.bankCode = bankCode;
	}

	public String getBankName() {
		return bankName;
	}

	public void setBankName(String bankName) {
		this.bankName = bankName;
	}

	public String getBankAccount() {
		return bankAccount;
	}

	public void setBankAccount(String bankAccount) {
		this.bankAccount = bankAccount;
	}
}
