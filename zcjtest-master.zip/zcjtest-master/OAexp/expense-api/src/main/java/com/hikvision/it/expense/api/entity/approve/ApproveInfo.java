package com.hikvision.it.expense.api.entity.approve;

import java.io.Serializable;
import java.util.List;

import com.hikvision.it.expense.api.entity.task.TodoInfo;

/**
 * 审批entity
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/5
 * Time: 13:47
 * To change this template use File | Settings | File Templates.
 */
public class ApproveInfo implements Serializable {
    private static final long serialVersionUID = -7367494622664642419L;
    /** 审批人 */
    private String userId;
    /** 审批人姓名 */
    private String userName;
    /** notes登陆id */
    private String notesId;
    /** 审批结果 */
    private String result;
    /** 审批意见 */
    private String comments;
    /** 审批任务list */
    private List<TodoInfo> tasks;

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getNotesId() {
        return notesId;
    }

    public void setNotesId(String notesId) {
        this.notesId = notesId;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getComments() {
        return comments;
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public List<TodoInfo> getTasks() {
        return tasks;
    }

    public void setTasks(List<TodoInfo> tasks) {
        this.tasks = tasks;
    }

    public String getUserName() {

        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }
}
