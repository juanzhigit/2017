package com.hikvision.it.expense.api.entity.form;

import java.io.Serializable;
import java.util.Date;

public class FormOtherInfo implements Serializable {
	private static final long serialVersionUID = -2491252589576005404L;

	private String cbFlag = "N";		//是否超标标识
	private String cqFlag = "N";		//是否超期标识
	private String hgjType = "N";		//核高基类别
	private String hgjFlag = "N";		//是否核高基
	private String zdjpFlag = "N";		//自定机票标识
	private String loanFlag = "N";		//借款标识
	private String txrFlag = "N";		//同行人标识
	private String hybcFlag = "N";		//会议包餐标识
	private String rantFlag = "N";		//租房标识
	private String payType = "C";		//付款方式(默认银行转账)
	private String repayFlag = "N";		//还款标识
	private String dsdfFlag = "N";		//是否代收代付
	private String pgdNo;				//派工单编号
	private String pgdUrl;				//派工单url
	private int    docYear;				//单据年度
	private int    docMonth;			//单据月度
	private Date   fphsDate;			//发票回收日期
	
	public String getCbFlag() {
		return cbFlag;
	}
	public void setCbFlag(String cbFlag) {
		this.cbFlag = cbFlag;
	}
	public String getCqFlag() {
		return cqFlag;
	}
	public void setCqFlag(String cqFlag) {
		this.cqFlag = cqFlag;
	}
	public String getHgjType() {
		return hgjType;
	}
	public void setHgjType(String hgjType) {
		this.hgjType = hgjType;
	}
	public String getHgjFlag() {
		return hgjFlag;
	}
	public void setHgjFlag(String hgjFlag) {
		this.hgjFlag = hgjFlag;
	}
	public String getZdjpFlag() {
		return zdjpFlag;
	}
	public void setZdjpFlag(String zdjpFlag) {
		this.zdjpFlag = zdjpFlag;
	}
	public String getLoanFlag() {
		return loanFlag;
	}
	public void setLoanFlag(String loanFlag) {
		this.loanFlag = loanFlag;
	}
	public String getTxrFlag() {
		return txrFlag;
	}
	public void setTxrFlag(String txrFlag) {
		this.txrFlag = txrFlag;
	}
	public String getHybcFlag() {
		return hybcFlag;
	}
	public void setHybcFlag(String hybcFlag) {
		this.hybcFlag = hybcFlag;
	}
	public String getRantFlag() {
		return rantFlag;
	}
	public void setRantFlag(String rantFlag) {
		this.rantFlag = rantFlag;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getRepayFlag() {
		return repayFlag;
	}
	public void setRepayFlag(String repayFlag) {
		this.repayFlag = repayFlag;
	}
	public String getDsdfFlag() {
		return dsdfFlag;
	}
	public void setDsdfFlag(String dsdfFlag) {
		this.dsdfFlag = dsdfFlag;
	}
	public String getPgdNo() {
		return pgdNo;
	}
	public void setPgdNo(String pgdNo) {
		this.pgdNo = pgdNo;
	}
	public String getPgdUrl() {
		return pgdUrl;
	}
	public void setPgdUrl(String pgdUrl) {
		this.pgdUrl = pgdUrl;
	}
	public int getDocYear() {
		return docYear;
	}
	public void setDocYear(int docYear) {
		this.docYear = docYear;
	}
	public int getDocMonth() {
		return docMonth;
	}
	public void setDocMonth(int docMonth) {
		this.docMonth = docMonth;
	}
	public Date getFphsDate() {
		return fphsDate;
	}
	public void setFphsDate(Date fphsDate) {
		this.fphsDate = fphsDate;
	}
}
