package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;

import com.hikvision.it.expense.api.enums.YesOrNoEnum;

public class TaskObject implements Serializable {
	private static final long serialVersionUID = 8720957465103600063L;
	
	private String processObjectId;		//流程定义编号
	private String taskName;			//任务名称
	private String taskDesc;			//任务描述
	private String nodeType;			//任务类型
	private String plugIn;				//转入
	private String plugOut;				//默认转出
	private String reject;				//驳回路径
	private String interfaces;			//转出接口实现类路径
	private String canAuto = "N";		//是否自动执行任务
	private String canShow = "Y";		//是否显示待办
	private String canBatch = "Y";		//是否可以批量审批
	private String canJump = "N";		//是否可以跳过
	private String canMoa = "Y";		//是否支持移动端审批
	private String serviceName;			//获取审批人service名称
	private boolean isShow = false;
	private boolean isBatch = false;
	private boolean isJump = false;
	private boolean isMoa = false;		
	private boolean isAuto = false;
	
	public String getProcessObjectId() {
		return processObjectId;
	}
	public void setProcessObjectId(String processObjectId) {
		this.processObjectId = processObjectId;
	}
	public String getCanAuto() {
		return canAuto;
	}
	public void setCanAuto(String canAuto) {
		this.canAuto = canAuto;
	}
	public String getCanShow() {
		return canShow;
	}
	public void setCanShow(String canShow) {
		this.canShow = canShow;
	}
	public String getCanBatch() {
		return canBatch;
	}
	public void setCanBatch(String canBatch) {
		this.canBatch = canBatch;
	}
	public String getCanJump() {
		return canJump;
	}
	public void setCanJump(String canJump) {
		this.canJump = canJump;
	}
	public String getCanMoa() {
		return canMoa;
	}
	public void setCanMoa(String canMoa) {
		this.canMoa = canMoa;
	}
	public String getTaskName() {
		return taskName;
	}
	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}
	public String getNodeType() {
		return nodeType;
	}
	public void setNodeType(String nodeType) {
		this.nodeType = nodeType;
	}
	public String getTaskDesc() {
		return taskDesc;
	}
	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}
	public String getPlugIn() {
		return plugIn;
	}
	public void setPlugIn(String plugIn) {
		this.plugIn = plugIn;
	}
	public String getPlugOut() {
		return plugOut;
	}
	public void setPlugOut(String plugOut) {
		this.plugOut = plugOut;
	}
	public String getInterfaces() {
		return interfaces;
	}
	public void setInterfaces(String interfaces) {
		this.interfaces = interfaces;
	}
	public String getReject() {
		return reject;
	}
	public void setReject(String reject) {
		this.reject = reject;
	}
	public boolean isShow() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(this.canShow)) {
			this.isShow = true;
		}
		return isShow;
	}
	public void setShow(boolean isShow) {
		this.isShow = isShow;
	}
	public boolean isBatch() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(this.canBatch)) {
			this.isBatch = true;
		}
		return isBatch;
	}
	public void setBatch(boolean isBatch) {
		this.isBatch = isBatch;
	}
	public boolean isJump() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(this.canJump)) {
			this.isJump = true;
		}
		return isJump;
	}
	public void setJump(boolean isJump) {
		this.isJump = isJump;
	}
	public boolean isMoa() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(this.canMoa)) {
			this.isMoa = true;
		}
		return isMoa;
	}
	public void setMoa(boolean isMoa) {
		this.isMoa = isMoa;
	}
	public boolean isAuto() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(this.canAuto)) {
			this.isAuto = true;
		}
		return isAuto;
	}
	public void setAuto(boolean isAuto) {
		this.isAuto = isAuto;
	}
	public String getServiceName() {
		return serviceName;
	}
	public void setServiceName(String serviceName) {
		this.serviceName = serviceName;
	}
}
