package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;

/**
 * 子公司分析维度信息
 * <p>Title: SubBukrsFxwd.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月24日
 *
 */
public class SubBukrsFxwd implements Serializable {
    private static final long serialVersionUID = -4353169640720365411L;
    /** 行业 */
    private String industryFlag;        
    /** 销售区域 */
    private String salesAreaFlag;       
    /** 交付派工 */
    private String jfpgFlag;            
    
    public String getIndustryFlag() {
        return industryFlag;
    }
    public void setIndustryFlag(String industryFlag) {
        this.industryFlag = industryFlag;
    }
    public String getSalesAreaFlag() {
        return salesAreaFlag;
    }
    public void setSalesAreaFlag(String salesAreaFlag) {
        this.salesAreaFlag = salesAreaFlag;
    }
    public String getJfpgFlag() {
        return jfpgFlag;
    }
    public void setJfpgFlag(String jfpgFlag) {
        this.jfpgFlag = jfpgFlag;
    }
}
