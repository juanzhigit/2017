package com.hikvision.it.expense.api.service.execute;

import com.hikvision.it.expense.api.entity.task.TaskObject;

/**
 * 流程任务流转配置服务接口
 * <p>Title: IExecuteService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月17日
 *
 */
public interface IExecutePlugService {
	/**
	 * 执行任务配置服务
	 * @param taskObject
	 * @param docId
	 * @return
	 */
	String execute(TaskObject taskObject, String docId);
}
