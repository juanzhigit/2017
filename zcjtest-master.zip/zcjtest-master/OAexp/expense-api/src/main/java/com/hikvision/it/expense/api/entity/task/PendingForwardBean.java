package com.hikvision.it.expense.api.entity.task;


import java.io.Serializable;
import java.sql.Date;

/**
 * 财务待办转发
 * @author zhongchaojie
 *
 */
public class PendingForwardBean implements Serializable {

	private static final long serialVersionUID = 129615598560265241L;
	private String applyid; //流程单号
	private String claimUserName;		//申请人姓名
	private String claimuser;		//申请人编号
	private String createtime;		//到达财务日期
	private Date subdate; //提交日期

	private Double amtclaim; // 金额
	private String curCredit;//信用等级
	private String zlts;//滞留天数
	private String docId;				//报销单号
	private String processId;			//流程编码
	private String taskId; // 任务唯一编号
	private String forwardSelect; // 流转接收人

	//扩展字段
	private String forwardType ;  //1为根据人员转发 2为根据单号转发
	private String userIdOrName ; //域账号或员工id
	private String processIds ; //需要批量转发的申请id拼接
	private String applyids ; //需要批量转发的流程id拼接
	//用于转发页面的页面传值,也可做他用,为无特殊意义字段
	private String id;
	private String text;

	public String getClaimuser() {
		return claimuser;
	}

	public void setClaimuser(String claimuser) {
		this.claimuser = claimuser;
	}

	public Date getSubdate() {
		return subdate;
	}

	public void setSubdate(Date subdate) {
		this.subdate = subdate;
	}

	public String getForwardSelect() {
		return forwardSelect;
	}

	public void setForwardSelect(String forwardSelect) {
		this.forwardSelect = forwardSelect;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getForwardType() {
		return forwardType;
	}

	public void setForwardType(String forwardType) {
		this.forwardType = forwardType;
	}

	public String getProcessIds() {
		return processIds;
	}

	public void setProcessIds(String processIds) {
		this.processIds = processIds;
	}

	public String getUserIdOrName() {
		return userIdOrName;
	}

	public void setUserIdOrName(String userIdOrName) {
		this.userIdOrName = userIdOrName;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public String getProcessId() {
		return processId;
	}

	public void setProcessId(String processId) {
		this.processId = processId;
	}

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getApplyid() {
		return applyid;
	}

	public void setApplyid(String applyid) {
		this.applyid = applyid;
	}

	public String getClaimUserName() {
		return claimUserName;
	}

	public void setClaimUserName(String claimUserName) {
		this.claimUserName = claimUserName;
	}



	public String getCreatetime() {
		return createtime;
	}

	public void setCreatetime(String createtime) {
		this.createtime = createtime;
	}

	public Double getAmtclaim() {
		return amtclaim;
	}

	public void setAmtclaim(Double amtclaim) {
		this.amtclaim = amtclaim;
	}

	public String getCurCredit() {
		return curCredit;
	}

	public void setCurCredit(String curCredit) {
		this.curCredit = curCredit;
	}

	public String getZlts() {
		return zlts;
	}

	public void setZlts(String zlts) {
		this.zlts = zlts;
	}

	public String getApplyids() {
		return applyids;
	}

	public void setApplyids(String applyids) {
		this.applyids = applyids;
	}
}
