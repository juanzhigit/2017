package com.hikvision.it.expense.api.service.fee;

import java.util.List;

import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.fee.DeductionInfo;
import com.hikvision.it.expense.api.entity.fee.ExpensedTrafficFee;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;

/**
 * 费用记录接口定义
 * <p>Title: IFeeService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月19日
 *
 */
public interface IFeeService {
	/**
	 * 获取未报销费用统计信息，用于图标展示
	 * @param userId
	 * @return
	 */
	List<ChartData> listUnExpenseFeeDataForChart(String userId);
	
	/**
	 * 获取所有未报销的车补信息
	 * @param userId
	 * @return
	 */
	List<FeeDetail> listUnExpensedCarSubsidy(String userId);
	
	/**
	 * 获取所有未报销的生育费用信息
	 * @param userId
	 * @return
	 */
	List<FeeDetail> listUnExpensedBirthInfo(String userId);
	
	/**
	 * 校验费用是否超期超标，返回费用信息
	 * @param header    表头信息
	 * @param feeDetail	费用信息
	 * @return
	 */
	FeeDetail checkFeeStatus(FormHeader header, FeeDetail feeDetail);

	/**
	 * 获取员工指定年月已报销市内交通费用
	 */
	List<ExpensedTrafficFee> getExpensedTrafficFees(String userId, String year, String month);

	/**
	 * 获取扣减信息
	 */
	GridData<DeductionInfo> getDeductionInfos(String userId, String docId);

	/**
	 * 保存扣减信息
	 */
	void saveDeductionInfos(String docId, List<DeductionInfo> list);
}
