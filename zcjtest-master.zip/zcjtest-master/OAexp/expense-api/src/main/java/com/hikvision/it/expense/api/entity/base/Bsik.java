package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 未清明细entity
 * <p>Title: Bsik.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class Bsik implements Serializable {
	private static final long serialVersionUID = -3818530558886346289L;
	
	private String bukrs;
    private String lifnr;
    private String umskz;
    private String zuonr;
    private String gjahr;
    private String belnr;
    private String buzei;
    private String budat;
    private String bldat;
    private String cpudt;
    private String waers;
    private String xblnr;
    private String blart;
    private String monat;
    private String bschl;
    private String zumsk;
    private String shkzg;
    private String gsber;
    private String mwskz;
    private BigDecimal dmbtr;
    private BigDecimal wrbtr;
    private String sgtxt;
    private String aufnr;
    private String anln1;
    private String anln2;
    private String ebeln;
    private String ebelp;
    private String saknr;
    private String hkont;
    private String zfbdt;
    private String zterm;
    private BigDecimal zbd1T;
    private BigDecimal zbd2T;
    private BigDecimal zbd3T;
    private BigDecimal zbd1P;
    private BigDecimal zbd2P;
    private BigDecimal skfbt;
    private String rebzg;
    private String projk;
    private String xref1;
    
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getLifnr() {
		return lifnr;
	}
	public void setLifnr(String lifnr) {
		this.lifnr = lifnr;
	}
	public String getUmskz() {
		return umskz;
	}
	public void setUmskz(String umskz) {
		this.umskz = umskz;
	}
	public String getZuonr() {
		return zuonr;
	}
	public void setZuonr(String zuonr) {
		this.zuonr = zuonr;
	}
	public String getGjahr() {
		return gjahr;
	}
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}
	public String getBelnr() {
		return belnr;
	}
	public void setBelnr(String belnr) {
		this.belnr = belnr;
	}
	public String getBuzei() {
		return buzei;
	}
	public void setBuzei(String buzei) {
		this.buzei = buzei;
	}
	public String getBudat() {
		return budat;
	}
	public void setBudat(String budat) {
		this.budat = budat;
	}
	public String getBldat() {
		return bldat;
	}
	public void setBldat(String bldat) {
		this.bldat = bldat;
	}
	public String getCpudt() {
		return cpudt;
	}
	public void setCpudt(String cpudt) {
		this.cpudt = cpudt;
	}
	public String getWaers() {
		return waers;
	}
	public void setWaers(String waers) {
		this.waers = waers;
	}
	public String getXblnr() {
		return xblnr;
	}
	public void setXblnr(String xblnr) {
		this.xblnr = xblnr;
	}
	public String getBlart() {
		return blart;
	}
	public void setBlart(String blart) {
		this.blart = blart;
	}
	public String getMonat() {
		return monat;
	}
	public void setMonat(String monat) {
		this.monat = monat;
	}
	public String getBschl() {
		return bschl;
	}
	public void setBschl(String bschl) {
		this.bschl = bschl;
	}
	public String getZumsk() {
		return zumsk;
	}
	public void setZumsk(String zumsk) {
		this.zumsk = zumsk;
	}
	public String getShkzg() {
		return shkzg;
	}
	public void setShkzg(String shkzg) {
		this.shkzg = shkzg;
	}
	public String getGsber() {
		return gsber;
	}
	public void setGsber(String gsber) {
		this.gsber = gsber;
	}
	public String getMwskz() {
		return mwskz;
	}
	public void setMwskz(String mwskz) {
		this.mwskz = mwskz;
	}
	public BigDecimal getDmbtr() {
		return dmbtr;
	}
	public void setDmbtr(BigDecimal dmbtr) {
		this.dmbtr = dmbtr;
	}
	public BigDecimal getWrbtr() {
		return wrbtr;
	}
	public void setWrbtr(BigDecimal wrbtr) {
		this.wrbtr = wrbtr;
	}
	public String getSgtxt() {
		return sgtxt;
	}
	public void setSgtxt(String sgtxt) {
		this.sgtxt = sgtxt;
	}
	public String getAufnr() {
		return aufnr;
	}
	public void setAufnr(String aufnr) {
		this.aufnr = aufnr;
	}
	public String getAnln1() {
		return anln1;
	}
	public void setAnln1(String anln1) {
		this.anln1 = anln1;
	}
	public String getAnln2() {
		return anln2;
	}
	public void setAnln2(String anln2) {
		this.anln2 = anln2;
	}
	public String getEbeln() {
		return ebeln;
	}
	public void setEbeln(String ebeln) {
		this.ebeln = ebeln;
	}
	public String getEbelp() {
		return ebelp;
	}
	public void setEbelp(String ebelp) {
		this.ebelp = ebelp;
	}
	public String getSaknr() {
		return saknr;
	}
	public void setSaknr(String saknr) {
		this.saknr = saknr;
	}
	public String getHkont() {
		return hkont;
	}
	public void setHkont(String hkont) {
		this.hkont = hkont;
	}
	public String getZfbdt() {
		return zfbdt;
	}
	public void setZfbdt(String zfbdt) {
		this.zfbdt = zfbdt;
	}
	public String getZterm() {
		return zterm;
	}
	public void setZterm(String zterm) {
		this.zterm = zterm;
	}
	public BigDecimal getZbd1T() {
		return zbd1T;
	}
	public void setZbd1T(BigDecimal zbd1t) {
		zbd1T = zbd1t;
	}
	public BigDecimal getZbd2T() {
		return zbd2T;
	}
	public void setZbd2T(BigDecimal zbd2t) {
		zbd2T = zbd2t;
	}
	public BigDecimal getZbd3T() {
		return zbd3T;
	}
	public void setZbd3T(BigDecimal zbd3t) {
		zbd3T = zbd3t;
	}
	public BigDecimal getZbd1P() {
		return zbd1P;
	}
	public void setZbd1P(BigDecimal zbd1p) {
		zbd1P = zbd1p;
	}
	public BigDecimal getZbd2P() {
		return zbd2P;
	}
	public void setZbd2P(BigDecimal zbd2p) {
		zbd2P = zbd2p;
	}
	public BigDecimal getSkfbt() {
		return skfbt;
	}
	public void setSkfbt(BigDecimal skfbt) {
		this.skfbt = skfbt;
	}
	public String getRebzg() {
		return rebzg;
	}
	public void setRebzg(String rebzg) {
		this.rebzg = rebzg;
	}
	public String getProjk() {
		return projk;
	}
	public void setProjk(String projk) {
		this.projk = projk;
	}
	public String getXref1() {
		return xref1;
	}
	public void setXref1(String xref1) {
		this.xref1 = xref1;
	}
}
