package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

/**
 * 下拉选项公共entity
 * <p>Title: SelectOpt.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月2日
 *
 */
public class SelectOpt implements Serializable {
	private static final long serialVersionUID = 6864600855258115681L;
	
	private String id;						//ID
	private String text;					//描述
	private String upId;					//上级id
	private String behavior;				//数据选择类别
	private String userId;					//操作人
	private String userName;				//操作人姓名
	private long   upTime;					//操作时间
	private List<SelectOpt> subOpt;			//子选项

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getText() {
		return text;
	}

	public void setText(String text) {
		this.text = text;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public long getUpTime() {
		return upTime;
	}

	public void setUpTime(long upTime) {
		this.upTime = upTime;
	}

	public String getUpId() {
		return upId;
	}

	public void setUpId(String upId) {
		this.upId = upId;
	}

	public List<SelectOpt> getSubOpt() {
		if (subOpt == null)
			subOpt = new ArrayList<SelectOpt>();
		return subOpt;
	}

	public String getBehavior() {
		return behavior;
	}

	public void setBehavior(String behavior) {
		this.behavior = behavior;
	}

	public void setSubOpt(List<SelectOpt> subOpt) {
		this.subOpt = subOpt;
	}
}
