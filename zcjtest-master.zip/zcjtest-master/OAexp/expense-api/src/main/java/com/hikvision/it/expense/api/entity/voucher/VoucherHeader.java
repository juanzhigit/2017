package com.hikvision.it.expense.api.entity.voucher;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 凭证抬头entity
 * <p>Title: VoucherHeader.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class VoucherHeader implements Serializable {
	private static final long serialVersionUID = -818232266776106127L;

	private String headerId; 				// 凭证唯一编号
	private String docId; 					// 任务编号
	private String docNo; 					// 单据号
	private int rn; 						// 凭证序列
	private String userId; 					// 报销人代码
	private String userName;		 		// 报销人姓名
	private String deptType; 				// 部门标识
	private String belnr; 					// 会计凭证编号(过账时设置报销系统申请单号)
	private String bukrs; 					// 公司代码
	private String docDate; 				// 凭证日期
	private String voucherType; 			// 凭证类型
	private String pstngDate; 				// 过账日期
	private String pstngUserId; 			// 过账人
	private String pstngUsername; 			// 过账人姓名
	private String currency; 				// 货币码
	private String refDocNo; 				// 参考凭证号(过账时设置申请单号+凭证序列)
	private String headerTxt; 				// 凭证抬头
	private String usnam; 					// 过账人员
	private String fflag; 					// 过账状态
	private String msg; 					// 返回消息文本
	private String postPeriod; 				// 过账期间
	private BigDecimal amount; 				// 审核金额
	private BigDecimal brtAmount; 			// 未清金额
	private BigDecimal dqwqAmount; 			// 到期未清金额
	private BigDecimal clrAmount; 			// 本次清账金额
	private String fiOrderStatus; 			// 财务单据状态
	private String acctMethod; 				// 过账方式(默认手工)
	
	public String getHeaderId() {
		return headerId;
	}
	public void setHeaderId(String headerId) {
		this.headerId = headerId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public int getRn() {
		return rn;
	}
	public void setRn(int rn) {
		this.rn = rn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDeptType() {
		return deptType;
	}
	public void setDeptType(String deptType) {
		this.deptType = deptType;
	}
	public String getBelnr() {
		return belnr;
	}
	public void setBelnr(String belnr) {
		this.belnr = belnr;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getDocDate() {
		return docDate;
	}
	public void setDocDate(String docDate) {
		this.docDate = docDate;
	}
	public String getVoucherType() {
		return voucherType;
	}
	public void setVoucherType(String voucherType) {
		this.voucherType = voucherType;
	}
	public String getPstngDate() {
		return pstngDate;
	}
	public void setPstngDate(String pstngDate) {
		this.pstngDate = pstngDate;
	}
	public String getPstngUserId() {
		return pstngUserId;
	}
	public void setPstngUserId(String pstngUserId) {
		this.pstngUserId = pstngUserId;
	}
	public String getPstngUsername() {
		return pstngUsername;
	}
	public void setPstngUsername(String pstngUsername) {
		this.pstngUsername = pstngUsername;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getRefDocNo() {
		return refDocNo;
	}
	public void setRefDocNo(String refDocNo) {
		this.refDocNo = refDocNo;
	}
	public String getHeaderTxt() {
		return headerTxt;
	}
	public void setHeaderTxt(String headerTxt) {
		this.headerTxt = headerTxt;
	}
	public String getUsnam() {
		return usnam;
	}
	public void setUsnam(String usnam) {
		this.usnam = usnam;
	}
	public String getFflag() {
		return fflag;
	}
	public void setFflag(String fflag) {
		this.fflag = fflag;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}
	public String getPostPeriod() {
		return postPeriod;
	}
	public void setPostPeriod(String postPeriod) {
		this.postPeriod = postPeriod;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getBrtAmount() {
		return brtAmount;
	}
	public void setBrtAmount(BigDecimal brtAmount) {
		this.brtAmount = brtAmount;
	}
	public BigDecimal getDqwqAmount() {
		return dqwqAmount;
	}
	public void setDqwqAmount(BigDecimal dqwqAmount) {
		this.dqwqAmount = dqwqAmount;
	}
	public BigDecimal getClrAmount() {
		return clrAmount;
	}
	public void setClrAmount(BigDecimal clrAmount) {
		this.clrAmount = clrAmount;
	}
	public String getFiOrderStatus() {
		return fiOrderStatus;
	}
	public void setFiOrderStatus(String fiOrderStatus) {
		this.fiOrderStatus = fiOrderStatus;
	}
	public String getAcctMethod() {
		return acctMethod;
	}
	public void setAcctMethod(String acctMethod) {
		this.acctMethod = acctMethod;
	}
}
