package com.hikvision.it.expense.api.entity.allowance;

import java.io.Serializable;
import java.sql.Date;

import com.google.common.base.Strings;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;

/**
 * 节假日工作标识entity
 * <p>Title: HolidayWork.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class HolidayWork implements Serializable {
	private static final long serialVersionUID = -1788406078669953857L;

	private Date workDate;		//工作日期
	private String workFlag;	//是否工作标识
	private boolean isWork;		//是否工作
	
	public Date getWorkDate() {
		return workDate;
	}
	public void setWorkDate(Date workDate) {
		this.workDate = workDate;
	}
	public String getWorkFlag() {
		return workFlag;
	}
	public void setWorkFlag(String workFlag) {
		this.workFlag = workFlag;
	}
	public boolean isWork() {
		isWork = !Strings.isNullOrEmpty(workFlag) &&
				YesOrNoEnum.Y.name().equalsIgnoreCase(workFlag);

		return isWork;
	}
	public void setWork(boolean isWork) {
		this.isWork = isWork;
	}
}
