package com.hikvision.it.expense.api.entity.voucher;

import java.io.Serializable;
import java.util.List;

import com.google.common.collect.Lists;

/**
 * 凭证entity 包含凭证抬头和凭证行项目
 * <p>Title: Voucher.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月10日
 *
 */
public class Voucher implements Serializable {
	private static final long serialVersionUID = 4275566419380117619L;
	
	private VoucherHeader voucherHeader;
	private List<VoucherItem> voucherItems = Lists.newArrayList();
	
	public VoucherHeader getVoucherHeader() {
		return voucherHeader;
	}
	public void setVoucherHeader(VoucherHeader voucherHeader) {
		this.voucherHeader = voucherHeader;
	}
	public List<VoucherItem> getVoucherItems() {
		return voucherItems;
	}
	public void setVoucherItems(List<VoucherItem> voucherItems) {
		this.voucherItems = voucherItems;
	}
}
