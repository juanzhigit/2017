package com.hikvision.it.expense.api.entity.flow;

import java.math.BigDecimal;
import java.sql.Date;

import com.hikvision.it.expense.api.enums.YesOrNoEnum;

public class FinalApproveConfig {
	private int 		grade;			//人员级别
	private String 		area;			//权限范围
	private String 		bigFeeType;		//业务大类
	private String 		smaFeeType;		//业务细类
	private BigDecimal 	minJe;			//起批金额
	private BigDecimal 	maxJe;			//最大审批金额
	private Date   		fromDate;		//有效起始日期
	private Date  		toDate;			//有效截止日期
	private String   	authFlag;		//是否可以授权标识
	private String 		validFlag;		//是否有效标识
	private boolean 	isValid;		//是否有效
	private boolean		canAuth;		//是否可以授权
	
	public int getGrade() {
		return grade;
	}
	public void setGrade(int grade) {
		this.grade = grade;
	}
	public String getArea() {
		return area;
	}
	public void setArea(String area) {
		this.area = area;
	}
	public String getBigFeeType() {
		return bigFeeType;
	}
	public void setBigFeeType(String bigFeeType) {
		this.bigFeeType = bigFeeType;
	}
	public String getSmaFeeType() {
		return smaFeeType;
	}
	public void setSmaFeeType(String smaFeeType) {
		this.smaFeeType = smaFeeType;
	}
	public BigDecimal getMinJe() {
		return minJe;
	}
	public void setMinJe(BigDecimal minJe) {
		this.minJe = minJe;
	}
	public BigDecimal getMaxJe() {
		return maxJe;
	}
	public void setMaxJe(BigDecimal maxJe) {
		this.maxJe = maxJe;
	}
	public Date getFromDate() {
		return fromDate;
	}
	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}
	public Date getToDate() {
		return toDate;
	}
	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}
	public String getValidFlag() {
		return validFlag;
	}
	public void setValidFlag(String validFlag) {
		this.validFlag = validFlag;
	}
	public boolean isValid() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(validFlag)) {
			this.isValid = true;
		}
		return isValid;
	}
	public void setValid(boolean isValid) {
		this.isValid = isValid;
	}
	public String getAuthFlag() {
		return authFlag;
	}
	public void setAuthFlag(String authFlag) {
		this.authFlag = authFlag;
	}
	public boolean isCanAuth() {
		if (YesOrNoEnum.Y.name().equalsIgnoreCase(authFlag)) {
			this.canAuth = true;
		}
		return canAuth;
	}
	public void setCanAuth(boolean canAuth) {
		this.canAuth = canAuth;
	}

}
