package com.hikvision.it.expense.api.entity.batch;

import java.util.List;

import com.google.common.collect.Lists;

public class PayParams {

	private List<PayHead> heads = Lists.newArrayList();
	private List<String> selects = Lists.newArrayList();
	
	public List<PayHead> getHeads() {
		return heads;
	}
	public void setHeads(List<PayHead> heads) {
		this.heads = heads;
	}
	public List<String> getSelects() {
		return selects;
	}
	public void setSelects(List<String> selects) {
		this.selects = selects;
	}
	
}
