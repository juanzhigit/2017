package com.hikvision.it.expense.api.enums;

public enum ProcessStatusEnum {
	/** 已创建，已启动 */
	START("S", "已创建，已启动"),
	/** 已创建，未启动 */
	DEFAULT("D", "已创建，未启动");

	private String key;
	private String desc;
	
	private ProcessStatusEnum(String key, String desc) {
		this.key = key;
		this.desc = desc;
	}

	public String getKey() {
		return key;
	}

	public String getDesc() {
		return desc;
	}
}
