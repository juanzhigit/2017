package com.hikvision.it.expense.api.entity.user;

import java.io.Serializable;

import com.hikvision.it.expense.api.enums.DeviceEnum;

/**
 * 登陆用户entity
 * <p>Title: LoginUser.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class LoginUser implements Serializable {
	private static final long serialVersionUID = 912657119734171989L;
	private String userId;			//员工id
    private String userName;		//员工姓名
    private String userGrade;		//员工级别
    private String sapAccount;		//sap账号
    private boolean branch;         //分公司标记
    private String notesId;			//登陆id
    private String language;		//语言
    private DeviceEnum device;		//登陆设备
    
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getSapAccount() {
		return sapAccount;
	}
	public void setSapAccount(String sapAccount) {
		this.sapAccount = sapAccount;
	}

    public boolean isBranch() {
        return branch;
    }

    public void setBranch(boolean branch) {
        this.branch = branch;
    }

    public String getNotesId() {
		return notesId;
	}
	public void setNotesId(String notesId) {
		this.notesId = notesId;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public DeviceEnum getDevice() {
		return device;
	}
	public void setDevice(DeviceEnum device) {
		this.device = device;
	}
	public String getUserGrade() {
		return userGrade;
	}
	public void setUserGrade(String userGrade) {
		this.userGrade = userGrade;
	}
}
