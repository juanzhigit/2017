package com.hikvision.it.expense.api.entity.trip;

import java.io.Serializable;
import java.sql.Date;

public class TripDays implements Serializable {
	private static final long serialVersionUID = -1637243218468427358L;
	
	private String id;						//数据唯一编号
	private String docId;					//申请单唯一编号
	private String docNo;					//申请单号
	private String userId;					//员工编号
	private String userName;				//员工姓名
	private Date   tripDate;				//差旅日期
	private String tripCountry;				//国家代码
	private String tripCity;				//城市代码
	private String tripCityDesc;			//城市描述
	private String workFlag;				//是否工作标识
	private long   upTime;					//更新时间
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getTripDate() {
		return tripDate;
	}
	public void setTripDate(Date tripDate) {
		this.tripDate = tripDate;
	}
	public String getTripCountry() {
		return tripCountry;
	}
	public void setTripCountry(String tripCountry) {
		this.tripCountry = tripCountry;
	}
	public String getTripCity() {
		return tripCity;
	}
	public void setTripCity(String tripCity) {
		this.tripCity = tripCity;
	}
	public String getTripCityDesc() {
		return tripCityDesc;
	}
	public void setTripCityDesc(String tripCityDesc) {
		this.tripCityDesc = tripCityDesc;
	}
	public String getWorkFlag() {
		return workFlag;
	}
	public void setWorkFlag(String workFlag) {
		this.workFlag = workFlag;
	}
	public long getUpTime() {
		return upTime;
	}
	public void setUpTime(long upTime) {
		this.upTime = upTime;
	}
}
