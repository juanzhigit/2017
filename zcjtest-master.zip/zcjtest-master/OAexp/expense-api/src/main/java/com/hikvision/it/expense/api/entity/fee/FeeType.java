package com.hikvision.it.expense.api.entity.fee;

public class FeeType {
	/** 其他费用 */
	public static final String OTHER = "OTHER";
	/** 市内交通 */
	public static final String SNJT = "SNJT";
	/** 长途交通 */
	public static final String CTJT = "CTJT";
	/** 房屋租赁 */
	public static final String FWZL = "FWZL";
    /** 住宿 */
    public static final String STAYS = "STAYS";
	/** 车辆补贴 */
	public static final String CLBT = "CLBT";
	/** 业务招待 */
	public static final String YWZD = "YWZD";
	/** 生育报销 */
	public static final String SYBX = "SYBX";
	/** 市内派车 */
	public static final String SNPC = "SNPC";
}
