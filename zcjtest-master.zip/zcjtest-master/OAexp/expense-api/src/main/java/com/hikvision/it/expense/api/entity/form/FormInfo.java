package com.hikvision.it.expense.api.entity.form;

import java.io.Serializable;
import java.util.List;

import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.history.ApproveHistory;
import com.hikvision.it.expense.api.entity.loan.LoanDetail;
import com.hikvision.it.expense.api.entity.oa.SqpgDoc;
import com.hikvision.it.expense.api.entity.trip.TravelReport;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.entity.trip.TripTogether;

/**
 * 单据信息
 * <p>Title: DocInfo.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月3日
 *
 */
public class FormInfo implements Serializable {
	private static final long serialVersionUID = -8981909719100578372L;

	private String taskId;				//任务编号
	private long   attachNumber;		//附件数量
	
	private FormHeader formHeader;		//表单抬头
	private FormOtherInfo formOther;	//表单扩展信息
	
	private List<Trip> 			 trips;						//差旅行程明细
	private List<LoanDetail> 	 loans;						//借款明细
	private List<TripTogether> 	 tripTogethers;				//同行人明细

	private List<FeeDetail>		 insideCityDriverFees;      //市内派车费用明细
	private List<FeeDetail>      longDistanceTrafficFees;	//长途交通费用明细
	private List<FeeDetail> 	 cityTrafficFees;			//市内交通费用明细
	private List<FeeDetail>	     entertainFees;				//业务招待费用明细
	private List<FeeDetail> 	 birthFees;					//生育费用明细
	private List<FeeDetail> 	 carAllowanceFees;			//车补费用明细
	private List<FeeDetail> 	 rentFees;					//租房费用明细
	private List<FeeDetail> 	 staysFees;					//住宿费用明细
	private List<FeeDetail> 	 otherFees;					//其他费用明细
	private List<TripDays>       tripDays;					//每天行程明细
	
	private List<FeeDetail>      allFees;					//所有费用明细 包含以上各类费用明细

    private List<OtherReceivor> otherReceivers;             // 他人收款列表

	private List<ApproveHistory> historys;					//单据审批历史

    private TravelReport travelReport;                      // 差旅报告

    private List<OverproofInfo>  overproofs;
    private List<SqpgDoc> sqpgDocs;

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public long getAttachNumber() {
		return attachNumber;
	}

	public void setAttachNumber(long attachNumber) {
		this.attachNumber = attachNumber;
	}

	public FormHeader getFormHeader() {
		return formHeader;
	}

	public void setFormHeader(FormHeader formHeader) {
		this.formHeader = formHeader;
	}

	public FormOtherInfo getFormOther() {
		return formOther;
	}

	public void setFormOther(FormOtherInfo formOther) {
		this.formOther = formOther;
	}

	public List<Trip> getTrips() {
		return trips;
	}

	public void setTrips(List<Trip> trips) {
		this.trips = trips;
	}

	public List<LoanDetail> getLoans() {
		return loans;
	}

	public void setLoans(List<LoanDetail> loans) {
		this.loans = loans;
	}

	public List<TripTogether> getTripTogethers() {
		return tripTogethers;
	}

	public void setTripTogethers(List<TripTogether> tripTogethers) {
		this.tripTogethers = tripTogethers;
	}

    public List<FeeDetail> getInsideCityDriverFees() {
        return insideCityDriverFees;
    }

    public void setInsideCityDriverFees(List<FeeDetail> insideCityDriverFees) {
        this.insideCityDriverFees = insideCityDriverFees;
    }

    public List<FeeDetail> getLongDistanceTrafficFees() {
		return longDistanceTrafficFees;
	}

	public void setLongDistanceTrafficFees(List<FeeDetail> longDistanceTrafficFees) {
		this.longDistanceTrafficFees = longDistanceTrafficFees;
	}

	public List<FeeDetail> getCityTrafficFees() {
		return cityTrafficFees;
	}

	public void setCityTrafficFees(List<FeeDetail> cityTrafficFees) {
		this.cityTrafficFees = cityTrafficFees;
	}

    public List<FeeDetail> getEntertainFees() {
        return entertainFees;
    }

    public void setEntertainFees(List<FeeDetail> entertainFees) {
        this.entertainFees = entertainFees;
    }

    public List<FeeDetail> getBirthFees() {
		return birthFees;
	}

	public void setBirthFees(List<FeeDetail> birthFees) {
		this.birthFees = birthFees;
	}

	public List<FeeDetail> getCarAllowanceFees() {
		return carAllowanceFees;
	}

	public void setCarAllowanceFees(List<FeeDetail> carAllowanceFees) {
		this.carAllowanceFees = carAllowanceFees;
	}

	public List<FeeDetail> getRentFees() {
		return rentFees;
	}

	public void setRentFees(List<FeeDetail> rentFees) {
		this.rentFees = rentFees;
	}

	public List<FeeDetail> getOtherFees() {
		return otherFees;
	}

	public void setOtherFees(List<FeeDetail> otherFees) {
		this.otherFees = otherFees;
	}

	public List<FeeDetail> getAllFees() {
		return allFees;
	}

	public void setAllFees(List<FeeDetail> allFees) {
		this.allFees = allFees;
	}

    public List<OtherReceivor> getOtherReceivers() {
        return otherReceivers;
    }

    public void setOtherReceivers(List<OtherReceivor> otherReceivers) {
        this.otherReceivers = otherReceivers;
    }

    public List<ApproveHistory> getHistorys() {
		return historys;
	}

	public void setHistorys(List<ApproveHistory> historys) {
		this.historys = historys;
	}

	public List<FeeDetail> getStaysFees() {
		return staysFees;
	}

	public void setStaysFees(List<FeeDetail> staysFees) {
		this.staysFees = staysFees;
	}

	public List<TripDays> getTripDays() {
		return tripDays;
	}

	public void setTripDays(List<TripDays> tripDays) {
		this.tripDays = tripDays;
	}

    public TravelReport getTravelReport() {
        return travelReport;
    }

    public void setTravelReport(TravelReport travelReport) {
        this.travelReport = travelReport;
    }

    public List<OverproofInfo> getOverproofs() {
        return overproofs;
    }

    public void setOverproofs(List<OverproofInfo> overproofs) {
        this.overproofs = overproofs;
    }

    public List<SqpgDoc> getSqpgDocs() {
        return sqpgDocs;
    }

    public void setSqpgDocs(List<SqpgDoc> sqpgDocs) {
        this.sqpgDocs = sqpgDocs;
    }
    
    /**
     * 是否未填写任何费用
     * @return
     */
    public boolean isEmptyFee() {
        return checkEmpty(birthFees) &&
               checkEmpty(carAllowanceFees) &&
               checkEmpty(cityTrafficFees) &&
               checkEmpty(entertainFees) &&
               checkEmpty(insideCityDriverFees) &&
               checkEmpty(otherFees) &&
               checkEmpty(rentFees) &&
               checkEmpty(staysFees) &&
			   checkEmpty(longDistanceTrafficFees);
    }

    private boolean checkEmpty(List<FeeDetail> feeDetails) {
    	return feeDetails == null || feeDetails.size() == 0;
	}
}
