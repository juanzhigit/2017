package com.hikvision.it.expense.api.entity.fee;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 费用明细entity
 * <p>Title: FeeDetail.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class FeeDetail implements Serializable {
	private static final long serialVersionUID = -6281546202001588945L;

	private String id; 				// 明细唯一编号
	private String docId;			// 报销编号
	private String docNo;			// 报销单号
	private Integer rn; 			// 序号
	private String feeType;			// 费用类别
	private String feeTypeName; 	// 费用类别名称		市内交通、长途交通、车补……
	private String feeFromDate; 	// 费用起始日期
	private String feeToDate; 		// 费用截止日期
	private String bigFeeType;		// 费用大类
	private String bigFeeTypeName; 	// 费用大类名称
	private String smaFeeType; 		// 费用小类
	private String smaFeeTypeName; 	// 费用小类名称
	private String subject;			// 科目代码
	private String subjectName;		// 科目描述
	private String taxSubject;		// 税分科目代码
	private String taxSubjectName;	// 税分科目描述

	private String fromTime;		//出发时间
	private String toTime;			//到达时间

	private String placeFrom;		//出发城市
	private String placeFromDesc;	//出发国家、城市描述
	private String placeTo;			//到达城市
	private String placeToDesc;		//到达国家、城市描述
	private String countryFrom;		//出发国家
	private String countryTo;		//达到国家

	private String trafficToolType;		//交通工具类别
	private String trafficToolLevel;	//交通工具级别
	private String trafficToolLevelDesc;//佳通工具级别描述

	private String rentType;		// 是否租住
	private String rentCity;		// 住宿城市
	private String rentCountry;		// 住宿国家
	private String rentCityDesc;	// 住宿城市描述
	private int    rentDays;		// 住宿天数
	private int    rentRooms;		// 住宿房间数

	private String currency; 		// 币种
	private String currencyDesc; 	// 币种描述
	private String remark; 			// 行程、事由
	private String flag; 			// 数据标识
	private String upTime; 			// 修改时间

	private BigDecimal exchangeRate;		// 汇率
	private BigDecimal taxRate;				// 税率
	private BigDecimal taxAmount;			// 税额
	private BigDecimal noTaxAmount;			// 不含税金额
	private BigDecimal expenseStandardAmt;	// 报销标准
	private BigDecimal amount; 				// 费用金额
	private BigDecimal localAmount; 		// 本位币金额
	private BigDecimal userLocalAmt;		// 用户请求本位币金额
	private BigDecimal adjustedAmount; 		// 会计调整金额
	private String 	   adjustReason; 		// 会计调整原因
//	private BigDecimal adjustedLocalAmount; // 会计调整本位币金额
	private BigDecimal paymentAmount;		// 付款金额
	private BigDecimal excessAmount; 		// 超标金额
	private String excessRemark;       	    // 超标说明

	private String     overDateFlag;		// 超期标识
	private String     overStandardFlag;	// 超标标识

	private String     userId;				//费用归属员工ID
	private String     userName;			//费用归属员工姓名

	private String     year;				//车补年度
	private String     month;				//车补月度
	private String	   sbsxFlag;			//实报实销标识
	private BigDecimal expensedCityTrafficAmount;	//已报销市内交通金额

	private String     deptCode;
	private String     deptName;
	private String     bukrs;
	private String     bukrsName;
	private String     approvedDate;		//核定日期
	private BigDecimal socialOffsetAmount;	//社保冲抵金额
	private String     oaId;				//oa单号
	private String     oaUrl;				//oaUrl

	private String trafficTool; 			// 交通工具
	private String trafficToolDesc; 		// 交通工具描述

	private int    perCounts; 				// 人数
	private int    dayCounts; 				// 天数
	private String entertain; 				// 招待方式
	private String entertainDesc; 			// 招待方式描述
	private String entertainLevel; 			// 招待级别
	private String entertainLevelDesc; 		// 招待级别描述

	private String salesArea; 				// 销售区域
	private String salesAreaDesc; 			// 销售区域描述
	private String industry; 				// 行业
	private String industryDesc; 			// 行业描述
	private String wbs; 					// ps项目
	private String wbsDesc; 				// ps项目描述
	private String trafficProject; 			// 交通项目
	private String trafficProjectDesc; 		// 交通项目描述
	private String hasBusinessOpportunity;  // 是否有商机: 1-有商机; 2-无商机
	private String entertainRange;			// 招待范围
	private String entertainRangeDesc;    	// 招待范围描述
	private String businessOpportunity;		// 商机
	private String customer;				// 客户
	private String users;					// 用户
	private String businessOpportunityDesc;	// 商机描述
	private String customerDesc;			// 客户描述
	private String usersDesc;				// 用户描述

	private String companyCardPay;			// 公司卡付款标识  Y:是 N:否
	private String specialRemark;			// 特殊情况说明
	private String tpFlag;                  //是否提票

	public String getTpFlag() {return tpFlag;}
	public void setTpFlag(String tpFlag) {this.tpFlag = tpFlag;}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getRn() {
		return rn;
	}
	public void setRn(Integer rn) {
		this.rn = rn;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getFeeType() {
		return feeType;
	}
	public void setFeeType(String feeType) {
		this.feeType = feeType;
	}
	public String getFeeTypeName() {
		return feeTypeName;
	}
	public void setFeeTypeName(String feeTypeName) {
		this.feeTypeName = feeTypeName;
	}
	public String getFeeFromDate() {
		return feeFromDate;
	}
	public void setFeeFromDate(String feeFromDate) {
		this.feeFromDate = feeFromDate;
	}
	public String getFeeToDate() {
		return feeToDate;
	}
	public void setFeeToDate(String feeToDate) {
		this.feeToDate = feeToDate;
	}
	public String getBigFeeType() {
		return bigFeeType;
	}
	public void setBigFeeType(String bigFeeType) {
		this.bigFeeType = bigFeeType;
	}
	public String getBigFeeTypeName() {
		return bigFeeTypeName;
	}
	public void setBigFeeTypeName(String bigFeeTypeName) {
		this.bigFeeTypeName = bigFeeTypeName;
	}
	public String getSmaFeeType() {
		return smaFeeType;
	}
	public void setSmaFeeType(String smaFeeType) {
		this.smaFeeType = smaFeeType;
	}
	public String getSmaFeeTypeName() {
		return smaFeeTypeName;
	}
	public void setSmaFeeTypeName(String smaFeeTypeName) {
		this.smaFeeTypeName = smaFeeTypeName;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrencyDesc() {
		return currencyDesc;
	}
	public void setCurrencyDesc(String currencyDesc) {
		this.currencyDesc = currencyDesc;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public String getUpTime() {
		return upTime;
	}
	public void setUpTime(String upTime) {
		this.upTime = upTime;
	}
	public BigDecimal getExchangeRate() {
		return exchangeRate;
	}
	public void setExchangeRate(BigDecimal exchangeRate) {
		this.exchangeRate = exchangeRate;
	}
	public BigDecimal getTaxRate() {
		return taxRate;
	}
	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}
	public BigDecimal getTaxAmount() {
		return taxAmount;
	}
	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}
	public BigDecimal getNoTaxAmount() {
		return noTaxAmount;
	}
	public void setNoTaxAmount(BigDecimal noTaxAmount) {
		this.noTaxAmount = noTaxAmount;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getLocalAmount() {
		return localAmount;
	}
	public void setLocalAmount(BigDecimal localAmount) {
		this.localAmount = localAmount;
	}
	public BigDecimal getUserLocalAmt() {
		return userLocalAmt;
	}
	public void setUserLocalAmt(BigDecimal userLocalAmt) {
		this.userLocalAmt = userLocalAmt;
	}
	public BigDecimal getAdjustedAmount() {
		return adjustedAmount;
	}
	public void setAdjustedAmount(BigDecimal adjustedAmount) {
		this.adjustedAmount = adjustedAmount;
	}
	public String getAdjustReason() {
		return adjustReason;
	}
	public void setAdjustReason(String adjustReason) {
		this.adjustReason = adjustReason;
	}
	public BigDecimal getPaymentAmount() {
		return paymentAmount;
	}
	public void setPaymentAmount(BigDecimal paymentAmount) {
		this.paymentAmount = paymentAmount;
	}
	public BigDecimal getExcessAmount() {
		return excessAmount;
	}
	public void setExcessAmount(BigDecimal excessAmount) {
		this.excessAmount = excessAmount;
	}
	public String getTrafficTool() {
		return trafficTool;
	}
	public void setTrafficTool(String trafficTool) {
		this.trafficTool = trafficTool;
	}
	public String getTrafficToolDesc() {
		return trafficToolDesc;
	}
	public void setTrafficToolDesc(String trafficToolDesc) {
		this.trafficToolDesc = trafficToolDesc;
	}
	public int getPerCounts() {
		return perCounts;
	}
	public void setPerCounts(int perCounts) {
		this.perCounts = perCounts;
	}
	public int getDayCounts() {
		return dayCounts;
	}
	public void setDayCounts(int dayCounts) {
		this.dayCounts = dayCounts;
	}
	public String getEntertain() {
		return entertain;
	}
	public void setEntertain(String entertain) {
		this.entertain = entertain;
	}
	public String getEntertainDesc() {
		return entertainDesc;
	}
	public void setEntertainDesc(String entertainDesc) {
		this.entertainDesc = entertainDesc;
	}
	public String getEntertainLevel() {
		return entertainLevel;
	}
	public void setEntertainLevel(String entertainLevel) {
		this.entertainLevel = entertainLevel;
	}
	public String getEntertainLevelDesc() {
		return entertainLevelDesc;
	}
	public void setEntertainLevelDesc(String entertainLevelDesc) {
		this.entertainLevelDesc = entertainLevelDesc;
	}
	public String getSalesArea() {
		return salesArea;
	}
	public void setSalesArea(String salesArea) {
		this.salesArea = salesArea;
	}
	public String getSalesAreaDesc() {
		return salesAreaDesc;
	}
	public void setSalesAreaDesc(String salesAreaDesc) {
		this.salesAreaDesc = salesAreaDesc;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getIndustryDesc() {
		return industryDesc;
	}
	public void setIndustryDesc(String industryDesc) {
		this.industryDesc = industryDesc;
	}
	public String getWbs() {
		return wbs;
	}
	public void setWbs(String wbs) {
		this.wbs = wbs;
	}
	public String getWbsDesc() {
		return wbsDesc;
	}
	public void setWbsDesc(String wbsDesc) {
		this.wbsDesc = wbsDesc;
	}
	public String getTrafficProject() {
		return trafficProject;
	}
	public void setTrafficProject(String trafficProject) {
		this.trafficProject = trafficProject;
	}
	public String getTrafficProjectDesc() {
		return trafficProjectDesc;
	}
	public void setTrafficProjectDesc(String trafficProjectDesc) {
		this.trafficProjectDesc = trafficProjectDesc;
	}

	public String getHasBusinessOpportunity() {
		return hasBusinessOpportunity;
	}

	public void setHasBusinessOpportunity(String hasBusinessOpportunity) {
		this.hasBusinessOpportunity = hasBusinessOpportunity;
	}

	public String getEntertainRange() {
		return entertainRange;
	}

	public void setEntertainRange(String entertainRange) {
		this.entertainRange = entertainRange;
	}

    public String getEntertainRangeDesc() {
        return entertainRangeDesc;
    }

    public void setEntertainRangeDesc(String entertainRangeDesc) {
        this.entertainRangeDesc = entertainRangeDesc;
    }

    public String getCompanyCardPay() {
		return companyCardPay;
	}
	public void setCompanyCardPay(String companyCardPay) {
		this.companyCardPay = companyCardPay;
	}
	public String getBusinessOpportunity() {
		return businessOpportunity;
	}
	public void setBusinessOpportunity(String businessOpportunity) {
		this.businessOpportunity = businessOpportunity;
	}
	public String getCustomer() {
		return customer;
	}
	public void setCustomer(String customer) {
		this.customer = customer;
	}
	public String getUsers() {
		return users;
	}
	public void setUsers(String users) {
		this.users = users;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getYear() {
		return year;
	}
	public void setYear(String year) {
		this.year = year;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}

    public String getDeptCode() {
        return deptCode;
    }

    public void setDeptCode(String deptCode) {
        this.deptCode = deptCode;
    }

    public String getDeptName() {
        return deptName;
    }

    public void setDeptName(String deptName) {
        this.deptName = deptName;
    }

    public String getBukrs() {
        return bukrs;
    }

    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }

    public String getBukrsName() {
        return bukrsName;
    }

    public void setBukrsName(String bukrsName) {
        this.bukrsName = bukrsName;
    }

    public String getApprovedDate() {
		return approvedDate;
	}
	public void setApprovedDate(String approvedDate) {
		this.approvedDate = approvedDate;
	}
	public BigDecimal getSocialOffsetAmount() {
		return socialOffsetAmount;
	}
	public void setSocialOffsetAmount(BigDecimal socialOffsetAmount) {
		this.socialOffsetAmount = socialOffsetAmount;
	}
	public String getOaId() {
		return oaId;
	}
	public void setOaId(String oaId) {
		this.oaId = oaId;
	}
	public String getOaUrl() {
		return oaUrl;
	}
	public void setOaUrl(String oaUrl) {
		this.oaUrl = oaUrl;
	}
	public String getRentType() {
		return rentType;
	}
	public void setRentType(String rentType) {
		this.rentType = rentType;
	}
	public String getRentCity() {
		return rentCity;
	}
	public void setRentCity(String rentCity) {
		this.rentCity = rentCity;
	}
	public String getRentCountry() {
		return rentCountry;
	}
	public void setRentCountry(String rentCountry) {
		this.rentCountry = rentCountry;
	}
	public String getRentCityDesc() {
		return rentCityDesc;
	}
	public void setRentCityDesc(String rentCityDesc) {
		this.rentCityDesc = rentCityDesc;
	}
	public int getRentDays() {
		return rentDays;
	}
	public void setRentDays(int rentDays) {
		this.rentDays = rentDays;
	}

	public int getRentRooms() {
		return rentRooms;
	}
	public void setRentRooms(int rentRooms) {
		this.rentRooms = rentRooms;
	}
	public BigDecimal getExpenseStandardAmt() {
		return expenseStandardAmt;
	}
	public void setExpenseStandardAmt(BigDecimal expenseStandardAmt) {
		this.expenseStandardAmt = expenseStandardAmt;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getSubjectName() {
		return subjectName;
	}
	public void setSubjectName(String subjectName) {
		this.subjectName = subjectName;
	}
	public String getTaxSubject() {
		return taxSubject;
	}
	public void setTaxSubject(String taxSubject) {
		this.taxSubject = taxSubject;
	}
	public String getTaxSubjectName() {
		return taxSubjectName;
	}
	public void setTaxSubjectName(String taxSubjectName) {
		this.taxSubjectName = taxSubjectName;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public BigDecimal getExpensedCityTrafficAmount() {
		return expensedCityTrafficAmount;
	}
	public void setExpensedCityTrafficAmount(BigDecimal expensedCityTrafficAmount) {
		this.expensedCityTrafficAmount = expensedCityTrafficAmount;
	}
	public String getOverDateFlag() {
		return overDateFlag;
	}
	public void setOverDateFlag(String overDateFlag) {
		this.overDateFlag = overDateFlag;
	}
	public String getOverStandardFlag() {
		return overStandardFlag;
	}
	public void setOverStandardFlag(String overStandardFlag) {
		this.overStandardFlag = overStandardFlag;
	}
	public String getFromTime() {
		return fromTime;
	}
	public void setFromTime(String fromTime) {
		this.fromTime = fromTime;
	}
	public String getToTime() {
		return toTime;
	}
	public void setToTime(String toTime) {
		this.toTime = toTime;
	}
	public String getPlaceFrom() {
		return placeFrom;
	}
	public void setPlaceFrom(String placeFrom) {
		this.placeFrom = placeFrom;
	}
	public String getPlaceFromDesc() {
		return placeFromDesc;
	}
	public void setPlaceFromDesc(String placeFromDesc) {
		this.placeFromDesc = placeFromDesc;
	}
	public String getPlaceTo() {
		return placeTo;
	}
	public void setPlaceTo(String placeTo) {
		this.placeTo = placeTo;
	}
	public String getPlaceToDesc() {
		return placeToDesc;
	}
	public void setPlaceToDesc(String placeToDesc) {
		this.placeToDesc = placeToDesc;
	}
	public String getCountryFrom() {
		return countryFrom;
	}
	public void setCountryFrom(String countryFrom) {
		this.countryFrom = countryFrom;
	}
	public String getCountryTo() {
		return countryTo;
	}
	public void setCountryTo(String countryTo) {
		this.countryTo = countryTo;
	}
	public String getTrafficToolType() {
		return trafficToolType;
	}
	public void setTrafficToolType(String trafficToolType) {
		this.trafficToolType = trafficToolType;
	}
	public String getTrafficToolLevel() {
		return trafficToolLevel;
	}
	public void setTrafficToolLevel(String trafficToolLevel) {
		this.trafficToolLevel = trafficToolLevel;
	}
	public String getTrafficToolLevelDesc() {
		return trafficToolLevelDesc;
	}
	public void setTrafficToolLevelDesc(String trafficToolLevelDesc) {
		this.trafficToolLevelDesc = trafficToolLevelDesc;
	}

    public String getSbsxFlag() {
        return sbsxFlag;
    }

    public void setSbsxFlag(String sbsxFlag) {
        this.sbsxFlag = sbsxFlag;
    }
	public String getBusinessOpportunityDesc() {
		return businessOpportunityDesc;
	}
	public void setBusinessOpportunityDesc(String businessOpportunityDesc) {
		this.businessOpportunityDesc = businessOpportunityDesc;
	}
	public String getCustomerDesc() {
		return customerDesc;
	}
	public void setCustomerDesc(String customerDesc) {
		this.customerDesc = customerDesc;
	}
	public String getUsersDesc() {
		return usersDesc;
	}
	public void setUsersDesc(String usersDesc) {
		this.usersDesc = usersDesc;
	}
	public String getExcessRemark() {
		return excessRemark;
	}
	public void setExcessRemark(String excessRemark) {
		this.excessRemark = excessRemark;
	}

	public String getSpecialRemark() {
		return specialRemark;
	}

	public void setSpecialRemark(String specialRemark) {
		this.specialRemark = specialRemark;
	}
}
