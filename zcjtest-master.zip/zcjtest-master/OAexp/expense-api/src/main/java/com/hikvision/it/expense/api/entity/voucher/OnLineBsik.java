package com.hikvision.it.expense.api.entity.voucher;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * 报销系统在途未清entity
 * <p>Title: OnLineBsik.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月13日
 *
 */
public class OnLineBsik implements Serializable {
	private static final long serialVersionUID = -8308279007979537745L;

	private String 		drCode;				//记账码
	private BigDecimal 	amount;				//本位币金额
	private String 		bukrs;				//公司代码
	private Date   		postDate;			//过账日期
	private String 		currency;			//原币别
	private String 		localCurrency;		//本位币币别
	
	public String getDrCode() {
		return drCode;
	}
	public void setDrCode(String drCode) {
		this.drCode = drCode;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public Date getPostDate() {
		return postDate;
	}
	public void setPostDate(Date postDate) {
		this.postDate = postDate;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getLocalCurrency() {
		return localCurrency;
	}
	public void setLocalCurrency(String localCurrency) {
		this.localCurrency = localCurrency;
	}
}
