package com.hikvision.it.expense.api.entity.history;

import java.io.Serializable;

public class ApproveHistory implements Serializable {
	private static final long serialVersionUID = 756646433247208024L;
	private String taskId;				//任务id
	private String taskName;			//任务名称
	private String taskDesc;
	private String result; 				//任务处理结果 **
	private String suggest; 			//任务处理意见
	private long   cmTime;				//完成时间
	private String completedBy; 		//处理人
	private String completedByName; 	//处理人姓名

	public String getTaskId() {
		return taskId;
	}

	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}

	public String getTaskName() {
		return taskName;
	}

	public void setTaskName(String taskName) {
		this.taskName = taskName;
	}

	public String getTaskDesc() {
		return taskDesc;
	}

	public void setTaskDesc(String taskDesc) {
		this.taskDesc = taskDesc;
	}

	public String getResult() {
		return result;
	}

	public void setResult(String result) {
		this.result = result;
	}

	public String getSuggest() {
		return suggest;
	}

	public void setSuggest(String suggest) {
		this.suggest = suggest;
	}

	public long getCmTime() {
		return cmTime;
	}

	public void setCmTime(long cmTime) {
		this.cmTime = cmTime;
	}

	public String getCompletedBy() {
		return completedBy;
	}

	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}

	public String getCompletedByName() {
		return completedByName;
	}

	public void setCompletedByName(String completedByName) {
		this.completedByName = completedByName;
	}
}
