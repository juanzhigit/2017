package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.sql.Date;

public class WorkInfo implements Serializable {
	private static final long serialVersionUID = -8057279975969044882L;
	private String 	id;				//考勤编号
	private String 	userId;			//员工编号
	private Date 	startDate;		//起始日期
	private Date 	endDate;		//截止日期
	private long   	amount; 		//总天数
	private String 	docNo;			//申请单号
	private String 	dataState;		//数据状态
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getDataState() {
		return dataState;
	}
	public void setDataState(String dataState) {
		this.dataState = dataState;
	}
}
