package com.hikvision.it.expense.api.service.user;

import java.util.List;

import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.user.SearchUser;
import com.hikvision.it.expense.api.entity.user.User;

/**
 * 员工接口
 * <p>Title: IUserService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月2日
 *
 */
public interface IUserService {
	/**
	 * 根据员工登录名称、语言获取员工信息
	 * @param userShortName     notes账号, 如zhangsanyf
	 * @param language			语言
	 */
	User findUserByUserShortName(String userShortName, String language);
	
	/**
	 * 根据员工编号、单据类别获取授权列表（包含员工本人）
	 */
	List<SelectOpt> findAuthUser(String docType);
	
	/**
	 * 过滤查询同行人列表
	 */
	List<SearchUser> findUserToAddTripTogether(String filter);

	/**
	 * 判断表单类型
	 * @return 表单类型 zb|fgs|jf|jtsyb|vp|xt|xtjf
	 */
	String judgeUserFormType(String userId);
}
