package com.hikvision.it.expense.api.service.attachment;

import java.util.List;

import com.hikvision.it.expense.api.entity.attachment.Attachment;

public interface IAttachmentService {

	void saveAttach(Attachment attach);

	void deleteAttach(String attachId);

    List<Attachment> getAttachByDocId(String docId);

	Attachment getOne(String attachId);

	Long countAttach(String docId);
}
