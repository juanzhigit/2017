package com.hikvision.it.expense.api.entity.trip;

import java.io.Serializable;

/**
 * 差旅报告单
 */
public class TravelReport implements Serializable {
    private static final long serialVersionUID = 3490712269176924564L;
    private String docId;
    private String procedure;
    private String result;
    private String suggestion;
    private String userId;

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getProcedue() {
        return procedure;
    }

    public void setProcedue(String procedue) {
        this.procedure = procedue;
    }

    public String getResult() {
        return result;
    }

    public void setResult(String result) {
        this.result = result;
    }

    public String getSuggestion() {
        return suggestion;
    }

    public void setSuggestion(String suggestion) {
        this.suggestion = suggestion;
    }

    public String getProcedure() {
        return procedure;
    }

    public void setProcedure(String procedure) {
        this.procedure = procedure;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
}
