package com.hikvision.it.expense.api.entity.form;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class FormHeader implements Serializable, Cloneable {
	private static final long serialVersionUID = -8567577199125237911L;

	private String docId;				//单据编号
	private String docNo;				//报销单号
	private String docType;				//单据类别
	private String docTypeName;			//单据类别名称
	private String expenseType;			//费用类别
	private String expenseTypeName;		//费用类别名称
	private String createdOn;			//创建时间
	private String createdBy;			//创建人员工号
	private String createdByName;		//创建人姓名
	private String bukrs;				//费用归属公司代码
	private String bukrsName;			//费用归属公司名称
	private String deptCode;			//费用归属部门代码
	private String deptCodePath;		//费用归属部门代码路径
	private String deptName;			//费用归属部门名称
	private String expensor;			//报销人员工号
	private String expensorName;		//报销人姓名
	private String expensorGrade;		//报销人级别
	private Date   submittedOn;			//提交时间
	private Date   completedOn;			//完成时间
	private String currency;			//付款币别
	private String currDesc;			//显示付款币别名称
	private BigDecimal amount;			//单据金额
	private BigDecimal subsidyAmount = BigDecimal.ZERO;	//补贴金额
	private BigDecimal payAmount;		//付款金额
	private BigDecimal kilometre;		//公里数
	private String remark;				//事由
	private String docStatus;			//单据状态
	private String docStatusName;		//单据状态名称
	private String operator;			//当前处理人
	private String refDocNo;			//引用单号
	private String refDocId;			//引用单据编号
	private String tripFromDate;		//差旅起始日期
	private String tripToDate;			//差旅截止日期
	private String language;			//语言
	private long   upTime;				//更新时间

	// 拓展信息
	private String cbFlag = "N";		//是否超标标识
	private String cqFlag = "N";		//是否超期标识
	private String hgjType = "N";		//核高基类别
	private String hgjFlag = "N";		//是否核高基
	private String zdjpFlag = "N";		//自定机票标识
	private String loanFlag = "N";		//借款标识
	private String txrFlag = "N";		//同行人标识
	private String hybcFlag = "N";		//会议包餐标识
	private String rantFlag = "N";		//租房标识
	private String payType = "C";		//付款方式(默认银行转账)
	private String repayFlag = "N";		//还款标识
	private String dsdfFlag = "N";		//是否代收代付
	private String pgdNo;				//派工单编号
	private String pgdUrl;				//派工单url
	private int    docYear;				//单据年度
	private int    docMonth;			//单据月度
	private Date   fphsDate;			//发票回收日期
	private String fgszbFlag = "N";		//回分公司/杭州总部
	// 拓展信息


	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getDocTypeName() {
		return docTypeName;
	}
	public void setDocTypeName(String docTypeName) {
		this.docTypeName = docTypeName;
	}
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public String getExpenseTypeName() {
		return expenseTypeName;
	}
	public void setExpenseTypeName(String expenseTypeName) {
		this.expenseTypeName = expenseTypeName;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getBukrsName() {
		return bukrsName;
	}
	public void setBukrsName(String bukrsName) {
		this.bukrsName = bukrsName;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public String getDeptCodePath() {
		return deptCodePath;
	}
	public void setDeptCodePath(String deptCodePath) {
		this.deptCodePath = deptCodePath;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getExpensor() {
		return expensor;
	}
	public void setExpensor(String expensor) {
		this.expensor = expensor;
	}
	public String getExpensorName() {
		return expensorName;
	}
	public void setExpensorName(String expensorName) {
		this.expensorName = expensorName;
	}
	public Date getSubmittedOn() {
		return submittedOn;
	}
	public void setSubmittedOn(Date submittedOn) {
		this.submittedOn = submittedOn;
	}
	public Date getCompletedOn() {
		return completedOn;
	}
	public void setCompletedOn(Date completedOn) {
		this.completedOn = completedOn;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getCurrDesc() {
		return currDesc;
	}
	public void setCurrDesc(String currDesc) {
		this.currDesc = currDesc;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

    public BigDecimal getSubsidyAmount() {
        return subsidyAmount;
    }

    public void setSubsidyAmount(BigDecimal subsidyAmount) {
        this.subsidyAmount = subsidyAmount;
    }

    public BigDecimal getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}
	public String getRemark() {
		return remark;
	}
	public void setRemark(String remark) {
		this.remark = remark;
	}
	public String getDocStatus() {
		return docStatus;
	}
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	public String getDocStatusName() {
		return docStatusName;
	}
	public void setDocStatusName(String docStatusName) {
		this.docStatusName = docStatusName;
	}
	public String getOperator() {
		return operator;
	}
	public void setOperator(String operator) {
		this.operator = operator;
	}
	public String getRefDocNo() {
		return refDocNo;
	}
	public void setRefDocNo(String refDocNo) {
		this.refDocNo = refDocNo;
	}
	public String getRefDocId() {
		return refDocId;
	}
	public void setRefDocId(String refDocId) {
		this.refDocId = refDocId;
	}
	public String getTripFromDate() {
		return tripFromDate;
	}
	public void setTripFromDate(String tripFromDate) {
		this.tripFromDate = tripFromDate;
	}
	public String getTripToDate() {
		return tripToDate;
	}
	public void setTripToDate(String tripToDate) {
		this.tripToDate = tripToDate;
	}
	public String getCreatedOn() {
		return createdOn;
	}
	public void setCreatedOn(String createdOn) {
		this.createdOn = createdOn;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
	public long getUpTime() {
		return upTime;
	}
	public void setUpTime(long upTime) {
		this.upTime = upTime;
	}
	public String getExpensorGrade() {
		return expensorGrade;
	}
	public void setExpensorGrade(String expensorGrade) {
		this.expensorGrade = expensorGrade;
	}
	public String getCbFlag() {
		return cbFlag;
	}
	public void setCbFlag(String cbFlag) {
		this.cbFlag = cbFlag;
	}
	public String getCqFlag() {
		return cqFlag;
	}
	public void setCqFlag(String cqFlag) {
		this.cqFlag = cqFlag;
	}
	public String getHgjType() {
		return hgjType;
	}
	public void setHgjType(String hgjType) {
		this.hgjType = hgjType;
	}
	public String getHgjFlag() {
		return hgjFlag;
	}
	public void setHgjFlag(String hgjFlag) {
		this.hgjFlag = hgjFlag;
	}
	public String getZdjpFlag() {
		return zdjpFlag;
	}
	public void setZdjpFlag(String zdjpFlag) {
		this.zdjpFlag = zdjpFlag;
	}
	public String getLoanFlag() {
		return loanFlag;
	}
	public void setLoanFlag(String loanFlag) {
		this.loanFlag = loanFlag;
	}
	public String getTxrFlag() {
		return txrFlag;
	}
	public void setTxrFlag(String txrFlag) {
		this.txrFlag = txrFlag;
	}
	public String getHybcFlag() {
		return hybcFlag;
	}
	public void setHybcFlag(String hybcFlag) {
		this.hybcFlag = hybcFlag;
	}
	public String getRantFlag() {
		return rantFlag;
	}
	public void setRantFlag(String rantFlag) {
		this.rantFlag = rantFlag;
	}
	public String getPayType() {
		return payType;
	}
	public void setPayType(String payType) {
		this.payType = payType;
	}
	public String getRepayFlag() {
		return repayFlag;
	}
	public void setRepayFlag(String repayFlag) {
		this.repayFlag = repayFlag;
	}
	public String getDsdfFlag() {
		return dsdfFlag;
	}
	public void setDsdfFlag(String dsdfFlag) {
		this.dsdfFlag = dsdfFlag;
	}
	public String getPgdNo() {
		return pgdNo;
	}
	public void setPgdNo(String pgdNo) {
		this.pgdNo = pgdNo;
	}
	public String getPgdUrl() {
		return pgdUrl;
	}
	public void setPgdUrl(String pgdUrl) {
		this.pgdUrl = pgdUrl;
	}
	public int getDocYear() {
		return docYear;
	}
	public void setDocYear(int docYear) {
		this.docYear = docYear;
	}
	public int getDocMonth() {
		return docMonth;
	}
	public void setDocMonth(int docMonth) {
		this.docMonth = docMonth;
	}
	public Date getFphsDate() {
		return fphsDate;
	}
	public void setFphsDate(Date fphsDate) {
		this.fphsDate = fphsDate;
	}
	public String getFgszbFlag() {
		return fgszbFlag;
	}
	public void setFgszbFlag(String fgszbFlag) {
		this.fgszbFlag = fgszbFlag;
	}
	public BigDecimal getKilometre() {
		return kilometre;
	}
	public void setKilometre(BigDecimal kilometre) {
		this.kilometre = kilometre;
	}

	@Override
	public FormHeader clone() {
		try {
			return (FormHeader) super.clone();
		} catch (CloneNotSupportedException e) {
			return null;
		}
	}
}
