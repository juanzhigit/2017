package com.hikvision.it.expense.api.exception;

public class ExpenseException extends RuntimeException {
	private static final long serialVersionUID = -6930181232289539426L;
	@SuppressWarnings("unused")
	private Throwable th;
	private int errorCode;

    public ExpenseException() {
    }

    public ExpenseException(String msg) {
        super(msg);
    }

    public ExpenseException(int errorCode) {
        this.errorCode = errorCode;
    }

    public ExpenseException(Throwable th) {
        super(th);
        this.th = th;
    }

    public int getErrorCode() {
        return errorCode;
    }
}
