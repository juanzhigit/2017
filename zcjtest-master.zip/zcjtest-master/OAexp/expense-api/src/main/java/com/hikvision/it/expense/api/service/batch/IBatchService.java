package com.hikvision.it.expense.api.service.batch;

import java.util.List;

import com.hikvision.it.expense.api.entity.batch.PayFilter;
import com.hikvision.it.expense.api.entity.batch.PayInfo;

public interface IBatchService {

	/**
	 * 获取他人收款列表
	 */
	List<PayInfo> getPayInfos(String userId, String language, PayFilter filter);

}
