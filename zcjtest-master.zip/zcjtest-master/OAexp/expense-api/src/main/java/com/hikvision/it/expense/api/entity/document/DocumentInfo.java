package com.hikvision.it.expense.api.entity.document;





import java.io.Serializable;
import java.util.Date;

import com.fasterxml.jackson.annotation.JsonFormat;

/**
 * 单据查询结果
 * @author liangdong5
 *
 */
public class DocumentInfo implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = -4462046947478031531L;
	private String id;
	private String applyId; 							//申请单号
	private String processCode; 						//流程类型
	private String processName; 						//流程类型名称
	private String busType; 							//业务类型
	private String busTypeName; 						//业务类型名称
	private String status; 								//状态
	private String statusName; 							//状态名称
	private String opuser; 								//当前处理人
	@JsonFormat(pattern = "yyyy-MM-dd",timezone="GMT+8")
	private Date completeTime; 							//完成时间
	@JsonFormat(pattern = "yyyy-MM-dd",timezone="GMT+8")
	private Date subTime; 								//提交时间
	@JsonFormat(pattern = "yyyy-MM-dd",timezone="GMT+8")
	private Date createTime; 							//创建时间
	private long upTime;								//时间戳
	private String userId; 								//申请人Id
	private String userName;							//申请人姓名
	private String creator; 							//创建者Id
	private String creatorName;							//创建者名称
	private String docStatus;							//单据状态
	private String docStatusName;						//单据状态名称
	private String remark;								//单据备注
	private String refApplyId; 							//关联报销单
	private String refFlowId; 							//关联报销单
	private String refAmt;								//报销金额
	private String hpAmt;								//汇票金额
	private String dhAmt;								//电汇金额
	private String otherAmt;							//其他金额
	private String refTZAmt;							//报销调整金额
	private String tripFromDate;		//差旅起始日期
	private String tripToDate;			//差旅截止日期
	public String getTripToDate() {
		return tripToDate;
	}

	public void setTripToDate(String tripToDate) {
		this.tripToDate = tripToDate;
	}

	public String getTripFromDate() {
		return tripFromDate;
	}

	public void setTripFromDate(String tripFromDate) {
		this.tripFromDate = tripFromDate;
	}


	
	private String refProcessCode;	//引用单据类型
	private String refBusType;		//引用业务类型
	
	private String sysType;	//对公(DG)、对私（DS）
	
	private String ywScan;//业务 还是财务扫描  SC_001 业务扫描   SC_002 财务扫描
	private String cwScan;//业务 还是财务扫描  SC_001 业务扫描   SC_002 财务扫描
	
	private String  approve_comments;//审批备注
	private String  approve_completetime;//审批时间
	
	private String lifnr;			//客商代码
	private String lifnrTxt;		//客商描述
	private String currency;		//币种
	private String paymentType;		//付款方式
	private String yfkj;			//应付会计
	private String fkkj;			//付款会计
	private String yfkjApproveDate; //应付会计审核时间
	private String fkkjApproveDate; //付款会计审核时间

	private String company;			//付款公司
	private String docId;           //单据Id
	
	private String companyCode;//公司编码
	
	
	private String refapplyProcesscode;//被关联单据的类型
	private String refapplyDocstatus;//被关联单据的流程状态
	
	
	private String flag ;//标识
	
	
	private String fkkjname;
	private String yfkjname;
	
	
	
	
	
	
	public String getFkkjname() {
		return fkkjname;
	}

	public void setFkkjname(String fkkjname) {
		this.fkkjname = fkkjname;
	}

	public String getYfkjname() {
		return yfkjname;
	}

	public void setYfkjname(String yfkjname) {
		this.yfkjname = yfkjname;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}

	public String getRefapplyProcesscode() {
		return refapplyProcesscode;
	}

	public void setRefapplyProcesscode(String refapplyProcesscode) {
		this.refapplyProcesscode = refapplyProcesscode;
	}

	public String getRefapplyDocstatus() {
		return refapplyDocstatus;
	}

	public void setRefapplyDocstatus(String refapplyDocstatus) {
		this.refapplyDocstatus = refapplyDocstatus;
	}

	public String getCompanyCode() {
		return companyCode;
	}

	public void setCompanyCode(String companyCode) {
		this.companyCode = companyCode;
	}

	public DocumentInfo() {
	}
	
	public String getHpAmt() {
		return hpAmt;
	}

	public void setHpAmt(String hpAmt) {
		this.hpAmt = hpAmt;
	}

	public String getDhAmt() {
		return dhAmt;
	}

	public void setDhAmt(String dhAmt) {
		this.dhAmt = dhAmt;
	}

	public String getOtherAmt() {
		return otherAmt;
	}

	public void setOtherAmt(String otherAmt) {
		this.otherAmt = otherAmt;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getApplyId() {
		return applyId;
	}

	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}

	public String getRefFlowId() {
		return refFlowId;
	}

	public void setRefFlowId(String refFlowId) {
		this.refFlowId = refFlowId;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getProcessCode() {
		return processCode;
	}

	public void setProcessCode(String processCode) {
		this.processCode = processCode;
	}

	public String getProcessName() {
		return processName;
	}

	public void setProcessName(String processName) {
		this.processName = processName;
	}

	public String getBusType() {
		return busType;
	}

	public void setBusType(String busType) {
		this.busType = busType;
	}

	public String getBusTypeName() {
		return busTypeName;
	}

	public void setBusTypeName(String busTypeName) {
		this.busTypeName = busTypeName;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getStatusName() {
		return statusName;
	}

	public void setStatusName(String statusName) {
		this.statusName = statusName;
	}

	public String getOpuser() {
		return opuser;
	}

	public void setOpuser(String opuser) {
		this.opuser = opuser;
	}

	

	public Date getCompleteTime() {
		return completeTime;
	}

	public void setCompleteTime(Date completeTime) {
		this.completeTime = completeTime;
	}

	public Date getSubTime() {
		return subTime;
	}

	public void setSubTime(Date subTime) {
		this.subTime = subTime;
	}

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getCreator() {
		return creator;
	}

	public void setCreator(String creator) {
		this.creator = creator;
	}

	public String getCreatorName() {
		return creatorName;
	}

	public void setCreatorName(String creatorName) {
		this.creatorName = creatorName;
	}

	public String getDocStatus() {
		return docStatus;
	}

	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}

	public String getDocStatusName() {
		return docStatusName;
	}

	public void setDocStatusName(String docStatusName) {
		this.docStatusName = docStatusName;
	}

	public String getRemark() {
		return remark;
	}

	public void setRemark(String remark) {
		this.remark = remark;
	}

	public String getRefApplyId() {
		return refApplyId;
	}

	public void setRefApplyId(String refApplyId) {
		this.refApplyId = refApplyId;
	}

	public String getRefAmt() {
		return refAmt;
	}

	public void setRefAmt(String refAmt) {
		this.refAmt = refAmt;
	}

	public String getRefTZAmt() {
		return refTZAmt;
	}

	public void setRefTZAmt(String refTZAmt) {
		this.refTZAmt = refTZAmt;
	}

	public String getSysType() {
		return sysType;
	}

	public void setSysType(String sysType) {
		this.sysType = sysType;
	}

	public String getRefProcessCode() {
		return refProcessCode;
	}

	public void setRefProcessCode(String refProcessCode) {
		this.refProcessCode = refProcessCode;
	}

	public String getRefBusType() {
		return refBusType;
	}

	public void setRefBusType(String refBusType) {
		this.refBusType = refBusType;
	}

	public String getYwScan() {
		return ywScan;
	}

	public void setYwScan(String ywScan) {
		this.ywScan = ywScan;
	}

	public String getCwScan() {
		return cwScan;
	}

	public void setCwScan(String cwScan) {
		this.cwScan = cwScan;
	}

	public String getApprove_comments() {
		return approve_comments;
	}

	public void setApprove_comments(String approve_comments) {
		this.approve_comments = approve_comments;
	}

	public String getApprove_completetime() {
		return approve_completetime;
	}

	public void setApprove_completetime(String approve_completetime) {
		this.approve_completetime = approve_completetime;
	}

	public String getLifnr() {
		return lifnr;
	}

	public void setLifnr(String lifnr) {
		this.lifnr = lifnr;
	}

	public String getLifnrTxt() {
		return lifnrTxt;
	}

	public void setLifnrTxt(String lifnrTxt) {
		this.lifnrTxt = lifnrTxt;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}

	public String getYfkj() {
		return yfkj;
	}

	public void setYfkj(String yfkj) {
		this.yfkj = yfkj;
	}

	public String getFkkj() {
		return fkkj;
	}

	public void setFkkj(String fkkj) {
		this.fkkj = fkkj;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getYfkjApproveDate() {
		return yfkjApproveDate;
	}

	public void setYfkjApproveDate(String yfkjApproveDate) {
		this.yfkjApproveDate = yfkjApproveDate;
	}

	public String getFkkjApproveDate() {
		return fkkjApproveDate;
	}

	public void setFkkjApproveDate(String fkkjApproveDate) {
		this.fkkjApproveDate = fkkjApproveDate;
	}

	public String getDocId() {
		return docId;
	}

	public void setDocId(String docId) {
		this.docId = docId;
	}

	public long getUpTime() {
		return upTime;
	}

	public void setUpTime(long upTime) {
		this.upTime = upTime;
	}
}
