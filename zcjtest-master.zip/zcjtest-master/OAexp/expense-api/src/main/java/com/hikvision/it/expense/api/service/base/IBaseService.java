package com.hikvision.it.expense.api.service.base;

import java.util.List;

import com.hikvision.it.expense.api.entity.base.Notice;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.bukrs.Bukrs;

/**
 * 币别接口
 * <p>Title: ICurrencyService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月3日
 *
 */
public interface IBaseService {
	/**
	 * 根据员工、公司、单据类别币别下拉
	 * 		
	 * 		优先匹配员工默认付款币别，如果未设置，则取币别下拉
	 * 		
	 * @param userId
	 * @param bukrs
	 * @param docType
	 * @return
	 */
	List<SelectOpt> findSelectCurrency(String userId, String bukrs, String docType);
	
	/**
	 * 根据过滤字段查询可选币别
	 * 
	 * 可输入国家名称、国家代码、币别、币别描述进行筛选
	 * 
	 * @param filter
	 * @return
	 */
	List<SelectOpt> findSelectCurrency(String filter);
	
	/**
	 * 根据语言获取差旅交通工具信息
	 * @return
	 */
	List<SelectOpt> findTipTool();
	
	/**
	 * 获取所有报销费用类别
	 * @return
	 */
	List<SelectOpt> listExpenseFeeType();
	
	/**
	 * 根据公司代码、单据类别、报销类别获取费用类别
	 * @param bukrs
	 * @param docType
	 * @param expenseType
	 * @return
	 */
	List<SelectOpt> listExpenseFeeType(String bukrs, String docType, String expenseType);
	
	/**
	 * 获取市内交通工具类别
	 * @return
	 */
	List<SelectOpt> findCityTraficTool();
	
	/**
	 * 查询差旅城市列表
	 * @param filter		筛选值
	 * @return
	 */
	List<TripCity> findTripCity(String filter);
	
	/**
	 * 根据获取热门城市
	 * @return
	 */
	List<TripCity> findHotCity();
	
	/**
	 * 批量获取消费金额汇率转换信息
	 * 
	 * 根据消费币别、金额、目标货币进行金额转换
	 * 
	 * @param rate
	 * @return
	 */
	Rate getRates(Rate rate);
	
	/**
	 * 分页查询公告信息
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<Notice> listNotices(int pageNumber, int pageSize);
	
	/**
	 * 获取可选币别
	 * @param country
	 * @return
	 */
	List<SelectOpt> listCurrencyOpt(String country);
	
	/**
	 * 查询交通项目
	 * @param filter
	 * @return
	 */
	List<SelectOpt> listTrafficProject(String filter);

	/**
	 * 查询科目
	 * @param filter
	 * @return
	 */
	List<SelectOpt> listGlAccount(String filter);
	
	/**
	 * 获取员工所属销售区域
	 * @param userId
	 * @return
	 */
	List<SelectOpt> listSalesArea(String userId);
	
	/**
	 * 获取公司信息
	 * @return
	 */
	List<SelectOpt> getCompanyInfo(String searchText);
	
	/**
	 * 获取行业信息
	 * @return
	 */
	List<SelectOpt> listIndustry();

	/**
	 * 招待方式
	 */
	List<SelectOpt> listEntertains();

	/**
	 * 招待级别
	 */
	List<SelectOpt> listEntertainLevels();

    /**
     * 根据部门code获取部门名称
     */
    String getDeptName(String deptCode);
    /**
     * 根据公司代码获取公司名称
     */
    String getBukrsName(String bukrs);

	/**
	 * 获取员工 筛选城市的住宿标准
	 * @param userId
	 * @param filter
	 * @return
	 */
	List<TripCity> getStayStandard(String userId, String filter);

	/**
	 * 筛选公司
	 * @param filter
	 * @return
	 */
	List<Bukrs> listBukrs(String filter);

	/**
	 * 刷选供应商
	 * @param filter
	 * @return
	 */
	List<SelectOpt> listLifnr(String filter);

	/**
	 * 刷选业务细类
	 * @param filter
	 * @return
	 */
	List<SelectOpt> listAdviceSmaFee(String filter);

	/**
	 * 获取费用类别名称
	 * @param expenseType
	 * @return
	 */
	String getExpenseTypeName(String expenseType);
}
