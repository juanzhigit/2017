package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.util.List;

public class RateReq implements Serializable {
	private static final long serialVersionUID = -1530983374785386700L;
	
	private String targetCurrency;	//目标币别
	private List<Rate> sourceCurrencies;	//请求转换原币消费信息
	
	public String getTargetCurrency() {
		return targetCurrency;
	}
	public void setTargetCurrency(String targetCurrency) {
		this.targetCurrency = targetCurrency;
	}
	public List<Rate> getSourceCurrencies() {
		return sourceCurrencies;
	}
	public void setSourceCurrencies(List<Rate> sourceCurrencies) {
		this.sourceCurrencies = sourceCurrencies;
	}
}
