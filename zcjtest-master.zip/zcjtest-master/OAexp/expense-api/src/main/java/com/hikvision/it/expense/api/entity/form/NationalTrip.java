package com.hikvision.it.expense.api.entity.form;

import java.io.Serializable;
import java.sql.Date;

public class NationalTrip implements Serializable {
	private static final long serialVersionUID = -6446973096444077615L;

	private String docNo; 					//申请单号
	private String docId;					//单据编号
	private Date   subdate;					//提交日期
	private String userId;					//员工编号
	private String userName;				//员工姓名
	private Date   startdate;				//出发日期
	private String countryFrom;				//出发国家
	private String countryFromDesc;			//出发国家名称
	private String cityFrom;				//出发城市
	private Date   enddate;					//到达日期
	private String countryTo;				//到达国家
	private String countryToDesc;			//到达国家名称
	private String cityTo;					//到达城市
	private String directMail;				//部门主管邮箱
	private String docType;					//单据类别
	
	private String procedue;				//处理过程
	private String processresult;			//处理结果
	private String suggestion;				//建议
	
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public Date getSubdate() {
		return subdate;
	}
	public void setSubdate(Date subdate) {
		this.subdate = subdate;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public Date getStartdate() {
		return startdate;
	}
	public void setStartdate(Date startdate) {
		this.startdate = startdate;
	}
	public String getCountryFrom() {
		return countryFrom;
	}
	public void setCountryFrom(String countryFrom) {
		this.countryFrom = countryFrom;
	}
	public String getCountryFromDesc() {
		return countryFromDesc;
	}
	public void setCountryFromDesc(String countryFromDesc) {
		this.countryFromDesc = countryFromDesc;
	}
	public String getCityFrom() {
		return cityFrom;
	}
	public void setCityFrom(String cityFrom) {
		this.cityFrom = cityFrom;
	}
	public Date getEnddate() {
		return enddate;
	}
	public void setEnddate(Date enddate) {
		this.enddate = enddate;
	}
	public String getCountryTo() {
		return countryTo;
	}
	public void setCountryTo(String countryTo) {
		this.countryTo = countryTo;
	}
	public String getCountryToDesc() {
		return countryToDesc;
	}
	public void setCountryToDesc(String countryToDesc) {
		this.countryToDesc = countryToDesc;
	}
	public String getCityTo() {
		return cityTo;
	}
	public void setCityTo(String cityTo) {
		this.cityTo = cityTo;
	}
	public String getDirectMail() {
		return directMail;
	}
	public void setDirectMail(String directMail) {
		this.directMail = directMail;
	}
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getProcedue() {
		return procedue;
	}
	public void setProcedue(String procedue) {
		this.procedue = procedue;
	}
	public String getProcessresult() {
		return processresult;
	}
	public void setProcessresult(String processresult) {
		this.processresult = processresult;
	}
	public String getSuggestion() {
		return suggestion;
	}
	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}
}
