package com.hikvision.it.expense.api.entity.oa;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * oa关联单据信息
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/27
 * Time: 19:30
 * To change this template use File | Settings | File Templates.
 */
public class OaInfo implements Serializable {
    private static final long serialVersionUID = 1674066545412246575L;
    /** oa单号id */
    private String oaId;
    /** oa url */
    private String url;
    /** oa 行项目code */
    private String itemCode;
    /** oa 行项目序列号 */
    private String itemNo;
    /** 费用所属 员工ID */
    private String userId;
    /** 费用所属员工姓名 */
    private String userName;
    /** 费用所属部门路径 */
    private String deptCodePath;
    /** 金额 */
    private BigDecimal amount;
    /** 事由 */
    private String remark;

    public String getOaId() {
        return oaId;
    }

    public void setOaId(String oaId) {
        this.oaId = oaId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getItemCode() {
        return itemCode;
    }

    public void setItemCode(String itemCode) {
        this.itemCode = itemCode;
    }

    public String getItemNo() {
        return itemNo;
    }

    public void setItemNo(String itemNo) {
        this.itemNo = itemNo;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getDeptCodePath() {
        return deptCodePath;
    }

    public void setDeptCodePath(String deptCodePath) {
        this.deptCodePath = deptCodePath;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
