package com.hikvision.it.expense.api.entity.flow;

import java.io.Serializable;

public class MailEntity implements Serializable {
	private static final long serialVersionUID = 8273677235543220980L;

	private String id;					//唯一ID
	private String[] toAddresses;		//接收人
	private String subject;				//标题
	private String content;				//正文
	private String isOutMail;			//是否外网邮件
	private String docId;				//报销id
	private String taskId;				//任务id
	private String receivors;			//接收人传（;分割）
	private String isApprove = "N";	//是否审批邮件
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String[] getToAddresses() {
		return toAddresses;
	}
	public void setToAddresses(String[] toAddresses) {
		this.toAddresses = toAddresses;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getIsOutMail() {
		return isOutMail;
	}
	public void setIsOutMail(String isOutMail) {
		this.isOutMail = isOutMail;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getReceivors() {
		return receivors;
	}
	public void setReceivors(String receivors) {
		this.receivors = receivors;
	}
	public String getIsApprove() {
		return isApprove;
	}
	public void setIsApprove(String isApprove) {
		this.isApprove = isApprove;
	}
}
