package com.hikvision.it.expense.api.entity.flow;

import java.util.Date;

public class DocHeader {
	private String processInstanceId;	//流程实例编号
	private String processObjectId;		//流程类别
	private String processObjectName;	//流程名称
	private String busType;				//业务类型
	private String applyId;				//流程单号
	private String bukrs;				//公司代码
	private String deptCodePath;		//部门路径
	private String deptCode;			//部门
	private Date   subDate;				//提交日期
	private String creator;				//提单人
	private String claimUserName;		//申请人姓名
	private String claimUserId;			//申请人编号
	private String bpmUUID;				//流程编号
	private String roleId;				//审批规则编号
	private String isLoan;				//是否借款
	private String mail;				//提单人邮箱地址
	private String bxMail;				//报销人邮箱
	private String refDocId;			//引用单据号
	private String docStatus;			//流程状态
	private String language;			//语言
	
	public String getProcessInstanceId() {
		return processInstanceId;
	}
	public void setProcessInstanceId(String processInstanceId) {
		this.processInstanceId = processInstanceId;
	}
	public String getProcessObjectId() {
		return processObjectId;
	}
	public void setProcessObjectId(String processObjectId) {
		this.processObjectId = processObjectId;
	}
	public String getProcessObjectName() {
		return processObjectName;
	}
	public void setProcessObjectName(String processObjectName) {
		this.processObjectName = processObjectName;
	}
	public String getBusType() {
		return busType;
	}
	public void setBusType(String busType) {
		this.busType = busType;
	}
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getDeptCodePath() {
		return deptCodePath;
	}
	public void setDeptCodePath(String deptCodePath) {
		this.deptCodePath = deptCodePath;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public Date getSubDate() {
		return subDate;
	}
	public void setSubDate(Date subDate) {
		this.subDate = subDate;
	}
	public String getCreator() {
		return creator;
	}
	public void setCreator(String creator) {
		this.creator = creator;
	}
	public String getClaimUserName() {
		return claimUserName;
	}
	public void setClaimUserName(String claimUserName) {
		this.claimUserName = claimUserName;
	}
	public String getClaimUserId() {
		return claimUserId;
	}
	public void setClaimUserId(String claimUserId) {
		this.claimUserId = claimUserId;
	}
	public String getBpmUUID() {
		return bpmUUID;
	}
	public void setBpmUUID(String bpmUUID) {
		this.bpmUUID = bpmUUID;
	}
	public String getIsLoan() {
		return isLoan;
	}
	public void setIsLoan(String isLoan) {
		this.isLoan = isLoan;
	}
	public String getMail() {
		return mail;
	}
	public void setMail(String mail) {
		this.mail = mail;
	}
	public String getRoleId() {
		return roleId;
	}
	public void setRoleId(String roleId) {
		this.roleId = roleId;
	}
	public String getBxMail() {
		return bxMail;
	}
	public void setBxMail(String bxMail) {
		this.bxMail = bxMail;
	}
	public String getRefDocId() {
		return refDocId;
	}
	public void setRefDocId(String refDocId) {
		this.refDocId = refDocId;
	}
	public String getDocStatus() {
		return docStatus;
	}
	public void setDocStatus(String docStatus) {
		this.docStatus = docStatus;
	}
	public String getLanguage() {
		return language;
	}
	public void setLanguage(String language) {
		this.language = language;
	}
}
