package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.math.BigDecimal;

public class DocParam implements Serializable {
	private static final long serialVersionUID = 3362672402020021064L;
	private String docType;			//单据类别
	private String bigFeeType;		//费用大类
	private String smaFeeType;		//费用细类
	private String bukrs;			//公司
	private String deptCode;		//部门
	private BigDecimal amount = BigDecimal.ZERO;		//金额
	
	public String getDocType() {
		return docType;
	}
	public void setDocType(String docType) {
		this.docType = docType;
	}
	public String getBigFeeType() {
		return bigFeeType;
	}
	public void setBigFeeType(String bigFeeType) {
		this.bigFeeType = bigFeeType;
	}
	public String getSmaFeeType() {
		return smaFeeType;
	}
	public void setSmaFeeType(String smaFeeType) {
		this.smaFeeType = smaFeeType;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getDeptCode() {
		return deptCode;
	}
	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
}
