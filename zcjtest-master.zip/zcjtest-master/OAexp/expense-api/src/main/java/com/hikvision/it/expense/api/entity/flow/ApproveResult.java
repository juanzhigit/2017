package com.hikvision.it.expense.api.entity.flow;

import java.io.Serializable;
import java.util.List;

import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.enums.DeviceEnum;
import com.hikvision.it.expense.api.enums.ResultEnum;

public class ApproveResult implements Serializable {
	private static final long serialVersionUID = -2475721122179446880L;
	
	private String taskId;					//任务实例编号
	private String docId;					//单据编号
	private String completedBy;				//处理人
	private String completedByName;			//处理人姓名
	private String suggest;					//处理意见
	private ResultEnum result;				//处理结果
	private DeviceEnum device;				//审批终端类型
	private Long   cmTime;					//完成时间毫秒
	private Long   upTime;					//最后更新时间
	private List<TaskReceivor> receivors;	//任务接收人
	
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getCompletedBy() {
		return completedBy;
	}
	public void setCompletedBy(String completedBy) {
		this.completedBy = completedBy;
	}
	public String getCompletedByName() {
		return completedByName;
	}
	public void setCompletedByName(String completedByName) {
		this.completedByName = completedByName;
	}
	public String getSuggest() {
		return suggest;
	}
	public void setSuggest(String suggest) {
		this.suggest = suggest;
	}
	public ResultEnum getResult() {
		return result;
	}
	public void setResult(ResultEnum result) {
		this.result = result;
	}
	public DeviceEnum getDevice() {
		return device;
	}
	public void setDevice(DeviceEnum device) {
		this.device = device;
	}
	public Long getCmTime() {
		return cmTime;
	}
	public void setCmTime(Long cmTime) {
		this.cmTime = cmTime;
	}
	public Long getUpTime() {
		return upTime;
	}
	public void setUpTime(Long upTime) {
		this.upTime = upTime;
	}
	public List<TaskReceivor> getReceivors() {
		return receivors;
	}
	public void setReceivors(List<TaskReceivor> receivors) {
		this.receivors = receivors;
	}
}
