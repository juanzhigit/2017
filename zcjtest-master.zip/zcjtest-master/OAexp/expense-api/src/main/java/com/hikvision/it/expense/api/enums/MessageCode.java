package com.hikvision.it.expense.api.enums;

/**
 * 消息code enum
 * <p>
 * Title: MessageCode.java
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2015
 * </p>
 * <p>
 * Company: hikvision
 * </p>
 * 
 * @author wuliangxxh1
 * @date 2015年7月2日
 *
 */
public enum MessageCode {
	/** 表格必须填写字段 */
	GRID_FIELD_REQUIRE_INPUT,
	/** 表格必填字段 */
	GRID_FIELD_LENGTH_LIMITTED,
	/** 表格数据不全 */
	GRID_LESS_DATA,
	/** 表格数据格式有误 */
	GRID_DATA_FORMAT_ERROR,
	/** 表格日期范围有误 */
	GRID_DATE_SCOPE_ERROR,
	/** 出发城市与上一行达到城市不一致 */
	GRID_TRIP_PLACE_ERROR,
	/** 出发城市与到达城市一致 */
	GRID_TRIP_PLACE_SAME_ERROR,
	/** 不能使用外币 */
	GRID_NO_FOREIGN_CURRENCY,

	/** 字段长度超限 */
	FORM_FIELD_REQUIRE_INPUT,
	/** 表单字段长度超限 */
	FORM_FIELD_LENGTH_LIMITTED,
	/** 表单数据格式有误 */
	FORM_DATA_FORMAT_ERROR,
	/** 差旅行程未形成闭环 */
	FORM_TRIP_CYCLE_ERROR,
	/** 差旅行程冲突 */
	FORM_TRIP_DUPLICATED_ERROR,
	/** 差旅行程闭环超过一个 */
	FORM_TRIP_MULTI_CYCLE,
	
	/** 数据条目有误 */
	SINGLE_DATA_ERROR,

	/** 未被授权打开当前单据 */
	MSG_NOT_AUTH_OPEN_URL,
	/** 未知单据类型 */
	MSG_UNKNOWN_DOCTYPE,
	/** 流程未配置 */
	MSG_PROCESS_NOT_CONFIG,
	/** 加签不允许转发 */
	MSG_APPROVE_ADDSTEP_CANNOT_FORWARD,
	/** 转发、加签不允许再加签 */
	MSG_APPROVE_CANNOT_ADDSTEP,
	/** 用户未登陆 */
	MSG_USER_NOT_LOGON,
	/** 区域等级未维护 */
	MSG_NO_REGION_LEVEL,
	/** 文件下载失败 */
	MSG_DOWNLOAD_FAILED,
	/** 审批意见不能为空 */
	MSG_COMMENT_NOT_EMPTY,

	/** 审批意见提示邮件标题 */
	TITLE_APPROVED_TEMP,
	/** 待办标题模板 */
	TITLE_TODO_TEMP,
	/** 待办标题不含金额模板 */
	TITLE_TODO_NO_MONEY_TEMP,
	/** 未核销预付款邮件提醒标题 */
	TITLE_VENDOR_ADVICE_TEMP,
	/** 国际机票提示邮件标题 */
	TITLE_AIRFARE_TEMP,
	/** 外币借款提醒邮件标题 */
	TITLE_FOREIGN_LOAN_TEMP,
	/** 境外险邮件标题 */
	TITLE_JWX_TEMP,
	
	/** 单据类别 */
	TITLE_DOCTYPE,
	/** 报销类别 */
	TITLE_EXPENSETYPE,
	/** 申请人 */
	TITLE_APPLICANT,
	/** 创建人 */
	TITLE_CREATOR,
	/** 部门 */
	TITLE_DEPARTMENT,
	/** 公司 */
	TITLE_BUKRS,
	/** 币别 */
	TITLE_CURRENCY,
	/** 创建日期 */
	TITLE_CREATED_DATE,
	/** 提交日期 */
	TITLE_SUBMIT_DATE,
	/** 事由 */
	TITLE_PURPOSE,
	/** 审批意见 */
	TITLE_SUGGEST,
	
	/** 费用日期 */
	TITLE_FEE_DATE,
    /** 入住日期 */
	TITLE_SZ_DATE,
    /** 退房日期 */
	TITLE_TF_DATE,
    /** 汇率 */
	TITLE_RATE,
	/** 本位币金额 */
	TITLE_LOCAL_AMT,
	/** 税率 */
	TITLE_TAX_RATE,
	/** 税额 */
	TITLE_TAX_AMOUNT,
	
	/** 出发日期 */
	TITLE_FROM_DATE,
	/** 出发国家 */
	TITLE_FROM_COUNTRY,
	/** 出发城市 */
	TITLE_FROM_CICY,
	/** 到达日期 */
	TITLE_TO_DATE,
	/** 到达国家 */
	TITLE_TO_COUNTRY,
	/** 到达城市 */
	TITLE_TO_CICY,
	/** 交通工具 */
	TITLE_TRIFFIC_TOOL,
	/** 交通工具级别 */
	TITLE_TRIFFIC_TOOL_LEVEL,
	
	/** 借款日期 */
	TITLE_LOAN_DATE,
	/** 预计还款日期 */
	TITLE_ESTIMATE_REPAYMENT_DATE,
	/** 付款方式 */
	TITLE_PAYMENT_METHOD,
	/** 金额 */
	TITLE_AMOUNT,

    /** 是否租房标识 */
	TITLE_RENT_FLAG,
    /** 入住日期 */
	TITLE_STAYS_DATE,
    /** 退房日期 */
	TITLE_LEAVE_DATE,
    /** 住宿城市 */
	TITLE_STAYS_CITY,
    /** 房间数 */
	TITLE_ROOMS,
    /** 住宿情况说明 */
	TITLE_STAYS_REMARK,

    /** 行程事由 */
	TITLE_TRIP_REMARK,
	
	/** PS项目 */
	TITLE_WBS,
    /** 销售区域 */
	TITLE_SALESAREA,
	/** 行业 */
	TITLE_INDUSTRY,
    /** 交通项目 */
	TITLE_TRAFFIC_PROJECT,
    /** 商机 */
	TITLE_SJ,
    /** 客户 */
	TITLE_KH,
    /** 用户 */
	TITLE_YH,

    /** 招待方式 */
	TITLE_ZDFS,
    /** 客户级别 */
	TITLE_KHJB,
    /** 天数 */
	TITLE_DAYS,
    /** 人数 */
	TITLE_PERSONS,
	/** 费用类型 */
	TITLE_SMAFEETYPE,
	
	/** 收款人 */
	TITLE_SKR,
	
	/** 行程明细 */
	GRID_NAME_TRIP,
	/** 借款明细 */
	GRID_NAME_LOAN,
	/** 同行人明细 */
	GRID_NAME_TRIP_TOGETHER,
	/** 市内交通 */
	GRID_NAME_CITY_TRIFFIC,
	/** 车辆补贴 */
	GRID_NAME_CAR_ALLOWANCE,
	/** 业务招待 */
	GRID_NAME_YWZD,
	/** 生育费用明细 */
	GRID_NAME_BIRTH,
	/** 房租费 */
	GRID_NAME_RENT,
    /** 住宿费 */
    GRID_NAME_STAYS,
	/** 长途交通 */
	GRID_NAME_CTJT,
    /** 其他费用 */
    GRID_NAME_OTHER,
    /** 他人收款 */
    GRID_NAME_OTHER_RECEIVE,
	
	/** 查询成功 */
	SUCCESS_SEARCH,
	/** 保存成功 */
	SUCCESS_SAVE,
	/** 删除成功 */
	SUCCESS_DELETE,
	/** 更新成功 */
	SUCCESS_UPDATE,
	/** 提交成功 */
	SUCCESS_SUBMIT,
	/** 审批成功 */
	SUCCESS_APPROVED,
	/** 流转成功 */
	SUCCESS_FORWORD,

	/** 审批失败 */
	FAILURE_APPROVED,
	
	/** 单据信息已变更，请刷新后重试 */
	MSG_DOC_CHANGED,

	/** 未查询到数据 */
	NO_DATA_FOUND,
	/** 未查询到消息 */
	MSG_NOT_FOUND,
	/** 传入参数异常 */
	ERROR_INPUT_PARAM,
	/** SAP员工订单未获取到 */
	SAP_ORDERID_NOT_FOUND,
	/** 部门路径未配置 */
	DEPT_PATH_NOT_FOUND,

	/** 在途未清大于sap未清金额 */
	VOUCH_ZT_CLR_AMT_DY_SAP_WQAMT,
	/** 清帐金额小于0 */
	VOUCH_CLR_AMT_XY_0,
	/** 清帐金额必须不能大于单据总金额 */
	VOUCH_CLR_AMT_DY_DOC_AMT,
	/** 清帐金额不等于单据总金额 */
	VOUCH_CLR_AMT_NEQ_DOC_AMT,
	/** 清帐金额必须大于等于到期未清金额 */
	VOUCH_CLR_AMT_GTR_DQWQ_AMT,
	/** 过账金额不等于会计调整后金额 */
	VOUCH_DOC_AMT_NEQ_ACC_AMT,
	/** 借贷不平 */
	VOUCH_JDBALANCE_ERROR,
	/** 清帐金额与凭证行项目清帐金额不等 */
	VOUCH_CLR_AMT_NEQ_VOUCH_ITEM,
	/** 凭证校验成功 */
	VOUCH_CHECK_SUCCESS,
	/** 凭证校验失败 */
	VOUCH_CHECK_FAILURE,
	/** 凭证过账成功 */
	VOUCH_POST_SUCCESS,
	/** 凭证过账失败 */
	VOUCH_POST_FAILURE,

	/** 请先预览凭证 */
	VOUCH_PREVIEW_FIRST,

	/** 通用凭证抬头 */
	VOUCH_EXP_COMMON,
	/** 通用借款抬头 */
	VOUCH_LOAN_COMMON,
	/** 通用借款抬头 */
	VOUCH_REPAY_COMMON,

	/** 未查询到科目信息 */
	SUBJECT_NOT_FOUND,
	/** 未获取到币种对应科目 */
	CURRENY_SUBJECT_NOT_FOUND,

	/** 未查询到sap汇率信息 */
	SAP_RATE_NOT_FOUND,

	/** 成本中心未配置 */
	COSTCENTER_NOT_FOUND,
	/** 实际成本中心未配置 */
	SJ_COSTCENTER_NOT_FOUND,

	/** 运行时异常 */
	RUNTIME_ERROR,
	
	/** 行项目为空 */
	EMPTY_ITEM,
	/** 行项目错误 */
	ITEM_ERROR,
	/** 已经提交 */
	HAD_SUBMIT,
	/** 日期逻辑错误 */
	DATE_NOT_LOGICAL,

	/** 金额调整错误 */
	ADJUST_ERROR,

	/** 草稿单据不存在 */
	DRAFT_NOT_FOUND,
	/** 草稿单跳转地址不存在 */
	DRAFT_URL_NOT_FOUND,

	/** 未知的打开方式 */
	UNKNOWN_OPEN_TYPE,

	/** 未查询到单据状态信息 */
	DOC_STATUS_NOT_FOUND,
	/** 单据已变更 */
	DOC_HAS_EXCHANGED,
	/** 单据已报销 */
	DOC_HAS_REIMBURSEMENT,
	/** 未查询到单据信息 */
	DOC_NOT_FOUND,
	/** 未获取到引用单号单据类型 */
	REF_DOC_PROCCESSCODE_NOT_FOUND,
	/** 引用单据流程未正常结束 */
	REF_DOC_NOT_ENDED,
	/** 单据包含借款切流程未完成 */
	DOC_CONTAIN_LOAN_NOT_END,
	/** 单据未审批完成不能转报销 */
	DOC_NOT_COMPLETED_CANNOT_BX,

	/** 撤回成功 */
	OPER_REVOKE_SUCESS,
	/** 撤回失败 */
	OPER_REVOKE_FAILURE,
	/** 撤销成功 */
	OPER_UNDO_SUCCESS,
	/** 撤销失败 */
	OPER_UNDO_FAILURE,

	/** 未设置任务接收人 */
	NO_RECEIVOR_FOUND,
	/** 海外审批标题 */
	TITLE_APPROVE_SUBJECT_HW01,
	/** 海外审批正文 */
	TITLE_APPROVE_CONTENT_HW01,
	
	/** 付款币别 */
	TITLE_PAYMENT_CURRENCY,
	/** 供应商名称 */
	TITLE_LIFNR_TXT,
	/** 银行名称 */
	TITLE_BANK_NAME,
	/** 银行账号 */
	TITLE_BANK_ACCOUNT,
	/** Swift Code */
	TITLE_SWIFT_CODE,
	/** Iban No. */
	TITLE_IBAN_NO,
	/** 备注 */
	TITLE_REMARK,
	/** 其他信息 */
	TITLE_OTHER_INFO,
	/** 发票日期 */
	TITLE_INVOICE_DATE,
	/** 调整金额 */
	TITLE_ADJUSTED_AMOUNT,
	/** 调整原因 */
	TITLE_ADJUSTED_REASON,
	/** 审批意见 */
	TITLE_SPYJ,
	
	/** 收款方抬头 */
	HEADER_RECEVIOR,
	/** 付款明细 */
	HEADER_PAY_DETAIL,
	
	/** 请选择交通工具 */
	TODO_SELECT_TRAVEL_TOOL,
	
	/**
	 * 单据作废成功
	 */
	OPER_CANCEL_SUCCESS,
	/** 单据作废失败
	 */
	OPER_CANCEL_FAILURE,
	/** 放弃报销成功
	 */
	
	OPER_RENDERUP_SUCCESS,
	/** 放弃报销失败
	 */
	OPER_RENDERUP_FAILURE,
    /**
     * 银行信息web service调用异常
     */
    WSDL_ERROR_BANK
}
