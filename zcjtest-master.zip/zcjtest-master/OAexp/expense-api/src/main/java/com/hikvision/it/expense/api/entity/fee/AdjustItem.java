package com.hikvision.it.expense.api.entity.fee;

import java.io.Serializable;
import java.math.BigDecimal;

public class AdjustItem implements Serializable {
    /**
	 * 
	 */
	private static final long serialVersionUID = 1759742577688181536L;
	/**
     * 行项目id
     */
    private String id;
    /**
     * 行项目金额
     */
    private BigDecimal amount;
    /**
     * 汇率
     */
    private BigDecimal exchangeRate;
    /**
     * 调减金额
     */
    private BigDecimal adjustAmount;
    /**
     * 付款金额 = (amount - adjustAmount) * exchangeRate
     */
    private BigDecimal paymentAmount;
    /**
     * 税率
     */
    private BigDecimal taxRate;
    /**
     * 税额
     */
    private BigDecimal taxAmount;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public BigDecimal getAdjustAmount() {
        return adjustAmount;
    }

    public void setAdjustAmount(BigDecimal adjustAmount) {
        this.adjustAmount = adjustAmount;
    }

    public BigDecimal getPaymentAmount() {
        return paymentAmount;
    }

    public void setPaymentAmount(BigDecimal paymentAmount) {
        this.paymentAmount = paymentAmount;
    }

	public BigDecimal getTaxRate() {
		return taxRate;
	}

	public void setTaxRate(BigDecimal taxRate) {
		this.taxRate = taxRate;
	}

	public BigDecimal getTaxAmount() {
		return taxAmount;
	}

	public void setTaxAmount(BigDecimal taxAmount) {
		this.taxAmount = taxAmount;
	}
}
