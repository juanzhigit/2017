package com.hikvision.it.expense.api.service.base;

/**
 * 字典表数据接口
 */
public interface IDictionaryService {

    /**
     * 取单个描述(语言信息取当前用户语言)
     * @see #findOne(String, String, String)
     */
    String findOne(String dataType, String dataCode);

    /**
     * 取指定语言的单个描述
     * @param dataType 数据类型, 常用类型: 业务类型-D202; 币种-D103; 单据类型-D104
     * @param dataCode 数据编码
     * @param language 语言
     * @return 描述信息
     */
    String findOne(String dataType, String dataCode, String language);

}
