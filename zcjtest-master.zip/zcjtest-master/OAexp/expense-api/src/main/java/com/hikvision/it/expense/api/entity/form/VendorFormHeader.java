package com.hikvision.it.expense.api.entity.form;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 *
 * 预付款催收报表entity
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/20
 * Time: 16:12
 * To change this template use File | Settings | File Templates.
 */
public class VendorFormHeader implements Serializable {
    private static final long serialVersionUID = 925765855307897014L;

    /** 单据编号 */
    private String docId;
    /** 单据号 */
    private String docNo;
    /** 费用大类 */
    private String bigFeeType;
    /** 费用大类名称 */
    private String bigFeeTypeName;
    /** 费用细类 */
    private String smaFeeType;
    /** 费用细类名称 */
    private String smaFeeTypeName;
    /** 公司代码 */
    private String bukrs;
    /** 完成日期 */
    private String completedDate;
    /** 发票回收日期 */
    private String fphsDate;
    /** 币别 */
    private String currency;
    /** 预付金额 */
    private BigDecimal amount;
    /** 已核销金额 */
    private BigDecimal writeOffAmount;
    /** 供应商代码 */
    private String lifnr;
    /** 供应商描述 */
    private String lifnrTxt;
    /** 申请人 */
    private String expensor;
    /** 申请人姓名 */
    private String expensorName;
    /** 事由 */
    private String remark;
    /** 部门路径 */
    private String deptPath;
    /** 邮件接收人 */
    private String mailReceivor;
    /** 邮件接收人姓名 */
    private String mailReceivorName;

    /** 邮件接收人邮箱地址 */
    private String mailReceivorMailAddress;

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    public String getBigFeeType() {
        return bigFeeType;
    }

    public void setBigFeeType(String bigFeeType) {
        this.bigFeeType = bigFeeType;
    }

    public String getBigFeeTypeName() {
        return bigFeeTypeName;
    }

    public void setBigFeeTypeName(String bigFeeTypeName) {
        this.bigFeeTypeName = bigFeeTypeName;
    }

    public String getSmaFeeType() {
        return smaFeeType;
    }

    public void setSmaFeeType(String smaFeeType) {
        this.smaFeeType = smaFeeType;
    }

    public String getSmaFeeTypeName() {
        return smaFeeTypeName;
    }

    public void setSmaFeeTypeName(String smaFeeTypeName) {
        this.smaFeeTypeName = smaFeeTypeName;
    }

    public String getBukrs() {
        return bukrs;
    }

    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }

    public String getFphsDate() {
        return fphsDate;
    }

    public void setFphsDate(String fphsDate) {
        this.fphsDate = fphsDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getWriteOffAmount() {
        return writeOffAmount;
    }

    public void setWriteOffAmount(BigDecimal writeOffAmount) {
        this.writeOffAmount = writeOffAmount;
    }

    public String getLifnr() {
        return lifnr;
    }

    public void setLifnr(String lifnr) {
        this.lifnr = lifnr;
    }

    public String getLifnrTxt() {
        return lifnrTxt;
    }

    public void setLifnrTxt(String lifnrTxt) {
        this.lifnrTxt = lifnrTxt;
    }

    public String getExpensor() {
        return expensor;
    }

    public void setExpensor(String expensor) {
        this.expensor = expensor;
    }

    public String getExpensorName() {
        return expensorName;
    }

    public void setExpensorName(String expensorName) {
        this.expensorName = expensorName;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDeptPath() {
        return deptPath;
    }

    public void setDeptPath(String deptPath) {
        this.deptPath = deptPath;
    }

    public String getMailReceivor() {
        return mailReceivor;
    }

    public void setMailReceivor(String mailReceivor) {
        this.mailReceivor = mailReceivor;
    }

    public String getMailReceivorName() {
        return mailReceivorName;
    }

    public void setMailReceivorName(String mailReceivorName) {
        this.mailReceivorName = mailReceivorName;
    }

    public String getMailReceivorMailAddress() {
        return mailReceivorMailAddress;
    }

    public void setMailReceivorMailAddress(String mailReceivorMailAddress) {
        this.mailReceivorMailAddress = mailReceivorMailAddress;
    }

    public String getCompletedDate() {
        return completedDate;
    }

    public void setCompletedDate(String completedDate) {
        this.completedDate = completedDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }
}
