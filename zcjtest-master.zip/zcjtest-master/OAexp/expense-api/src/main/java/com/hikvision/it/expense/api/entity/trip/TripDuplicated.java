package com.hikvision.it.expense.api.entity.trip;

import java.io.Serializable;

public class TripDuplicated implements Serializable {
	private static final long serialVersionUID = -2726323434384585286L;
	private String docNo;		//申请单号
	private String userName;	//姓名
	private String fromDate;	//出发日期
	private String fromDesc;	//出发城市
	private String toDate;		//到达日期
	private String toDesc;		//达到城市
	
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getFromDesc() {
		return fromDesc;
	}
	public void setFromDesc(String fromDesc) {
		this.fromDesc = fromDesc;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getToDesc() {
		return toDesc;
	}
	public void setToDesc(String toDesc) {
		this.toDesc = toDesc;
	}
}
