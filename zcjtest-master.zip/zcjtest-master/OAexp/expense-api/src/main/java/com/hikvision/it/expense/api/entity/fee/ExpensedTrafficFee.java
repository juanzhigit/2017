package com.hikvision.it.expense.api.entity.fee;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 已报销市内交通费用
 */
public class ExpensedTrafficFee implements Serializable {

    private String docId;           //单据编号
    private String docNo;           //报销单号
    private String feeDate;         //费用日期
    private BigDecimal amount;      //报销金额
    private String toolDesc;        //工具描述
    private String currency;        //币别
    private String remark;          //报销事由
    private String docStatusName;   //单据状态

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    public String getFeeDate() {
        return feeDate;
    }

    public void setFeeDate(String feeDate) {
        this.feeDate = feeDate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getToolDesc() {
        return toolDesc;
    }

    public void setToolDesc(String toolDesc) {
        this.toolDesc = toolDesc;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getDocStatusName() {
        return docStatusName;
    }

    public void setDocStatusName(String docStatusName) {
        this.docStatusName = docStatusName;
    }
}
