package com.hikvision.it.expense.api.entity.trip;

import java.io.Serializable;

public class TripTogether implements Serializable {
	private static final long serialVersionUID = -4276567092007348379L;

	private String  id;			//同行人列表唯一编号
	private Integer rn;			//序号
	private String  userId;		//同行人员工编号
	private String  userName;	//同行人姓名
	private String  deptCode;	//部门代码
	private String  deptPath;	//部门路径
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public Integer getRn() {
		return rn;
	}
	public void setRn(Integer rn) {
		this.rn = rn;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getDeptPath() {
		return deptPath;
	}
	public void setDeptPath(String deptPath) {
		this.deptPath = deptPath;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}
}
