package com.hikvision.it.expense.api.service.allowance;

import java.util.List;

import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;

/**
 * 补贴计算service
 * 
 * 计算误餐补贴、周末补贴、艰苦补贴、早晚补贴
 * 计算租住补贴
 * 
 * <p>Title: IAllowanceService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月27日
 *
 */
public interface ISubsidyService {

	/**
	 * 根据单据编号获取补贴汇总
	 * @param docId
	 * @return
	 */
	List<Allowance> listAllowance(String docId);

	/**
	 * 根据单据编号获取补贴明细
	 */
	List<AllowanceDetail> listAllowanceDetail(String docId);
	/**
	 * 根据单据编号获取补贴明细(租住补贴)
	 */
	List<AllowanceDetail> listRentAllowanceDetail(String docId);

}
