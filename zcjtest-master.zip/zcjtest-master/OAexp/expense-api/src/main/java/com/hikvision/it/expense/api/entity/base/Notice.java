package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;

/**
 * 公告entity
 * <p>Title: Notice.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年4月19日
 *
 */
public class Notice implements Serializable {
	private static final long serialVersionUID = -6820438229867576682L;
	
	private String userName = "admin";	//发布人
	private String publishDate;			//发布时间
	private String title;				//内容
	private String content;				//内容
	
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPublishDate() {
		return publishDate;
	}
	public void setPublishDate(String publishDate) {
		this.publishDate = publishDate;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
}
