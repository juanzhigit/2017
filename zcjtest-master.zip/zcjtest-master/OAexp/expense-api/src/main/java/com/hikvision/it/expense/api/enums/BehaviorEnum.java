package com.hikvision.it.expense.api.enums;

/**
 * 行为类别
 * <p>Title: BehaviorEnum.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月11日
 *
 */
public enum BehaviorEnum {
	BUS_OP("1000", "商机"),
	CUSTOMER("1001", "客户"),
	USER("1003", "用户"),
	PS("1002", "PS项目"),
	SALES_AREA("1004", "销售区域"),
	INDUSTRY("1005", "行业"),
	TRA_PROJ("1006", "交通项目"),
	GL_ACCOUNT("1007", "科目");

	private String id;
	private String text;
	
	private BehaviorEnum(String id, String text) {
		this.id = id;
		this.text = text;
	}


	public String getId() {
		return id;
	}


	public String getText() {
		return text;
	}
}
