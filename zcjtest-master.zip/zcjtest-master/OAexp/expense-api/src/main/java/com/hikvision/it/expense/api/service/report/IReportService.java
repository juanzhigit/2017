package com.hikvision.it.expense.api.service.report;

import java.util.List;

import com.hikvision.it.expense.api.entity.base.ChartData;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.QueryForm;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;

/**
 * 报表service
 * <p>
 * Title: IReportService.java
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2015
 * </p>
 * <p>
 * Company: hikvision
 * </p>
 * 
 * @author wuliangxxh1
 * @date 2017年5月16日
 *
 */
public interface IReportService {
	/**
	 * 获取报销单列表
	 * 
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listExpenses(int pageNumber, int pageSize);

	/**
	 * 获取借还款列表
	 * 
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listLoanAndRepayments(int pageNumber, int pageSize);

	/**
	 * 获取差旅申请和行程变更列表
	 * 
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listTravelApplys(int pageNumber, int pageSize);

	/**
	 * 获取草稿单列表
	 * 
	 * @param pageNumber
	 * @param pageSize
	 * @return
	 */
	List<FormHeader> listDrafts(int pageNumber, int pageSize);

	/**
	 * 根据用户信息,申请单号,创建时间区间等查询草稿单列表
	 * @param form
	 * @param userId
	 * @param sidx
	 * @param sord
	 * @param page
     * @param rows
     * @return
     */
	GridData<DocumentInfo> listDraftDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows);

	/**
	 *根据单号 提交日期 单据状态  查询申请单列表
	 * @param form
	 * @param userId
	 * @param sidx
	 * @param sord
	 * @param page
     * @param rows
     * @return
     */
	GridData<DocumentInfo> listApplyDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows);

	/**
	 * 根据申请单号 提交日期区间 金额区间  供应商 事由 单据状态 查询申请单列表
	 * @param form
	 * @param userId
	 * @param sidx
	 * @param sord
	 * @param page
     * @param rows
     * @return
     */
	GridData<DocumentInfo> listPublicExpenseDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows);

	/**
	 * *根据单号 提交日期 单据状态  查询报销单列表
	 * @param form
	 * @param userId
	 * @param sidx
	 * @param sord
	 * @param page
     * @param rows
     * @return
     */
	GridData<DocumentInfo> listPrivateExpenseDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows);

	/**
	 *根据单号 提交日期 单据状态  查询借还款列表
	 * @param form
	 * @param userId
	 * @param sidx
	 * @param sord
	 * @param page
     * @param rows
     * @return
     */
	GridData<DocumentInfo> listLoanAndRepayDoc(QueryForm form, String userId, String sidx, String sord, int page, int rows);

	/**
	 * 查询预付款催收清单
	 * @param bukrsList
	 * @param expensorList
	 * @param lifnrList
	 * @param currencyList
	 * @param  smaFeeList
	 * @return
	 */
	List<VendorFormHeader> listVendorAdvice(List<String> bukrsList,
											List<String> expensorList,
											List<String> lifnrList,
											List<String> currencyList,
											List<String> smaFeeList);

	/**
	 * 获取员工个人在途报销费用统计信息按照报销单据类别统计
	 * @param userId
	 * @return
	 */
	List<ChartData> getOnlineReimTotal(String userId);
}
