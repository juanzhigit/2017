package com.hikvision.it.expense.api.entity.fee;

import java.io.Serializable;
import java.util.List;

public class AdjustAmountBean implements Serializable {

    private String docId;

    private List<AdjustItem> snpcAdjustItems;
    private List<AdjustItem> ctjtAdjustItems;
    private List<AdjustItem> zsfyAdjustItems;

    /**
     * 借款明细调减项
     */
    private List<AdjustItem> loanAdjustItems;
    /**
     * 市内交通/业务招待/其他调减
     */
    private List<AdjustItem> feeAdjustItems;
    /**
     * 车辆补贴调减
     */
    private List<AdjustItem> clbtAdjustItems;
    /**
     * 生育报销调减
     */
    private List<AdjustItem> sybxAdjustItems;
    /**
     * 房屋租赁调减
     */
    private List<AdjustItem> fwzlAdjustItems;
    /**
     * 收款人金额调减
     */
    private List<AdjustItem> skrAdjustItems;
    /**
     * 还款调减
     */
    private AdjustItem repaymentAdjustItems;

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public List<AdjustItem> getSnpcAdjustItems() {
        return snpcAdjustItems;
    }

    public void setSnpcAdjustItems(List<AdjustItem> snpcAdjustItems) {
        this.snpcAdjustItems = snpcAdjustItems;
    }

    public List<AdjustItem> getCtjtAdjustItems() {
        return ctjtAdjustItems;
    }

    public void setCtjtAdjustItems(List<AdjustItem> ctjtAdjustItems) {
        this.ctjtAdjustItems = ctjtAdjustItems;
    }

    public List<AdjustItem> getZsfyAdjustItems() {
        return zsfyAdjustItems;
    }

    public void setZsfyAdjustItems(List<AdjustItem> zsfyAdjustItems) {
        this.zsfyAdjustItems = zsfyAdjustItems;
    }

    public List<AdjustItem> getLoanAdjustItems() {
        return loanAdjustItems;
    }

    public void setLoanAdjustItems(List<AdjustItem> loanAdjustItems) {
        this.loanAdjustItems = loanAdjustItems;
    }

    public List<AdjustItem> getFeeAdjustItems() {
        return feeAdjustItems;
    }

    public void setFeeAdjustItems(List<AdjustItem> feeAdjustItems) {
        this.feeAdjustItems = feeAdjustItems;
    }

    public List<AdjustItem> getClbtAdjustItems() {
        return clbtAdjustItems;
    }

    public void setClbtAdjustItems(List<AdjustItem> clbtAdjustItems) {
        this.clbtAdjustItems = clbtAdjustItems;
    }

    public List<AdjustItem> getSybxAdjustItems() {
        return sybxAdjustItems;
    }

    public void setSybxAdjustItems(List<AdjustItem> sybxAdjustItems) {
        this.sybxAdjustItems = sybxAdjustItems;
    }

    public List<AdjustItem> getFwzlAdjustItems() {
        return fwzlAdjustItems;
    }

    public void setFwzlAdjustItems(List<AdjustItem> fwzlAdjustItems) {
        this.fwzlAdjustItems = fwzlAdjustItems;
    }

    public List<AdjustItem> getSkrAdjustItems() {
        return skrAdjustItems;
    }

    public void setSkrAdjustItems(List<AdjustItem> skrAdjustItems) {
        this.skrAdjustItems = skrAdjustItems;
    }

    public AdjustItem getRepaymentAdjustItems() {
        return repaymentAdjustItems;
    }

    public void setRepaymentAdjustItems(AdjustItem repaymentAdjustItems) {
        this.repaymentAdjustItems = repaymentAdjustItems;
    }
}
