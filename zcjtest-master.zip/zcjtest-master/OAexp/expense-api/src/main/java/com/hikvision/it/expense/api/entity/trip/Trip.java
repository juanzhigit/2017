package com.hikvision.it.expense.api.entity.trip;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

public class Trip implements Serializable {
	private static final long serialVersionUID = -9047927030695082098L;

	private String id; 					// 唯一编号
	private String docId; 				// 流程号
	private Integer rn; 				// jqgrid 指定序号名称
	private String fromDate; 			// 出发日期
	private Integer fromTime;			// 出发时间
	private String toDate; 				// 截止日期
	private Integer toTime;				// 到达时间
	private String toolType; 			// 交通工具
	private String toolLevel; 			// 交通工具级别
	private String toolDesc; 			// 交通工具级别描述
	private String countryFrom; 		// 出发国家
	private String placeFrom; 			// 出发地点
	private String fromDesc; 			// 出发城市、国家描述
	private String countryTo; 			// 到达国家
	private String placeTo; 			// 到达地点
	private String toDesc; 				// 到达城市、国家描述
	private String spRequest; 			// 特殊要求
	private String hotelName; 			// 酒店名称
	private String isParking; 			// 是否停车
	private String datType; 			// 数据类型（HTL：住宿；CAR：租车；D：行程）
	private String airTicket; 			// 是否需要机票
	private Date   upTime; 				// 更新时间
	private String flag; 				// 标识
	private BigDecimal subsidyAmount = BigDecimal.ZERO;	// 补贴金额
	private BigDecimal zcDays = BigDecimal.ZERO; // 租车天数
	private BigDecimal zsDays = BigDecimal.ZERO; // 住宿天数
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public Integer getRn() {
		return rn;
	}
	public void setRn(Integer rn) {
		this.rn = rn;
	}
	public String getFromDate() {
		return fromDate;
	}
	public void setFromDate(String fromDate) {
		this.fromDate = fromDate;
	}
	public String getToDate() {
		return toDate;
	}
	public void setToDate(String toDate) {
		this.toDate = toDate;
	}
	public String getToolType() {
		return toolType;
	}
	public void setToolType(String toolType) {
		this.toolType = toolType;
	}
	public String getToolLevel() {
		return toolLevel;
	}
	public void setToolLevel(String toolLevel) {
		this.toolLevel = toolLevel;
	}
	public String getToolDesc() {
		return toolDesc;
	}
	public void setToolDesc(String toolDesc) {
		this.toolDesc = toolDesc;
	}
	public String getCountryFrom() {
		return countryFrom;
	}
	public void setCountryFrom(String countryFrom) {
		this.countryFrom = countryFrom;
	}
	public String getPlaceFrom() {
		return placeFrom;
	}
	public void setPlaceFrom(String placeFrom) {
		this.placeFrom = placeFrom;
	}
	public String getFromDesc() {
		return fromDesc;
	}
	public void setFromDesc(String fromDesc) {
		this.fromDesc = fromDesc;
	}
	public String getCountryTo() {
		return countryTo;
	}
	public void setCountryTo(String countryTo) {
		this.countryTo = countryTo;
	}
	public String getPlaceTo() {
		return placeTo;
	}
	public void setPlaceTo(String placeTo) {
		this.placeTo = placeTo;
	}
	public String getToDesc() {
		return toDesc;
	}
	public void setToDesc(String toDesc) {
		this.toDesc = toDesc;
	}
	public String getSpRequest() {
		return spRequest;
	}
	public void setSpRequest(String spRequest) {
		this.spRequest = spRequest;
	}
	public String getHotelName() {
		return hotelName;
	}
	public void setHotelName(String hotelName) {
		this.hotelName = hotelName;
	}
	public String getIsParking() {
		return isParking;
	}
	public void setIsParking(String isParking) {
		this.isParking = isParking;
	}
	public String getDatType() {
		return datType;
	}
	public void setDatType(String datType) {
		this.datType = datType;
	}
	public String getAirTicket() {
		return airTicket;
	}
	public void setAirTicket(String airTicket) {
		this.airTicket = airTicket;
	}
	public Date getUpTime() {
		return upTime;
	}
	public void setUpTime(Date upTime) {
		this.upTime = upTime;
	}
	public String getFlag() {
		return flag;
	}
	public void setFlag(String flag) {
		this.flag = flag;
	}
	public BigDecimal getZcDays() {
		return zcDays;
	}
	public void setZcDays(BigDecimal zcDays) {
		this.zcDays = zcDays;
	}
	public BigDecimal getZsDays() {
		return zsDays;
	}
	public void setZsDays(BigDecimal zsDays) {
		this.zsDays = zsDays;
	}
	public Integer getFromTime() {
		return fromTime;
	}
	public void setFromTime(Integer fromTime) {
		this.fromTime = fromTime;
	}
	public Integer getToTime() {
		return toTime;
	}
	public void setToTime(Integer toTime) {
		this.toTime = toTime;
	}
	public BigDecimal getSubsidyAmount() {
		return subsidyAmount;
	}
	public void setSubsidyAmount(BigDecimal subsidyAmount) {
		this.subsidyAmount = subsidyAmount;
	}
}
