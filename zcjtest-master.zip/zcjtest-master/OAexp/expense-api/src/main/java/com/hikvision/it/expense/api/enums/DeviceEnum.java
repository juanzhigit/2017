package com.hikvision.it.expense.api.enums;

public enum DeviceEnum {
	/** 电脑 */
	PC,
	/** 安卓移动端 */
	ANDROID,
	/** IOS移动端 */
	IOS,
	/** 系统自动 */
	SYSTEM
}
