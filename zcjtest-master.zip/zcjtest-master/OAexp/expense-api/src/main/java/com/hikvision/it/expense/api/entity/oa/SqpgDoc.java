package com.hikvision.it.expense.api.entity.oa;

import java.io.Serializable;

public class SqpgDoc implements Serializable {
    private static final long serialVersionUID = 4838811370197070363L;
    private String id;
    private String docId;
    private String oaDocNum;
    private String oaDocTitle;
    private String oaDocUrl;
    private String flag;
    private String writeBack;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getOaDocNum() {
        return oaDocNum;
    }

    public void setOaDocNum(String oaDocNum) {
        this.oaDocNum = oaDocNum;
    }

    public String getOaDocTitle() {
        return oaDocTitle;
    }

    public void setOaDocTitle(String oaDocTitle) {
        this.oaDocTitle = oaDocTitle;
    }

    public String getOaDocUrl() {
        return oaDocUrl;
    }

    public void setOaDocUrl(String oaDocUrl) {
        this.oaDocUrl = oaDocUrl;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getWriteBack() {
        return writeBack;
    }

    public void setWriteBack(String writeBack) {
        this.writeBack = writeBack;
    }
}
