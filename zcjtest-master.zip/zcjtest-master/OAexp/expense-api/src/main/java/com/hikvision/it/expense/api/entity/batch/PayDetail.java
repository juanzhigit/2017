package com.hikvision.it.expense.api.entity.batch;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

public class PayDetail extends PayHead implements Serializable {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = -4776033960605393080L;
	
	private String belnr; // 会计凭证编号
	private String gjahr; // 会计年度
	private Date postDate; // 过账日期
	private BigDecimal amount; // 金额
	private String currency; // 币别
	private String lineNo; // 行号
	
	public Date getPostDate() {
		return postDate;
	}
	public void setPostDate(Date postDate) {
		this.postDate = postDate;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public String getLineNo() {
		return lineNo;
	}
	public void setLineNo(String lineNo) {
		this.lineNo = lineNo;
	}
	public String getBelnr() {
		return belnr;
	}
	public void setBelnr(String belnr) {
		this.belnr = belnr;
	}
	public String getGjahr() {
		return gjahr;
	}
	public void setGjahr(String gjahr) {
		this.gjahr = gjahr;
	}

}
