package com.hikvision.it.expense.api.enums;

public enum DocTypeEnum {
	/** 差旅申请 */
	WEM001,
	/** 行程变更 */
	WEM002,
	/** 借款 */
	WEM003,
	/** 还款 */
	WEM004,
	/** 国内差旅报销 */
	WEM006,
	/** 个人费用报销 */
	WEM008,
	/** 国际差旅报销 */
	WEM010,
	/** 市内派车 */
	WEM011,
	/** 长途派车 */
	WEM012
}
