package com.hikvision.it.expense.api.service.task;

import java.util.List;

import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.task.PendingForwardBean;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.entity.task.TodoInfo;
import com.hikvision.it.expense.api.enums.ResultEnum;

public interface ITaskService {
    /**
     * 审批任务
     *
     * @param taskId  任务编号
     * @param result  审批结果
     * @param suggest 审批意见
     * @return
     */
    HikResult<String> completeTask(String taskId, ResultEnum result, String suggest);

    /**
     * 转发待办任务
     *
     * @param taskId   任务编号
     * @param suggest  意见
     * @param receivor 任务接收人
     * @return
     */
    HikResult<String> forwardTask(String taskId, String suggest, TaskReceivor receivor);

    /**
     * 加签任务
     *
     * @param taskId    任务编号
     * @param suggest   意见
     * @param receivors 任务接收人
     * @return
     */
    HikResult<String> addStep(String taskId, String suggest, List<TaskReceivor> receivors);

    /**
     * 开启流程任务
     *
     * @param process
     * @return
     */
    void startTask(ProcessInstance process);

    /**
     * 根据taskId获取docId
     */
    String getDocIdByTaskId(String taskId);

    /**
     * 根据任务id获取任务实例
     *
     * @param taskId
     * @return
     */
    TaskInstance getTaskInstance(String taskId);

    /**
     * 根据用户关键信息查询该员工下面的所有待办信息
     */
    GridData<PendingForwardBean> getPendingByUserName(String userNameOrEmpId,
                                                      int pageNum, int pageSize);

    /**
     * 根据单号批量查询待办信息
     */
    GridData<PendingForwardBean> getRecordByApplyIds(String applyIds,
                                                     int pageNum, int pageSize);

    /**
     * 修改当前审批人数据
     */
    void updateBpmInfo(String delegator, String processIds, String taskIds) throws Exception;

    /**
     * 根据关键字查找用户
     */
    List<PendingForwardBean> getSelectUser(String searchText);

    /**
     * 获取待审批任务列表
     * @return
     */
    List<TodoInfo> getTasksToApprove();

    /**
     * 获取已审批任务列表
     * @param pageNumber
     * @param pageSize
     * @return
     */
    List<TodoInfo> getApprovedTasks(int pageNumber, int pageSize);
}
