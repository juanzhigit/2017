package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.util.List;

public class GridData<T> implements Serializable{
	private static final long serialVersionUID = 8501710523017854L;
	/** Total number of pages */
	private int total;
	/** The current page number */
	private int page;
	/** Total number of records */
	private Long records;
	/** The actual data */
	private List<T> rows;

	public GridData() {
	}

	public GridData(int total, int page, Long records, List<T> rows) {
		this.total = total;
		this.page = page;
		this.records = records;
		this.rows = rows;
	}

	public int getTotal() {
		return total;
	}

	public int getPage() {
		return page;
	}

	public Long getRecords() {
		return records;
	}

	public List<T> getRows() {
		return rows;
	}

}
