package com.hikvision.it.expense.api.entity.batch;

import java.sql.Date;

public class PayFilter {

	private String applyId; // 报销单号
	private String userName; // 报销人
	private String apUserName; // 财务会计
	private String bukrs; // 公司
	private Date startDate; // 开始日期
	private Date endDate; // 结束日期
	
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getApUserName() {
		return apUserName;
	}
	public void setApUserName(String apUserName) {
		this.apUserName = apUserName;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public Date getStartDate() {
		return startDate;
	}
	public void setStartDate(Date startDate) {
		this.startDate = startDate;
	}
	public Date getEndDate() {
		return endDate;
	}
	public void setEndDate(Date endDate) {
		this.endDate = endDate;
	}
	
}
