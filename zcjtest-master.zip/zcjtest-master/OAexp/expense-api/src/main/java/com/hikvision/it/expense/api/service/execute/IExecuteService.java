package com.hikvision.it.expense.api.service.execute;

import java.util.List;

import com.hikvision.it.expense.api.entity.flow.ProcessInstance;
import com.hikvision.it.expense.api.entity.task.TaskInstance;

/**
 * 通用服务配置接口
 * <p>Title: IExecuteService.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月17日
 *
 */
public interface IExecuteService {
	/**
	 * 用服务接口方法
	 * @param process	流程实例信息
	 * @param tasks		当前任务信息
	 */
	void execute(ProcessInstance process, List<TaskInstance> tasks);
}
