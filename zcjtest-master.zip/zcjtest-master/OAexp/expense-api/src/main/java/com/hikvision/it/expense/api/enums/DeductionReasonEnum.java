package com.hikvision.it.expense.api.enums;

/**
 * 扣减原因码
 * <p>Title: DeductionReasonEnum.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月29日
 *
 */
public enum DeductionReasonEnum {
	/** 补贴已发放 */
	PAID,
	/** 实习、外派人员不享受补贴 */
	SX_OR_WP_NO_SUBSIDY,
	/** 重复餐补，既享受误餐补贴，又报销业务招待费 */
	DUP,
	/** 未配置 */
	NOMATCH,
	/** 补贴差额计算 */
	WP_SUB,
	/** 会议包餐 */
	HYBC,
	/** 国际差旅无节假日补贴 */
	GJ_NO_BT,
	/** 会议培训差旅 */
	HYPX,
	/** 周末调休 */
	OFF_WEEKEND,
	/** 节假日未工作 */
	HOLIDAY_NO_WORK,
}
