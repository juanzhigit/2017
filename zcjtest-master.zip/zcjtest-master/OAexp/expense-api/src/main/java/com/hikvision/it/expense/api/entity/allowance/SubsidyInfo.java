package com.hikvision.it.expense.api.entity.allowance;

import java.io.Serializable;
import java.math.BigDecimal;
import java.sql.Date;

/**
 * 补贴明细entity
 * <p>Title: SubsidyInfo.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class SubsidyInfo implements Serializable {
	private static final long serialVersionUID = 2598744871634795976L;
	
	private String expenseType;			//费用类别
	private String userGrade;			//员工级别
	private String country;				//国家
	private String city;				//城市
	private String cityGrade;			//城市等级
	private String currency;			//币别
	private Date   validFrom;			//生效日期
	private Date   validTo;				//截止日期
	private int    hour;				//小时点
	private BigDecimal lineKM;			//公里数
	private BigDecimal amount = BigDecimal.ZERO;//标准金额
	
	public String getExpenseType() {
		return expenseType;
	}
	public void setExpenseType(String expenseType) {
		this.expenseType = expenseType;
	}
	public String getUserGrade() {
		return userGrade;
	}
	public void setUserGrade(String userGrade) {
		this.userGrade = userGrade;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCityGrade() {
		return cityGrade;
	}
	public void setCityGrade(String cityGrade) {
		this.cityGrade = cityGrade;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public Date getValidFrom() {
		return validFrom;
	}
	public void setValidFrom(Date validFrom) {
		this.validFrom = validFrom;
	}
	public Date getValidTo() {
		return validTo;
	}
	public void setValidTo(Date validTo) {
		this.validTo = validTo;
	}
	public int getHour() {
		return hour;
	}
	public void setHour(int hour) {
		this.hour = hour;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getLineKM() {
		return lineKM;
	}
	public void setLineKM(BigDecimal lineKM) {
		this.lineKM = lineKM;
	}
}
