package com.hikvision.it.expense.api.entity.allowance;

import java.io.Serializable;
import java.math.BigDecimal;

public class AllowanceDetail implements Serializable {
	private static final long serialVersionUID = 3928049937697596599L;
	
	private String id;					//唯一编号
	private String docId;				//单据编号
	private String docNo;				//申请单号
	private String userId;				//员工编号
	private String userName;			//员工姓名
	private String allowanceDate;		//补贴日期
	private String dateType = "ALL";	//AM:上午 PM:下午 ALL:全天
	private String allowanceType;		//补贴类别
	private String country;				//补贴国家
	private String city;				//补贴城市
	private String cityName;			//补贴城市名称
	private String currency;			//补贴币别
	private BigDecimal rate = BigDecimal.ONE;			//汇率 默认1
	private BigDecimal allowanceAmount = BigDecimal.ZERO;	//补贴金额
	private BigDecimal deductionAmount = BigDecimal.ZERO;	//扣减金额
	private BigDecimal payAmount = BigDecimal.ZERO;		//应付金额
	private String deductionReason;		//扣减原因
	private String deductionCurrency;	//扣减币别
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getDocNo() {
		return docNo;
	}
	public void setDocNo(String docNo) {
		this.docNo = docNo;
	}
	public String getUserId() {
		return userId;
	}
	public void setUserId(String userId) {
		this.userId = userId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getAllowanceDate() {
		return allowanceDate;
	}
	public void setAllowanceDate(String allowanceDate) {
		this.allowanceDate = allowanceDate;
	}
	public String getDateType() {
		return dateType;
	}
	public void setDateType(String dateType) {
		this.dateType = dateType;
	}
	public String getAllowanceType() {
		return allowanceType;
	}
	public void setAllowanceType(String allowanceType) {
		this.allowanceType = allowanceType;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getCityName() {
		return cityName;
	}
	public void setCityName(String cityName) {
		this.cityName = cityName;
	}
	public String getCurrency() {
		return currency;
	}
	public void setCurrency(String currency) {
		this.currency = currency;
	}
	public BigDecimal getAllowanceAmount() {
		return allowanceAmount;
	}
	public void setAllowanceAmount(BigDecimal allowanceAmount) {
		this.allowanceAmount = allowanceAmount;
	}
	public BigDecimal getDeductionAmount() {
		return deductionAmount;
	}
	public void setDeductionAmount(BigDecimal deductionAmount) {
		this.deductionAmount = deductionAmount;
	}
	public BigDecimal getPayAmount() {
		return payAmount;
	}
	public void setPayAmount(BigDecimal payAmount) {
		this.payAmount = payAmount;
	}
	public String getDeductionReason() {
		return deductionReason;
	}
	public void setDeductionReason(String deductionReason) {
		this.deductionReason = deductionReason;
	}
	public BigDecimal getRate() {
		return rate;
	}
	public void setRate(BigDecimal rate) {
		this.rate = rate;
	}
	public String getDeductionCurrency() {
		return deductionCurrency;
	}
	public void setDeductionCurrency(String deductionCurrency) {
		this.deductionCurrency = deductionCurrency;
	}
}
