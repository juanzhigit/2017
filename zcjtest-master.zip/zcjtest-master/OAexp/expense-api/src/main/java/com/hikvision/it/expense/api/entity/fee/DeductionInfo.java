package com.hikvision.it.expense.api.entity.fee;

import java.io.Serializable;
import java.math.BigDecimal;

public class DeductionInfo implements Serializable {

    private String docId;
    private String docNo;
    private String userId;
    private String subsidyDate;             // 补贴日期
    private BigDecimal exchangeRate;        // 汇率
    private BigDecimal amount;              // 补贴金额
    private String currency;                // 补贴币别
    private int count;                      // 业务招待次数
    private BigDecimal subAmount;           // 已扣金额
    private BigDecimal ykAmount;            // 应扣金额
    private BigDecimal adjustAmount;        // 可扣金额
    private BigDecimal adjustLocalAmount;   // 扣减人民币金额
    private int type;                       // 1-业务招待扣除; 2-包餐; 3-其他
    private String remark;                  // 备注
    private String operator;                // 操作人

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getSubsidyDate() {
        return subsidyDate;
    }

    public void setSubsidyDate(String subsidyDate) {
        this.subsidyDate = subsidyDate;
    }

    public BigDecimal getExchangeRate() {
        return exchangeRate;
    }

    public void setExchangeRate(BigDecimal exchangeRate) {
        this.exchangeRate = exchangeRate;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }

    public BigDecimal getSubAmount() {
        return subAmount;
    }

    public void setSubAmount(BigDecimal subAmount) {
        this.subAmount = subAmount;
    }

    public BigDecimal getYkAmount() {
        return ykAmount;
    }

    public void setYkAmount(BigDecimal ykAmount) {
        this.ykAmount = ykAmount;
    }

    public BigDecimal getAdjustAmount() {
        return adjustAmount;
    }

    public void setAdjustAmount(BigDecimal adjustAmount) {
        this.adjustAmount = adjustAmount;
    }

    public BigDecimal getAdjustLocalAmount() {
        return adjustLocalAmount;
    }

    public void setAdjustLocalAmount(BigDecimal adjustLocalAmount) {
        this.adjustLocalAmount = adjustLocalAmount;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }

    public String getOperator() {
        return operator;
    }

    public void setOperator(String operator) {
        this.operator = operator;
    }
}
