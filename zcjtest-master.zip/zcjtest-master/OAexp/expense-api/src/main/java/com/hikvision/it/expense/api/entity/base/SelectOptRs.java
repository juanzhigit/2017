package com.hikvision.it.expense.api.entity.base;

import java.io.Serializable;
import java.util.List;

/**
 * 选择结果通用返回逻辑
 */
public class SelectOptRs implements Serializable {
    private static final long serialVersionUID = 2330665343004377437L;
    private boolean group;          //是否分组
    private List<SelectOpt> data;   //可选数据

    public SelectOptRs() {
    }

    public SelectOptRs(boolean group, List<SelectOpt> data) {
        this.group = group;
        this.data = data;
    }

    public boolean isGroup() {
        return group;
    }

    public void setGroup(boolean group) {
        this.group = group;
    }

    public List<SelectOpt> getData() {
        return data;
    }

    public void setData(List<SelectOpt> data) {
        this.data = data;
    }
}
