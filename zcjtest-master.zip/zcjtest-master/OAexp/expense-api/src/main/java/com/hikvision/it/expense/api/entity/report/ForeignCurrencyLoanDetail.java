package com.hikvision.it.expense.api.entity.report;

import java.math.BigDecimal;

/**
 * 外币借款明细
 */
public class ForeignCurrencyLoanDetail {

    private String docId;       // 单据编号
    private String docNo;       // 单号
    private String bukrsName;   // 付款公司名称
    private String userName;    // 借款人姓名
    private String loanDate;    // 借款日期
    private String currency;    // 币别
    private BigDecimal amount;  // 借款金额

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getDocNo() {
        return docNo;
    }

    public void setDocNo(String docNo) {
        this.docNo = docNo;
    }

    public String getBukrsName() {
        return bukrsName;
    }

    public void setBukrsName(String bukrsName) {
        this.bukrsName = bukrsName;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public String getLoanDate() {
        return loanDate;
    }

    public void setLoanDate(String loanDate) {
        this.loanDate = loanDate;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }
}
