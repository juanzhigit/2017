package com.hikvision.it.expense.api.entity.voucher;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 在途未清统计
 */
public class OnlineBsikSummary implements Serializable {

    private BigDecimal cny = BigDecimal.ZERO;
    private BigDecimal eur = BigDecimal.ZERO;
    private BigDecimal usd = BigDecimal.ZERO;
    private BigDecimal gbp = BigDecimal.ZERO;
    private BigDecimal total = BigDecimal.ZERO;

    public BigDecimal getCny() {
        return cny;
    }

    public void setCny(BigDecimal cny) {
        this.cny = cny;
    }

    public BigDecimal getEur() {
        return eur;
    }

    public void setEur(BigDecimal eur) {
        this.eur = eur;
    }

    public BigDecimal getUsd() {
        return usd;
    }

    public void setUsd(BigDecimal usd) {
        this.usd = usd;
    }

    public BigDecimal getGbp() {
        return gbp;
    }

    public void setGbp(BigDecimal gbp) {
        this.gbp = gbp;
    }

    public BigDecimal getTotal() {
        return total;
    }

    public void setTotal(BigDecimal total) {
        this.total = total;
    }

    public void add(String currency, BigDecimal num) {
        if ("CNY".equals(currency)) {
            cny = cny.add(num);
        } else if ("USD".equals(currency)) {
            usd = usd.add(num);
        } else if ("GBP".equals(currency)) {
            gbp = gbp.add(num);
        } else if ("EUR".equals(currency)) {
            eur = eur.add(num);
        }
    }
    public void addTotal(BigDecimal num) {
        total = total.add(num);
    }
}
