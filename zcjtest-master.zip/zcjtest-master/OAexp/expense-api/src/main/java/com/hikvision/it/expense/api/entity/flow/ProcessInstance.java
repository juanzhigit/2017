package com.hikvision.it.expense.api.entity.flow;

import java.io.Serializable;

public class ProcessInstance implements Serializable {
	private static final long serialVersionUID = -3054547220895106199L;
	
	private String processId;			//流程编码
	private String processObjectId;		//流程定义编号
	private String docId;				//报销单号
	private String processStatus;		//流程状态
	private String processStatusDesc;	//流程状态描述
	private String createdBy;			//创建人
	private String createdByName;		//创建人姓名
	private Long   crTime;				//创建时间毫秒数（当地时间）
	private Long   cmTime;				//完成时间的毫秒数（当地时间）
	private int    versionRd = 1;		//审批回合  默认1
	private String isCompleted = "N";	//流程结束标识
	private Long   upTime;				//更新时间毫秒
	private Long   currentTime;			//当前时间毫秒
	private String operators;			//当前处理人
	
	public String getProcessId() {
		return processId;
	}
	public void setProcessId(String processId) {
		this.processId = processId;
	}
	public String getProcessObjectId() {
		return processObjectId;
	}
	public void setProcessObjectId(String processObjectId) {
		this.processObjectId = processObjectId;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getProcessStatus() {
		return processStatus;
	}
	public void setProcessStatus(String processStatus) {
		this.processStatus = processStatus;
	}
	public String getProcessStatusDesc() {
		return processStatusDesc;
	}
	public void setProcessStatusDesc(String processStatusDesc) {
		this.processStatusDesc = processStatusDesc;
	}
	public String getCreatedBy() {
		return createdBy;
	}
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}
	public String getCreatedByName() {
		return createdByName;
	}
	public void setCreatedByName(String createdByName) {
		this.createdByName = createdByName;
	}
	public Long getCrTime() {
		return crTime;
	}
	public void setCrTime(Long crTime) {
		this.crTime = crTime;
	}
	public Long getCmTime() {
		return cmTime;
	}
	public void setCmTime(Long cmTime) {
		this.cmTime = cmTime;
	}
	public int getVersionRd() {
		return versionRd;
	}
	public void setVersionRd(int versionRd) {
		this.versionRd = versionRd;
	}
	public String getIsCompleted() {
		return isCompleted;
	}
	public void setIsCompleted(String isCompleted) {
		this.isCompleted = isCompleted;
	}
	public Long getUpTime() {
		return upTime;
	}
	public void setUpTime(Long upTime) {
		this.upTime = upTime;
	}
	public Long getCurrentTime() {
		return currentTime;
	}
	public void setCurrentTime(Long currentTime) {
		this.currentTime = currentTime;
	}
	public String getOperators() {
		return operators;
	}
	public void setOperators(String operators) {
		this.operators = operators;
	}
}
