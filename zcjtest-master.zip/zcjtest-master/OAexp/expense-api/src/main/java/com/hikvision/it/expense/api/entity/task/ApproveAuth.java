package com.hikvision.it.expense.api.entity.task;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 审批权限entity
 * <p>Title: ApproveAuth.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年3月17日
 *
 */
public class ApproveAuth implements Serializable {
	private static final long serialVersionUID = 9190772632159774814L;

	private String author;			//授权人
	private String authorName;		//授权人姓名
	private String authArea;		//授权范围
	private String authBus;			//授权业务类型
	private String authDept;		//授权部门
	private String agent;			//代理人
	private String agentName;		//代理人姓名
	private String agentMail;		//代理人邮箱
	private int    agentGrade;		//代理人级别
	private BigDecimal minJe;		//起批金额
	private BigDecimal maxJe;		//最大审批金额
	private int    lv;				//匹配级别
	
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getAuthorName() {
		return authorName;
	}
	public void setAuthorName(String authorName) {
		this.authorName = authorName;
	}
	public String getAuthArea() {
		return authArea;
	}
	public void setAuthArea(String authArea) {
		this.authArea = authArea;
	}
	public String getAuthBus() {
		return authBus;
	}
	public void setAuthBus(String authBus) {
		this.authBus = authBus;
	}
	public String getAuthDept() {
		return authDept;
	}
	public void setAuthDept(String authDept) {
		this.authDept = authDept;
	}
	public String getAgent() {
		return agent;
	}
	public void setAgent(String agent) {
		this.agent = agent;
	}
	public String getAgentName() {
		return agentName;
	}
	public void setAgentName(String agentName) {
		this.agentName = agentName;
	}
	public String getAgentMail() {
		return agentMail;
	}
	public void setAgentMail(String agentMail) {
		this.agentMail = agentMail;
	}
	public int getAgentGrade() {
		return agentGrade;
	}
	public void setAgentGrade(int agentGrade) {
		this.agentGrade = agentGrade;
	}
	public BigDecimal getMinJe() {
		return minJe;
	}
	public void setMinJe(BigDecimal minJe) {
		this.minJe = minJe;
	}
	public BigDecimal getMaxJe() {
		return maxJe;
	}
	public void setMaxJe(BigDecimal maxJe) {
		this.maxJe = maxJe;
	}
	public int getLv() {
		return lv;
	}
	public void setLv(int lv) {
		this.lv = lv;
	}
}
