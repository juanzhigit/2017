package com.hikvision.it.expense.api.entity.batch;

import java.io.Serializable;

public class PayHead implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -1389680747030806669L;

	private String taskId; // 任务id
	private String docId; // 单据id
	private String status; // 付款状态
	private String apUserName; // 财务会计
	private String processName; // 流程名称
	private String applyId; // 报销单号
	private String expensor; // 报销人
	private String expensorName; // 报销人姓名
	private String bukrs; // 公司
	private String bukrsName; // 公司名
	private String message; // 消息

	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public String getApUserName() {
		return apUserName;
	}
	public void setApUserName(String apUserName) {
		this.apUserName = apUserName;
	}
	public String getProcessName() {
		return processName;
	}
	public void setProcessName(String processName) {
		this.processName = processName;
	}
	public String getApplyId() {
		return applyId;
	}
	public void setApplyId(String applyId) {
		this.applyId = applyId;
	}
	public String getBukrs() {
		return bukrs;
	}
	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}
	public String getBukrsName() {
		return bukrsName;
	}
	public void setBukrsName(String bukrsName) {
		this.bukrsName = bukrsName;
	}
	public String getTaskId() {
		return taskId;
	}
	public void setTaskId(String taskId) {
		this.taskId = taskId;
	}
	public String getMessage() {
		return message;
	}
	public void setMessage(String message) {
		this.message = message;
	}
	public String getDocId() {
		return docId;
	}
	public void setDocId(String docId) {
		this.docId = docId;
	}
	public String getExpensor() {
		return expensor;
	}
	public void setExpensor(String expensor) {
		this.expensor = expensor;
	}
	public String getExpensorName() {
		return expensorName;
	}
	public void setExpensorName(String expensorName) {
		this.expensorName = expensorName;
	}

}
