package com.hikvision.it.expense.api.entity.form;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * 超标信息
 */
public class OverproofInfo implements Serializable {
    private static final long serialVersionUID = -3102459879371768975L;
    private String docId;
    private String type;
    private BigDecimal amount;
    private String remark;

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public String getRemark() {
        return remark;
    }

    public void setRemark(String remark) {
        this.remark = remark;
    }
}
