package com.hikvision.it.expense.admin.controller;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.service.user.IUserService;
import org.jasig.cas.client.authentication.AttributePrincipalImpl;
import org.jasig.cas.client.util.AbstractCasFilter;
import org.jasig.cas.client.validation.AssertionImpl;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.mvc.support.RedirectAttributesModelMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Reference(version = Version.VERSION_LATEST)
    IUserService userService;

    @RequestMapping(value = "login", method = RequestMethod.GET)
    public String login(HttpServletRequest request, HttpSession session) {
        return "login";
    }

    @RequestMapping(value = "login", method = RequestMethod.POST)
    public String login(String userShortName, String language, HttpSession session, RedirectAttributesModelMap redirectModel) {

        User user = userService.findUserByUserShortName(userShortName, language);
        if (user == null) {
            redirectModel.addFlashAttribute("message", "用户不存在");
        } else {
            AssertionImpl assertion = new AssertionImpl(new AttributePrincipalImpl(userShortName, Maps.newConcurrentMap()));
            session.setAttribute(AbstractCasFilter.CONST_CAS_ASSERTION, assertion);
            redirectModel.addFlashAttribute("message", "登录成功");

            LoginUser loginUser = new LoginUser();
            loginUser.setUserId(user.getUserId());
            loginUser.setLanguage(language);
            loginUser.setUserName(user.getUserName());
            loginUser.setNotesId(user.getNotesId());
            loginUser.setSapAccount(user.getSapId());
            loginUser.setUserGrade(user.getGrade());
            session.setAttribute("ExpenseUser", loginUser);
            UserContext.set(loginUser);
        }
        return "redirect:/login";
    }
}
