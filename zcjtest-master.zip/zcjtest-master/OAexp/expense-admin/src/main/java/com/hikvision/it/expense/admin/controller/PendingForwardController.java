package com.hikvision.it.expense.admin.controller;


import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.admin.dto.ForwardBean;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.task.PendingForwardBean;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.service.task.ITaskService;

@Controller
@RequestMapping("/pending")
public class PendingForwardController {

    public static final String PERSON_FORWARDING_TYPE = "1";//待办转发查询种类为按人员查询
    public static final String ODD_NUMBERS_FORWARDING_TYPE = "2";//待办转发查询种类为按单号查询
    private Logger logger = LoggerFactory.getLogger(getClass());
    @Reference(version = Version.VERSION_LATEST)
    ITaskService taskService;

    /**
     * 对私待办转发数据查询
     * @param pending
     * @param page
     * @param rows
     * @return
     */
    @RequestMapping("/showList")
    public ResponseEntity<GridData<PendingForwardBean>> showList(PendingForwardBean pending, @RequestParam(value = "page", defaultValue = "1") int page, @RequestParam(value = "rows") int rows) {
        GridData<PendingForwardBean> pendingList = null;
        if (PERSON_FORWARDING_TYPE.equals(pending.getForwardType())) {
            pendingList = taskService.getPendingByUserName(pending.getUserIdOrName(),
                    page, rows);
        }
        if (ODD_NUMBERS_FORWARDING_TYPE.equals(pending.getForwardType())) {
            pendingList = taskService.getRecordByApplyIds(pending.getApplyids(),
                    page, rows);
        }
        if (pendingList == null) {
            pendingList = new GridData<>();
        }
        return ResponseEntity.ok(pendingList);
    }

    /**
     * 对私待办转发页面跳转
     * @param response
     * @return
     */
    @RequestMapping("/forward")
    public String pendingHtml(HttpServletResponse response) {
        return "pendingForward/pendingForward";
    }

    /*转发对话框跳转*/
    @RequestMapping(value = "/forwardDialog")
    String forward(String taskIds, String processIds, Model model) {
        model.addAttribute("taskIds", taskIds);
        model.addAttribute("processIds", processIds);
        return "pendingForward/forwardForm";
    }

    /*接收人选查询*/
    @RequestMapping(value = "selectUser", produces = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<HikResult<List<PendingForwardBean>>> selectUser(
            @RequestParam(value = "term", required = false) String term) {
        HikResult<List<PendingForwardBean>> result = new HikResult<List<PendingForwardBean>>();
        List<PendingForwardBean> items = Lists.newLinkedList();
        if (!Strings.isNullOrEmpty(term))
            items = taskService.getSelectUser(term);
        result.setData(items);
        return ResponseEntity.ok(result);
    }

    /*开始转发*/
    @ResponseBody
    @RequestMapping("/forwardEvent")
    public HikResult<String> forwardEvent(@RequestBody ForwardBean forwardBean) {
        LoginUser user = UserContext.get();
        HikResult<String> result = new HikResult<String>();
        String taskIds = forwardBean.getTaskIds();
        String processIds = forwardBean.getProcessIds();
        String delegator = forwardBean.getDelegator();
        if (Strings.isNullOrEmpty(taskIds) || Strings.isNullOrEmpty(delegator) || delegator.equalsIgnoreCase(user.getUserId())) {
            result.addError("转发失败!转发人不能为空或者不能为自己");
            return result;
        }
        try {
            taskService.updateBpmInfo(delegator, processIds, taskIds);
        } catch (Exception e) {
            logger.error(e.getMessage(), e);
            result.addError("转发失败!");
        }
        return result;
    }
}
