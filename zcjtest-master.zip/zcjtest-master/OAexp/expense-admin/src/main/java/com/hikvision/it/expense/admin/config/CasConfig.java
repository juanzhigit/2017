package com.hikvision.it.expense.admin.config;

import javax.servlet.DispatcherType;

import org.jasig.cas.client.util.AssertionThreadLocalFilter;
import org.jasig.cas.client.util.HttpServletRequestWrapperFilter;
import org.springframework.boot.web.servlet.FilterRegistrationBean;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

@Configuration
public class CasConfig {

    @Bean
    public FilterRegistrationBean casHttpRequestFilter() {
        HttpServletRequestWrapperFilter filter = new HttpServletRequestWrapperFilter();
        FilterRegistrationBean casHttpRequestFilter = new FilterRegistrationBean(filter);
        casHttpRequestFilter.addUrlPatterns("/*");
        return casHttpRequestFilter;
    }

    @Bean
    public FilterRegistrationBean assertionThreadLocalFilter() {
        AssertionThreadLocalFilter filter = new AssertionThreadLocalFilter();
        FilterRegistrationBean registration = new FilterRegistrationBean(filter);
        registration.setDispatcherTypes(DispatcherType.REQUEST);
        registration.addUrlPatterns("/*");
        return registration;
    }

}
