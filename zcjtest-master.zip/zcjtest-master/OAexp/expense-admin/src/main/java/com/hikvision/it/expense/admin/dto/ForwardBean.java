package com.hikvision.it.expense.admin.dto;

import java.io.Serializable;

/**
 * 转发DTO
 * 
 * @author liangdong5
 *
 */
public class ForwardBean implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = -7893738635989071108L;
	private String delegator; // 转发用户
	private String processIds;// 流程Ids
	private String taskIds;// 任务Ids
	private String comments; // 备注

	public ForwardBean() {
	}

	public String getDelegator() {
		return delegator;
	}

	public void setDelegator(String delegator) {
		this.delegator = delegator;
	}



	public String getProcessIds() {
		return processIds;
	}

	public void setProcessIds(String processIds) {
		this.processIds = processIds;
	}

	public String getTaskIds() {
		return taskIds;
	}

	public void setTaskIds(String taskIds) {
		this.taskIds = taskIds;
	}

	public String getComments() {
		return comments;
	}

	public void setComments(String comments) {
		this.comments = comments;
	}

}
