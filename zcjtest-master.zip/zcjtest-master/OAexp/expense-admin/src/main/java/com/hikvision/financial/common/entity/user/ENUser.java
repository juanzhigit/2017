package com.hikvision.financial.common.entity.user;

import java.io.Serializable;

public class ENUser extends User implements Serializable {

	private static final long serialVersionUID = -7331849805984159864L;

	private String isNew;// 是否新系统
	private String oneToMany;// 申请转报销可以一对多
	private String baseId;// 海外用户所在地

	public String getBaseId() {
		return baseId;
	}

	public void setBaseId(String baseId) {
		this.baseId = baseId;
	}

	public String getIsNew() {
		return isNew;
	}

	public void setIsNew(String isNew) {
		this.isNew = isNew;
	}

	public String getOneToMany() {
		return oneToMany;
	}

	public void setOneToMany(String oneToMany) {
		this.oneToMany = oneToMany;
	}

}
