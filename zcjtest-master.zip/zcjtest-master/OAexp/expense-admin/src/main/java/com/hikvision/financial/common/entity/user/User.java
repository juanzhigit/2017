package com.hikvision.financial.common.entity.user;

import java.io.Serializable;

public class User implements Serializable {
	private static final long serialVersionUID = 8192363075329228061L;
	private String userId; // 用戶id
	private String userName; // 用户名称
	private String grade; // 用户级别
	private String nation; // 国家代码
	private String deptCode; // 部门编码
	private String deptName; // 部门名称
	private String deptPath; // 部门路劲
	private String deptCodePath;// 部门代码路径
	private String notesId; // oa账号
	private String uniqueName; // 唯一用户名
	private String bukrs; // 公司代码
	private String bukrsName; // 公司名称
	private String currency; // 公司的货币
	private String sapId; // sap员工号
	private String credit_lv; // 员工诚信等级
	private String userStatus; // 员工状态
	private String userInmail; // 邮箱

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getNation() {
		return nation;
	}

	public void setNation(String nation) {
		this.nation = nation;
	}

	public String getDeptCode() {
		return deptCode;
	}

	public void setDeptCode(String deptCode) {
		this.deptCode = deptCode;
	}

	public String getDeptName() {
		return deptName;
	}

	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}

	public String getNotesId() {
		return notesId;
	}

	public void setNotesId(String notesId) {
		this.notesId = notesId;
	}

	public String getUniqueName() {
		return uniqueName;
	}

	public void setUniqueName(String uniqueName) {
		this.uniqueName = uniqueName;
	}

	public String getBukrs() {
		return bukrs;
	}

	public void setBukrs(String bukrs) {
		this.bukrs = bukrs;
	}

	public String getBukrsName() {
		return bukrsName;
	}

	public void setBukrsName(String bukrsName) {
		this.bukrsName = bukrsName;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getSapId() {
		return sapId;
	}

	public void setSapId(String sapId) {
		this.sapId = sapId;
	}

	public String getCredit_lv() {
		return credit_lv;
	}

	public void setCredit_lv(String credit_lv) {
		this.credit_lv = credit_lv;
	}

	public String getUserStatus() {
		return userStatus;
	}

	public void setUserStatus(String userStatus) {
		this.userStatus = userStatus;
	}

	public String getUserInmail() {
		return userInmail;
	}

	public void setUserInmail(String userInmail) {
		this.userInmail = userInmail;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public String getDeptPath() {
		return deptPath;
	}

	public void setDeptPath(String deptPath) {
		this.deptPath = deptPath;
	}

	public String getDeptCodePath() {
		return deptCodePath;
	}

	public void setDeptCodePath(String deptCodePath) {
		this.deptCodePath = deptCodePath;
	}
}
