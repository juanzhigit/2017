package com.hikvision.it.expense.admin.filter.dubbo;

import com.alibaba.dubbo.rpc.*;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.enums.DeviceEnum;
import com.hikvision.it.expense.api.exception.ExpenseException;

import java.util.Map;

public class CurrentUserFilter implements Filter {
    @Override
    public Result invoke(Invoker<?> invoker, Invocation invocation) throws ExpenseException, RpcException {
        Map<String, String> attachments = invocation.getAttachments();

//        LoginUser user = UserContext.get();
//        if (user != null) {
//            attachments.put("userId", user.getUserId());
//            attachments.put("language", user.getLanguage());
//            attachments.put("userName", user.getUserName());
//            attachments.put("notesId", user.getNotesId());
//            attachments.put("sapAccount", user.getSapAccount());
//            attachments.put("device", DeviceEnum.PC.name());
//        } else {
//            if (!"findUserByUserShortName".equals(invocation.getMethodName())) {
//                throw new ExpenseException(401);
//            }
//        }
        if (!"findUserByUserShortName".equals(invocation.getMethodName())) {
            try {
                LoginUser user = UserContext.get();
                attachments.put("userId", user.getUserId());
                attachments.put("language", user.getLanguage());
                attachments.put("userName", user.getUserName());
                attachments.put("notesId", user.getNotesId());
                attachments.put("sapAccount", user.getSapAccount());
                attachments.put("device", DeviceEnum.PC.name());
            } catch (ExpenseException ex) {
                throw new ExpenseException(401);
            }
        }
        return invoker.invoke(invocation);
    }
}
