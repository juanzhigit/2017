//初始化 按钮 查询
function initFiFlowJs() {
    initApplyTable();
    initSearchBtn();
}


function initSearchBtn() {
    $("#searchBtn").click(function (event) {

        var forwardType = $("input[name='forwardType']:checked").val();
        var applyId = getApplyIdFromTextArea();
        var userIdOrName = $("#userIdOrName").val();
        gridReload(applyId, userIdOrName, forwardType);
    });
    $("#forwardBtn").click(function (event) {
        runOpenForward();
    });

    $(":radio").click(function () {
        var type = $(this).val();
        if (type == 2) {
            $("#userIdOrName").val('');
            $("#userIdOrName").attr("readOnly", "true");
            $("#leftApply").css("visibility", "visible");
            $("#applyIds").focus();
        } else {
            $("#userIdOrName").removeAttr("readOnly").focus();
            $("#applyIds").val('');
            $("#leftApply").css("visibility", "hidden");
        }

    });

}


/**
 * grid刷新
 */
function gridReload(applyId, userIdOrName, forwardType) {
    $applyTable.jqGrid('setGridParam', {
        url: path + '/pending/showList?applyids=' + applyId + '&userIdOrName=' + encodeURI(userIdOrName) + '&forwardType=' + forwardType
        ,
        page: 1
    }).trigger("reloadGrid");
}


var $applyTable;

/**
 * fiflowLastRow
 * fiflowLastCell
 * 在删除之前先模拟保存，这样编辑单元格下方的单元格，在上面行删除的时候，就不会信息丢失了
 */
var fiflowLastRow;
var fiflowLastCell;


function initApplyTable() {
    $applyTable = $("#flowTable");
    $applyTable.jqGrid({

        url: path + '/pending/showList',
        'datatype': 'json',
        'autoScroll': true,
        'multiselect': true,
        'rownumbers': true,
        'cmTemplate': {
            'sortable': false,
            'resizable': false,
            align: 'center'
        },
        'height': '200',
        colNames: ['id', 'taskId', 'processId', '单号', '人员编号', '人员姓名', '提单日期', '到达财务日期', '金额(元)', '信用等级', '滞留天数'],
        colModel: [
            {
                name: 'id',
                align: 'center',
                hidden: true,
                editable: false
            },
            {
                name: 'taskId',
                align: 'center',
                hidden: true,
                editable: false
            }, {
                name: 'processId',
                align: 'center',
                hidden: true,
                editable: false
            },
            {
                name: 'applyid',
                align: 'center',
                editable: false
            },
            {
                name: 'claimuser',
                align: 'center',
                editable: false,
                width: 120,

            },
            {
                name: 'claimUserName',
                align: 'center',
                editable: false,
            },
            {
                name: 'subdate',
                align: 'center',
                editable: false,
                width: 150,

            }, {
                name: 'createtime',
                align: 'center',
                editable: false,
                width: 180,


            }, {
                name: 'amtclaim',
                align: 'center',
                editable: false,

            },
            {
                name: 'curCredit',
                align: 'center',
                editable: false,

            },
            {
                name: 'zlts',
                align: 'center',
                editable: false,

            }
        ],
        //rowNum : 10,
        //rowList:[10,50,100],
        mtype: "POST",
        //pager : jQuery('#pagerb'),
        //sortname : 'subTime',
        //sortorder : "desc",
        pgbuttons: true,
        viewrecords: true,
        afterEditCell: function (rowid, cellname, value, iRow, iCol) {

        },
        afterSubmitCell: function (rowid, cellname, value, iRow, iCol) {

        },
        onSelectCell: function (rowid, cellname, value, iRow, iCol) {

        },
        loadComplete: function (data) {
            if (data.records < 8) {
                $(this).setGridHeight(374);
            } else {
                $(this).setGridHeight('100%');
            }
        },

        afterSaveCell: function (rowid, cellname, value, iRow, iCol) {

        },

        beforeSaveCell: function (rowid, cellname, value, iRow, iCol) {

        },
        beforeEditCell: function (rowid, cellname, value, iRow, iCol) {
            fiflowLastRow = iRow;
            fiflowLastCell = iCol;
        },
        gridComplete: function (data) {
            var ids = $applyTable.jqGrid('getDataIDs');
            if (undefined != ids && null != ids && ids.length > 0) {
            }

        }
    });


    $applyTable.closest(".ui-jqgrid-bdiv").css({'overflow-y': 'scroll'});

}


function showMsg(id, cls, msg, time) {
    jQuery('#' + id).addClass(cls + ' msg-font').html(msg).show().hide(time);
}


function getApplyIdFromTextArea() {
    var applyidlist = $("#applyIds").val();
    if (applyidlist != null && applyidlist.length > 0) {
        applyidlist = applyidlist.replace(/\n/g, ";");
    }
    return applyidlist;
}
/*拼接taskids及processids*/
function runOpenForward(taskId) {
    var taskIds = [];
    var processIds = [];
    var selects = $applyTable.jqGrid('getGridParam', 'selarrrow');
    if (selects.length > 0) {
        for (selectId in selects) {
            var rowData = $applyTable.jqGrid("getRowData", selects[selectId]);
            taskIds.push(rowData.taskId);
            processIds.push(rowData.processId);
        }
    } else {

        Public.showError("没有选择的行项目");
        return;
    }
    var forwardDialog = BootstrapDialog.show({
        message: function (dialog) {
            var $message = $('<div></div>');
            var pageToLoad = dialog.getData('pageToLoad');
            $message.load(pageToLoad);

            return $message;
        },
        data: {
            'pageToLoad': path + '/pending/forwardDialog?taskIds=' + taskIds + '&processIds=' + processIds
        },
        onshow: function () { //解决select2下拉框错位问题
            this._top = $(document).scrollTop();
            $(document).scrollTop(0);
        },
        onhide: function () { //解决select2下拉框错位问题
            $(document).scrollTop(this._top);
        },
        title: '<strong>转发</strong>',
        buttons: [{
            label: '确定',
            cssClass: 'btn-primary',
            action: function (dialogItself) {
                $.when(forwordFunc()).done(function (rs) {
                    if (rs.success) {
                        Public.showSuccess("流转成功");
                        $("#flowTable").trigger("reloadGrid");
                    } else {
                        Public.showError(rs.errorMsgs);
                    }
                });

                dialogItself.close();
            }
        }, {
            label: '关闭',
            action: function (dialogItself) {
                dialogItself.close();
            }
        }]
    });

    forwardDialog.getModal().removeAttr("tabindex");


}
Public.ajaxPost = function (url, params, callback, errCallback, dataType) {
    $.ajax({
        contentType: 'application/json',
        type: "POST",
        url: path + url,
        data: JSON.stringify(params),
        dataType: dataType ? dataType : 'json',
        success: function (data, status) {
            if (data.status == 504) {
                $('html').html(data.responseText);
            } else {
                callback(data);
            }
        },
        error: function (err) {
            if (err.status == 504) {
                $('html').html(err.responseText);
            } else {
                parent.Public.tips({
                    type: 1,
                    content: '操作失败了哦，请检查您的网络链接！'
                });

                errCallback && errCallback(err);
            }
        }
    });
}
function forwordFunc() {
    var defer = $.Deferred();
    var data = {};
    data.taskIds = $("#taskIds").val();
    data.processIds = $("#processIds").val();
    data.delegator = $("#forwardSelect").val();
    data.comments = $("#forwardComments").val();
    Public.ajaxPost("/pending/forwardEvent", data, function (rs) {
        defer.resolve(rs);
    }, function (rs) {
        defer.reject(rs);
    });
    return defer.promise();
}

function isIE() { //ie?
    if (!!window.ActiveXObject || "ActiveXObject" in window)
        return true;
    else
        return false;
}

function bindSelect(url, formatRepo, formatRepoSelection, minimun) {
    var modalId = $(this).parents("div.modal.bootstrap-dialog").attr("id");
    if (formatRepo == 'undefined')
        formatRepo = null;
    if (formatRepoSelection == 'undefined')
        formatRepoSelection = null;
    if (minimun == 'undefined')
        minimun = 1;
    $(this).select2({
        ajax: {
            url: path + url,
            dataType: 'json',
            tags: true,
            delay: 250,
            data: function (params) {
                return {
                    term: params.term // search term
                };
            },
            processResults: function (rs, page) {
                return {
                    results: rs.data
                };
            },
            cache: true
        },
        minimumInputLength: minimun,
        escapeMarkup: function (markup) {
            return markup;
        },
        templateResult: formatRepo,
        templateSelection: formatRepoSelection,
        dropdownParent: (modalId == undefined ? "" : "#" + modalId)
    });
}


