$.extend($.jgrid.defaults, {
    rowNum : 10000,
    'cmTemplate' : {
        'sortable' : false,
        'resizable' : false,
        align : 'center',

        searchoptions : {
            clearSearch : false,
            dataInit : function(element) {
                $(element).attr("placeholder", "Search");
            }
        }
    },
    responsive : false,
    styleUI : 'Bootstrap',
    loadError : function(xhr, status, error) {
        parent.Public.tips({
            type : 1,
            content : '表格加载失败!'
        });
    }
});

/* 公共方法 */
var Grid = Grid || {};

Grid.addRow = function($grid, init) {
    this.saveCell($grid);
	$grid.jqGrid('addRowData', getUUID(), init, 'last');
}

Grid.saveCell = function ($grid) {
	var iRow = $grid.data('iRow');
    var iCol = $grid.data('iCol');
    if (iRow && iCol) {
    	$grid.jqGrid("saveCell", iRow, iCol);
	}
}

Grid.getJson = function($grid, all) {
    this.saveCell($grid);
	if (all)
        $grid.find("tr.ui-row-ltr").addClass('edited');
	return $grid.getChangedCells("all");
}

/**
 * 初始化表格数据
 * @param $grid 对应表格
 * @param data 初始化数据
 * @param minRows 最少显示行数, 默认1, 不小于data.length
 */
Grid.initRowData = function ($grid, data, minRows) {
    minRows = minRows === undefined ? 1 : minRows;
	data = data || [];
	if (data.length > minRows) {
	    minRows = data.length;
    }
    var emptyRowIdx = data.length;
	while(data.length < minRows) {
		data.push({
			id: Public.getUUID()
		});
	}
    $grid.jqGrid('clearGridData');
	for (var i = 0; i < data.length; i++) {
		var rowData = data[i];
		if (!rowData.id) {
			rowData.id = Public.getUUID();
		}
        $grid.jqGrid('addRowData', rowData.id, rowData);
		if (i < emptyRowIdx) {
        	$grid.find("#" + rowData.id).addClass('edited');
		}
    }
};

Grid.addRowData = function($grid, id, rowData, edited) {
    $grid.jqGrid('addRowData', id, rowData);
    if (edited) {
        $grid.find("#" + id).addClass('edited');
    }
};

Grid.localGrid = function($grid, op, groupHeaders) {
	var opt = {
		'cellEdit' : true,
		'cellsubmit' : 'clientArray',
		'datatype' : "local",
		'responsive' : false,
		'autoScroll' : true,
		'height' : 'auto',
//		'toolbar' : [ true, 'bottom' ],
		'footerrow' : true,
		'hidegrid' : false,
		'rownumbers' : true,
		'multiselect' : false,
		'viewrecords' : true
	}

	var options = $.extend(true, opt, op);
	$grid.jqGrid(options);
	if (groupHeaders.length > 0) {
		$grid.jqGrid('setGroupHeaders', {
			useColSpanStyle : false,
			groupHeaders : groupHeaders
		})
	}
}

/**
 * 通用加载表格数据方法
 */
Grid.loadGridData = function($grid, data, readonly, addopt) {
	// 先清除表格数据，再加载表格
	$grid.jqGrid('clearGridData');
	if (data && data.length > 0) {
		for (var i = 0; i < data.length; i++) {
			var rowData = data[i];

			if (!rowData.id) {
				rowData.id = Public.getUUID();
			}

			$grid.jqGrid('addRowData', rowData.id, rowData);
		}
		$grid.find("tr.ui-row-ltr").addClass('edited');
	} else {
		if (!readonly) {
			for (var i = 0; i < 1; i++) {
				var id = Public.getUUID();
				var optd = {
					id : id
				};
				if (addopt) {
					optd = $.extend(optd, addopt);
				}
				$grid.jqGrid('addRowData', id, optd, 'last');
			}
		}
	}
}

Grid.rowIndex = function($grid, rowId) {
    $grid.getDataIDs().indexOf(rowId)
}
/**
 * @param includeSelf true-本行加下一行;false-上一行加下一行
 */
Grid.neighbors = function($grid, rowId, includeSelf) {
    var arr = [];
	var rowIds = $grid.getDataIDs();
	var currIdx = rowIds.indexOf(rowId);
    var offset = 0;
    if (includeSelf === false) {
    	offset = -1;
	}
    if (currIdx + offset >= 0) {
        $grid.getRowData(rowIds[currIdx + offset])
        arr.push($grid.getRowData(rowIds[currIdx + offset]));
	} else {
		arr.push(undefined);
	}
	if (currIdx < rowIds.length - 1) {
        $grid.getRowData(rowIds[currIdx + 1])
        arr.push($grid.getRowData(rowIds[currIdx + 1]));
    } else {
		arr.push(undefined);
	}
	return arr;
}
Grid.saveGrid = function($grid) {
    var iRow = $grid.data('iRow');
    var iCol = $grid.data('iCol');
    $grid.saveCell(iRow, iCol);
}