var Public = Public || {};

/**
 * 可查询的select列表
 * @param minInputLength 最小输入个数出发搜索
 * @param id 指定返回结构做key的字段
 * @param text 指定返回结构做value的字段
 */
Public.select = function($select, url, minInputLength, id, text) {
    if (!id) {
        id = "id";
    }
    if (!text) {
        text = "text";
    }

    if (minInputLength == 'undefined')
        minInputLength = 1;
    $select.select2({
        language : "zh-CN",
        ajax : {
            url : url,
            dataType : 'json',
            tags : true,
            delay : 250,
            data : function(params) {
                return {
                    term : params.term, // search term
                };
            },
            processResults : function(data) {
                var arr = [];
                for (var i = 0; i < data.length; i++) {
                    arr.push({
                        id: data[i][id],
                        text: data[i][text]
                    });
                }
                return {
                    results : arr
                };
            },
            cache : true
        },
        minimumInputLength : minInputLength,
        escapeMarkup : function(markup) {
            return markup;
        }
    });

    $select.select2('open');
};


/**
 * 从服务器加载select列表
 * selectFromRemote($node, url, cacheName[, true|false])
 * selectFromRemote($node, url, true|false)
 * selectFromRemote($node, url)
 * @param remoteUrl 数据地址
 * @param param4 存在param3参数时, param4代表双层下拉列表(交通工具/费用类型)还是单层的
 */
Public.selectFromRemote = function ($selectNode, remoteUrl, param3, param4) {
    var cacheName = undefined;
    var single = true;
    if (typeof(param3) === 'string') {
        cacheName = param3;
        if (typeof(param4) === 'boolean') {
            single = param4;
        }
    } else if (typeof(param3) === 'boolean') {
        single = param3;
    }
    function createSelect(data) {
        var html = '';
        for (var i = 0; i < data.length; i++) {
            if (single) {// 单层
                html += '<option value="'+data[i].id+'">';
                html += data[i].text;
                html += '</option>';
            } else { // 双层
                if (data[i].subOpt && data[i].subOpt.length > 0) {
                    html += '<optgroup label="'+data[i].text+'">';
                    for (var j = 0; j < data[i].subOpt.length; j++) {
                        html += '<option value="'+data[i].subOpt[j].id+'">';
                        html += data[i].text + '-' + data[i].subOpt[j].text;
                        html += '</option>';
                    }
                    html += '</optgroup>';
                }
            }
        }
        $selectNode.html(html);
        $selectNode.select2();
        $selectNode.trigger("change");
        $selectNode.select2('open');
    }
    if (Public.cache[cacheName]) {
        createSelect(Public.cache[cacheName]);
        return;
    }
    $.get(remoteUrl, function(data) {
        if (cacheName) {
            Public.cache[cacheName] = data;
        }
        createSelect(data);
    });
};

/**
 * 交通工具下拉
 * @param $selectNode
 */
Public.tripToolSelect = function($selectNode) {
    function createSelect() {
        var data = Public.cache.tripTool;
        var html = '';
        for (var i = 0; i < data.length; i++) {
            if (data[i].subOpt && data[i].subOpt.length > 0) {
                html += '<optgroup label="'+data[i].text+'">';
                for (var j = 0; j < data[i].subOpt.length; j++) {
                    html += '<option value="'+data[i].subOpt[j].id+'">';
                    html += data[i].text + '-' + data[i].subOpt[j].text;
                    html += '</option>';
                }
                html += '</optgroup>';
            }
        }
        $selectNode.html(html);
        $selectNode.select2({
            width : '100%'
        });
        $selectNode.trigger("change");
        $selectNode.select2('open');
    }
    if (Public.cache.tripTool) {
        createSelect();
        return;
    }
    $.get(path + '/api/tripTool', function(data) {
        Public.cache.tripTool = data;
        createSelect();
    });
};

/**
 * 用户授权下拉, 用户/部门切换同事会触发公司下拉change事件
 * @param u 用户select id
 * @param d 部门select id
 * @param c 公司select id
 * @param curr 币别select id
 * @param docType 单据类型
 * @param vu 用户值
 * @param vd 部门值
 * @param vc 公司值
 * @param vcurr 货币值
 */
Public.authSelect = function (u, d, c, curr, docType, vu, vd, vc, vcurr) {

    $.get(path + '/api/authUser', {
        docType: docType
    }, function(users) {

        var $u = $('#' + u);
        var $d = $('#' + d);
        var $c = $('#' + c);
        var $curr = $('#' + curr);
        $u.data('authInfo', users);

        $u.on('change', function() {
            var users = $(this).data('authInfo');
            var v = $(this).val();
            var depts;
            for (var i = 0; i < users.length; i++) {
                if (users[i].id === v) {
                    depts= users[i].subOpt;
                    break;
                }
            }
            if (depts) {
                $d.empty();
                $c.empty();
                for (var j = 0; j < depts.length; j++) {
                    var deptSelected = ' ';
                    if (j === 0) {
                        deptSelected = ' selected ';
                        var companies = depts[j].subOpt;
                        for (var k = 0; k < companies.length; k++) {
                            var compSelected = (k === 0) ? ' selected ' : ' ';
                            $c.append('<option value="'+ companies[k].id +'" ' + compSelected + '>'+ companies[k].text +'</option>');
                        }
                    }
                    $d.append('<option value="'+ depts[j].id +'" ' + deptSelected + '>'+ depts[j].text +'</option>');
                }
            }
            $c.trigger('change');
        });

        $d.on('change', function() {
            var users = $(this).data('authInfo');
            var v = $(this).val();
            var depts;
            for (var i = 0; i < users.length; i++) {
                if (users[i].id === $u.val()) {
                    depts= users[i].subOpt;
                    break;
                }
            }
            if (depts) {
                var companies;
                for (var j = 0; j < depts.length; j++) {
                    if (depts[j].id === v) {
                        companies = depts[j].subOpt;
                        break;
                    }
                }
                if (companies) {
                    $c.empty();
                    for (var k = 0; k < companies.length; k++) {
                        var compSelected = (k === 0) ? ' selected ' : ' ';
                        $c.append('<option value="'+ companies[k].id +'" ' + compSelected + '>'+ companies[k].text +'</option>');
                    }
                }
            }
            $c.trigger('change');
        });

        $c.on('change', function() {
            Public.userCurrencySelect($curr, $u, $c, docType, vcurr);
        });

        for (var i = 0; i < users.length; i++) {
            var userSelected = ' ';
            if ((vu && vu === users[i].id) || (!vu && i === 0)) {// 有默认值选中默认值行,没有选中第0行
                userSelected = ' selected ';
                var depts = users[i].subOpt;
                for (var j = 0; j < depts.length; j++) {
                    var deptSelected = ' ';
                    if ((vd && vd === depts[j].id) || (!vd && j === 0)) {
                        deptSelected = ' selected ';
                        var companies = depts[j].subOpt;
                        for (var k = 0; k < companies.length; k++) {
                            var compSelected = ((vc && vc === companies[k].id) || (!vc && k === 0)) ? ' selected ' : ' ';
                            $c.append('<option value="'+ companies[k].id +'" ' + compSelected + '>'+ companies[k].text +'</option>');
                        }
                    }
                    $d.append('<option value="'+ depts[j].id +'" ' + deptSelected + '>'+ depts[j].text +'</option>');
                }
            }
            $u.append('<option value="'+ users[i].id +'" ' + userSelected + '>'+ users[i].text +'</option>');
        }
        $c.trigger('change');
    });
};

Public.userCurrencySelect = function($el, $u, $c, docType, vcurr) {
    $.get(path + '/api/userCurrency', {
        userId: $u.val(),
        bukrs: $c.val(),
        docType: docType
    }, function(data) {
        $el.empty();
        for (var i = 0; i < data.length; i++) {
            var selected = ((vcurr && vcurr === data[i].id) || (!vcurr && i === 0)) ? ' selected ' : ' ';
            $el.append('<option value="' + data[i].id + '"' + selected +'>' + data[i].text + '</option>');
        }
        $el.trigger('change');
    });
};

// 城市搜索
Public.cityBox = {
    $el: undefined,
    loaded: false,
    i18n: {
        zh: {
            input_placeholder: '输入关键字',
            tab_recent: '最近',
            tab_hot: '热门',
            tab_search: '搜索'
        },
        en: {
            input_placeholder: 'input keywords',
            tab_recent: 'Recent',
            tab_hot: 'Popular',
            tab_search: 'Search'
        }
    },
    init: function(cb) {
        this.$el.addClass('city-input');

       // 国际化设置
        $(".city-box input").attr('placeholder', this.i18n[lang].input_placeholder);
        $(".city-box .tab-recent").text(this.i18n[lang].tab_recent);
        $(".city-box .tab-hot").text(this.i18n[lang].tab_hot);
        $(".city-box .tab-search").text(this.i18n[lang].tab_search);

        var self = this;

        // if (self.loaded) {
        //     return;
        // }

        self.initTab('hot');
        self.initTab('recent');

        $('.city-box').on('click', '.quick-index>ul>li.tab', function () {
            $('.city-box').find('.quick-index>ul>li.tab').removeClass('active');
            $(this).addClass('active');
            $('.city-box').find('.quick-index>ul>li.tab').each(function(idx) {
                if ($(this).is('.active')) {
                    $('.city-box .quick-index .city-content:eq('+idx+')').show();
                } else {
                    $('.city-box .quick-index .city-content:eq('+idx+')').hide();
                }
            });
        }).on('click', '.close', function() {
            // $(this).closest('.city-box').hide()
            $('#cityModal').hide();
        }).on('click', '.city-content .city-list .city', function() {
            cb($(this).data('cityInfo'));
            // $(this).closest('.city-box').hide()
            $('#cityModal').hide();
        }).on('keyup', '.tips input:text', function(e) {
            if ((e.keyCode < 65 || e.keyCode > 90) && e.keyCode !== 8 && e.keyCode !== 46) {
                return;
            }
            $('.city-box .quick-index .tab-search').show().click();

            var $input = $(this);
            clearTimeout($input.data('search'));
            var t = setTimeout(function() {
                $.get(path + '/api/city', {
                    type: 'search',
                    filter: $input.val()
                },function(data) {
                    var $el = $('#searchCity');
                    // var domestic = data['DOMESTIC'];
                    // var international = data['INTERNATIONAL'];
                    $el.empty();
                    for (key in data) {
                        self.buildHtml($el, data[key]);
                    }
                });
            }, 500);
            $input.data('search', t);
        });
        self.loaded = true;
    },
    buildHtml: function ($el, data) {
        if (data.length === 0) {
            return;
        }
        var $div = $('<div>');
        var $idx = $('<div class="index">' + data[0].countryName + '</div>');
        var $cityList = $('<div class="city-list">');
        for (var i = 0; i < data.length; i++) {
            var $city;
            $city = $('<span class="city">' + data[i].cityName + '</span>');
            $city.data('cityInfo', data[i]);
            $city.appendTo($cityList);
        }
        $div.append($idx).append($cityList);
        $div.appendTo($el);
    },
    initTab: function(type) {

        var self = this;

        if (type !== 'hot' && type !== 'recent') {
            alert('invalid type, use hot or recent');
            return;
        }

        if (type === 'recent') {
            $el = $('#recentCity');
            $.get(path + '/api/city', {
                type: type
            },function(data) {
                $el.empty();
                for (key in data) {
                    self.buildHtml($el, data[key]);
                }
            });

        } else if (type === 'hot') {
            $el = $('#hotCity');
            $el.empty();
            var data = Public.hotCity();
            for (key in data) {
                self.buildHtml($el, data[key]);
            }
        } else {
            alert('invalid type, use hot or recent');
            return;
        }
    }
}

// 差旅同行人
Public.travelPartnerModal = function (hikCard) {
    var id = this.getUUID();
    var gridId = this.getUUID();

    var msg =   "<div id='" + id + "'>" +
                '   <div class="form-inline">' +
                '      <div class="form-group" style="margin-bottom: 10px;">' +
                '          <input type="text" placeholder="'+i18n.travel_partner_placeholder+'" class="form-control">' +
                '          <button type="button" class="btn btn-default">' + i18n.search + '</button>' +
                '      </div>' +
                '   </div>' +
                '   <table id="' + gridId + '">' +
                '   </table>' +
                '</div>';
    BootstrapDialog.show({
        cssClass : 'dialog-w8',
        message : msg,
        buttons: [{
            label: i18n.label_ok,
            action: function (dialog) {
                dialog.close();
            }
        }],
        title : i18n.add_travel_partner,
        onshown: function () {
            $('#' + id + ' input').focus();

            var $grid = $("#" + gridId);
            var opt = jqGridOpt($grid);
            //加载表格数据
            Grid.localGrid($grid, opt, []);
            Grid.loadGridData($grid, [{}, {}, {}, {}, {}], true);
            $('#' + id).on('click', 'button', function () {
                $.get(path + '/api/searchUser', {
                    term: $('#' + id + ' input').val()
                }, function(data) {
                    Grid.loadGridData($grid, data, true);
                });
            }).on('click', 'a', function(e) {
                e.stopPropagation();
                var rowId = $(this).attr('rowid');
                var data = $('#' + gridId).jqGrid('getRowData', rowId);
                hikCard.addData({
                    userId: data.userId,
                    userName: data.userName,
                    deptPath: data.deptPath
                });
                $(this).parent('td').html(i18n.added);
            }).on('keyup', 'input', function(e) {
                if (e.keyCode !== 13) {
                    return;
                }
                $.get('/expense/api/searchUser', {
                    term: $('#' + id + ' input').val()
                }, function(data) {
                    Grid.loadGridData($grid, data, true);
                });
            });
        }
    });

    function jqGridOpt() {
        return {
            // 'caption' : "asdf",
            'width': 750,
            'footerrow': false,
            'toolbar': false,
            'colNames': [
                i18n.emp_id,
                i18n.emp_name,
                i18n.dept_path,
                ''
            ],
            'colModel': [{
                name: 'userId',
                index: 'userId',
                hidden: true,
                width: 150
            }, {
                name: 'userName',
                index: 'userName',
                width: 150
            }, {
                name: 'deptPath',
                index: 'deptPath',
                // align : 'left',
                width: 300
            }, {
                name: '',
                index: '',
                width: 60,
                formatter: function (cellvalue, options, rowObject) {
                    if (rowObject.userId) {
                        return '<a href="javascript:void(0);" rowid="' + rowObject.id + '">添加</a>';
                    } else {
                        return '';
                    }
                }
            }]
        };
    }
};

Public.oaInfo = function(docId, $grid) {
    var opt = {
        shrinkToFit: true,
        pgbuttons: false,
        pginput: false,
        autowidth: true,
        footerrow: false,
        'caption': 'OA',
        'colNames': ['id', '单据号', '类型id', '类型', '说明', '金额', ''],
        'colModel': [{
            name: 'id',
            index: 'id',
            hidden: true
        }, {
            name: 'oaNo',
            index: 'oaNo',
            editable: true
        }, {
            name: 'oaType',
            index: 'oaType',
            hidden: true
        }, {
            name: 'oaTypeName',
            index: 'oaTypeName',
            width: 120
        }, {
            name: 'remark',
            index: 'remark',
            width: 300,
            editable: true
        }, {
            name: 'amount',
            index: 'amount',
            align : 'right',
            width: 100,
            editable : true,
            formatter : 'currency',
            formatoptions : {
                decimalSeparator : ".",
                defaultValue : 0,
                thousandsSeparator : ",",
                decimalPlaces : 2
            }
        }, {
            name: '',
            index: '',
            width: 100,
            formatter: function (cellvalue, options, rowObject) {
                return '<a class="jq-action-icon jq-add-row" rowid="'+rowObject.id+'"><i class="fa fa-lg fa-plus-square"></i></a>' +
                    '&nbsp;&nbsp;' +
                    '<a class="jq-action-icon jq-del-row" rowid="'+rowObject.id+'"><i class="fa fa-lg fa-trash"></i></a>' +
                    '&nbsp;&nbsp;' +
                    '<a class="jq-action-icon jq-search-row" rowid="'+rowObject.id+'"><i class="fa fa-lg fa-search"></i></a>';
            }
        }],
        'afterSaveCell' : function(rowId, cellName, value, iRow, iCol) {
            var rowData = $(this).jqGrid('getRowData', rowId);
            if (cellName===  'loanCurrencyName') {
                $(this).jqGrid('setRowData', rowId, {
                    loanCurrency : value
                });
                if ('CNY' === value) {
                    $(this).jqGrid('setRowData', rowId, {
                        paymentType : 'C',
                        paymentTypeName : i18n.bank_transfer
                    });
                } else {
                    $(this).jqGrid('setRowData', rowId, {
                        paymentType : 'M',
                        paymentTypeName : i18n.cash
                    });
                }
            }

        },
        'afterEditCell' : function(rowId, cellname, value, iRow, iCol) {
            $(this).data('iRow', iRow);
            $(this).data('iCol', iCol);
            if (cellname == 'date') {
                var dp = iRow + "_date";
                new Pikaday({
                    field : document.getElementById(dp),
                    dateFormat : "yy-mm-dd"
                });
            }
        }
    };

    Grid.localGrid($grid, opt, []);

    var oaList = [{
        id: Public.getUUID()
    }, {
        id: Public.getUUID()
    }, {
        id: Public.getUUID()
    }];
    for (var i = 0; i < oaList.length; i++) {
        $grid.jqGrid('addRowData', oaList[i].id, oaList[i]);
    }

};

Public.summary = function ($grid) {
    var opt = {
        shrinkToFit: true,
        pgbuttons: false,
        pginput: false,
        autowidth: true,
        'caption': '汇总',
        'colNames': ['id', 'type', '类别', '小计', '超标合计', '超标/超期信息'],
        'colModel': [{
            name: 'id',
            index: 'id',
            hidden: true
        }, {
            name: 'type',
            index: 'type',
            hidden: true
        }, {
            name: 'typeName',
            index: 'typeName',
            width: 150
        }, {
            name: 'amount',
            index: 'amount',
            width: 150
        }, {
            name: 'cbAmount',
            index: 'cbAmount',
            width: 150
        }, {
            name: 'remark',
            index: 'remark',
            width: 500
        }]
    };

    Grid.localGrid($grid, opt, []);

    var oaList = [{
        id: Public.getUUID(),
        typeName: '业务招待费'
    }, {
        id: Public.getUUID(),
        typeName: '市内交通费	'
    }, {
        id: Public.getUUID(),
        typeName: '其他金额'
    }, {
        id: Public.getUUID(),
        typeName: '重复餐补'
    }];
    for (var i = 0; i < oaList.length; i++) {
        $grid.jqGrid('addRowData', oaList[i].id, oaList[i]);
    }

};

Public.bankInfo = function (func) {
    var html =  '<table class="table table-bordered" id="bankTable">' +
                '    <tr>' +
                '        <td width="30%">'+i18n.bank_code+':</td>' +
                '        <td class="bankL">...</td>' +
                '    </tr>' +
                '    <tr>' +
                '        <td>' + i18n.account_name + ':</td>' +
                '        <td class="bankN">...</td>' +
                '    </tr>' +
                '    <tr>' +
                '        <td>' + i18n.account + ':</td>' +
                '        <td class="name1">...</td>' +
                '    </tr>' +
                '    <tr>' +
                '        <td colspan="2" style="font-size: 12px;color: red;">' + i18n.check_bank_warning + '</td>' +
                '    </tr>' +
                '</table>';
    BootstrapDialog.show({
        title: i18n.check_payee_info,
        message: html,
        closable: false,
        type: BootstrapDialog.TYPE_PRIMARY,
        buttons: [{
            label: i18n.label_ok,
            action: function (dialog) {
                func && func();
                dialog.close();
            }
        }, {
            label: i18n.label_cancel,
            action: function (dialog) {
                dialog.close();
            }
        }],
        onshown: function() {
            $.get('/expense/api/getUserBank', {
                userId: $("#user").val(),
                bukrs: $("#comp").val()
            }, function(data) {
                if (data && data.length === 1) {
                    var $bank = $("#bankTable");
                    $bank.find('.bankL').text(data[0].bankL);
                    $bank.find('.bankN').text(data[0].bankN);
                    $bank.find('.name1').text(data[0].name1);
                }
            });
        }
    });
};

// 存放一些后台请求数据
Public.cache = {
    tripTool: undefined
};

Public.showSuccess = function (message, func) {
    var msg = '';
    if (!(message instanceof Array)) {
        message = [message];
    }
    for (var i = 0; i < message.length; i++) {
        msg += "<p><i class='fa fa-thumbs-up green'></i>" + message[i] + "</p>";
    }
    BootstrapDialog.show({
        title: 'Success',
        message: msg,
        closable: false,
        type: BootstrapDialog.TYPE_SUCCESS,
        buttons: [{
            label: '确定',
            action: function (dialog) {
                func && func();
                dialog.close();
            }
        }, {
            label: '关闭',
            action: function (dialog) {
                dialog.close();
                self.opener = null;
                self.close();
            }
        }]
    });
};

Public.showError = function (message, func) {
    var msg = '';
    if (!(message instanceof Array)) {
        message = [message];
    }
    for (var i = 0; i < message.length; i++) {
        msg += "<p><i class='fa fa-ban red'></i>" + message[i] + "</p>";
    }
    BootstrapDialog.show({
        title: 'Error',
        message: msg,
        closable: false,
        type: BootstrapDialog.TYPE_DANGER,
        buttons: [{
            label: '确定',
            action: function (dialog) {
                func && func();
                dialog.close();
            }
        }/*, {
            label: '关闭',
            action: function (dialog) {
                dialog.close();
                self.opener = null;
                self.close();
            }
        }*/]
    });
};

Public.getUUID = function() {
    var s = [];
    var hexDigits = "0123456789ABCDEF";
    for (var i = 0; i < 36; i++) {
        s[i] = hexDigits.substr(Math.floor(Math.random() * 0x10), 1);
    }
    s[14] = "4"; // bits 12-15 of the time_hi_and_version field to 0010
    s[19] = hexDigits.substr((s[19] & 0x3) | 0x8, 1); // bits 6-7 of the
    // clock_seq_hi_and_reserved
    // to 01
    return s.join("");
};

Public.hotCity = function () {
    var en = {
        "CN": [{
            "cityId": "330100",
            "cityName": "HangZhou ",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "310000",
            "cityName": "ShangHai",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "110000",
            "cityName": "BeiJing",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "410100",
            "cityName": "ZhengZhou",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "500000",
            "cityName": "ZhongQing",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "440300",
            "cityName": "ShenZhen",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "420100",
            "cityName": "WuHan",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "320100",
            "cityName": "NanJing",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "650100",
            "cityName": "WuLuMuQi",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "510100",
            "cityName": "ChengDou",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "440100",
            "cityName": "GuangZhou",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "610100",
            "cityName": "XiAn",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "530100",
            "cityName": "KunMing",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "120000",
            "cityName": "TianJin",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "520100",
            "cityName": "GuiYang",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "210100",
            "cityName": "ShenYang",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "370200",
            "cityName": "QingDao",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "430100",
            "cityName": "ZhangSha",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "320500",
            "cityName": "SuZhou",
            "countryId": "CN",
            "countryName": "CN"
        }, {
            "cityId": "640100",
            "cityName": "YinChuan",
            "countryId": "CN",
            "countryName": "CN"
        }]
    };
    var zh = {
        "中国":[{
                "cityId":"330100",
                "cityName":"杭州",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"310000",
                "cityName":"上海",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"110000",
                "cityName":"北京",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"410100",
                "cityName":"郑州",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"500000",
                "cityName":"重庆",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"440300",
                "cityName":"深圳",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"420100",
                "cityName":"武汉",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"320100",
                "cityName":"南京",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"650100",
                "cityName":"乌鲁木齐",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"510100",
                "cityName":"成都",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"440100",
                "cityName":"广州",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"610100",
                "cityName":"西安",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"530100",
                "cityName":"昆明",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"120000",
                "cityName":"天津",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"520100",
                "cityName":"贵阳",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"210100",
                "cityName":"沈阳",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"370200",
                "cityName":"青岛",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"430100",
                "cityName":"长沙",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"320500",
                "cityName":"苏州",
                "countryId":"CN",
                "countryName":"中国"
            }, {
                "cityId":"640100",
                "cityName":"银川",
                "countryId":"CN",
                "countryName":"中国"
            }
        ]
    };
    return lang === 'zh' ? zh : en;
};

Public.showImageList = function () {
    var docId = $("#docId").val();
    var id = this.getUUID();

    var msg = "<div><table id='" + id + "'></table></div>";
    BootstrapDialog.show({
        cssClass : 'dialog-w8',
        message : msg,
        title : i18n.title_imageList,
        closable : false,
        buttons: [{
            label: i18n.label_ok,
            action: function (dialog) {
                dialog.close();
            }
        }],
        onshown: function () {
            var $grid = $("#" + id);
            var opt = getImageList();
            //加载表格数据
            $.get('/expense/api/imageList/' + docId, function (data) {
                Grid.localGrid($grid, opt, []);
                Grid.loadGridData($grid, data, true);
            })
        }
    });

    function getImageList() {
        return {
            // 'caption' : "",
            'width': 760,
            'footerrow': false,
            'toolbar': false,
            'colNames': [
                i18n.col_name_imageId,
                i18n.col_name_imageType,
                i18n.col_name_pageNum,
                i18n.col_name_source,
                i18n.col_name_location,
                i18n.col_name_archiveDate,
                i18n.col_name_dupScan
            ],
            'colModel': [{
                name: 'opentextId',
                index: 'opentextId',
                hidden: true
            }, {
                name: 'imageType',
                index: 'imageType',
                width: 100,
                formatter: function (cellvalue, options, rowObject) {
                    var cellTxt;
                    if (rowObject.opentextType === 'ZHIK_BX_FP') {
                        cellTxt = i18n.txt_invoice;
                    } else if (rowObject.opentextType === 'ZHIK_BX_FJ') {
                        cellTxt = i18n.txt_attachment;
                    }
                    return '<a href="/print/image/' + rowObject.opentextId + '.pdf" class="blue" target="_blank">' + cellTxt + '</a>';
                }
            }, {
                name: 'page',
                index: 'page',
                width: 80
            }, {
                name: 'source',
                index: 'source',
                width: 80
            }, {
                name: 'location',
                index: 'location',
                width: 80
            }, {
                name: 'archiveDate',
                index: 'archiveDate',
                width: 200,
                formatter: function (cellvalue, options, rowObject) {
                    return moment(rowObject.archiveDate).format('YYYY-MM-DD HH:mm:ss')
                }
            }, {
                name: 'dupTag',
                index: 'dupTag',
                width: 100,
                formatter: function (cellvalue, options, rowObject) {
                    if (cellvalue === true) {
                        return '<span style="color: red">重复</span>';
                    } else {
                        return '';
                    }
                }
            }]
        };
    }
};

Public.print = function() {
    var docId = $("#docId").val();
    var html =  '<div class="content" style="width: 100%;">' +
        '    <h1 class="section-title">' +
        '        <span><strong>打印粘贴单</strong></span>' +
        '    </h1>' +
        '    <div class="wrapper">' +
        '        <a href="/print/' + docId + '.pdf" target="_blank" id="printLink" class="btn btn-sm btn-success" style="color: #ffffff;">打印</a>' +
        '        <button id="modalCancelBtn" class="btn btn-sm btn-danger" onclick="$(this).closest(\'.modal\').modal(\'hide\')">取消</button>' +
        '        <hr>' +
        '        <div class="checkbox">' +
        '            <label>' +
        '                <input type="checkbox" id="invoice">发票封面（发票指打的票，停车过路票，增值税普通发票，增值税专用发票，国税定额发票等）' +
        '            </label>' +
        '        </div>' +
        '        <div class="checkbox">' +
        '            <label>' +
        '                <input type="checkbox" id="manifest">附件封面（附件指除了发票以外的消费清单明细/刷卡记录/合同/快递面单等）' +
        '            </label>' +
        '        </div>' +
        '    </div>' +
        '    <h1 class="section-title">' +
        '        <span><strong>粘贴规范</strong></span>' +
        '    </h1>' +
        '    <div class="wrapper" style="max-height: 200px; overflow-y: auto;">' +
        '        <p class="h4">1. 报销单封面打印</p>' +
        '        <p>　(1) 报销单发票封面和附件封面统一使用A4纸张打印，封面条形码和单号必须清晰可见。但是A4粘贴单一定不能有条形码，可以使用任何不带信息安全的A4纸。</p>' +
        '        <p>　(2) 封面页数请如实填写（含封面，一张A4粘贴单算一页，一张A5/A4纸大小发票算一页）</p>' +
        '        <p class="h4">2. 发票附件分类顺序</p>' +
        '        <p>　(1) 发票必须分类整理，并且同一种类的发票按时间先后顺序排列粘贴，发票金额必须清晰可见。</p>' +
        '        <p>　(2) 发票、附件等必须分别粘贴在不同粘贴单上。</p>' +
        '        <p class="h4">3. 票据具体粘贴要求</p>' +
        '        <p>　(1) 出租车票和定额停车票采用“鱼鳞式”粘贴，只需金额清晰可见。通行费（过路费）必须平铺，露出时间，发票代码和发票号码。</p>' +
        '        <p>　(2) 发票粘贴不得超出A4粘贴纸的边缘。</p>' +
        '        <p>　(3) 封面与粘贴单、粘贴单与粘贴单不需要粘贴在一起，改用订书钉装订或者夹子夹在一起，以便于对单据进行批量影像扫描。A5或A4大小的发票/附件，不用粘贴，全部装订或夹在相应的报销封面后即可，其他发票/附件需要粘贴在粘贴单上；</p>' +
        '    </div>' +
        '    <h1 class="section-title">' +
        '        <span><strong>粘贴规范模板</strong></span>' +
        '    </h1>' +
        '    <div class="wrapper">' +
        '        <img src="/expense/static/images/print-template.jpg"/>' +
        '    </div>' +
        '</div>';

    BootstrapDialog.show({
        cssClass : 'dialog-w10',
        message : html,
        closable : true,
        showHeader: false,
        showFooter: false,
        onshown: function () {
            $("#invoice, #manifest").on('click', function() {
                var url = "/print/65E2AF1152BB45A289457F737FF882BA.pdf?";
                var printType = "ALL";
                var isInvoice = $("#invoice").is(":checked");
                var isManifest = $("#manifest").is(":checked");
                if (isInvoice && !isManifest) {
                    printType = "INVOICE";
                } else if (!isInvoice && isManifest) {
                    printType = "MANIFEST";
                }
                $("#printLink").attr("href", url + "type=" + printType);
            });
        }
    })

};

/**
 * 附件管理
 */
Public.attach = function() {

    var docId = $("#docId").val(); // "C7E0CCD0F9414025B74C806ADC0D44B2";//
    var $grid;
    var docStatus = $("#docStatus").val();
    var editable = (docStatus === 'S001' || docStatus === 'S005' || docStatus == '');

    /**
     * 上传附件
     */
    function init_uploader() {

        if (!editable) {
            return;
        }
        var uploader = WebUploader.create({
            // swf文件路径
            swf : '/expense/static/js/uploader.swf',
            auto : true,
            // 文件接收服务端。
            server : "/expense/file/attachment/upload",
            formData : {
                docId : docId
            },
            // 选择文件的按钮。可选。
            // 内部根据当前运行是创建，可能是input元素，也可能是flash.
            pick : '#file-picker',
            // 不压缩image, 默认如果是jpeg，文件上传前会压缩一把再上传！
            resize : false,
            chunked : false,
            duplicate : true,
            fileSingleSizeLimit : 20 * 1024 * 1024
        });

        uploader.on('error', function(code) {
            setTimeout('$(".modal-dialog").hideLoading()', 100);
            if (code == 'F_EXCEED_SIZE') {
                Public.showError("File size must be less than 20 MB!");
            }
        });
        uploader.on('startUpload', function(file, percentage) {
            $(".modal-dialog").showLoading();
        });

        // 文件上传成功
        uploader.on('uploadSuccess', function(file) {
        });

        // 文件上传失败
        uploader.on('uploadError', function(file) {
            Public.showError("uploadFile error");
        });

        // 完成上传完了，成功或者失败，先删除进度条。
        uploader.on('uploadComplete', function(file) {
            setTimeout('$(".modal-dialog").hideLoading()', 100);
            $grid.trigger("reloadGrid");
        });
    }

    var uploadHtml = '<div id="file-uploader">' +
                     '    <div id="file-thelist" class="uploader-list"></div>' +
                     '    <div>' +
                     '    <div id="file-picker">' + i18n.select_attachments + '</div>' +
                     '    </div>' +
                     '</div>';

    var tableHtml = '<table id="attachTable"></table>';
    var html = editable ? uploadHtml + tableHtml : tableHtml;

    BootstrapDialog.show({
        cssClass : 'dialog-w8',
        title : i18n.txt_attachment,
        message : html,
        closable : false,
        buttons : [{
            label : i18n.label_ok,
            action : function(dialog) {
                $("#attachNumber").text($('#attachTable').jqGrid('getGridParam', 'records'));
                dialog.close();
            }
        }],
        onshown: function() {
            $grid = $("#attachTable");
            if (editable) {
                init_uploader();
            }

            $grid.jqGrid({
                'url' : '/expense/file/attachment/list/' + docId,
                'datatype' : "json",
                'autoScroll' : true,
                'rownumbers' : true,
                mtype : "POST",
                autowidth: true,
                height: 330,
                rowNum : 500,
                colNames : ['', i18n.col_name_attach_name, i18n.col_name_upload_time, i18n.col_name_attach_size, i18n.col_name_operate],
                colModel : [{
                    name : 'flowId',
                    index : 'id',
                    hidden : true
                }, {
                    name : 'fileName',
                    index : 'fileName',
                    width: 200,
                    formatter : function(cellValue, options, rowObject) {
                        return '<a href="/expense/file/attachment/download/' + rowObject.id+'" target="_blank" style="text-decoration:underline;color:blue">'+cellValue+'</a>';
                    }
                }, {
                    name : 'createTime',
                    index : 'createTime',
                    width: 100
                }, {
                    name : 'fileSize',
                    index : 'fileSize',
                    width: 100,
                    formatter : function(value) {
                        var unitArr;
                        if (lang === 'zh') {
                            unitArr = ["字节", "KB", "MB"];
                        } else {
                            unitArr = ["Byte", "KB", "MB"];
                        }

                        value = parseFloat(value);
                        var i = 0;
                        while(value > 999 && i < 3) { // 根据文件大小适配不同单位
                            value = value / 1024;
                            i++;
                        }
                        // 控制最后位数0不显示
                        value = value.toFixed(2) * 100;
                        if (value % 100 === 0) {
                            return (value/100) + unitArr[i];
                        } else if (value % 10 === 0) {
                            return (value/100).toFixed(1) + ' ' + unitArr[i];
                        } else {
                            return (value/100).toFixed(2) + ' ' + unitArr[i];
                        }
                    }
                }, {
                    name : 'id',
                    index : 'id',
                    width: 50,
                    formatter : function(cellValue) {
                        return editable ? '<a data-id="'+cellValue+'" class="del-btn fa fa-lg fa-trash"></a>' : '';
                    }
                }]
            });

            $("#attachTable").on('click', '.del-btn', function() {
                var $this = $(this);
                var rowId = $this.closest('tr').attr('id');
                $.post('/expense/file/attachment/delete/' + $this.data('id'), function (data) {
                    if (data.success) {
                        $("#attachTable").jqGrid('delRowData', rowId);
                    } else {
                        Public.showError(data.errorMsgs);
                    }
                });
            });
        }

    });
};

Public.saveForm = function (data) {
    $.ajax({
        contentType : 'application/json',
        type : "POST",
        url : '/expense/form/save',
        data : JSON.stringify(data),
        dataType : 'json',
        success : function(data) {
            if (data.success) {
                window.location.href='edit?docId=' + $("#docId").val();
            } else {
                Public.showError(data.errorMsgs);
            }
        }
    });
};

Public.submitForm = function (data) {

    function submit() {
        $.ajax({
            contentType: 'application/json',
            type: "POST",
            url: '/expense/form/submit',
            data: JSON.stringify(data),
            dataType: 'json',
            success: function (data) {
                if (data.success) {
                    window.location.href = 'view?docId=' + $("#docId").val();
                } else {
                    Public.showError(data.errorMsgs);
                }
            }
        });
    }

    // TODO 判断哪些情况需要确认银行信息
    // if (needConfirmBankInfo) {
    //     Public.bankInfo(submit);
    // } else {
    //     submit();
    // }
    submit();

};

Public.holiday = function () {
    var $holiday = $("#holiday");
    if ($holiday.length === 0) {
        $holiday = $('<div class="modal fade" id="holiday" tabindex="-1" role="dialog">');
        var html = '<div class="modal-dialog">' +
                   '    <div class="modal-content">' +
                   '        <div class="modal-header">' +
                   '            <p class="modal-title" id="myModalLabel">节假日工作情况</p>' +
                   '        </div>' +
                   '        <div class="modal-body">' +
                   '            <div class="row">' +
                   '                <div class="dates col-md-12"><span class="date selected"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span><span class="date"><span>2017-05-03</span></span></div>' +
                   '            </div>' +
                   '        </div>' +
                   '        <div class="modal-footer">' +
                   '            <button class="btn btn-primary saveBtn">'+ i18n.label_save+'</button>' +
                   '            <button class="btn btn-default" data-dismiss="modal">'+ i18n.label_cancel +'</button>' +
                   '        </div>' +
                   '    </div>' +
                   '</div>';
        $holiday.append(html);
        $holiday.on('click', '.date', function() {
            var $this = $(this);
            if ($this.is('.selected')) {
                $this.removeClass('selected');
            } else {
                $this.addClass('selected');
            }
        }).on('click', 'button.saveBtn', function() {
            var $dates = $holiday.find('.dates .selected span');
            var dates = [];
            for (var i = 0; i < $dates.length; i++) {
                dates.push($($dates[i]).text());
            }
            $.post('/expense/api/addWorkingHolidays', {
                docId: $("#docId").val(),
                dates: dates
            }, function (data) {
                if (data.success) {
                    $holiday.modal('hide');
                } else {
                    Public.showError(data.errorMsgs);
                }
            });
        });
    }
    // 获取行程日期范围
    var tripDates = $ctjtTable.jqGrid('getCol', 'feeFromDate').concat($ctjtTable.jqGrid('getCol', 'feeToDate'));
    var dateRange = Public.dateRange(tripDates);

    $.get('/expense/api/listWorkingHolidays', {
        docId: $("#docId").val(),
        bukrs: $("#comp").val(),
        minDate: dateRange[0],
        maxDate: dateRange[1]
    }, function (data) {
        var $dates = $holiday.find('.dates');
        $dates.empty();
        for (var i = 0; i < data.length; i++) {
            var $span = $('<span class="date"><span>'+data[i].workDate+'</span></span>');
            if (data[i].work) {
                $span.addClass('selected');
            }
            $span.appendTo($dates);
        }
    });
    $holiday.modal({
        backdrop: 'static'
    });
};

Public.approveHistory = function () {
    var docId = $("#docId").val();

    var $h = $("#history");
    if ($h.length === 0) {
        return;
    }

    $("#history").on('click', '.item', function() {
        var size = $('.item').length;
        var $this = $(this);
        var id = $this.closest('.item').attr('id');
        var seq = parseInt(id.replace('item-', ''));
        var start, end;
        if (seq < 4) {
            start = 1;
            end = 7;
        } else if (seq > size - 4) {
            start = size - 6;
            end = size;
        } else {
            start = seq - 3;
            end = seq + 3;
        }
        for (var i = 1; i <= size; i++) {
            if (i >= start && i <= end) {
                $("#item-" + i).show();
            } else {
                $("#item-" + i).hide();
            }
        }
    });

    $.get('/expense/approve/history/' + docId, {}, function(list) {
        $h.empty();
        if (list.length === 0) {
            return;
        }
        for (var i = 0; i < list.length; i++) {
            var item = list[i];
            var stepClass, actionName;
            if (item.result == 'REJECT') {
                stepClass = "bg-red";
            } else if (item.taskName == 'END') {
                stepClass = "bg-blue";
            } else if (item.result == 'ADDSTEP') {
                stepClass = "bg-blue";
            } else if (item.taskName == 'A02') {
                stepClass = "bg-yellow";
            } else if (item.result == 'SUBMIT') {
                stepClass = "bg-green";
            } else if (item.result == 'AGREE') {
                stepClass = "bg-green";
            } else if (item.result == 'RETRACK') {
                stepClass = "bg-red";
            } else if (item.result == 'UNDO') {
                stepClass = "bg-red";
            } else if (item.result == 'REFUSE') {
                stepClass = "bg-red";
            } else {
                stepClass = "bg-grey";
            }

            if (item.result == 'REJECT') {
                actionName = i18n.txt_reject;
            } else if (item.taskName == 'END') {
                actionName = i18n.txt_end;
            } else if (item.result == 'ADDSTEP') {
                actionName = i18n.txt_add_step;
            } else if (item.result == 'SUBMIT') {
                actionName = i18n.txt_submit;
            } else if (item.result == 'AGREE') {
                actionName = i18n.txt_agree;
            } else if (item.result == 'RETRACK') {
                actionName = i18n.txt_retrack;
            } else if (item.result == 'UNDO') {
                actionName = i18n.txt_undo;
            } else if (item.result == 'REFUSE') {
                actionName = i18n.txt_refuse;
            } else {
                actionName = i18n.txt_inProcess;
            }

            var suggest = '';
            if (item.suggest && item.suggest.length > 20) {
                suggest = '<p data-toggle="tooltip" data-placement="bottom" title="' + item.suggest + '">' +
                          item.suggest.substr(0, 20) + '...' +
                          '</p>';
            } else {
                suggest = '<p>' + (item.suggest || "") + '</p>';
            }
            var approveTime = '';
            if (item.cmTime > 0) {
                approveTime = moment(item.cmTime).format('YYYY-MM-DD');
            }
            
            var completedByName = '';
            if (item.completedByName) {
            	completedByName = item.completedByName;
            }
            var html =  '<div class="item" id="item-'+(i + 1)+'" style="display: none">' +
                        '    <div class="item-header">' +
                        '        <div class="step-num '+ stepClass +'">' + (i + 1) + '</div>' +
                        '    </div>' +
                        '   <div class="suggest">' +
                        '    ' + completedByName + '(' + actionName + ')' + '<br/>' + approveTime + '<br/>' + suggest +
                        '   </div>' +
                        '</div>';
            $h.append($(html));
        }
        $h.append($('<div style="clear:both"></div>')).show();

        if ( $('.item').length < 7) {
            $(".item").show().off('click').css('cursor', 'default');
        } else {
            $(".item:last").click();
        }
        $("#history .suggest p").tooltip();
    });
};

/**
 * 获取日期区间[minDate, maxDate]
 */
Public.dateRange = function (dates) {
    // 获取行程日期范围
    var minDate = moment('2099-12-31', 'YYYY-MM-DD');
    var maxDate = moment('2000-01-01', 'YYYY-MM-DD');
    for (var i = 0; i < dates.length; i++) {
        if (!dates[i]) {
            continue;
        }
        var date = moment(dates[i], 'YYYY-MM-DD');
        if (date.isBefore(minDate)) {
            minDate = date;
        }
        if (date.isAfter(maxDate)) {
            maxDate = date;
        }
    }
    return [minDate.format('YYYY-MM-DD'), maxDate.format('YYYY-MM-DD')];
}