package com.hikvision.it.expense.common.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;

import javax.servlet.http.HttpServletResponse;

/**
 * 通用http response输出工具类
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/12
 * Time: 18:36
 * To change this template use File | Settings | File Templates.
 */
public class ResponseUtil {
    /**
     * 通用输出文件流
     * @param response
     * @param filePath
     * @param userName
     * @throws IOException
     */
    public static void outputStream(HttpServletResponse response, String filePath, String userName) throws IOException {
        // 设置相应头
        response.setCharacterEncoding("UTF-8");
        response.setContentType("application/octet-stream;");
        InputStream inputStream = null;
        OutputStream os = null;

        try {
            String fileName = new String((userName + System.currentTimeMillis() + ".xlsx").getBytes("GBK"),"iso-8859-1");
            response.addHeader("Content-Disposition", "attachment;fileName=" + fileName);
            inputStream = new FileInputStream(new File(filePath));

            os = response.getOutputStream();
            byte[] b = new byte[1024];
            int length;
            while ((length = inputStream.read(b)) > 0) {
                os.write(b, 0, length);
            }
        } finally {
            try {
                if (os != null)
                    os.close();
            } catch (IOException e) {
            }
            try {
                if (inputStream != null)
                    inputStream.close();
            } catch (IOException e) {
            }
        }
    }
}
