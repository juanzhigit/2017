package com.hikvision.it.expense.common.utils;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Calendar;
import java.util.List;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.streaming.SXSSFSheet;
import org.apache.poi.xssf.streaming.SXSSFWorkbook;

import com.google.common.io.Files;

/**
 * 分页导出数据 默认2万分sheet导出
 * 
 * 生成完成后会生成一个文件保存在服务器中， 然后返回一个服务器下载地址，web端从该地址下载文件流
 * 
 * <p>
 * Title: PagesPOIExport.java
 * </p>
 * <p>
 * Description:
 * </p>
 * <p>
 * Copyright: Copyright (c) 2015
 * </p>
 * <p>
 * Company: hikvision
 * </p>
 * 
 * @author wuliangxxh1
 * @date 2015年10月16日
 *
 */
public abstract class PagesPOIExport<T> {
	/** 导出文件存放路径 */
	protected final static String DEFAULT_FILE_PATH = "C:/export";
	/** 默认分页大小2万条 */
	protected final static int DEFAULT_PAGE_SIZE = 20000;
	/** 分页大小 */
	private int pageSize;
	/** 保存文件路径 */
	private String filePath;
	/** 导出用户名 */
	private String exportUserName;

	/**
	 * 默认构造方法
	 */
	public PagesPOIExport() {
		this(DEFAULT_PAGE_SIZE, DEFAULT_FILE_PATH, "UNKNOWN");
	}

	/**
	 * 重载构造方法，可以设置分页大小
	 * 
	 * @param pageSize
	 */
	public PagesPOIExport(int pageSize) {
		this(pageSize, DEFAULT_FILE_PATH, "UNKNOWN");
	}

	public PagesPOIExport(String filePath) {
		this(DEFAULT_PAGE_SIZE, filePath, "UNKNOWN");
	}

	public PagesPOIExport(String filePath, String exportUserName) {
		this(DEFAULT_PAGE_SIZE, filePath, exportUserName);
	}

	public PagesPOIExport(int pageSize,
                          String filePath,
                          String exportUserName) {
		this.pageSize = pageSize;
		this.exportUserName = exportUserName;
		if (filePath != null)
			this.filePath = filePath;
		else
			this.filePath = DEFAULT_FILE_PATH;
	}

	/**
	 * 数据导出接口类，用于直接传入实体entity list时的导出
	 * 
	 * @author wuliangxxh1
	 * @date 2015年10月19日
	 *
	 * @param <T>
	 */
	public interface IEntityExport<T> {
		/**
		 * 逐行导出数据到工作表
		 * 
		 * @param sh
		 *            工作表
		 * @param data
		 *            需导出的数据行
		 * @param rowNum
		 *            行索引
		 */
		public void entityExport(Sheet sh, T data, int rowNum);
	}

	/**
	 * 分页导出数据 用于大批量数据分sheet导出 默认每页2万条数据一个工作表
	 * 
	 * 小批量数据导出
	 * 
	 * @param datas
	 * @param exportExecute
	 *            需使用人实现该接口 具体字段如何设置到工作表中
	 * @param headers
	 * @return
	 */
	public String exportData(List<T> datas, IEntityExport<T> exportExecute,
			String[] headers) throws IOException {
		ResultSet rs = null;
		SXSSFWorkbook wb = null;
		FileOutputStream out = null;
		try {
			// 关闭缓存自动刷新
			wb = new SXSSFWorkbook(-1);

			Sheet sh = null;
			if (datas.isEmpty()) {
				sh = wb.createSheet();
				// 输出表头
				this.exportHeader(sh, headers);
			} else {
				// 开始导出数据
				int rowNum = 0; // 用于统计导出数据数
				for (T data : datas) {
					// 每2万条数据新建工作表，然后将数据输出到新工作表
					if (rowNum % pageSize == 0) {
						// 新开启一个工作表
						sh = wb.createSheet(String.valueOf(wb.getNumberOfSheets() + 1));
						// 输出表头
						this.exportHeader(sh, headers);
						//重置起始输出行
						rowNum = 0;
					} 
					//行数+1
					rowNum++;
					// 先输出数据到工作表
					exportExecute.entityExport(sh, data, rowNum);
					// 自定义每100条数据刷新一次
					if (rowNum % 100 == 0) {
						// 清空其他缓存，保留最近的100条缓存记录
						((SXSSFSheet) sh).flushRows(100);
					}
				}
			}
			// 获取最近磁盘存储的文件路径 包含文件名
			File file = concatFilePath();
			out = new FileOutputStream(file);
			wb.write(out);
			// 释放临时文件到相应磁盘路径
			wb.dispose();

			return file.getAbsolutePath();
		} finally {
			if (rs != null)
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
				}
			if (out != null)
				try {
					out.close();
				} catch (Exception e) {
				}
			if (wb != null)
				try {
					wb.close();
				} catch (Exception e) {
				}
		}
	}

	/**
	 * 输出工作表抬头
	 * 
	 * @param headers
	 */
	protected void exportHeader(Sheet sh, String[] headers) {
		Row row = sh.createRow(0);

		int fieldSize = headers.length;
		for (int cellnum = 0; cellnum < fieldSize; cellnum++) {
			Cell cell = row.createCell(cellnum);

			cell.setCellValue(headers[cellnum]);
		}
	}

	/**
	 * 将数据写入工作表
	 * 
	 * @param sh
	 *            工作表
	 * @param rs
	 *            要写入的数据entity
	 * @param rowNum
	 * @param fieldSize
	 * @return
	 */
	protected void exportDateToSheet(Sheet sh, ResultSet rs, int rowNum,
			int fieldSize) throws SQLException {
		Row row = sh.createRow(rowNum + 1);
		for (int cellnum = 0; cellnum < fieldSize; cellnum++) {
			Cell cell = row.createCell(cellnum);

			cell.setCellValue(rs.getString(cellnum + 1));
		}
	}

	/**
	 * 拼接文件实际路径和文件名称
	 * 
	 * 文件名为唯一ID
	 *
	 * @return
	 */
	protected File concatFilePath() {
		//以export为根目录，然后年/月/日为子目录
		try {
			Calendar cal = Calendar.getInstance();
			
			int year = cal.get(Calendar.YEAR);
			int month = cal.get(Calendar.MONTH) + 1;
			int dayOfMonth = cal.get(Calendar.DAY_OF_MONTH);
			
			File file = new File(filePath + File.separator + 
								 year + File.separator + 
								 month + File.separator + 
								 dayOfMonth + File.separator + 
								 (this.exportUserName + "-" + "-" + StringUtil.getUUID() + ".xlsx"));
			Files.createParentDirs(file);
			return file;
		} catch (IOException e) {
			e.printStackTrace();
		}
		return null;
	}

	public void setPageSize(int pageSize) {
		this.pageSize = pageSize;
	}
}
