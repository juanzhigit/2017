package com.hikvision.it.expense.common.utils;

import java.util.Scanner;
import java.util.UUID;

public class Test {
    public static void main(String[] args) {
        Scanner cin = new Scanner(System.in);
        int size = cin.nextInt();
        while(size-- > 0) {
            System.out.println(UUID.randomUUID().toString().replaceAll("-", "").toUpperCase());
        }
        cin.close();


    }
}
