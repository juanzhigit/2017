package com.hikvision.it.expense.common.utils;

import java.util.List;

public class ListUtil {
	/**
	 * 判断list是否为空
	 */
	public static boolean isEmpty(List<?> list) {
		return !(list != null && list.size() != 0);
	}

	public static boolean isNotEmpty(List<?> list) {
		return !isEmpty(list);
	}
}
