package com.hikvision.it.expense.common.utils;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

public class DateUtil {
    /**
     * 校验是否周末
     */
    public static boolean checkIsWeekend(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        cal.setTime(date);
        int dayOfWeek = cal.get(Calendar.DAY_OF_WEEK);
        //周末
        if (dayOfWeek == 1 || dayOfWeek == 7) {
            return true;
        }

        return false;
    }

    /**
     * 获取上个月
     */
    public static java.sql.Date getLastMonth(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        if (date != null)
            cal.setTimeInMillis(date.getTime());
        cal.add(Calendar.MONTH, -1);

        return new java.sql.Date(cal.getTimeInMillis());
    }

    /**
     * 获取上一年
     */
    public static java.sql.Date getLastYear(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        if (date != null)
            cal.setTimeInMillis(date.getTime());
        cal.add(Calendar.YEAR, -1);

        return new java.sql.Date(cal.getTimeInMillis());
    }

    /**
     * 天数+1
     */
    public static java.sql.Date addDay(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        cal.setTimeInMillis(date.getTime());

        cal.add(Calendar.DAY_OF_MONTH, 1);

        return new java.sql.Date(cal.getTimeInMillis());
    }

    /**
     * 月份+1
     */
    public static java.sql.Date addMonth(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        if (date != null)
            cal.setTimeInMillis(date.getTime());

        cal.add(Calendar.MONTH, 1);

        return new java.sql.Date(cal.getTimeInMillis());
    }

    /**
     * 增加年度
     */
    public static java.sql.Date addYearByIncreaseNumber(java.sql.Date date, int number) {
        Calendar cal = Calendar.getInstance();

        if (date != null)
            cal.setTimeInMillis(date.getTime());

        cal.add(Calendar.YEAR, number);

        return new java.sql.Date(cal.getTimeInMillis());
    }

    /**
     * 获取月份
     */
    public static int getMonth(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        cal.setTimeInMillis(date.getTime());

        return cal.get(Calendar.MONTH) + 1;
    }

    /**
     * 获取月份
     */
    public static int getYear(java.sql.Date date) {
        Calendar cal = Calendar.getInstance();

        cal.setTimeInMillis(date.getTime());

        return cal.get(Calendar.YEAR);
    }

    /**
     * 获取当前日期的年份
     */
    public static int getCurrenctDateYear() {
        Calendar cal = Calendar.getInstance();

        return cal.get(Calendar.YEAR);
    }

    /**
     * 根据时区获取当前年度
     */
    public static int getCurrentYearByTimeZone(String timeZone) {
        int year = 0;

        try {
            Date date = getCurrentDateTimeByTimeZone(timeZone);

            Calendar cal = Calendar.getInstance();

            cal.setTimeInMillis(date.getTime());

            year = cal.get(Calendar.YEAR);
        } catch (ParseException e) {
            year = Calendar.getInstance().get(Calendar.YEAR);
        }

        return year;
    }

    /**
     * 获取当前日期的月份
     */
    public static int getCurrenctDateMonth() {
        Calendar cal = Calendar.getInstance();

        return cal.get(Calendar.MONTH) + 1;
    }

    /**
     * 获取当前日期的月份中的天数
     *
     * @return
     */
    public static int getCurrenctDateDayOfMonth() {
        Calendar cal = Calendar.getInstance();

        return cal.get(Calendar.DAY_OF_MONTH);
    }

    /**
     * 根据公司代码获取当前时间信息 yyyy/MM/dd HH:mm:ss
     */
    public static Date getCurrentDateTimeByTimeZone(String timeZone) throws ParseException {
        if (StringUtil.isEmptyTrim(timeZone))
            timeZone = "GMT+8";
        Calendar calendar = Calendar.getInstance();

        calendar.setTimeZone(TimeZone.getTimeZone(timeZone));

        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        int min = calendar.get(Calendar.MINUTE);
        int sec = calendar.get(Calendar.SECOND);

        Calendar curCal = Calendar.getInstance();

        curCal.set(Calendar.YEAR, year);
        curCal.set(Calendar.MONTH, month);
        curCal.set(Calendar.DAY_OF_MONTH, dayOfMonth);
        curCal.set(Calendar.HOUR_OF_DAY, hour);
        curCal.set(Calendar.MINUTE, min);
        curCal.set(Calendar.SECOND, sec);

        return curCal.getTime();
    }

    public static boolean isEqualOrBefore(Date start, Date end) {
        return start.before(end) || start.equals(end);
    }

    /**
     * 获取日期的时点
     * @param date
     * @return
     */
    public static int getTimeHour(Date date) {
        Calendar cal = Calendar.getInstance();

        cal.setTime(date);

        return cal.get(Calendar.HOUR_OF_DAY);
    }

    /**
     * 根据时区，返回毫秒数
     *
     * @param timeZone
     */
    public static Long getCurrentTimeByTimeZone(String timeZone) throws ParseException {
        if (StringUtil.isEmptyTrim(timeZone)) {
            timeZone = "GMT+8";
        }
        return getCurrentDateTimeByTimeZone(timeZone).getTime();
    }

    /**
     * 两个日期比较 返回比较后的日期
     *
     * @param begin
     * @param stop
     * @param max
     * @return
     */
    public static Date compareDate(Date begin, Date stop, Boolean max) {
        boolean flag = begin.before(stop);
        if (max) {
            flag = !flag;
        }
        if (flag) {
            return stop;
        } else {
            return begin;
        }

    }

    /**
     * 获取当前util时间
     */
    public static Date getCurrentUtilDate() {
        return Calendar.getInstance().getTime();
    }

    /**
     * 获取当前util时间
     */
    public static java.sql.Date getCurrentSqlDate() {
        return java.sql.Date.valueOf(getCurrentDateString());
    }

    /**
     * 以yyyy-MM-dd方式返回日期数据
     */
    public static String getCurrentDateString() {
        String result = null;
        SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD);
        Date nowDate = new Date();
        result = sdf.format(nowDate);
        return result;
    }

    /**
     * 以yyyy-MM-dd HH:mm:ss方式返回时间
     */
    public static String getCurrentDateTime() {
        String result = null;
        SimpleDateFormat sdf = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS);
        Date nowDate = new Date();
        result = sdf.format(nowDate);
        return result;
    }

    /**
     * 以yyyyMM方式返回日期格式
     */
    public static String dateToString6(Date date) {
        if (date == null)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM);
        return simpleDateFormat.format(date);
    }

    /**
     * 以yyyyMMdd方式返回日期
     */
    public static String dateToString(Date date) {
        if (date == null)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD);
        return simpleDateFormat.format(date);
    }

    public static String dateToString(Date date, String pattern) {
        if (date == null)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);
        return simpleDateFormat.format(date);
    }

    public static final int daysBetween(Date early, Date late) {

        java.util.Calendar calst = java.util.Calendar.getInstance();
        java.util.Calendar caled = java.util.Calendar.getInstance();
        calst.setTime(early);
        caled.setTime(late);
        // 设置时间为0时
        calst.set(java.util.Calendar.HOUR_OF_DAY, 0);
        calst.set(java.util.Calendar.MINUTE, 0);
        calst.set(java.util.Calendar.SECOND, 0);
        caled.set(java.util.Calendar.HOUR_OF_DAY, 0);
        caled.set(java.util.Calendar.MINUTE, 0);
        caled.set(java.util.Calendar.SECOND, 0);
        // 得到两个日期相差的天数
        int days = ((int) (caled.getTime().getTime() / 1000) - (int) (calst.getTime().getTime() / 1000)) / 3600 / 24;

        return days;
    }

    public static java.sql.Date stringToSQLDate(String string, String pattern) {
        if (StringUtil.isNotEmptyTrim(string)) {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

            try {
                return new java.sql.Date(simpleDateFormat.parse(string).getTime());
            } catch (ParseException e) {
                e.printStackTrace();
            }
        }

        return null;
    }

    /**
     * 由yyyy-MM-dd格式的字符串返回日期
     */
    public static java.sql.Date stringToSQLDate(String string) {
        if (string == null)
            return null;
        if (string.trim().length() == 0)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD);

        try {
            return new java.sql.Date(simpleDateFormat.parse(string).getTime());
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 由yyyy-MM-dd HH:mm:ss格式的字符串返回日期时间
     * @param string 时间
     */
    public static Date stringToTime(String string) {
        if (string == null)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD_HH_MM_SS);

        try {
            return simpleDateFormat.parse(string);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 格式字符串返回日期时间
     *
     * @param string 时间
     * @param pattern 格式
     */
    public static Date stringToTime(String string, String pattern) {
        if (string == null)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(pattern);

        try {
            return simpleDateFormat.parse(string);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    /**
     * 由yyyy-MM-dd格式的字符串返回日期
     */
    public static Date stringToDate(String string) {
        if (string == null)
            return null;
        if (string.trim().length() == 0)
            return null;
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat(YYYY_MM_DD);

        try {
            return simpleDateFormat.parse(string);
        } catch (ParseException e) {
            e.printStackTrace();
        }

        return null;
    }

    public static final String YYYY_MM_DD = "yyyy-MM-dd";
    public static final String YYYYMMDD = "yyyyMMdd";
    public static final String HHMMSS = "HHmmss";
    public static final String YYYY_MM_DD_HH_MM_SS = "yyyy-MM-dd HH:mm:ss";
    public static final String YYYY_MM_DD_HH_MM = "yyyy-MM-dd HH:mm";
    public static final String YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
    public static final String YYYY_MM_DD_HHMMSS = "yyyy-MM-dd HHmmss";
    public static final String HH_MM_SS = "HH:mm:ss";
    public static final String YYYY_MM = "yyyyMM";

}

