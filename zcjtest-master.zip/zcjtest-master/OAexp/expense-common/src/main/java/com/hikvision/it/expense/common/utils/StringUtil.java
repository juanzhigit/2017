package com.hikvision.it.expense.common.utils;

import java.io.UnsupportedEncodingException;
import java.util.Objects;
import java.util.UUID;

import org.apache.commons.codec.binary.Base64;

/**
 * string工具类
 * <p>Title: StringUtil.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年5月22日
 *
 */
public class StringUtil {
	/**
	 * 通配符
	 */
	public static final String COMMON_REGEX = "*";
	/** 结尾相似匹配 */
	public static final String LIKE_REGEX = "%";
	/** 美金 */
	public static final String USD = "USD";
	
	/**
	 * 判断字符串不为空
	 * 
	 * @param source
	 * @return
	 */
	public static boolean isNotEmptyTrim(String source) {
		return !isEmptyTrim(source);
	}

	/**
	 * 判断字符串为空
	 * 
	 * @param source
	 * @return
	 */
	public static boolean isEmptyTrim(String source) {
		if (null != source && !"".equalsIgnoreCase(source.trim())) {
			return false;
		} else {
			return true;
		}
	}

	/**
	 * 获取uuid
	 * 
	 * @return
	 */
	public static String getUUID() {
		return UUID.randomUUID().toString().replaceAll("-", "").toUpperCase();
	}

	/**
	 * 将加密串解密
	 * 
	 * @param encodeStr
	 * @return
	 */
	public static String decodeStr(String encodeStr) {
		byte[] decodeBytes = Base64.decodeBase64(encodeStr.getBytes());

		try {
			return new String(decodeBytes, "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * 加密字符串
	 * 
	 * @param str
	 * @return
	 */
	public static String encodeStr(String str) {
		try {
			return new String(Base64.encodeBase64(str.getBytes()), "UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}

		return null;
	}

	/**
	 * 字符串忽略大小写比较
	 */
	public static boolean equalsIgnoreCase(String str1, String str2) {
		if (Objects.equals(str1, str2)) {
			return true;
		}
		if (str1 == null || str2 == null) {
			return false;
		}
		return str1.equalsIgnoreCase(str2);
	}
}
