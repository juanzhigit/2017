package com.hikvision.it.expense.common.utils;

import java.net.Authenticator;
import java.net.PasswordAuthentication;

/**
 * pi接口调用公共认证类
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/12
 * Time: 9:56
 * To change this template use File | Settings | File Templates.
 */
public class PIAuthenticator extends Authenticator {
    private String userId;
    private String password;

    public PIAuthenticator(String userId, String password) {
        super();
        this.userId = userId;
        this.password = password;
    }

    protected PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(StringUtil.decodeStr(userId),
                StringUtil.decodeStr(password).toCharArray());
    }
}
