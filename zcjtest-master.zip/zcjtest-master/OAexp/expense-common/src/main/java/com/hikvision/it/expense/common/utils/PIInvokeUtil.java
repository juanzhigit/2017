package com.hikvision.it.expense.common.utils;

import java.util.Map;

import javax.xml.ws.BindingProvider;

/**
 * pi调用工具类
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/12
 * Time: 10:06
 * To change this template use File | Settings | File Templates.
 */
public class PIInvokeUtil {
    /**
     * 绑定认证信息
     * @param port
     * @param usr
     * @param pwd
     */
    public static void bindAuchenticator(Object port, String usr, String pwd) {
        BindingProvider bp = (BindingProvider) port;
        Map<String, Object> context = bp.getRequestContext();
        context.put(BindingProvider.USERNAME_PROPERTY, usr);
        context.put(BindingProvider.PASSWORD_PROPERTY, pwd);
    }
}
