package com.hikvision.it.expense.icbc.enums;

/**
 * 文件类别
 * <p>Title: DocType.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年7月6日
 *
 */
public enum DocTypeEnum {
    PDF("PDF"),
    SIGN("SIGN");
    
    private String key;
    
    private DocTypeEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
