package com.hikvision.it.expense.icbc.service.zip;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.Writer;
import java.util.Enumeration;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.icbc.entity.ICBCPdfFileInfo;
import com.hikvision.it.expense.icbc.enums.ActionEnum;
import com.hikvision.it.expense.icbc.enums.DocTypeEnum;

/**
 * 接口实现类
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/11
 * Time: 15:14
 * To change this template use File | Settings | File Templates.
 */
@Service
public class ICBCUnZipFileServiceImpl implements  ICBCUnZipFileService {
    //logback日志
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Override
    public List<ICBCPdfFileInfo> unZipPDFFiles(String downPath) {
        List<ICBCPdfFileInfo> list = Lists.newArrayList();

        File file = new File(downPath);
        //读取下载文件夹下内容
        if (file.exists()) {
            logger.info(DateUtil.dateToString(DateUtil.getCurrentUtilDate(), DateUtil.YYYYMMDDHHMMSS) + "开始解压缩zip文件");
            File[] files = file.listFiles();
            //遍历下载文件加下文件，对zip文件进行解压缩
            for (File childFile : files) {
                String childFileName = childFile.getName();
                try {
                    if (childFileName.toLowerCase().endsWith(".zip")) {
                        ZipFile zipFile = new ZipFile(childFile);
                        //解压zip文件
                        this.unZipFiles(zipFile, downPath, list);
                        logger.info(childFileName + "完成解压！");
                    }
                } catch (Exception e) {
                    logger.info(childFileName + "解压出错！");
                }
            }
            logger.info(DateUtil.dateToString(DateUtil.getCurrentUtilDate(), DateUtil.YYYYMMDDHHMMSS) + "完成解压缩zip文件");
        } else {
            logger.info("(" + downPath + ")文件下载目录有误！");
        }

        return list;
    }

    /**
     * 解压文件
     * @param zipFile
     * @param downPath
     * @param list
     *
     * @throws IOException
     */
    private void unZipFiles(ZipFile zipFile, String downPath, List<ICBCPdfFileInfo> list) throws IOException {
        String fileSeparator = File.separator;

        try {
            for (Enumeration<?> entries = zipFile.entries(); entries.hasMoreElements();) {
                ZipEntry entry = (ZipEntry) entries.nextElement();

                String zipEntryName = entry.getName();

                if (zipEntryName.endsWith(".PDF")) {
                    String[] splitNames = zipEntryName.split("_");

                    if (splitNames.length == 3) {

                        String folderName = splitNames[0];
                        String pdfFileName = splitNames[2];
                        String pdfFolderName = pdfFileName.replace(".PDF", "").replace(".pdf", "");
                        String archiveDate = splitNames[1];

                        //创建pdf回单实体entity，并且添加到list中
                        ICBCPdfFileInfo pdfFileInfo = new ICBCPdfFileInfo();

                        pdfFileInfo.setDocType(DocTypeEnum.PDF);
                        pdfFileInfo.setBankAccount(folderName);
                        pdfFileInfo.setTransDate(archiveDate);
                        pdfFileInfo.setSeqNo(pdfFolderName);
                        pdfFileInfo.setAction(ActionEnum.INSERT);

                        list.add(pdfFileInfo);

                        String rootFolderName = folderName + archiveDate + pdfFolderName;
                        //电子回单文件夹路径
                        String rootFolderPath = downPath + fileSeparator + rootFolderName;
                        //pdf文件夹路径
                        String pdfFolderPath = downPath + fileSeparator + rootFolderName + fileSeparator + pdfFolderName;
                        //pdf文件路径
                        String pdfFilePath = pdfFolderPath + fileSeparator + pdfFolderName + ".PDF";
                        //创建电子回单文件目录以及属性文件
                        createHdFolder(rootFolderPath, folderName, pdfFolderName);
                        //创建pdf文件存放目录以及子属性
                        createPDFFileFolder(pdfFolderPath, pdfFileName, archiveDate, pdfFolderName, folderName);
                        //解压pdf文件到pdf文件夹
                        unzipFileToPath(zipFile, entry, pdfFilePath);
                    } else {
                        throw new IOException("文件路径有误，请确认文件路径！");
                    }
                }
            }
        } finally {
            if (zipFile != null)
                zipFile.close();
        }
    }

    /**
     * 解压pdf文件到pdf文件目录
     *
     * @param zipFile
     * @param entry
     * @param pdfFilePath
     *
     * @throws IOException
     */
    private void unzipFileToPath(ZipFile zipFile, ZipEntry entry, String pdfFilePath) throws IOException {
        InputStream in = null;
        OutputStream out = null;
        try {
            File file = new File(pdfFilePath);
            if(!file.exists()){
                in = zipFile.getInputStream(entry);
                out = new FileOutputStream(pdfFilePath);
                byte[] buf1 = new byte[1024];
                int len;
                while((len=in.read(buf1)) > 0){
                    out.write(buf1,0,len);
                }
            }
        } finally {
            this.closeInputStream(in);
            this.closeOutputStream(out);
        }
    }

    /**
     * 创建电子回单文件夹
     *
     * @param folderPath      电子回单存放目录
     * @param folderName      电子回单文件夹名称
     * @param pdfFolderName   电子回单文件名
     *
     * @throws IOException
     */
    private void createHdFolder(String folderPath, String folderName, String pdfFolderName) throws IOException {
        //创建文件夹
        createFile(true, folderPath);
        //创建docordertxt子属性文件
        createDocOrderTxtFile(folderPath, pdfFolderName);
        //创建grlock子文件属性
        createGrLockFile(folderPath, folderName);
    }

    /**
     * 创建pdf文件存放目录
     *
     * @param pdfFolderPath     电子回单目录路径
     * @param pdfFileName       pdf文件名
     * @param archiveDate       日期
     * @param pdfFolderName     pdf文件夹路径
     * @param rootFolderName    电子档案文件夹路径
     * @throws IOException
     */
    private void createPDFFileFolder(String pdfFolderPath,
                                     String pdfFileName,
                                     String archiveDate,
                                     String pdfFolderName,
                                     String rootFolderName) throws IOException {
        //创建PDF文件夹存放目录
        createFile(true, pdfFolderPath);
        //创建pdf日志文件
        createPdfLogFile(pdfFolderPath);
        //生成pdf ixattr文件
        createIXATTRFile(pdfFolderPath);
        //生成pdf commands文件
        createCommandFile(pdfFolderPath, pdfFolderName, pdfFileName, rootFolderName, archiveDate);
    }

    /**
     * 生成pdf commands文件
     * @param pdfFolderPath
     * @param pdfFolderName
     * @param pdfFileName
     * @param rootFolderName
     * @param archiveDate
     * @throws IOException
     */
    private void createCommandFile(String pdfFolderPath, String pdfFolderName,
                                   String pdfFileName,
                                   String rootFolderName,
                                   String archiveDate) throws IOException {
        File file = null;
        BufferedWriter writer = null;
        FileWriter fw = null;
        file = new File(pdfFolderPath + File.separator + "COMMANDS");
        if(!file.exists()){
            //创建文件
            file.createNewFile();
        }
        //写文件
        try {
            fw = new FileWriter(file);
            writer = new BufferedWriter(fw);

            writer.write("DOCTYPE PDF");
            writer.newLine();//换行
            writer.write("COMP data1 application/pdf " + pdfFileName);
            writer.newLine();//换行
            writer.write("R3_DESTINATION PRD800");
            writer.newLine();//换行
            writer.write("R3_CLIENT 800");
            writer.newLine();//换行
            writer.write("R3_SAP_OBJ BKPF");
            writer.newLine();//换行
            writer.write("DocNo " + pdfFolderName);
            writer.newLine();//换行
            writer.write("ARCHIVID Z2");
            writer.newLine();//换行
            writer.write("R3_AR_OBJ ZHIK_HD");
            writer.newLine();//换行
            writer.write("archiveDate " + DateUtil.dateToString(DateUtil.stringToSQLDate(archiveDate, DateUtil.YYYYMMDD), DateUtil.YYYY_MM_DD));
            writer.newLine();//换行
            writer.write("ID " + rootFolderName);

            writer.flush();
        } finally {
            this.closeWriter(writer);
            this.closeWriter(fw);
        }
    }

    /**
     * 生成pdf ixattr文件
     * @param pdfFolderPath
     * @throws IOException
     */
    private void createIXATTRFile(String pdfFolderPath) throws IOException {
        File file = null;
        BufferedWriter writer = null;
        FileWriter fw = null;
        file = new File(pdfFolderPath + File.separator + "IXATTR");
        if(!file.exists()){
            //创建文件
            file.createNewFile();
        }
        //写文件
        try {
            fw = new FileWriter(file);
            writer = new BufferedWriter(fw);

            writer.write("NEWDOC");
            writer.newLine();//换行
            writer.write("R3_CLIENT    TOAV0|MANDT|CC|%s||");
            writer.newLine();//换行
            writer.write("ARCHIVIDATTR TOAV0|ARCHIV_ID|CC|%s||");
            writer.newLine();//换行
            writer.write("DOCIDATTR    TOAV0|ARC_DOC_ID|CC|%s||");
            writer.newLine();//换行
            writer.write("R3_SAP_OBJ   TOAV0|SAP_OBJECT|CC|%s||");
            writer.newLine();//换行
            writer.write("R3_OBJ_ID    TOAV0|OBJECT_ID|CC|%s||");
            writer.newLine();//换行
            writer.write("R3_AR_OBJ    TOAV0|AR_OBJECT|CC|%s||");

            writer.flush();
        } finally {
            this.closeWriter(writer);
            this.closeWriter(fw);
        }
    }

    /**
     * 关闭输出流
     * @param writer
     * @throws IOException
     */
    private void closeWriter(Writer writer) throws IOException {
        if (writer != null)
            writer.close();
    }

    /**
     * 创建pdf日志文件
     * @param pdfFolderPath
     */
    private void createPdfLogFile(String pdfFolderPath) throws IOException {
        File file = null;
        FileOutputStream out = null;

        file = new File(pdfFolderPath + File.separator + "log");

        if(!file.exists()){
            //创建文件
            file.createNewFile();
        }
        //写文件
        try {
            out = new FileOutputStream(file);
        } finally {
            this.closeOutputStream(out);
        }
    }

    /**
     * 创建文件/文件夹
     * @param isCreateFolder    是否创建文件夹
     * @param filePath          创建路径
     * @return
     * @throws IOException
     */
    private static void createFile(boolean isCreateFolder, String filePath) throws IOException {
        File file = new File(filePath);
        if (isCreateFolder) {
            if(!file.exists()){
                file.mkdirs();
            }
        } else {
            if(!file.exists()){
                //创建文件
                file.createNewFile();
            }
        }
    }

    /**
     * 生成docOrder文档
     * @param filePath
     * @param pdfFileName
     * @throws IOException
     */
    private void createDocOrderTxtFile(String filePath, String pdfFileName) throws IOException {
        File file = null;
        FileOutputStream out = null;

        file = new File(filePath + File.separator + "Doc_Order.txt");

        if(!file.exists()){
            //创建文件
            file.createNewFile();
        }
        //写文件
        try {
            out = new FileOutputStream(file);
            out.write(pdfFileName.getBytes("GBK"));
        } finally {
            this.closeOutputStream(out);
        }
    }

    /**
     * 生成GR_LOCK txt文件
     * @param filePath
     * @param rootFolderName
     * @param filePath
     * @param rootFolderName
     * @throws IOException
     */
    private void createGrLockFile(String filePath, String rootFolderName) throws IOException {
        File file = null;
        FileOutputStream out = null;

        file = new File(filePath + File.separator + "GR_LOCK.txt");

        if(!file.exists()){
            //创建文件
            file.createNewFile();
        }
        //写文件
        try {
            out = new FileOutputStream(file);
            out.write(rootFolderName.getBytes("GBK"));
        } finally {
            this.closeOutputStream(out);
        }
    }

    /**
     * 关闭输出流
     * @param out
     * @throws IOException
     */
    private void closeOutputStream(OutputStream out) throws IOException {
        if (out != null)
            out.close();
    }

    /**
     * 关闭输入流
     * @param inputStream
     * @throws IOException
     */
    private void closeInputStream(InputStream inputStream) throws IOException {
        if (inputStream != null)
            inputStream.close();
    }
}
