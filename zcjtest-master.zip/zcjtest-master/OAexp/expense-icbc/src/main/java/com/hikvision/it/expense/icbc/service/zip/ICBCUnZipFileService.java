package com.hikvision.it.expense.icbc.service.zip;

import java.util.List;

import com.hikvision.it.expense.icbc.entity.ICBCPdfFileInfo;

/**
 * 按要求解压zip文件
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/11
 * Time: 15:08
 * To change this template use File | Settings | File Templates.
 */
public interface ICBCUnZipFileService {
    /**
     * <p>1、读取download文件夹下所有的zip压缩文件，逐一解压文件中的pdf回单到独立的文件夹中
     * <p>    文件夹名称规则为：银行账号+交易日期+交易流水号
     * <p>2、在文件中创建Doc_Order.txt、GR_LOCK.TXT两个文件用于影像系统归档
     * <p>   Doc_Order.txt   内容为   交易流水号
     * <p>   GR_LOCK.TXT     内容为   银行账号
     * <p>3、在文件夹中创建子文件夹并且以交易流水号命名，然后把pdf文件解压到子文件中，以交易流水号.PDF命名
     * <p>4、在子文件夹中创建COMMANDS、IXATTR、log三个文件，用于影像系统归档
     * <p>  COMMANDS        内容为：    DOCTYPE PDF
     * <p>                         COMP data1 application/pdf {交易流水号.PDF}
     * <p>                         R3_DESTINATION PRD800
     * <p>                         R3_CLIENT 800
     * <p>                         R3_SAP_OBJ BKPF
     * <p>                         DocNo {交易流水号}
     * <p>                         ARCHIVID Z2
     * <p>                         R3_AR_OBJ ZHIK_HD
     * <p>                         archiveDate {交易日期}  需要格式转换 YYYY-MM-DD
     * <p>                         ID {银行账号}
     * <p>  IXATTR          内容为：    NEWDOC
     * <p>                         R3_CLIENT    TOAV0|MANDT|CC|%s||
     * <p>                         ARCHIVIDATTR TOAV0|ARCHIV_ID|CC|%s||
     * <p>                         DOCIDATTR    TOAV0|ARC_DOC_ID|CC|%s||
     * <p>                         R3_SAP_OBJ   TOAV0|SAP_OBJECT|CC|%s||
     * <p>                         R3_OBJ_ID    TOAV0|OBJECT_ID|CC|%s||
     * <p>                         R3_AR_OBJ    TOAV0|AR_OBJECT|CC|%s||
     * <p>  log为空文件
     *
     * @param downPath      zip文件下载存放路径
     *
     * @return
     */
    List<ICBCPdfFileInfo> unZipPDFFiles(String downPath);
}
