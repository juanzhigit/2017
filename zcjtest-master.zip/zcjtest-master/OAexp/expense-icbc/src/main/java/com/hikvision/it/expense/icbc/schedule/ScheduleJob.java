package com.hikvision.it.expense.icbc.schedule;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.scheduling.config.ScheduledTask;
import org.springframework.stereotype.Component;

import com.hikvision.it.expense.icbc.entity.ICBCPdfFileInfo;
import com.hikvision.it.expense.icbc.service.archive.IArchiveService;
import com.hikvision.it.expense.icbc.service.ftp.ICBCFtpService;
import com.hikvision.it.expense.icbc.service.zip.ICBCUnZipFileService;

/**
 * 后台任务job
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/7
 * Time: 16:35
 * To change this template use File | Settings | File Templates.
 */
@Component
public class ScheduleJob {
    private static final Logger logger = LoggerFactory.getLogger(ScheduledTask.class);
    @Autowired
    ICBCFtpService ftpService;
    @Autowired
    ICBCUnZipFileService zipService;
    @Autowired
    IArchiveService archiveService;

    /**
     * 解压工行pdf文件,每天5点运行一次
     */
    @Scheduled(cron = "0 0/1 * * * ?")
    public void unzipICBCPdfZipFile() {
        try {
            // 1、首先从ftp上将所有zip文件下载到本地
            String downPath = ftpService.downloadZIPFileFromFtp();
            // 2、逐个解压zip文件到指定目录
            List<ICBCPdfFileInfo> pdfFiles = zipService.unZipPDFFiles(downPath);
            // 3、调用接口，并且记录同步推送日志
            archiveService.synchPdfFileInfoToSap(pdfFiles);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
