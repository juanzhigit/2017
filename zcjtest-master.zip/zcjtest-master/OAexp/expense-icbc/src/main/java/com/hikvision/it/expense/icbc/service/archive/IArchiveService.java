package com.hikvision.it.expense.icbc.service.archive;

import java.util.List;

import com.hikvision.it.expense.icbc.entity.ICBCPdfFileInfo;

/**
 * 电子回单解析结果回传sap接口服务
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/11
 * Time: 16:52
 * To change this template use File | Settings | File Templates.
 */
public interface IArchiveService {
    /**
     * 同步pdf文件信息到sap
     * @param pdfFiles
     */
    void synchPdfFileInfoToSap(List<ICBCPdfFileInfo> pdfFiles);
}
