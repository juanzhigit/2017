@javax.xml.bind.annotation.XmlSchema(namespace = "urn:hikvision:erp:oa:fico")
package com.hikvision.it.expense.icbc.pi.archive.client;
