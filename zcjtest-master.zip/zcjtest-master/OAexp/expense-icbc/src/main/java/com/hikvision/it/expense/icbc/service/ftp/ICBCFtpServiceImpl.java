package com.hikvision.it.expense.icbc.service.ftp;

import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPCmd;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.hikvision.it.expense.common.utils.DateUtil;

/**
 * 工行pdf文件ftp读取service
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/7
 * Time: 16:54
 * To change this template use File | Settings | File Templates.
 */
@Service
public class ICBCFtpServiceImpl implements ICBCFtpService {
    //logback日志
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Value("${system.icbc.ftp.host}")
    private String host;
    @Value("${system.icbc.ftp.user}")
    private String user;
    @Value("${system.icbc.ftp.password}")
    private String password;
    @Value("${system.zip.download.path}")
    private String downloadPath;

    @Override
    public String downloadZIPFileFromFtp() {
        //获取下载路径
        String downPath = this.getDownloadPath();
        FTPClient ftpClient = null;
        try {
            try {
                ftpClient = getFTPClient();
                logger.info(DateUtil.getCurrentDateTime() + " - 开始下载zip文件");
                String backUpFilePath = this.createBackupDirectory(ftpClient);
                //下载文件
                this.downloadFile(ftpClient, downPath, backUpFilePath);
            } catch (Exception e) {
                e.printStackTrace();
                logger.info("获取ftp连接异常!");
            }


        } finally {
            try {
                ftpClient.disconnect();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        return downPath;
    }

    /**
     * 创建文件夹
     * @return
     */
    private String getDownloadPath() {
        //获取下载存放目录
        String tmpPath = DateUtil.dateToString(DateUtil.getCurrentUtilDate(), DateUtil.YYYYMMDDHHMMSS);
        //下载文件存放目录
        String downPath = downloadPath + tmpPath + File.separator;

        File file = new File(downPath);

        if (!file.exists()) {
            file.mkdir();
        }

        return downPath;
    }

    /**
     * 下载ftp文件
     * @param ftpClient
     * @param downPath
     * @param backUpFilePath 文件备份目录
     */
    private void downloadFile(FTPClient ftpClient, String downPath, String backUpFilePath) {
        int fileNumbers = 0;
        int fileExistsNumber = 0;

        try {
            FTPFile[] files = ftpClient.listFiles();
            //定义输入流，下载文件到本地
            String fileName = null;
            for (FTPFile file : files) {
                fileName = file.getName();
                String filePath = downPath + fileName;
                //从ftp上将所有zip文件下载到本地
                if (filePath.toLowerCase().endsWith(".zip")) {
                    File locaFile= new File(filePath);
                    if (locaFile.exists()) {
                        fileExistsNumber += 1;
                        continue;
                    } else {
                        //下载
                        this.download(ftpClient, filePath, fileName, backUpFilePath);
                        logger.info(fileName);
                        fileNumbers += 1;
                    }
                } else {
                    continue;
                }
            }

            logger.info(DateUtil.getCurrentDateTime() + " - 完成下载" +
                    (fileNumbers + fileExistsNumber) + "个文件，其中已下载文件数量为：" + fileExistsNumber);
        } catch (IOException e) {
            e.printStackTrace();
            logger.info("获取ftp文件列表异常，" + e.getMessage());
        }
    }

    /**
     * 逐个下载文件
     * @param ftpClient
     * @param filePath
     * @param fileName
     * @param backUpFilePath
     */
    private void download(FTPClient ftpClient, String filePath, String fileName, String backUpFilePath) {
        OutputStream outs = null;

        try {
            outs = new FileOutputStream(filePath);
            ftpClient.retrieveFile(fileName, outs);
            outs.flush();
            //下载完成后，将源文件移动到history文件夹下
            ftpClient.sendCommand(FTPCmd.RNFR, fileName);
            ftpClient.sendCommand(FTPCmd.RNTO, backUpFilePath + fileName);
        } catch (IOException e) {
            e.printStackTrace();
            logger.info(fileName + "文件下载出错，" + e.getMessage());
        }finally {
            //关闭流
            if (outs != null) {
                try {
                    outs.close();
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 创建备份目录
     * @param ftpClient
     */
    private String createBackupDirectory(FTPClient ftpClient) throws IOException {
        String backUpDirDame = "history";
        //将已下载的文件转移到history目录下，并且放到以当前日期+序列的文件夹中进行备份
        ftpClient.makeDirectory(backUpDirDame);
        //修改工作目录
        ftpClient.changeWorkingDirectory(backUpDirDame);
        String year = DateUtil.getCurrenctDateYear() + "";
        //创建年度文件夹
        ftpClient.makeDirectory(year);
        ftpClient.changeWorkingDirectory(year);
        //获取当天同步次数
        String index = "";
        int size = ftpClient.listNames().length;
        if (size < 9) {
            index += "0";
        }
        index += (size + 1);
        //按照日期和下载次数创建备份目录
        ftpClient.makeDirectory(index);
        //移动到根目录
        ftpClient.changeWorkingDirectory("/");
        //返回备份文件目录
        return backUpDirDame + "/" + year + "/" + index + "/";
    }

    /**
     * 获取FTP连接方法
     * @return
     * @throws Exception
     */
    private FTPClient getFTPClient() throws Exception {
        FTPClient ftp = new FTPClient();
        // 连接FTP服务器
        // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
        ftp.connect(host, 21);
        ftp.setControlEncoding("UTF-8");
        // 登录
        boolean login = ftp.login(user, password);
        ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
        if (!login) {
            throw new Exception("FTP Login error, please contact the administrator!");
        }
        int reply = ftp.getReplyCode();
        // FTP服务器连接成功
        if (!FTPReply.isPositiveCompletion(reply)) {
            ftp.disconnect();
        }

        return ftp;
    }
}
