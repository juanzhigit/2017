package com.hikvision.it.expense.icbc.entity;

import java.io.Serializable;

import com.hikvision.it.expense.icbc.enums.ActionEnum;
import com.hikvision.it.expense.icbc.enums.DocTypeEnum;

/**
 * 工行pdf电子回单信息entity
 * <p>Title: ICBCPdfFileInfo.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年7月6日
 *
 */
public class ICBCPdfFileInfo implements Serializable {
    private static final long serialVersionUID = 1886218600430255300L;
    
    /** 银行账号 */
    private String bankAccount;
    /** 交易日期 */
    private String transDate;
    /** 交易流水号 */
    private String seqNo;
    /** 文档类别  PDF */
    private DocTypeEnum docType;
    /** 操作类别 */
    private ActionEnum action;
    /** 同步状态 */
    private String flag;
    /** 返回消息 */
    private String msg;
    
    public String getBankAccount() {
        return bankAccount;
    }
    public void setBankAccount(String bankAccount) {
        this.bankAccount = bankAccount;
    }
    public String getTransDate() {
        return transDate;
    }
    public void setTransDate(String transDate) {
        this.transDate = transDate;
    }
    public String getSeqNo() {
        return seqNo;
    }
    public void setSeqNo(String seqNo) {
        this.seqNo = seqNo;
    }
    public DocTypeEnum getDocType() {
        return docType;
    }
    public void setDocType(DocTypeEnum docType) {
        this.docType = docType;
    }
    public ActionEnum getAction() {
        return action;
    }
    public void setAction(ActionEnum action) {
        this.action = action;
    }

    public String getFlag() {
        return flag;
    }

    public void setFlag(String flag) {
        this.flag = flag;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }
}
