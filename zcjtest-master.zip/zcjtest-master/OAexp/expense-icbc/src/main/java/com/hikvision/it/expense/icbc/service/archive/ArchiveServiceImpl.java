package com.hikvision.it.expense.icbc.service.archive;

import java.net.Authenticator;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.LinkedHashMap;
import java.util.List;

import javax.xml.namespace.QName;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.PIAuthenticator;
import com.hikvision.it.expense.common.utils.PIInvokeUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.icbc.dao.IArchiveDao;
import com.hikvision.it.expense.icbc.entity.ICBCPdfFileInfo;
import com.hikvision.it.expense.icbc.enums.ActionEnum;
import com.hikvision.it.expense.icbc.pi.archive.client.DTARCHIVICBCRECEIPTREQ;
import com.hikvision.it.expense.icbc.pi.archive.client.DTARCHIVICBCRECEIPTRESP;
import com.hikvision.it.expense.icbc.pi.archive.client.SIARCHIVICBCRECEIPTOUT;
import com.hikvision.it.expense.icbc.pi.archive.client.SIARCHIVICBCRECEIPTOUTService;

/**
 * 电子回单解析结果回传sap接口实现类
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/11
 * Time: 16:52
 * To change this template use File | Settings | File Templates.
 */
@Service
public class ArchiveServiceImpl implements IArchiveService {
    //logback日志
    private final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    IArchiveDao dao;
    @Value("${system.pi.archive.url}")
    private String url;
    @Value("${system.pi.archive.namespace}")
    private String nameSpace;
    @Value("${system.pi.archive.localpart}")
    private String localPart;
    @Value("${system.pi.user}")
    private String piUser;
    @Value("${system.pi.password}")
    private String piUserPassWord;

    @Override
    public void synchPdfFileInfoToSap(List<ICBCPdfFileInfo> pdfFiles) {
        //获取当前时间
        String logId = DateUtil.dateToString(DateUtil.getCurrentUtilDate(), DateUtil.YYYYMMDDHHMMSS);
        try {
            logger.info(logId + " - 开始同步数据到sap");
            if (!ListUtil.isEmpty(pdfFiles)) {
                //同步数据到sap
                URL wsdlURL = null;
                try {
                    wsdlURL = new URL(url);
                } catch (MalformedURLException e) {
                    e.printStackTrace();
                    return;
                }
                //设置自定义权限认证
                Authenticator.setDefault(new PIAuthenticator(piUser, piUserPassWord));
                //获取服务接口
                SIARCHIVICBCRECEIPTOUTService service = new SIARCHIVICBCRECEIPTOUTService(wsdlURL, new QName(nameSpace, localPart));
                //获取服务接口
                SIARCHIVICBCRECEIPTOUT port = service.getHTTPPort();
                //绑定认证信息
                PIInvokeUtil.bindAuchenticator(port, StringUtil.decodeStr(piUser), StringUtil.decodeStr(piUserPassWord));
                //设置请求参数
                DTARCHIVICBCRECEIPTREQ req = new DTARCHIVICBCRECEIPTREQ();
                LinkedHashMap<String, ICBCPdfFileInfo> reqMap = this.setRequestParam(req, pdfFiles);
                //获取并解析请求参数
                DTARCHIVICBCRECEIPTRESP response = port.archivICBCRECEIPT(req);
                //解析同步结果
                pdfFiles = this.analysisResponse(response, reqMap);
            }
        } finally {
            if (!ListUtil.isEmpty(pdfFiles)) {
                //记录需要同步的pdf文件列表，并且关联本次同步唯一key
                dao.recordSynchInfo(logId, pdfFiles.size());
                //同步pdf文档明细到sap并且记录更新状态
                dao.recordSynchDetail(logId, pdfFiles);
            } else {
                //记录需要同步的pdf文件列表，并且关联本次同步唯一key
                dao.recordSynchInfo(logId, 0);
            }
            logger.info(DateUtil.dateToString(DateUtil.getCurrentUtilDate(), DateUtil.YYYYMMDDHHMMSS) + " - 完成同步数据");
        }
    }

    /**
     * 设置请求参数
     * @param req
     * @param pdfFileInfos
     */
    private LinkedHashMap<String, ICBCPdfFileInfo> setRequestParam(DTARCHIVICBCRECEIPTREQ req, List<ICBCPdfFileInfo> pdfFileInfos) {
        LinkedHashMap<String, ICBCPdfFileInfo> reqMap = Maps.newLinkedHashMap();

        List<DTARCHIVICBCRECEIPTREQ.ITEM> reqItems = req.getITEM();
        for (ICBCPdfFileInfo pdfInfo : pdfFileInfos) {
            DTARCHIVICBCRECEIPTREQ.ITEM item = new DTARCHIVICBCRECEIPTREQ.ITEM();

            item.setBANKN(pdfInfo.getBankAccount());
            item.setTRANDATE(pdfInfo.getTransDate());
            item.setSERNO(pdfInfo.getSeqNo());
            item.setDOCTYP(pdfInfo.getDocType().getKey());
            item.setACTTYP(ActionEnum.INSERT.getKey());

            reqItems.add(item);
            //将请求参数放入map中
            reqMap.put(this.packageKey(pdfInfo), pdfInfo);
        }

        return reqMap;
    }

    /**
     * 拼接key
     * @param pdfInfo
     * @return
     */
    private String packageKey(ICBCPdfFileInfo pdfInfo) {
        return pdfInfo.getBankAccount() + "-" + pdfInfo.getTransDate() + "-" + pdfInfo.getSeqNo();
    }

    /**
     * 解析返回结果
     * @param response
     * @param reqMap
     */
    private List<ICBCPdfFileInfo> analysisResponse(DTARCHIVICBCRECEIPTRESP response, LinkedHashMap<String, ICBCPdfFileInfo> reqMap) {
        List<DTARCHIVICBCRECEIPTRESP.ITEM> items = response.getITEM();

        for (DTARCHIVICBCRECEIPTRESP.ITEM item : items) {
            String key = item.getBANKN() + "-" + item.getTRANDATE() + "-" + item.getSERNO();

            if (reqMap.containsKey(key)) {
                ICBCPdfFileInfo pdfInfo = reqMap.get(key);

                pdfInfo.setFlag(item.getMSGTYPE());
                pdfInfo.setMsg(item.getMSG());
            } else {
                logger.info("传入参数中不存在回单数据：" + key);
            }
        }

        return Lists.newArrayList(reqMap.values());
    }
}
