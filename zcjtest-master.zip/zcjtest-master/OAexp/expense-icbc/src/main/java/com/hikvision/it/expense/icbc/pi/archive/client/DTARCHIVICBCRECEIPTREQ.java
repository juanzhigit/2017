
package com.hikvision.it.expense.icbc.pi.archive.client;

import java.util.ArrayList;
import java.util.List;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlType;


/**
 * 工行电子回单归档
 * 
 * <p>DT_ARCHIV_ICBCRECEIPT_REQ complex type的 Java 类。
 * 
 * <p>以下模式片段指定包含在此类中的预期内容。
 * 
 * <pre>
 * &lt;complexType name="DT_ARCHIV_ICBCRECEIPT_REQ"&gt;
 *   &lt;complexContent&gt;
 *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *       &lt;sequence&gt;
 *         &lt;element name="ITEM" maxOccurs="unbounded" minOccurs="0"&gt;
 *           &lt;complexType&gt;
 *             &lt;complexContent&gt;
 *               &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
 *                 &lt;sequence&gt;
 *                   &lt;element name="BANKN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="TRAN_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="SER_NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="DOC_TYP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="ARC_DOC_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                   &lt;element name="ACT_TYP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
 *                 &lt;/sequence&gt;
 *               &lt;/restriction&gt;
 *             &lt;/complexContent&gt;
 *           &lt;/complexType&gt;
 *         &lt;/element&gt;
 *       &lt;/sequence&gt;
 *     &lt;/restriction&gt;
 *   &lt;/complexContent&gt;
 * &lt;/complexType&gt;
 * </pre>
 * 
 * 
 */
@XmlAccessorType(XmlAccessType.FIELD)
@XmlType(name = "DT_ARCHIV_ICBCRECEIPT_REQ", propOrder = {
    "item"
})
public class DTARCHIVICBCRECEIPTREQ {

    @XmlElement(name = "ITEM")
    protected List<ITEM> item;

    /**
     * Gets the value of the item property.
     * 
     * <p>
     * This accessor method returns a reference to the live list,
     * not a snapshot. Therefore any modification you make to the
     * returned list will be present inside the JAXB object.
     * This is why there is not a <CODE>set</CODE> method for the item property.
     * 
     * <p>
     * For example, to add a new item, do as follows:
     * <pre>
     *    getITEM().add(newItem);
     * </pre>
     * 
     * 
     * <p>
     * Objects of the following type(s) are allowed in the list
     * {@link ITEM }
     * 
     * 
     */
    public List<ITEM> getITEM() {
        if (item == null) {
            item = new ArrayList<ITEM>();
        }
        return this.item;
    }


    /**
     * <p>anonymous complex type的 Java 类。
     * 
     * <p>以下模式片段指定包含在此类中的预期内容。
     * 
     * <pre>
     * &lt;complexType&gt;
     *   &lt;complexContent&gt;
     *     &lt;restriction base="{http://www.w3.org/2001/XMLSchema}anyType"&gt;
     *       &lt;sequence&gt;
     *         &lt;element name="BANKN" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="TRAN_DATE" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="SER_NO" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="DOC_TYP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="ARC_DOC_ID" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *         &lt;element name="ACT_TYP" type="{http://www.w3.org/2001/XMLSchema}string" minOccurs="0"/&gt;
     *       &lt;/sequence&gt;
     *     &lt;/restriction&gt;
     *   &lt;/complexContent&gt;
     * &lt;/complexType&gt;
     * </pre>
     * 
     * 
     */
    @XmlAccessorType(XmlAccessType.FIELD)
    @XmlType(name = "", propOrder = {
        "bankn",
        "trandate",
        "serno",
        "doctyp",
        "arcdocid",
        "acttyp"
    })
    public static class ITEM {

        @XmlElement(name = "BANKN")
        protected String bankn;
        @XmlElement(name = "TRAN_DATE")
        protected String trandate;
        @XmlElement(name = "SER_NO")
        protected String serno;
        @XmlElement(name = "DOC_TYP")
        protected String doctyp;
        @XmlElement(name = "ARC_DOC_ID")
        protected String arcdocid;
        @XmlElement(name = "ACT_TYP")
        protected String acttyp;

        /**
         * 获取bankn属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getBANKN() {
            return bankn;
        }

        /**
         * 设置bankn属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setBANKN(String value) {
            this.bankn = value;
        }

        /**
         * 获取trandate属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getTRANDATE() {
            return trandate;
        }

        /**
         * 设置trandate属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setTRANDATE(String value) {
            this.trandate = value;
        }

        /**
         * 获取serno属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getSERNO() {
            return serno;
        }

        /**
         * 设置serno属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setSERNO(String value) {
            this.serno = value;
        }

        /**
         * 获取doctyp属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getDOCTYP() {
            return doctyp;
        }

        /**
         * 设置doctyp属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setDOCTYP(String value) {
            this.doctyp = value;
        }

        /**
         * 获取arcdocid属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getARCDOCID() {
            return arcdocid;
        }

        /**
         * 设置arcdocid属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setARCDOCID(String value) {
            this.arcdocid = value;
        }

        /**
         * 获取acttyp属性的值。
         * 
         * @return
         *     possible object is
         *     {@link String }
         *     
         */
        public String getACTTYP() {
            return acttyp;
        }

        /**
         * 设置acttyp属性的值。
         * 
         * @param value
         *     allowed object is
         *     {@link String }
         *     
         */
        public void setACTTYP(String value) {
            this.acttyp = value;
        }

    }

}
