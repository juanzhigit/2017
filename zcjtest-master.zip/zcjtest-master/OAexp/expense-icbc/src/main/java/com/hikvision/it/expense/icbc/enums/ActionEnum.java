package com.hikvision.it.expense.icbc.enums;

/**
 * 操作enum
 * <p>Title: ActionEnum.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2017年7月6日
 *
 */
public enum ActionEnum {
    /** 新增 */
    INSERT("I"),
    /** 修改 */
    UPDATE("C");
    
    private String key;
    
    private ActionEnum(String key) {
        this.key = key;
    }

    public String getKey() {
        return key;
    }
}
