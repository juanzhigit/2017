package com.hikvision.it.expense.icbc.dao;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import com.hikvision.it.expense.icbc.entity.ICBCPdfFileInfo;

/**
 * 电子回单同步sap记录dao
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/7/11
 * Time: 16:52
 * To change this template use File | Settings | File Templates.
 */
public interface IArchiveDao {
    /**
     * 记录同步日志
     * @param logId
     * @param fileNumber
     */
    void recordSynchInfo(@Param("logId") String logId, @Param("fileNumber") int fileNumber);

    /**
     * 记录同步明细
     * @param logId
     * @param pdfFileInfos
     */
    void recordSynchDetail(@Param("logId") String logId, @Param("pdfFileInfos") List<ICBCPdfFileInfo> pdfFileInfos);
}
