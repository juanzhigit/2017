package com.hikvision.it.expense.icbc.service.ftp;

/**
 * 工行电子回单ftp service服务接口
 */
public interface ICBCFtpService {
    /**
     *
     * @return
     * @throws Exception
     */
    String downloadZIPFileFromFtp() throws Exception;
}
