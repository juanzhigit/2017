package com.hikvision.it.expense.web.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;

import com.hikvision.it.expense.web.util.I18nFactory;

public class BaseController {

    protected Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    protected I18nFactory i18n;

}
