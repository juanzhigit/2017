package com.hikvision.it.expense.web.enums;

public enum FormAction {
    create,
    view,
    edit,
    copy,
    approve
}
