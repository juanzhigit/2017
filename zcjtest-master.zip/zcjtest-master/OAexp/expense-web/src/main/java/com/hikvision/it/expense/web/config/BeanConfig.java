package com.hikvision.it.expense.web.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.hikvision.it.expense.web.util.FtpFactory;
import com.hikvision.it.expense.web.util.I18nFactory;
import com.hikvision.it.expense.web.util.JsonFactory;

@Configuration
public class BeanConfig {

    @Bean
    public I18nFactory i18nFactory() {
        return new I18nFactory();
    }

    @Bean
    public FtpFactory ftpFactory() {
        return new FtpFactory();
    }

    @Bean
    public JsonFactory json() {
        return new JsonFactory();
    }

}
