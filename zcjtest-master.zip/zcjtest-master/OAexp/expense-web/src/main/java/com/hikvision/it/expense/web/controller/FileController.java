package com.hikvision.it.expense.web.controller;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.google.common.io.Files;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.attachment.Attachment;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.attachment.IAttachmentService;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.api.service.pi.IPiService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.web.util.ExcelReadUtil;
import com.hikvision.it.expense.web.util.FtpFactory;
import com.hikvision.it.expense.web.util.I18nFactory;

@Controller
@RequestMapping("/file")
public class FileController {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Reference(version = Version.VERSION_LATEST)
    IAttachmentService attachService;

    @Reference(version = Version.VERSION_LATEST)
    IBaseService baseService;

    @Reference(version = Version.VERSION_LATEST)
    IPiService piService;

    @Autowired
    I18nFactory i18n;

    @Autowired
    FtpFactory ftpFactory;

    @ResponseBody
    @RequestMapping(value = "/attachment/list/{docId}")
    public GridData<Attachment> list(@PathVariable("docId") String docId) {
        List<Attachment> list = attachService.getAttachByDocId(docId);
        return new GridData<>(list.size(), 1, (long) list.size(), list);
    }

    @ResponseBody
    @RequestMapping(value = "/attachment/upload", method = RequestMethod.POST)
    public ResponseEntity<String> upload(@RequestParam("docId") String docId,
                                 @RequestParam MultipartFile file) {
        HikResult<String> result = new HikResult<>();
        if (!file.isEmpty() && !Strings.isNullOrEmpty(docId)) {
            try {
                Attachment attach = fastUpload(file, docId);
                attachService.saveAttach(attach);
            } catch (Exception e) {
                logger.error("upload failed", e);
                result.addError("upload failed");
            }
        }
        return ResponseEntity.ok(JSON.toJSONString(result));
    }

    @ResponseBody
    @RequestMapping(value = "/attachment/delete/{attachmentId}", method = RequestMethod.POST)
    public HikResult<String> delete(@PathVariable("attachmentId") String attachmentId) {
        attachService.deleteAttach(attachmentId);
        return new HikResult<String>();
    }

    @RequestMapping("/attachment/download/{attachmentId}")
    public void download(@PathVariable("attachmentId") String attachmentId, HttpServletResponse response) throws Exception {
        Attachment attach = attachService.getOne(attachmentId);
        if (attach != null) {
            try {
                ftpFactory.download(attach.getRealName(), attach.getFileSize(), response);
            } catch (Exception e) {
                logger.error("download failed:" + attachmentId, e);

                response.setCharacterEncoding("UTF-8");
                response.setContentType("text/html");
                PrintWriter out = response.getWriter();
                out.print(i18n.get(MessageCode.MSG_DOWNLOAD_FAILED, attachmentId));
            }
        }
    }

    private Attachment fastUpload(MultipartFile file, String docId) {
        String id = StringUtil.getUUID();
        String originalFilename = file.getOriginalFilename();
        String extension = Files.getFileExtension(originalFilename);
        String realFileName = id + "." + extension;
        String realName = DateUtil.dateToString6(new Date()) + "/" + docId + "/" + realFileName;
        Attachment attach = new Attachment();
        attach.setId(id);
        attach.setFileType(extension);
        attach.setFileSize(file.getSize());
        attach.setFileName(originalFilename);
        attach.setRealName(realName);
        attach.setDocId(docId);
        InputStream is = null;
        try {
            is = file.getInputStream();
            if (is != null) {
                ftpFactory.upload(realName, is);
            }
        } catch (Exception e) {
            is = null;
            throw new ExpenseException(e);
        } finally {
            if (is != null)
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
        }
        return attach;
    }

    @ResponseBody
    @RequestMapping(value = "/excel/readBirth", method = RequestMethod.POST)
    public ResponseEntity<String> readExcel(@RequestParam("docId") String docId, @RequestParam MultipartFile file) {
        InputStream is = null;
        try {
            is = file.getInputStream();
            String fileName = file.getOriginalFilename();

            ExcelReadUtil<FeeDetail> ofeeExcelRead = this.getBirthExcelReadUtil();
            HikResult<List<FeeDetail>> ofeesRs = ofeeExcelRead.readExcel(is, fileName);
            List<FeeDetail> feeDetails = ofeesRs.getData();
            if (feeDetails == null) {
                feeDetails = Lists.newArrayList();
            }
            for (FeeDetail detail : feeDetails) {
                detail.setFeeFromDate(DateUtil.getCurrentDateString());
                detail.setBigFeeType("660609");
                detail.setBigFeeTypeName("社会保险费");
                detail.setCurrency("CNY");
                detail.setSmaFeeType("66060905");
                detail.setSmaFeeTypeName("生育保险费");
                detail.setExchangeRate(BigDecimal.ONE);
                detail.setId(StringUtil.getUUID());
                if (Strings.isNullOrEmpty(detail.getApprovedDate())) {
                    detail.setApprovedDate(detail.getFeeFromDate());
                }
            }
            return ResponseEntity.ok(JSONObject.toJSONString(feeDetails));
        } catch (IOException e) {
            logger.error("read excel error", e);
            throw new ExpenseException("Excel读取异常");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 收款人excel读取
     */
    @ResponseBody
    @RequestMapping(value = "/excel/readSkr", method = RequestMethod.POST)
    public ResponseEntity<String> readExcelSkr(@RequestParam MultipartFile file) {
        InputStream is = null;
        try {
            is = file.getInputStream();
            String fileName = file.getOriginalFilename();
            HikResult<List<OtherReceivor>> result = this.getSkrExcelReadUtil().readExcel(is, fileName);
            return ResponseEntity.ok(JSONObject.toJSONString(result.getData()));
        } catch (IOException e) {
            logger.error("read excel error", e);
            throw new ExpenseException("Excel读取异常");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 市内交通excel读取
     */
    @ResponseBody
    @RequestMapping(value = "/excel/readSnjt", method = RequestMethod.POST)
    public ResponseEntity<String> readExcelSnjt(@RequestParam MultipartFile file) {
        InputStream is = null;
        try {
            is = file.getInputStream();
            String fileName = file.getOriginalFilename();
            HikResult<List<FeeDetail>> result = this.getSnjtExcelReadUtil().readExcel(is, fileName);
            return ResponseEntity.ok(JSONObject.toJSONString(result.getData()));
        } catch (IOException e) {
            logger.error("read excel error", e);
            throw new ExpenseException("Excel读取异常");
        } finally {
            if (is != null) {
                try {
                    is.close();
                } catch (IOException e) {
                    e.printStackTrace();
                }
            }
        }
    }

    /**
     * 获取excel读取bean
     */
    private ExcelReadUtil<FeeDetail> getBirthExcelReadUtil() {
        return new ExcelReadUtil<FeeDetail>() {
            @Override
            public FeeDetail readRow(Row row) throws Exception {
                int rowNumber = row.getRowNum() + 1;
                FeeDetail detail = new FeeDetail();
                //读取人员姓名
                Cell cell = row.getCell(0);
                detail.setUserName(getCellStringValue(cell, rowNumber));
                //读取员工编号
                cell = row.getCell(1);
                detail.setUserId(getCellStringValue(cell, rowNumber));
                //读取所在部门
                cell = row.getCell(2);
                detail.setDeptCode(getCellStringValue(cell, rowNumber));
                //读取部门路径
                String deptName = baseService.getDeptName(detail.getDeptCode());
                if (StringUtil.isNotEmptyTrim(deptName)) {
                    detail.setDeptName(deptName);
                } else {
                    detail.setDeptCode(null);
                }
                //读取所在公司
                cell = row.getCell(3);
                detail.setBukrs(getCellStringValue(cell, rowNumber));
                //读取公司名称
                String bukrsName = baseService.getBukrsName(detail.getBukrs());
                if (StringUtil.isNotEmptyTrim(bukrsName)) {
                    detail.setBukrsName(bukrsName);
                } else {
                    detail.setBukrs(null);
                }
                //读取核定日期
                cell = row.getCell(4);
                detail.setApprovedDate(getCellStringValue(cell, rowNumber));
                //读取社保冲抵
                cell = row.getCell(5);
                detail.setSocialOffsetAmount(new BigDecimal(getCellStringValue(cell, rowNumber)));
                //读取核定报销金额
                cell = row.getCell(6);
                detail.setLocalAmount(new BigDecimal(getCellStringValue(cell, rowNumber)));
                //设置费用日期
                detail.setFeeFromDate(DateUtil.getCurrentDateString());

                return detail;
            }
        };
    }

    /**
     * 获取收款人excel读取bean
     */
    private ExcelReadUtil<OtherReceivor> getSkrExcelReadUtil() {
        return new ExcelReadUtil<OtherReceivor>() {
            @Override
            public OtherReceivor readRow(Row row) throws Exception {
                int cellIdx = 0;
                OtherReceivor detail = new OtherReceivor();
                //读取人员姓名
                Cell cell = row.getCell(cellIdx++);
                detail.setUserId(cell.getStringCellValue());
                cell = row.getCell(cellIdx++);
                if (cell != null) {
                    detail.setUserName(cell.getStringCellValue());
                }
                cell = row.getCell(cellIdx++);
                detail.setAmount(BigDecimal.valueOf(cell.getNumericCellValue()));
                return detail;
            }
        };
    }

    /**
     * 获取市内交通excel读取bean
     */
    private ExcelReadUtil<FeeDetail> getSnjtExcelReadUtil() {
        return new ExcelReadUtil<FeeDetail>() {
            @Override
            public FeeDetail readRow(Row row) throws Exception {
                int cellIdx = 0;
                FeeDetail detail = new FeeDetail();
                detail.setId(StringUtil.getUUID());
                //读取人员姓名
                Cell cell = row.getCell(cellIdx++);
                detail.setFeeFromDate(DateUtil.dateToString(cell.getDateCellValue())); // 日期
                cell = row.getCell(cellIdx++);
                detail.setRemark(cell.getStringCellValue()); // 备注
                cell = row.getCell(cellIdx++);
                detail.setTrafficToolDesc(cell.getStringCellValue()); // 交通工具描述
                cell = row.getCell(cellIdx++);
                detail.setCurrencyDesc(cell.getStringCellValue()); // 货币名称
                cell = row.getCell(cellIdx++);
                detail.setAmount(BigDecimal.valueOf(cell.getNumericCellValue())); // 金额
                cell = row.getCell(cellIdx++);
                detail.setTrafficTool(cell.getStringCellValue()); // 交通工具代码
                cell = row.getCell(cellIdx++);
                detail.setCurrency(cell.getStringCellValue()); // 货币代码
                return detail;
            }
        };
    }


}
