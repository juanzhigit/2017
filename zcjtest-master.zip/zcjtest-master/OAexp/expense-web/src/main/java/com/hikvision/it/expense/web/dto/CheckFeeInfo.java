package com.hikvision.it.expense.web.dto;

import java.util.Date;

import org.springframework.format.annotation.DateTimeFormat;

import com.hikvision.it.expense.api.entity.fee.FeeDetail;

public class CheckFeeInfo {

    private String expensor;
    private String bukrs;
    @DateTimeFormat(pattern="yyyy-MM-dd")
    private Date submittedOn;

    private FeeDetail detail;

    public String getExpensor() {
        return expensor;
    }

    public void setExpensor(String expensor) {
        this.expensor = expensor;
    }

    public String getBukrs() {
        return bukrs;
    }

    public void setBukrs(String bukrs) {
        this.bukrs = bukrs;
    }

    public Date getSubmittedOn() {
        return submittedOn;
    }

    public void setSubmittedOn(Date submittedOn) {
        this.submittedOn = submittedOn;
    }

    public FeeDetail getDetail() {
        return detail;
    }

    public void setDetail(FeeDetail detail) {
        this.detail = detail;
    }
}
