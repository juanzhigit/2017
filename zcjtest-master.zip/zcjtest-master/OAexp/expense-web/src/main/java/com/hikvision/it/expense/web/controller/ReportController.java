package com.hikvision.it.expense.web.controller;


import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.document.DocumentInfo;
import com.hikvision.it.expense.api.entity.form.QueryForm;
import com.hikvision.it.expense.api.entity.report.ForeignCurrencyLoanDetail;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.service.report.ILoanService;
import com.hikvision.it.expense.api.service.report.IReportService;

@Controller
@RequestMapping("/report")
public class ReportController {


    @Reference(version = Version.VERSION_LATEST)
    IReportService reportService;

    @Reference(version = Version.VERSION_LATEST)
    ILoanService loanService;


    @RequestMapping(value = "/draft", method = RequestMethod.POST)
    ResponseEntity<GridData<DocumentInfo>> draft(
            HttpSession session,
            QueryForm form,
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "rows") int rows,
            @RequestParam(value = "sidx", required = false, defaultValue = "1") String sidx,
            @RequestParam(value = "sord", required = false, defaultValue = "asc") String sord) {
        LoginUser user = UserContext.get();
        GridData<DocumentInfo> gridData = reportService.listDraftDoc(form, user.getUserId(), sidx,
                sord, page, rows);
        return ResponseEntity.ok(gridData);
    }

    @RequestMapping(value = "/apply", method = RequestMethod.POST)
    ResponseEntity<GridData<DocumentInfo>> apply(
            HttpSession session,
            QueryForm form,
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "rows") int rows,
            @RequestParam(value = "sidx", required = false, defaultValue = "1") String sidx,
            @RequestParam(value = "sord", required = false, defaultValue = "asc") String sord) {
        LoginUser user = UserContext.get();
        GridData<DocumentInfo> gridData = reportService.listApplyDoc(form, user.getUserId(), sidx,
                sord, page, rows);
        return ResponseEntity.ok(gridData);
    }

    /**
     * 我的申请单
     *
     * @return
     */
    @RequestMapping(value = "/private/expense", method = RequestMethod.POST)
    ResponseEntity<GridData<DocumentInfo>> privateExpense(
            HttpSession session,
            QueryForm form,
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "rows") int rows,
            @RequestParam(value = "sidx", required = false, defaultValue = "1") String sidx,
            @RequestParam(value = "sord", required = false, defaultValue = "asc") String sord) {
        LoginUser user = UserContext.get();
        GridData<DocumentInfo> gridData = reportService.listPrivateExpenseDoc(form,
                user.getUserId(), sidx, sord, page, rows);
        return ResponseEntity.ok(gridData);
    }


    @RequestMapping(value = "/jhk", method = RequestMethod.POST)
    ResponseEntity<GridData<DocumentInfo>> jhk(
            HttpSession session,
            QueryForm form,
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "rows") int rows,
            @RequestParam(value = "sidx", required = false, defaultValue = "1") String sidx,
            @RequestParam(value = "sord", required = false, defaultValue = "asc") String sord) {
        LoginUser user = UserContext.get();
        GridData<DocumentInfo> gridData = reportService.listLoanAndRepayDoc(form, user.getUserId(),
                sidx, sord, page, rows);
        return ResponseEntity.ok(gridData);
    }

    @RequestMapping(value = "/public/expense", method = RequestMethod.POST)
    ResponseEntity<GridData<DocumentInfo>> publicExpense(
            HttpSession session,
            QueryForm form,
            @RequestParam(value = "page", defaultValue = "1") int page,
            @RequestParam(value = "rows") int rows,
            @RequestParam(value = "sidx", required = false, defaultValue = "1") String sidx,
            @RequestParam(value = "sord", required = false, defaultValue = "asc") String sord) {
        LoginUser user = UserContext.get();
        GridData<DocumentInfo> gridData = reportService.listPublicExpenseDoc(form, user.getUserId(),
                sidx, sord, page, rows);
        return ResponseEntity.ok(gridData);
    }

    @ResponseBody
    @RequestMapping(value = "/foreignCurrencyLoans", method = RequestMethod.POST)
    public List<ForeignCurrencyLoanDetail> listForeignCurrencyLoans() {
        return loanService.listForeignCurrencyLoans();
    }


}
