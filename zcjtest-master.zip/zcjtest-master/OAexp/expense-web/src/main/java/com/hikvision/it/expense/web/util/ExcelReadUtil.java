package com.hikvision.it.expense.web.util;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.common.utils.StringUtil;

/**
 * Excel读取抽象接口类
 * <p>Title: ExcelUtil.java</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2015</p>
 * <p>Company: hikvision</p>
 * @author wuliangxxh1
 * @date 2016年4月19日
 *
 * @param <T>
 */
public abstract class ExcelReadUtil<T> {
	private final static int VERSION2003 = 2003;  
    private final static int VERSION2007 = 2007;  

    private Logger logger = LoggerFactory.getLogger(getClass());

	/**
	 * 读取输入流，解析Excel文件
	 * @param is
	 * @return
	 */
	public HikResult<List<T>> readExcel(InputStream is, String fileName) {
		HikResult<List<T>> rs = new HikResult<List<T>>();
		
		try {
			//默认设置空数据
			rs.setData(new ArrayList<T>());
			//判断Excel版本
			switch (this.analizeExcelVersion(fileName)) {
				case VERSION2003:
					read2003(is, rs);
					break;
				case VERSION2007:
					read2007(is, rs);
					break;
				default:
					break;
			}
		} catch (Exception e) {
			logger.error("read excel error", e);
			throw new ExpenseException("读取Excel失败，当前文件已加密或者存在域控，" + e.getMessage());
		}

		return rs;
	}
	
	/**
	 * 读取xls
	 * @param is
	 * @param rs
	 */
	private void read2003(InputStream is, HikResult<List<T>> rs) throws Exception {
		HSSFWorkbook book = null;
		try {
			// 得到工作表
			book = new HSSFWorkbook(is);
			//获取第一个工作表
	        Sheet sheet = book.getSheetAt(0);
	        //读取第一个工作表
	        this.readSheet(sheet, rs);
		} finally {
			if (book != null)
				try {
					book.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	/**
	 * 读取xlsx
	 * @param is
	 * @param rs
	 */
	private void read2007(InputStream is, HikResult<List<T>> rs) throws Exception {
		XSSFWorkbook book = null;
		try {
			// 得到工作表
			book = new XSSFWorkbook(is);
			//获取第一个工作表
	        Sheet sheet = book.getSheetAt(0);
	        //读取第一个工作表
	        this.readSheet(sheet, rs);
		} finally {
			if (book != null)
				try {
					book.close();
				} catch (IOException e) {
					e.printStackTrace();
				}
		}
	}
	
	//此方法判别Excel2003和Excel2007  
    private int analizeExcelVersion(String fileName) {  
        if (fileName != null) {  
            if (fileName.endsWith(".xls")) {
            	return VERSION2003;
            } else {
            	return VERSION2007;
            }
        } 
        
        return 0;
    }  
	
	/**
	 * 通用读取Sheet方法
	 * @param sheet
	 * @param rs
	 */
	private void readSheet(Sheet sheet, HikResult<List<T>> rs) throws Exception {
		//计算连续空行数目，如果联系空行出现5行以上，则退出读取，标识已经读到最后一行
		int emptyRowNumber = 0;
		List<T> datas = rs.getData();
		for (Iterator<Row> rowIt = sheet.iterator(); rowIt.hasNext();) {
			Row row = rowIt.next();
			if (row.getRowNum() != 0) {
				if (!this.checkIsEmptyRow(row)) {
					emptyRowNumber = 0;
					//将读取回来的信息添加到结果集中
					//datas.add(this.readRow(row));
					T t = this.readRow(row);
					if (t != null) {
						datas.add(t);
					}
				} else {
					emptyRowNumber++;
				}
				if (emptyRowNumber >= 5) {
					break;
				}
			}
		}
	}
	
	/**
	 * 校验是否空行
	 * @param row
	 * @return
	 */
	private boolean checkIsEmptyRow(Row row) {
		int emptyCellNumber = 0;
		for (Iterator<Cell> cellIt = row.cellIterator(); cellIt.hasNext();) {
			Cell cell = cellIt.next();
			
			if (cell != null) {
				//if (StringUtil.isEmptyTrim(cell.getStringCellValue())) {
				if (cell.getCellType() == Cell.CELL_TYPE_BLANK) {
					emptyCellNumber++;
				} else {
					emptyCellNumber = 0;
				}
			} else {
				emptyCellNumber++;
			}
			
			if (emptyCellNumber >= 5) {
				return true;
			}
		}
		
		return false;
	}
	
	/**
	 * 获取cell的值
	 * @param cell
	 * @return
	 */
	public String getCellStringValue(Cell cell, int rowNumber) throws Exception {
		String value = null;
		
		if (cell != null)
			value = cell.getStringCellValue();

		if (StringUtil.isNotEmptyTrim(value))
			return value;
		else
			throw new Exception("第" + rowNumber + "行，缺少必填的数据，请先补充完整数据！");
	}
	
	/**
	 * 读取每一行数据需根据实际情况实现
	 * @param row
	 * @return
	 */
	public abstract T readRow(Row row) throws Exception;
}
