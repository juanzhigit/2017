package com.hikvision.it.expense.web.dto;

import java.util.List;

import com.hikvision.it.expense.api.entity.task.TaskReceivor;
import com.hikvision.it.expense.api.enums.ResultEnum;

public class ApproveInfo {

    private String taskId;
    private ResultEnum result;
    private String suggest;
    private List<TaskReceivor> receivers;

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    public ResultEnum getResult() {
        return result;
    }

    public void setResult(ResultEnum result) {
        this.result = result;
    }

    public String getSuggest() {
        return suggest;
    }

    public void setSuggest(String suggest) {
        this.suggest = suggest;
    }

    public List<TaskReceivor> getReceivers() {
        return receivers;
    }

    public void setReceivers(List<TaskReceivor> receivers) {
        this.receivers = receivers;
    }
}
