package com.hikvision.it.expense.web.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.base.Strings;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.batch.PayDetail;
import com.hikvision.it.expense.api.entity.batch.PayFilter;
import com.hikvision.it.expense.api.entity.batch.PayHead;
import com.hikvision.it.expense.api.entity.batch.PayInfo;
import com.hikvision.it.expense.api.entity.batch.PayParams;
import com.hikvision.it.expense.api.service.batch.IBatchService;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.DateUtil;
import com.hikvision.it.expense.common.utils.PagesPOIExport;
import com.hikvision.it.expense.common.utils.PagesPOIExport.IEntityExport;
import com.hikvision.it.expense.common.utils.ResponseUtil;

/*
 * batch: 批量
 */
@Controller
@RequestMapping("/batch")
public class BatchController extends BaseController {
	@Reference(version = Version.VERSION_LATEST)
	private IBatchService batchService;
	@Reference(version = Version.VERSION_LATEST)
	private IVoucherService voucherService;

	/**
	 * 出纳付款页面
	 * 
	 */
	@RequestMapping("/payment")
	public String batchPayment(HttpServletRequest request) {
		return "batch/payment";
	}

	/**
	 * 获取付款信息
	 * 
	 */
	@ResponseBody
	@RequestMapping(value = "/pays", produces = MediaType.APPLICATION_JSON_VALUE)
	public HikResult<Map<String, Object>> getPays(@RequestBody PayFilter filter) {
		HikResult<Map<String, Object>> result = new HikResult<Map<String, Object>>();
		Map<String, Object> map = new HashMap<String, Object>();
		List<String> currencys = new ArrayList<String>();
		List<PayInfo> pays = batchService.getPayInfos(UserContext.getUserId(), UserContext.getLanguage(), filter);
		for (PayInfo pay : pays) {
			List<PayDetail> details = pay.getDetails();
			for (PayDetail detail : details) {
				String currency = detail.getCurrency();
				if (!currencys.contains(currency)) {
					currencys.add(currency);
				}
			}
		}
		// 排序
		Collections.sort(currencys);
		map.put("gridData", pays);
		map.put("currencyData", currencys);
		result.setData(map);
		return result;
	}

	/**
	 * 付款确认
	 * 
	 */
	@ResponseBody
	@RequestMapping("/paySure")
	public HikResult<String> paySure(@RequestBody PayParams params) {
		List<PayHead> heads = getSelectedHeads(params.getHeads(), params.getSelects());
		HikResult<String> result = new HikResult<String>();
		try {
			result = voucherService.paySure(heads);
			result.setData("付款已确认！");
		} catch (Exception e) {
			result.getErrorMsgs().add(e.getMessage());
		}
		return result;
	}

	/**
	 * 导出表格
	 * 
	 */
	@RequestMapping(value = "export", produces = MediaType.APPLICATION_JSON_VALUE, method = RequestMethod.POST)
	@ResponseBody
	HikResult<String> exportPayInfo(@RequestBody List<PayInfo> pays, HttpSession session) {

		List<PayDetail> details = new ArrayList<PayDetail>();
		for (PayInfo pay : pays) {
			List<PayDetail> tmps = pay.getDetails();
			for (PayDetail tmp : tmps) {
				tmp.setApUserName(pay.getApUserName());
				tmp.setProcessName(pay.getProcessName());
				tmp.setApplyId(pay.getApplyId());
				tmp.setExpensorName(pay.getExpensorName());
				tmp.setBukrsName(pay.getBukrsName());
			}
			details.addAll(tmps);
		}
		HikResult<String> rs = new HikResult<String>();
		try {
			String export_path = "c:/export";
			PagesPOIExport<PayDetail> export = new PagesPOIExport<PayDetail>(export_path,
					UserContext.get().getNotesId()) {
			};
			String[] headers = new String[] { "付款状态", "财务会计", "流程类型", "单据号", "报销人", "付款公司", "凭证编号", "会计年度", "过账日期",
					"币别", "金额" };
			IEntityExport<PayDetail> exportExecute = new IEntityExport<PayDetail>() {
				@Override
				public void entityExport(Sheet sh, PayDetail data, int rowNum) {
					Row row = sh.createRow(rowNum);
					Cell cell = row.createCell(0);
					cell.setCellValue(Strings.nullToEmpty(data.getStatus()));// 付款状态
					cell = row.createCell(1);
					cell.setCellValue(Strings.nullToEmpty(data.getApUserName()));// 财务会计
					cell = row.createCell(2);
					cell.setCellValue(Strings.nullToEmpty(data.getProcessName()));// 流程类型
					cell = row.createCell(3);
					cell.setCellValue(Strings.nullToEmpty(data.getApplyId()));// 单据号
					cell = row.createCell(4);
					cell.setCellValue(Strings.nullToEmpty(data.getExpensorName()));// 报销人
					cell = row.createCell(5);
					cell.setCellValue(Strings.nullToEmpty(data.getBukrsName()));// 付款公司
					cell = row.createCell(6);
					cell.setCellValue(Strings.nullToEmpty(data.getBelnr()));// 凭证编号
					cell = row.createCell(7);
					cell.setCellValue(Strings.nullToEmpty(data.getGjahr()));// 会计年度
					cell = row.createCell(8);
					java.util.Date postDate = data.getPostDate();
					if (postDate != null) {
						cell.setCellValue(DateUtil.dateToString(postDate, "yyyy/MM/dd"));// 过账日期
					}
					cell = row.createCell(9);
					cell.setCellValue(Strings.nullToEmpty(data.getCurrency()));// 币别
					cell = row.createCell(10);
					cell.setCellValue(data.getAmount() == null ? 0 : data.getAmount().doubleValue());
				}
			};
			String path = export.exportData(details, exportExecute, headers);
			rs.setData(path);
		} catch (Exception e) {
			e.printStackTrace();
			rs.addError(e.getMessage());
		}
		return rs;
	}

	/**
	 * 文件下载
	 * 
	 */
	@RequestMapping("/file")
	ResponseEntity<String> downloadByPath(HttpServletRequest request,
			@RequestParam(value = "path", required = false) String path, HttpServletResponse response,
			HttpSession session) {

		String userName = UserContext.getUserName();

		try {
			ResponseUtil.outputStream(response, path, userName);
		} catch (IOException e) {
			e.printStackTrace();
		}

		return ResponseEntity.ok("");
	}

	// 获取相同顺序的列表
	private List<PayHead> getSelectedHeads(List<PayHead> heads, List<String> selects) {
		List<PayHead> selectedHeads = new ArrayList<PayHead>();
		for (PayHead head : heads) {
			if (selects.contains(head.getDocId())) {
				selectedHeads.add(head);
			}
		}
		return selectedHeads;
	}

}