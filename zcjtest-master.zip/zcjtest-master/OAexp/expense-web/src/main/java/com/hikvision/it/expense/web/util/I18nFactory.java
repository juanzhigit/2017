package com.hikvision.it.expense.web.util;

import java.util.Locale;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.MessageSource;
import org.springframework.context.NoSuchMessageException;
import org.springframework.stereotype.Component;

import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.enums.MessageCode;

/**
 * 国际化支持
 */
@Component
public class I18nFactory {

    private Logger logger = LoggerFactory.getLogger(I18nFactory.class);

    @Autowired
    private MessageSource messageSource;

    /**
     * 获取国际化信息
     * @return 返回国际化消息, 没有时返回code和args拼接的字符串
     */
    public final String get(MessageCode code, Object ... args) {
        return get(code.name(), args);
    }

    /**
     * 获取国际化信息
     * @return 返回国际化消息, 没有时返回code和args拼接的字符串
     */
    public final String get(String code, Object ... args) {
        String lang = UserContext.getLanguage();
        Locale locale = "en".equalsIgnoreCase(lang) ? Locale.ENGLISH : Locale.CHINESE;
        try {
            return messageSource.getMessage(code, args, locale);
        } catch (NoSuchMessageException e) {
            logger.error("invalid message code {}, not found", code);
            StringBuilder sb = new StringBuilder(code);
            if (args != null) {
                for (Object arg : args) {
                    sb.append(" ,").append(arg);
                }
            }
            return sb.toString();
        }
    }

    public String get(String code) {
        return get(code, "");
    }

}
