package com.hikvision.it.expense.web.spring;

import java.io.IOException;
import java.util.Enumeration;
import java.util.Properties;

import org.springframework.boot.env.PropertySourceLoader;
import org.springframework.core.PriorityOrdered;
import org.springframework.core.env.PropertiesPropertySource;
import org.springframework.core.env.PropertySource;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PropertiesLoaderUtils;
import org.springframework.util.Base64Utils;

/**
 * 加密资源文件加载器
 */
public class SecurityPropertiesPropertySourceLoader implements PropertySourceLoader, PriorityOrdered {
    @Override
    public String[] getFileExtensions() {
        return new String[]{"properties"};
    }

    @Override
    public PropertySource<?> load(String name, Resource resource, String profile) throws IOException {
        if (profile == null) {
            Properties properties = PropertiesLoaderUtils.loadProperties(resource);
            Properties securityProperties = new Properties();
            Enumeration<?> enumeration = properties.propertyNames();
            while (enumeration.hasMoreElements()) {
                String key = (String) enumeration.nextElement();
                String value = properties.getProperty(key, "");
                if (value.startsWith("DECODE(") && value.endsWith(")")) {
                    value = new String(Base64Utils.decodeFromString(value.substring(7, value.length() - 1)));
                }
                securityProperties.put(key, value);
            }
            if (!properties.isEmpty()) {
                return new PropertiesPropertySource(name, securityProperties);
            }
        }
        return null;
    }

    @Override
    public int getOrder() {
        return HIGHEST_PRECEDENCE;
    }

}
