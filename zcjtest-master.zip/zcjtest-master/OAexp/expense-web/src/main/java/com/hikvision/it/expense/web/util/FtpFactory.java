package com.hikvision.it.expense.web.util;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.InputStream;

import javax.servlet.http.HttpServletResponse;

import org.apache.commons.net.ftp.FTPClient;
import org.apache.commons.net.ftp.FTPFile;
import org.apache.commons.net.ftp.FTPReply;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;

import com.hikvision.it.expense.api.exception.ExpenseException;

public class FtpFactory {

    @SuppressWarnings("unused")
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Value("${ftp.host}")
    private String host;
    @Value("${ftp.username}")
    private String user;
    @Value("${ftp.password}")
    private String password;
    @Value("${ftp.port}")
    private int port;

//    private final ImmutableList forbiddenTypes = ImmutableList.of(".exe", ".msi", ".bat", ".jsp", ".js");

    /**
     * 上传文件
     */
    public void upload(String filename, InputStream is) throws Exception {
        FTPClient client = getClient();
        try {
            String ftpFileName = changeFtpPath(client, filename);
            client.storeFile(ftpFileName, is);
            boolean exist = false;
            for (String fileName: client.listNames()) {
                if (ftpFileName.contains(fileName)) {
                    exist = true;
                }
            }
            if (!exist) {
                throw new Exception("upload failed");
            }

        } finally {
            close(client);
        }
    }

    public void download(String fileName, Long fileSize, HttpServletResponse response) throws Exception {
        FTPClient client = null;
        try {
            client = getClient();
            String ftpFileName = changeFtpPath(client, fileName);
            FTPFile[] ftpFiles = client.listFiles(ftpFileName);
            int length = ftpFiles.length;

            if (length == 1) {
                InputStream inputStream = client.retrieveFileStream(ftpFileName);
                BufferedInputStream bis = null;
                BufferedOutputStream bos = null;
                try {
                    String downLoadName = new String(fileName.getBytes("GBK"), "iso-8859-1");
                    // 设置相应头
                    response.setCharacterEncoding("UTF-8");
                    response.setContentType("application/octet-stream;");
                    response.addHeader("Content-Disposition", "attachment;fileName=" + downLoadName);
                    if (fileSize != null)
                        response.addHeader("Content-Length", fileSize.toString());
                    bis = new BufferedInputStream(inputStream);
                    bos = new BufferedOutputStream(response.getOutputStream());
                    byte[] buff = new byte[2048];
                    int bytesRead;
                    while (-1 != (bytesRead = bis.read(buff, 0, buff.length))) {
                        bos.write(buff, 0, bytesRead);
                    }
                } finally {
                    if (bos != null) {
                        bos.flush();
                        bos.close();
                    }
                    if (bis != null) {
                        bis.close();
                    }
                    if (inputStream != null) {
                        inputStream.close();
                    }
                }
            } else if (length == 0) {
                throw new Exception("No file found!");
            } else {
                throw new Exception("Result returns more than one elements!");
            }
        } finally {
            close(client);
        }
    }

    private void close(FTPClient client) throws Exception {
        if (client != null && client.isConnected()) {
            client.disconnect();
        }
    }

    /**
     * 更改ftp工作路径并且返回文件名
     */
    private String changeFtpPath(FTPClient ftp, String filePath) throws Exception {
        String ftpFileName = null;
        String paths[] = filePath.split("/");
        int i = 0;
        for (String path : paths) {
            if ((i + 1) == paths.length) {
                ftpFileName = path;
            } else {
                changeFTPWorkingDir(ftp, path);
            }
            i++;
        }
        return ftpFileName;
    }


    /**
     * 变更FTP服务器工作目录
     */
    private void changeFTPWorkingDir(FTPClient ftp, String workingDir) throws Exception {
        // 变更工作目录
        boolean cwd = ftp.changeWorkingDirectory(workingDir);
        if (!cwd) {
            ftp.makeDirectory(workingDir);
            cwd = ftp.changeWorkingDirectory(workingDir);
        }

        /**
         * 变更工作目录，如果变更失败则创建工作目录，然后再变更工作目录
         *
         * 如果不成功，抛出异常
         */
        if (!cwd) {
            throw new ExpenseException("Failed to create directory!");
        }
    }

    private FTPClient getClient() throws Exception {
        FTPClient ftp = new FTPClient();
        // 连接FTP服务器
        // 如果采用默认端口，可以使用ftp.connect(url)的方式直接连接FTP服务器
        ftp.connect(host, port);
        ftp.setControlEncoding("UTF-8");
        // 登录
        boolean login = ftp.login(user, password);
        ftp.setFileType(FTPClient.BINARY_FILE_TYPE);
        if (!login) {
            throw new Exception("FTP Login error, please contact the administrator!");
        }
        int reply = ftp.getReplyCode();
        // FTP服务器连接成功
        if (!FTPReply.isPositiveCompletion(reply)) {
            ftp.disconnect();
        }

        return ftp;
    }
}
