package com.hikvision.it.expense.web.controller.api;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.Objects;

import org.springframework.beans.BeanUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.base.Strings;
import com.google.common.collect.LinkedHashMultimap;
import com.google.common.collect.Lists;
import com.google.common.collect.Multimap;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.allowance.HolidayWork;
import com.hikvision.it.expense.api.entity.base.Bsik;
import com.hikvision.it.expense.api.entity.base.BsikInfo;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.base.SelectOpt;
import com.hikvision.it.expense.api.entity.base.SelectOptRs;
import com.hikvision.it.expense.api.entity.base.TripCity;
import com.hikvision.it.expense.api.entity.bukrs.Bukrs;
import com.hikvision.it.expense.api.entity.dsdf.OtherReceivor;
import com.hikvision.it.expense.api.entity.fee.ExpensedTrafficFee;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.oa.SqpgDoc;
import com.hikvision.it.expense.api.entity.trip.TripDays;
import com.hikvision.it.expense.api.entity.user.SearchUser;
import com.hikvision.it.expense.api.entity.user.UserBank;
import com.hikvision.it.expense.api.entity.voucher.OnlineBsikSummary;
import com.hikvision.it.expense.api.enums.BehaviorEnum;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.api.service.behavior.IBehaviorService;
import com.hikvision.it.expense.api.service.fee.IFeeService;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.pi.IPiService;
import com.hikvision.it.expense.api.service.user.IUserService;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.web.controller.BaseController;
import com.hikvision.it.expense.web.dto.CheckFeeInfo;

@RestController
@RequestMapping("/api")
public class CommonController extends BaseController {
	@Reference(version = Version.VERSION_LATEST)
	IVoucherService voucherService;

    @Reference(version = Version.VERSION_LATEST)
    IBaseService baseService;

    @Reference(version = Version.VERSION_LATEST)
    IBehaviorService behaviorService;

    @Reference(version = Version.VERSION_LATEST)
    IUserService userService;

    @Reference(version = Version.VERSION_LATEST)
    IPiService piService;

    @Reference(version = Version.VERSION_LATEST)
    IFeeService feeService;

    @Reference(version = Version.VERSION_LATEST)
    IFormService formService;

    @RequestMapping("/tripTool")
    public List<SelectOpt> tripTools() {
        return baseService.findTipTool();
    }

    @RequestMapping("/authUser")
    public List<SelectOpt> authUser(String docType) {
        return userService.findAuthUser(docType);
    }

    /**
     * 获取城市列表, 返回格式
     * {
     * "DOMESTIC": [],
     * "INTERNATIONAL": []
     * }
     *
     * @param type   查询类型: hot-热门;recent-最近
     * @param filter
     */
    @RequestMapping("/city")
    public Map<String, Collection<TripCity>> city(String type, String filter) {

        List<TripCity> cities;
        if ("recent".equals(type)) {
            cities = behaviorService.findCommonUsedCity();
        } else if ("search".equals(type)) {
            cities = baseService.findTripCity(filter);
        } else {
            cities = Lists.newArrayList();
        }

        Multimap<String, TripCity> map = LinkedHashMultimap.create();
        for (TripCity hotCity : cities) {
            map.put(hotCity.getCountryName(), hotCity);
        }
        return map.asMap();
    }
    
    @RequestMapping("/record/city")
    public void recordSelectCity(TripDays tripDays) {
    	try {
    		behaviorService.recordSelectTripCity(tripDays);
		} catch (Exception e) {
		}
    }

    /**
     * PS项目
     */
    @RequestMapping("/wbs")
    public SelectOptRs wbs(String type, String bukrs, String filter) {
        SelectOptRs rs = new SelectOptRs();

        rs.setGroup(false);

        if ("recent".equals(type)) {
            rs.setData(behaviorService.findCommonUsedOpt(BehaviorEnum.PS));
        } else if ("search".equals(type)) {
            rs.setData(piService.getWBSFromSap(bukrs, filter));
        }


        return rs;
    }

    /**
     * 科目选择
     * @param type
     * @param filter
     * @return
     */
    @RequestMapping("/glAccount")
    public SelectOptRs glAccount(String type, String filter) {
        SelectOptRs rs = new SelectOptRs();

        rs.setGroup(false);

        if ("recent".equals(type)) {
            rs.setData(behaviorService.findCommonUsedOpt(BehaviorEnum.GL_ACCOUNT));
        } else if ("search".equals(type)) {
            rs.setData(baseService.listGlAccount(filter));
        }

        return rs;
    }

    /**
     * 获取单据表头用户可选货币
     */
    @RequestMapping("/userCurrency")
    public List<SelectOpt> userCurrency(String userId, String bukrs, String docType) {
        return baseService.findSelectCurrency(userId, bukrs, docType);
    }
    
    @RequestMapping("/filterCurrency")
    public SelectOptRs filterCurrencySelect(String type, String filter) {
        List<SelectOpt> list;
    	if (!Strings.isNullOrEmpty(filter) && "search".equals(type)) {
        	list = baseService.findSelectCurrency(filter.toUpperCase());
        } else {
    	    list = Lists.newArrayList();
        }
        return new SelectOptRs(false, list);
    }

    /**
     * 货币查询接口
     */
    @RequestMapping("/currency")
    public List<SelectOpt> currency(String term) {
        return baseService.listCurrencyOpt(null);
    }

    /**
     * 员工查询
     */
    @RequestMapping("/searchUser")
    public List<SearchUser> searchUser(String term) {
        return userService.findUserToAddTripTogether(term);
    }

    /**
     * 公司查询
     * @param term
     * @return
     */
    @RequestMapping("/searchBukrs")
    public List<Bukrs> searchBukrs(String term) {
        return baseService.listBukrs(term);
    }

    /**
     * 供应商查询
     * @param term
     * @return
     */
    @RequestMapping("/searchLifnr")
    public List<SelectOpt> searchLifnr(String term) {
        return baseService.listLifnr(term);
    }

    /**
     * 预付费用细类查询
     * @param term
     * @return
     */
    @RequestMapping("/searchAdviceSmaFee")
    public List<SelectOpt> searchAdviceSmaFee(String term) {
        return baseService.listAdviceSmaFee(term);
    }

    /**
     * 影像列表
     */
    @RequestMapping("/imageList/{docId}")
    public List<Object> imageList(@PathVariable("docId") String docId) {
        // TODO get image list
        return Lists.newArrayList();
    }

    @RequestMapping(value = "/getRate")
    public HikResult<Rate> getRate(Rate req) {
        Rate rate;
        if (Objects.equals(req.getCurrency(), req.getPayCurrency())) {
            rate = req;
            rate.setPayAmount(rate.getAmount());
            rate.setRate(BigDecimal.ONE);
        } else {
            rate = baseService.getRates(req);
        }
        HikResult<Rate> result = new HikResult<>();
        result.setData(rate);
        return result;
    }

    @RequestMapping(value = "/getUserBank")
    public List<UserBank> getUserBank(String userId, String bukrs) {
        UserBank user = new UserBank();
        user.setLifnr(userId);
        user.setBukrs(bukrs);
        return piService.findUserBankFromSAP(Lists.newArrayList(user));
    }

    @RequestMapping(value = "/synchUserBank")
    public UserBank synchUserBank(String userId, String bukrs) {
        UserBank user = new UserBank();
        user.setLifnr(userId);
        user.setBukrs(bukrs);
        return piService.synchUserBankFromSAP(user);
    }

    /**
     * 城市交通工具
     */
    @RequestMapping(value = "/cityTrafficTool")
    public List<SelectOpt> cityTrafficTool() {
        return baseService.findCityTraficTool();
    }

    @RequestMapping("/expenseFeeTypes")
    public List<SelectOpt> expenseFeeTypes(String bukrs, String docType, String expenseType) {
        if (Strings.isNullOrEmpty(bukrs) || Strings.isNullOrEmpty(docType) || Strings.isNullOrEmpty(expenseType)) {
            return baseService.listExpenseFeeType();
        } else {
            return baseService.listExpenseFeeType(bukrs, docType, expenseType);
        }
    }

    @RequestMapping("/entertains")
    public List<SelectOpt> entertains() {
        return baseService.listEntertains();
    }

    @RequestMapping("/entertainLevels")
    public List<SelectOpt> entertainLevels() {
        return baseService.listEntertainLevels();
    }

    /**
     * 商机
     */
    @RequestMapping("/businessOpportunities")
    public SelectOptRs businessOpportunities(String type, String userId, String filter) {
        SelectOptRs rs = new SelectOptRs();

        rs.setGroup(false);

        if ("recent".equals(type)) {
            rs.setData(behaviorService.findCommonUsedOpt(BehaviorEnum.BUS_OP));
        } else if ("search".equals(type)) {
            rs.setData(piService.getBusinessOpportunityFromCRM(userId, filter));
        }

        return rs;
    }

    /**
     * 客户/用户
     */
    @RequestMapping("/customers")
    public SelectOptRs customers(String userId, String term) {
        List<SelectOpt> list = piService.getPartnerFromCRM(userId, term);
        return new SelectOptRs(false, list);
    }

    /**
     * 交通项目
     */
    @RequestMapping("/trafficProjects")
    public SelectOptRs trafficProjects(String type, String filter) {
        SelectOptRs rs = new SelectOptRs();

        rs.setGroup(false);

        if ("recent".equals(type)) {
            rs.setData(behaviorService.findCommonUsedOpt(BehaviorEnum.TRA_PROJ));
        } else if ("search".equals(type)) {
            rs.setData(baseService.listTrafficProject(filter));
        }

        return rs;
    }

    /**
     * 行业
     */
    @RequestMapping("/industries")
    public SelectOptRs industries(String type) {
        SelectOptRs rs = new SelectOptRs();

        rs.setGroup(false);

        if ("recent".equals(type)) {
            rs.setData(behaviorService.findCommonUsedOpt(BehaviorEnum.TRA_PROJ));
        } else if ("search".equals(type)) {
            rs.setData(baseService.listIndustry());
        }

        return rs;
    }

    /**
     * 销售区域
     */
    @RequestMapping("/salesArea")
    public SelectOptRs salesArea(String type, String userId) {
        SelectOptRs rs = new SelectOptRs();

        rs.setGroup(false);

//        if ("recent".equals(type)) {
//            rs.setData(behaviorService.findCommonUsedOpt(BehaviorEnum.SALES_AREA));
//        } else if ("search".equals(type)) {
//            rs.setData(baseService.listSalesArea(userId));
//        }
        if ("recent".equals(type)) {
            rs.setData(baseService.listSalesArea(userId));
        }

        return rs;
    }

    /**
     * 记录选项日志，用于最近选择检索
     * @param opt       选项值
     */
    @RequestMapping("/{selectType}/record")
    public void recordSelectIndustry(@PathVariable("selectType") String selectType, SelectOpt opt) {
        this.recordSelectOpt(this.matchBehavior(selectType), opt);
    }

    /**
     * 根据操作类型匹配操作类型枚举
     * @param selectType
     * @return
     */
    private BehaviorEnum matchBehavior(String selectType) {
        BehaviorEnum behaviorEnum = null;

        switch (selectType) {
            case "wbs" : {
                behaviorEnum = BehaviorEnum.PS;
                break;
            }
            case "industries" : {
                behaviorEnum = BehaviorEnum.INDUSTRY;
                break;
            }
            case "trafficProjects" : {
                behaviorEnum = BehaviorEnum.TRA_PROJ;
                break;
            }
            case "salesArea" : {
                behaviorEnum = BehaviorEnum.SALES_AREA;
                break;
            }
            case "businessOpportunities" : {
                behaviorEnum = BehaviorEnum.BUS_OP;
                break;
            }
            case "customers" : {
                behaviorEnum = BehaviorEnum.CUSTOMER;
                break;
            }
            case "glAccount" : {
                behaviorEnum = BehaviorEnum.GL_ACCOUNT;
                break;
            }
            default:
                break;
        }

        return behaviorEnum;
    }

    /**
     * 通用记录选项日志
     * @param behaviorEnum      选择类别
     * @param opt               选择值
     */
    private void recordSelectOpt(BehaviorEnum behaviorEnum, SelectOpt opt) {
        try {
            behaviorService.recordSelectOpt(behaviorEnum, opt);
        } catch (Exception e) {
        }
    }

    /**
     * 未报销车补
     */
    @RequestMapping("/unExpensedCarSubsidy")
    public List<FeeDetail> unExpensedCarSubsidy(String userId) {
        return feeService.listUnExpensedCarSubsidy(userId);
    }

    /**
     * 未报销生育补贴
     */
    @RequestMapping("/unExpensedBirthInfo")
    public List<FeeDetail> unExpensedBirthInfo(String userId) {
        return feeService.listUnExpensedBirthInfo(userId);
    }

    /**
     * 检查费用是否超标/超期
     * @param info
     * @return
     */
    @ResponseBody
    @RequestMapping("/checkFeeStatus")
    public FeeDetail checkFeeStatus(@RequestBody CheckFeeInfo info) {
        FormHeader header = new FormHeader();
        BeanUtils.copyProperties(info, header, "detail");
        return feeService.checkFeeStatus(header, info.getDetail());
    }

    /**
     * 收款人列表
     */
    @ResponseBody
    @RequestMapping("/otherReceivers")
    public List<OtherReceivor> otherReceivers(@RequestParam("docId") String docId) {
        return formService.listOtherReceiver(docId);
    }

    @ResponseBody
    @RequestMapping(value = "/addWorkingHolidays", method = RequestMethod.POST)
    public HikResult<String> addWorkingHolidays(@RequestParam("docId") String docId, @RequestParam(value = "dates[]", required = false) String[] dates) {
        if (dates != null && dates.length > 0) {
            formService.addWorkingHolidays(docId, Arrays.asList(dates));
        }
        return new HikResult<String>();
    }

    @ResponseBody
    @RequestMapping(value = "/listWorkingHolidays", method = RequestMethod.GET)
    public List<HolidayWork> listWorkingHolidays(@RequestParam("docId") String docId,
                                                  @RequestParam("bukrs") String bukrs,
                                                  @RequestParam("minDate") String minDate,
                                                  @RequestParam("maxDate") String maxDate) {
        return formService.listWorkingHolidays(docId, bukrs, minDate, maxDate);
    }

    /**
     * @return 未清明细及在途统计
     * {
     *     bsiks: [ // 未清明细
     *     ],
     *     onlineBsikSummary: { // 在途统计(各币种及本位币在途)
     *     }
     * }
     */
    @RequestMapping(value = "/getBsik", method = RequestMethod.POST)
    public HikResult<BsikInfo> getBsik(String userId, String bukrs) {
        HikResult<BsikInfo> result = new HikResult<>();
        
        BsikInfo bsikInfo = new BsikInfo();

        List<Bsik> bsiks = piService.getBsik(userId, bukrs);
        OnlineBsikSummary summary = voucherService.countOnlineReim(bukrs, userId);

		bsikInfo.setBsiks(bsiks);
		bsikInfo.setOnlineBsikSummary(summary);

        result.setData(bsikInfo);

        return result;
    }

    /**
     * 售前派工查询
     */
    @ResponseBody
    @RequestMapping("/sqpg")
    public List<SqpgDoc> getSqpg(String term) {
        SqpgDoc doc = new SqpgDoc();
        doc.setOaDocNum("PG20170310_0251");
        doc.setOaDocTitle("西海岸天网项目交流谷歌浏览器相关事宜");
        doc.setOaDocUrl("http://www.baidu.com");
        List<SqpgDoc> list = Lists.newArrayList(doc);
        return list;
    }

    /**
     * 根据用户id校验是否需要售前派工
     */
    @ResponseBody
    @RequestMapping("/needSqpg")
    public boolean needSqpg(String userId) {
        return formService.checkSqpgRel(userId);
    }
   
    @RequestMapping("/company")
    public List<SelectOpt> selectCompany(String term) {
        return baseService.getCompanyInfo(term);
    }

    /**
     * 校验是否可以报市内交通费用(个人费用)
     */
    @ResponseBody
    @RequestMapping("/checkSnjtFee")
    public boolean checkSnjtFee(String userId, String year, String month) {
        return formService.checkSnjtFee(userId, year, month);
    }

    /**
     * 获取员工指定年月市内交通费用
     */
    @ResponseBody
    @RequestMapping("/getExpensedTrafficFees")
    public List<ExpensedTrafficFee> getExpensedTrafficFees(String userId, String year, String month) {
        return feeService.getExpensedTrafficFees(userId, year, month);
    }

}
