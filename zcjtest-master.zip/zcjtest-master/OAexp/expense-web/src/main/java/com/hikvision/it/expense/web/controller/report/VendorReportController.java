package com.hikvision.it.expense.web.controller.report;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.Row;
import org.apache.poi.ss.usermodel.Sheet;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.base.Strings;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.form.VendorFormHeader;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.report.IReportService;
import com.hikvision.it.expense.common.utils.PagesPOIExport;
import com.hikvision.it.expense.common.utils.PoiReadExcel;
import com.hikvision.it.expense.common.utils.ResponseUtil;

/**
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/14
 * Time: 14:40
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/report/vendor")
public class VendorReportController {
    @Reference(version = Version.VERSION_LATEST)
    IReportService reportService;
    @Reference(version = Version.VERSION_LATEST)
    IFormService formService;
    @Value("${export.path}")
    private String path;

    /**
     * 预付催收报表页面跳转
     * @return
     */
    @RequestMapping(value = "/advice")
    String showAdviceReport() {
        return "redirect:/static/html/report/approve/advice.html";
    }

    /**
     * 查询预付催收表单数据
     * @param param
     * @return
     */
    @RequestMapping(value = "/advice/getDate", method = RequestMethod.POST)
    ResponseEntity<List<VendorFormHeader>> advice(AdviceParam param) {
        LoginUser user = UserContext.get();

        return ResponseEntity.ok(reportService.listVendorAdvice(param.getBukrsList(), param.getExpensorList(), param.getLifnrList(), param.getCurrencyList(), param.getSmaFeeList()));
    }

    /**
     * 查询预付催收表单数据
     * @param id
     * @param mailReceivorMailAddress
     * @return
     */
    @RequestMapping(value = "/advice/saveMailAddress", method = RequestMethod.POST)
    ResponseEntity<HikResult<String>> saveMailAddress(String id, String mailReceivorMailAddress) {
        LoginUser user = UserContext.get();

        return ResponseEntity.ok(formService.saveVendorInvoiceMailAddress(id, mailReceivorMailAddress));
    }

    @RequestMapping(value = "/advice/export")
    void adviceExport(AdviceParam param, HttpServletResponse response) {
        PagesPOIExport<VendorFormHeader> export = new PagesPOIExport<VendorFormHeader>(path, UserContext.get().getNotesId()) {};
        String[] headers = new String[] {
                "单据编号", "预付单号", "业务大类", "业务细类", "公司代码", "发票回收日期", "预付金额", "已核销金额",
                "供应商代码", "供应商名称", "填报人", "填报人姓名", "事由", "接收人邮箱" };

        PagesPOIExport.IEntityExport<VendorFormHeader> exportExecute = new PagesPOIExport.IEntityExport<VendorFormHeader>() {
            @Override
            public void entityExport(Sheet sh, VendorFormHeader data, int rowNum) {
                Row row = sh.createRow(rowNum);
                Cell cell = row.createCell(0);
                cell.setCellValue(Strings.nullToEmpty(data.getDocId()));// 单据编号
                cell = row.createCell(1);
                cell.setCellValue(Strings.nullToEmpty(data.getDocNo()));// 预付单号
                cell = row.createCell(2);
                cell.setCellValue(Strings.nullToEmpty(data.getBigFeeTypeName()));// 业务大类
                cell = row.createCell(3);
                cell.setCellValue(Strings.nullToEmpty(data.getSmaFeeTypeName()));// 业务细类
                cell = row.createCell(4);
                cell.setCellValue(Strings.nullToEmpty(data.getBukrs()));// 公司代码
                cell = row.createCell(5);
                cell.setCellValue(Strings.nullToEmpty(data.getFphsDate()));// 发票回收日期
                cell = row.createCell(6);                           // 预付金额
                if (data.getAmount() != null) {
                    cell.setCellValue(data.getAmount().doubleValue());
                } else {
                    cell.setCellValue(0);
                }
                cell = row.createCell(7);                   // 已核销金额
                if (data.getWriteOffAmount() != null) {
                    cell.setCellValue(data.getWriteOffAmount().doubleValue());
                } else {
                    cell.setCellValue(0);
                }
                cell = row.createCell(8);
                cell.setCellValue(Strings.nullToEmpty(data.getLifnr()));// 供应商代码
                cell = row.createCell(9);
                cell.setCellValue(Strings.nullToEmpty(data.getLifnrTxt()));// 供应商名称
                cell = row.createCell(10);
                cell.setCellValue(Strings.nullToEmpty(data.getExpensor()));//填报人
                cell = row.createCell(11);
                cell.setCellValue(Strings.nullToEmpty(data.getExpensorName()));//填报人姓名
                cell = row.createCell(12);
                cell.setCellValue(Strings.nullToEmpty(data.getRemark()));//事由
                cell = row.createCell(13);
                cell.setCellValue(Strings.nullToEmpty(data.getMailReceivorMailAddress()));//邮件接收人
            }
        };

        try {
            List<VendorFormHeader> formList = reportService.listVendorAdvice(param.getBukrsList(), param.getExpensorList(), param.getLifnrList(), param.getCurrencyList(), param.getSmaFeeList());

            String path = export.exportData(formList, exportExecute, headers);

            this.printStream(response, path, UserContext.getUserName());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    /**
     * 下载文件流
     *
     * @param response
     * @param filePath
     */
    private void printStream(HttpServletResponse response, String filePath,
                             String userName) throws IOException {
        ResponseUtil.outputStream(response, filePath, userName);
    }

    /**
     * 该接口仅用于导出2007以上版本  xlsx后缀
     *
     * @return
     */
    @RequestMapping(value = "/advice/import")
    ResponseEntity<HikResult<List<VendorFormHeader>>> adviceImport(@RequestParam MultipartFile file) {
        HikResult<List<VendorFormHeader>> hikResult = new HikResult<>();
        InputStream is;
        try {
            is = file.getInputStream();
            PoiReadExcel excelReader = new PoiReadExcel();
            String[] title = excelReader.readExcelTitle(is);
//            测试列长度  因为导入的数据必须要以导出的数据为模板 所以验证是否是导出时的14列
            if (title.length != 14) {
                hikResult.addError("列个数错误");
            }
            // 读取Excel表格内容
            Map<Integer, String> map = excelReader.readExcelContent(is);
            hikResult = formService.batchSaveVendorInvoiceMailAddress(map);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return ResponseEntity.ok(hikResult);
    }

    /**
     * 将选中数据保存到logmail表中
     *
     * @param lists
     * @return
     */
    @RequestMapping(value = "/advice/sendMail", method = RequestMethod.POST)
    ResponseEntity<HikResult<String>> sendMail(@RequestBody List<VendorFormHeader> lists) {
        HikResult<String> hikResult = new HikResult<>();
        hikResult = formService.recordMail(lists);

        return ResponseEntity.ok(hikResult);
    }
}
