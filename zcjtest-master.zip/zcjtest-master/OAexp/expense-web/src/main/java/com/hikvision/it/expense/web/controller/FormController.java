package com.hikvision.it.expense.web.controller;

import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM001;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM002;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM003;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM004;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM006;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM008;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM010;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM011;
import static com.hikvision.it.expense.api.enums.DocTypeEnum.WEM012;
import static com.hikvision.it.expense.api.enums.ExpenseType.F1;
import static com.hikvision.it.expense.api.enums.ExpenseType.H8;
import static com.hikvision.it.expense.api.enums.ExpenseType.HB;
import static com.hikvision.it.expense.api.enums.ExpenseType.HC;
import static com.hikvision.it.expense.api.enums.ExpenseType.HZ;
import static com.hikvision.it.expense.api.enums.ExpenseType.MM;
import static com.hikvision.it.expense.web.enums.FormAction.approve;
import static com.hikvision.it.expense.web.enums.FormAction.create;
import static com.hikvision.it.expense.web.enums.FormAction.view;

import java.math.BigDecimal;
import java.util.Comparator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.alibaba.fastjson.JSON;
import com.google.common.base.Joiner;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.form.OverproofInfo;
import com.hikvision.it.expense.api.entity.task.TaskInstance;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.enums.DocStatusEnum;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.api.enums.ExpenseType;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.YesOrNoEnum;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.api.service.base.IDictionaryService;
import com.hikvision.it.expense.api.service.fee.IFeeItemService;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.task.ITaskService;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.web.dto.ButtonCtrl;
import com.hikvision.it.expense.web.dto.FormParam;
import com.hikvision.it.expense.web.enums.FormAction;

@Controller
@RequestMapping("/form")
public class FormController extends BaseController {
    @Reference(version = Version.VERSION_LATEST)
    private IFormService formService;
    @Reference(version = Version.VERSION_LATEST)
    private ITaskService taskService;
    @Reference(version = Version.VERSION_LATEST)
    private IVoucherService voucherService;
    @Reference(version = Version.VERSION_LATEST)
    private IBaseService baseService;
    @Reference(version = Version.VERSION_LATEST)
    private IFeeItemService feeItemService;
    @Reference(version = Version.VERSION_LATEST)
    private IDictionaryService dictionaryService;

    /**
     * task跳转兼容:
     * /{docType}/approve/taskId -> /{docType}/approve?taskId=taskId
     */
    @RequestMapping({"/{docType}/edit/{docId}", "/{docType}/view/{docId}", "/{docType}/approve/{taskId}"})
    public String redirect(@PathVariable("docType") DocTypeEnum docType, @PathVariable(value = "docId", required = false) String docId, @PathVariable(value = "taskId", required = false) String taskId, HttpServletRequest request) {
        String uri = request.getRequestURI();
        uri = uri.substring(0, uri.lastIndexOf("/"));
        if (uri.contains("/edit") || uri.contains("/view")) {
            uri = uri + "?docId=" + docId; // ../edit|approve?taskId=taskId
        } else { //approve
            TaskInstance taskInstance = taskService.getTaskInstance(taskId);
            if ("A01".equals(taskInstance.getTaskName())) { // 驳回
                uri = uri.replace("/approve", "/edit");
            }
            uri = uri + "?taskId=" + taskId; // ../edit|approve?taskId=taskId
        }
        return "redirect:/expense" + uri;
    }

    /**
     * create
     * view?docId
     * approve?taskId
     * edit?docId|taskId 草稿箱编辑docId, 驳回提交taskId, 不能同时为空或者同时有值
     * @param action edit | view | create | approve
     */
    @RequestMapping("/{docType}/{action}")
    public String editRequest(@PathVariable("docType") DocTypeEnum docType, @PathVariable("action") FormAction action, String refDocId, String taskId, String docId, String expenseType, Model model) {
    	FormParam param = new FormParam(action, docType, taskId, docId, refDocId, expenseType);
        String checkResult = check(param, model);
        if (!Strings.isNullOrEmpty(checkResult)) {
            return checkResult;
        }

        FormInfo formInfo;
        if (create.equals(action)) {
            formInfo = initForm(param);
        } else if (FormAction.edit == action || FormAction.view == action || FormAction.approve == action){
            HikResult<FormInfo> result = formService.getFormInfo(param.getDocId(), UserContext.getUserId());
            if (!result.isSuccess()) {
                throw new ExpenseException(Joiner.on(",").join(result.getErrorMsgs()));
            }
            formInfo = result.getData();
        } else {
            throw new ExpenseException("never run here");
        }

        addAttributeToModel(param, formInfo, model);

        return getReturnPath(param, formInfo.getFormHeader());
    }

    @RequestMapping("/{docType}/requestList")
    public String requestList(@PathVariable("docType") DocTypeEnum docType, Model model) {
        List<FormHeader> lists = formService.listApplyWithDefaultStatus();
        model.addAttribute("lists", lists);

        if (docType.equals(DocTypeEnum.WEM002)) {
            model.addAttribute("listType", "exchange");
        } else {
            model.addAttribute("listType", "reimburse");
        }

        return "/travel/requestList";
    }

    @ResponseBody
    @RequestMapping("/save")
    public HikResult<String> save(@RequestBody FormInfo formInfo) {
        formInfo.getFormHeader().setCreatedBy(UserContext.getUserId());
        return formService.saveFormInfo(formInfo);
    }

    @ResponseBody
    @RequestMapping("/submit")
    public HikResult<String> submit(@RequestBody FormInfo formInfo) {
        formInfo.getFormHeader().setCreatedBy(UserContext.getUserId());
        return formService.submitFormInfo(formInfo);
    }

    /**
     * <pre>
     * 校验参数是否完整, 校验单据读取,修改,审批权限
     * 如果参数只有taskId, 会将对应的docId取出来放到param中
     * </pre>
     * @exception com.hikvision.it.expense.api.exception.ExpenseException 校验不通过抛出异常
     * @return 返回null, 或者跳转地址: /travel/requestList
     */
    private String check(FormParam param, Model model) {

        logger.debug("check form param: {}", param.toString());

        FormAction action = param.getAction();
        String refDocId = param.getRefDocId();
        String docId = param.getDocId();
        DocTypeEnum docType = param.getDocType();
        String expenseType = param.getExpenseType();
        String taskId = param.getTaskId();

        if (create == action) {
            if (docType == WEM002) {
                if (Strings.isNullOrEmpty(refDocId)) {
                    //获取可变更列表
                	List<FormHeader> lists = formService.listApplyWithDefaultStatus();
                	model.addAttribute("lists", lists);
                    model.addAttribute("listType", "exchange");
                    return "/travel/requestList";
                } else {
                    param.setDocId(refDocId);
                }
            } else if (docType == WEM006 || docType == WEM010) {
                String grade = UserContext.get().getUserGrade();

                if (!UserContext.get().isBranch() && !"M5".equalsIgnoreCase(grade)) {
                    if (Strings.isNullOrEmpty(refDocId)) {
                        //获取可报销列表
                        List<FormHeader> lists = formService.listApplyWithDefaultStatus();
                        model.addAttribute("lists", lists);
                        model.addAttribute("listType", "reimburse");
                        return "/travel/requestList";
                    }
                }
            } else if (docType == WEM008) {
            	String grade = UserContext.get().getUserGrade();

                if (Strings.isNullOrEmpty(expenseType)) {
                	if (!"M5".equalsIgnoreCase(grade)) {
                		return "personal/expenseTypeList";
                	}
                }
            }
        } else if (FormAction.view == action) {
            if (!formService.isReadable(docId)) {
                throw new ExpenseException(i18n.get(MessageCode.MSG_NOT_AUTH_OPEN_URL));
            }
        } else if (FormAction.edit == action) {
            if (!Strings.isNullOrEmpty(taskId)) {
                docId = taskService.getDocIdByTaskId(taskId);
                param.setDocId(docId);
            }
            if (!formService.isEditable(docId)) {
                throw new ExpenseException(i18n.get(MessageCode.MSG_NOT_AUTH_OPEN_URL));
            }
        } else if (FormAction.approve == action) {
            if (!Strings.isNullOrEmpty(taskId)) {
                docId = taskService.getDocIdByTaskId(taskId);
                param.setDocId(docId);
            }
            TaskInstance taskInstance = taskService.getTaskInstance(taskId);
            if (taskInstance == null) { // 获取不到userId对应taskId信息
                throw new ExpenseException(i18n.get(MessageCode.MSG_NOT_AUTH_OPEN_URL));
            } else {// 已审批, 不能进行approve操作
                if (YesOrNoEnum.Y.name().equals(taskInstance.getStatus())) {
                    throw new ExpenseException(i18n.get(MessageCode.MSG_NOT_AUTH_OPEN_URL));
                }
            }
        }
        return null;
    }


    /**
     * 初始化单据
     */
    private FormInfo initForm(FormParam param) {
        FormInfo formInfo = null;

        if (param.getDocType() == WEM001) {
            FormHeader formHeader = new FormHeader();
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM001.name());
            formHeader.setDocStatus(DocStatusEnum.S001.name());

            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
        } else if (param.getDocType() == WEM002) {
            HikResult<FormInfo> result = formService.getFormInfo(param.getDocId(), UserContext.getUserId());
            if (!result.isSuccess()) {
                throw new ExpenseException(Joiner.on(",").join(result.getErrorMsgs()));
            }
            FormInfo requestForm = result.getData();
            FormHeader formHeader = requestForm.getFormHeader();
            formHeader.setRefDocId(formHeader.getDocId());
            formHeader.setRefDocNo(formHeader.getDocNo());
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM002.name());
            formHeader.setDocStatus(DocStatusEnum.S001.name());
            formHeader.setAmount(BigDecimal.ZERO);

            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
            formInfo.setTrips(requestForm.getTrips());
        } else if (param.getDocType() == WEM003) {
            FormHeader formHeader = new FormHeader();
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM003.name());
            formHeader.setExpenseType(ExpenseType.C3.name());
            formHeader.setDocStatus(DocStatusEnum.S001.name());
            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
        } else if (param.getDocType() == WEM004) {
            FormHeader formHeader = new FormHeader();
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM004.name());
            formHeader.setExpenseType("02");

            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
        } else if (param.getDocType() == WEM006) {
            LoginUser loginUser = UserContext.get();
            if ((loginUser.isBranch() || "M5".equals(loginUser.getUserGrade())) && Strings.isNullOrEmpty(param.getRefDocId())) { // 分公司|VP没有选关联单号, 直接打开
                FormHeader formHeader = new FormHeader();
                formHeader.setDocId(StringUtil.getUUID());
                formHeader.setDocType(WEM006.name());
                if ("M5".equals(loginUser.getUserGrade())) {
                    formHeader.setExpenseType(MM.name());
                } else {
                    formHeader.setExpenseType(F1.name());
                }
                formHeader.setDocStatus(DocStatusEnum.S001.name());

                formInfo = new FormInfo();
                formInfo.setFormHeader(formHeader);
            } else {// 根据关联单号获取行程
                HikResult<FormInfo> result = formService.getFormInfo(param.getRefDocId(), UserContext.getUserId());
                if (!result.isSuccess()) {
                    throw new ExpenseException(Joiner.on(",").join(result.getErrorMsgs()));
                }
                FormInfo requestForm = result.getData();

                FormHeader formHeader = requestForm.getFormHeader();
                formHeader.setRefDocId(formHeader.getDocId());
                formHeader.setRefDocNo(formHeader.getDocNo());
                String docId=StringUtil.getUUID();
                formHeader.setDocId(docId);
                formHeader.setDocNo(null);
                formHeader.setDocType(WEM006.name());
                formHeader.setExpenseType(ExpenseType.F1.name());
                formHeader.setDocStatus(DocStatusEnum.S001.name());
                formHeader.setSubmittedOn(null);

                formInfo = new FormInfo();
                formInfo.setFormHeader(formHeader);

                // 转化行程, 生成住宿信息, 并保存到数据库
                List<FeeDetail> newCtjtList = transferTripsToLongDistanceTrafficFees(requestForm.getTrips());
                for(FeeDetail fee:newCtjtList){
                    fee.setDocId(docId);
                }
                newCtjtList = feeItemService.save(newCtjtList);
                formInfo.setLongDistanceTrafficFees(newCtjtList);
            }
        } else if (param.getDocType() == WEM008) {
            FormHeader formHeader = new FormHeader();
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM008.name());
            formHeader.setExpenseType(param.getExpenseType());
                formHeader.setExpenseTypeName(dictionaryService.findOne("D202", param.getExpenseType()));
            formHeader.setDocStatus(DocStatusEnum.S001.name());
            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
        } else if (param.getDocType() == WEM011) {
            FormHeader formHeader = new FormHeader();
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM011.name());
            formHeader.setExpenseType(ExpenseType.F7.name());
            formHeader.setDocStatus(DocStatusEnum.S001.name());
            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
        } else if (param.getDocType() == WEM012) {
            FormHeader formHeader = new FormHeader();
            formHeader.setDocId(StringUtil.getUUID());
            formHeader.setDocType(WEM012.name());
            formHeader.setExpenseType(ExpenseType.F5.name());
            formHeader.setDocStatus(DocStatusEnum.S001.name());
            formInfo = new FormInfo();
            formInfo.setFormHeader(formHeader);
        }

        if (!Strings.isNullOrEmpty(param.getExpenseType())) {
            formInfo.getFormHeader().setExpenseTypeName(baseService.getExpenseTypeName(param.getExpenseType()));
        }

        return formInfo;
    }

    private void addAttributeToModel(FormParam param, FormInfo formInfo, Model model) {
        formInfo.setTaskId(param.getTaskId());
        model.addAttribute("formInfo", formInfo);
        if (param.getDocType() == WEM001) {
            model.addAttribute("tripJson", JSON.toJSONString(formInfo.getTrips()));
            model.addAttribute("loanJson", JSON.toJSONString(formInfo.getLoans()));
            model.addAttribute("travelPartnerJson", JSON.toJSONString(formInfo.getTripTogethers()));
            model.addAttribute("action", param.getAction());
        } else if (param.getDocType() == WEM002) {
            model.addAttribute("tripJson", JSON.toJSONString(formInfo.getTrips()));
        } else if (param.getDocType() == WEM003) {
            model.addAttribute("loanJson", JSON.toJSONString(formInfo.getLoans()));
        } else if (param.getDocType() == WEM006) {
            model.addAttribute("ctjtJson", JSON.toJSONString(formInfo.getLongDistanceTrafficFees()));
            model.addAttribute("zsfyJson", JSON.toJSONString(formInfo.getStaysFees()));
            model.addAttribute("feeJson", JSON.toJSONString(this.mergeFeeDetails(formInfo)));

            model.addAttribute("sqpgJson", JSON.toJSONString(formInfo.getSqpgDocs()));
            model.addAttribute("travelReport", formInfo.getTravelReport());
            model.addAttribute("branch", UserContext.get().isBranch());
        } else if (param.getDocType() == WEM008) {
            ExpenseType type;
            if (create == param.getAction()) {
            	String grade = UserContext.get().getUserGrade();
            	if ("M5".equalsIgnoreCase(grade)) {
            		type = MM;
            		formInfo.getFormHeader().setExpenseType(type.name());
            	} else {
            		type = ExpenseType.valueOf(param.getExpenseType());
            	}
            } else {
                type = ExpenseType.valueOf(formInfo.getFormHeader().getExpenseType());
            }
            model.addAttribute("fee", type != H8 && type != HB && type != HC && type != HZ);
            model.addAttribute("fwzl", type == H8); // 房租费
            model.addAttribute("sybx", type == HC || type == HB); // 生育报销
            model.addAttribute("clbt", type == HZ); // 车辆补贴

            model.addAttribute("feeJson", JSON.toJSONString(this.mergeFeeDetails(formInfo)));
            model.addAttribute("fwzlJson", JSON.toJSONString(formInfo.getRentFees()));
            model.addAttribute("sybxJson", JSON.toJSONString(formInfo.getBirthFees()));
            model.addAttribute("clbtJson", JSON.toJSONString(formInfo.getCarAllowanceFees()));
        } else if (param.getDocType() == WEM011) {
            model.addAttribute("feeJson", JSON.toJSONString(this.mergeFeeDetails(formInfo)));
            model.addAttribute("snpcJson", JSON.toJSONString(formInfo.getInsideCityDriverFees()));
        } else if (param.getDocType() == WEM012) {
            model.addAttribute("ctjtJson", JSON.toJSONString(formInfo.getLongDistanceTrafficFees()));
            model.addAttribute("zsfyJson", JSON.toJSONString(formInfo.getStaysFees()));
            model.addAttribute("feeJson", JSON.toJSONString(this.mergeFeeDetails(formInfo)));
        }

        if (ListUtil.isNotEmpty(formInfo.getOverproofs())) {
            for (OverproofInfo item : formInfo.getOverproofs()) {
                model.addAttribute(item.getType(), item.getRemark());
            }
        }

        TaskInstance taskInstance = null;
        if (param.getAction() == FormAction.approve && !Strings.isNullOrEmpty(param.getTaskId())) {
            taskInstance = taskService.getTaskInstance(param.getTaskId());
            if (taskInstance == null) {
                throw new ExpenseException("invalid task id");
            }
            model.addAttribute("taskInstance", taskInstance);
        }

        addButtonsControlToModel(param, formInfo, taskInstance, model);
    }

    /**
     * 增加按钮控制
     */
    private void addButtonsControlToModel(FormParam param, FormInfo formInfo, TaskInstance taskInstance, Model model) {
        ButtonCtrl btnCtrl = new ButtonCtrl();
        FormHeader header = formInfo.getFormHeader();
        boolean existAgree = (approve == param.getAction() && ("S002".equals(header.getDocStatus())|| "S003".equals(header.getDocStatus())));
        boolean showAgree = existAgree;
        boolean existPreview = false;
        if (existAgree) {
            if (taskInstance != null  && "F01".equals(taskInstance.getTaskName())) { // 财务环节看凭证是否过账
                boolean allVoucherPosted = voucherService.checkAllVoucherPosted(param.getDocId());
                showAgree = allVoucherPosted;
                existPreview = !allVoucherPosted;
            }
        }
        btnCtrl.setExistAgree(existAgree);
        btnCtrl.setShowAgree(showAgree);
        btnCtrl.setExistPreview(existPreview);
        model.addAttribute("btnCtrl", btnCtrl);
    }

    private String getReturnPath(FormParam param, FormHeader formHeader) {
        String action;
        if (param.getAction() == create || param.getAction() == FormAction.edit) {
            action = "edit";
        } else if (param.getAction() == FormAction.approve) {
            action = "approve";
        } else {
            action = "view";
        }

        // TODO view和approve页面合并: (wem002|WEM004|wem006|wem008|wem010已改)
        if ((param.getDocType() == WEM002
                || param.getDocType() == WEM004
                || param.getDocType() == WEM006
                || param.getDocType() == WEM010
                || param.getDocType() == WEM008
                || param.getDocType() == WEM011
                || param.getDocType() == WEM012
        )
                && (param.getAction() == approve || param.getAction() == view)) {
            action = "view";
        }

        if (param.getDocType() == WEM001) {
            return "/travel/" + action + "Request";
        } else if (param.getDocType() == WEM002) {
            return "/travel/" + action + "Exchange";
        } else if (param.getDocType() == WEM003) {
            return "/loan/" + action + "Loan";
        } else if (param.getDocType() == WEM004) {
            return "/repayment/" + action + "Repayment";
        } else if (param.getDocType() == WEM006) {
            String grade = formHeader.getExpensorGrade();
            if (Strings.isNullOrEmpty(grade)) {
                grade = UserContext.get().getUserGrade();
            }
            if ("M5".equals(grade)) {
                return "/travel/" + action + "ReimburseVp";
            } else {
                return "/travel/" + action + "Reimburse";
            }
        } else if (param.getDocType() == WEM008) {
            return "/personal/" + action + "Personal";
        } else if (param.getDocType() == WEM011) {
            return "/driver/" + action + "InsideCity";
        } else if (param.getDocType() == WEM012) {
            return "/driver/" + action + "OutsideCity";
        }
        return null;
    }

    /**
     * 差旅申请行程转化成报销行程
     */
    private List<FeeDetail> transferTripsToLongDistanceTrafficFees(List<Trip> trips) {
        List<FeeDetail> list = Lists.newArrayList();

        // 判断国际差旅
        boolean international = false;
        for (Trip trip : trips) {
            //只要存在非本国的行程则默认为国际差旅
            if (!"CN".equalsIgnoreCase(trip.getCountryFrom()) ||
                    !"CN".equalsIgnoreCase(trip.getCountryTo())) {
                international = true;
                break;
            }
            //CN的国际差旅特殊判断，港澳台属于国际差旅
            String hk = "810000,";
            String am = "820000";
            String tw = "710000";
            String cityFrom = trip.getPlaceFrom();
            String cityTo = trip.getPlaceTo();
            //港澳台判断
            if ((hk.equalsIgnoreCase(cityFrom) || hk.equalsIgnoreCase(cityTo)) ||
                    (am.equalsIgnoreCase(cityFrom) || am.equalsIgnoreCase(cityTo)) ||
                    (tw.equalsIgnoreCase(cityFrom) || tw.equalsIgnoreCase(cityTo))) {
                international = true;
                break;
            }
        }

        for (Trip trip : trips) {
            FeeDetail detail = new FeeDetail();
            detail.setRn(trip.getRn());
            detail.setFeeType("CTJT");
            detail.setFeeFromDate(trip.getFromDate());
            detail.setCountryFrom(trip.getCountryFrom());
            detail.setPlaceFrom(trip.getPlaceFrom());
            detail.setPlaceFromDesc(trip.getFromDesc());

            detail.setFeeToDate(trip.getToDate());
            detail.setCountryTo(trip.getCountryTo());
            detail.setPlaceTo(trip.getPlaceTo());
            detail.setPlaceToDesc(trip.getToDesc());

            detail.setTrafficToolType(trip.getToolType());
            detail.setTrafficToolLevel(trip.getToolLevel());
            detail.setTrafficToolLevelDesc(trip.getToolDesc());

            if ("0314,0315,0316".contains(detail.getTrafficToolLevel())) { // 飞机, 公司订票, 金额默认0
                detail.setCurrency("CNY");
                detail.setCurrencyDesc("CNY - 人民币");
                detail.setExchangeRate(BigDecimal.ONE);
                detail.setAmount(BigDecimal.ZERO);
                detail.setLocalAmount(BigDecimal.ZERO);
            }
            if (!international) { // 国内差旅币别默认"CNY"
                detail.setCurrency("CNY");
                detail.setCurrencyDesc("CNY - 人民币");
                detail.setExchangeRate(BigDecimal.ONE);
            }

            list.add(detail);
        }

        return list;
    }

    /**
     * 将市内交通,业务招待,其他费用合并. 按日期排序
     * @param formInfo
     * @return
     */
    private List<FeeDetail> mergeFeeDetails(FormInfo formInfo) {
        List<FeeDetail> list = Lists.newArrayList();
        if (ListUtil.isNotEmpty(formInfo.getCityTrafficFees())) {
            list.addAll(formInfo.getCityTrafficFees());
        }
        if (ListUtil.isNotEmpty(formInfo.getEntertainFees())) {
            list.addAll(formInfo.getEntertainFees());
        }
        if (ListUtil.isNotEmpty(formInfo.getOtherFees())) {
            list.addAll(formInfo.getOtherFees());
        }
        list.sort(Comparator.comparing(FeeDetail::getFeeFromDate));
        return list;
    }
}