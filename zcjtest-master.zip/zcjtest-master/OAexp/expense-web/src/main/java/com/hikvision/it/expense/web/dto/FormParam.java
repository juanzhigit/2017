package com.hikvision.it.expense.web.dto;

import com.google.common.base.MoreObjects;
import com.hikvision.it.expense.api.enums.DocTypeEnum;
import com.hikvision.it.expense.web.enums.FormAction;

public class FormParam {

    private FormAction action;
    private DocTypeEnum docType;
    private String refDocId;
    private String expenseType;
    private String docId;
    private String taskId;

    public FormParam() {
    }

    public FormParam(FormAction action, DocTypeEnum docType, String taskId, String docId, String refDocId, String expenseType) {
        this.docType = docType;
        this.action = action;
        this.taskId = taskId;
        this.docId = docId;
        this.refDocId = refDocId;
        this.expenseType = expenseType;
    }

    public FormAction getAction() {
        return action;
    }

    public void setAction(FormAction action) {
        this.action = action;
    }

    public DocTypeEnum getDocType() {
        return docType;
    }

    public void setDocType(DocTypeEnum docType) {
        this.docType = docType;
    }

    public String getRefDocId() {
        return refDocId;
    }

    public void setRefDocId(String refDocId) {
        this.refDocId = refDocId;
    }

    public String getExpenseType() {
        return expenseType;
    }

    public void setExpenseType(String expenseType) {
        this.expenseType = expenseType;
    }

    public String getDocId() {
        return docId;
    }

    public void setDocId(String docId) {
        this.docId = docId;
    }

    public String getTaskId() {
        return taskId;
    }

    public void setTaskId(String taskId) {
        this.taskId = taskId;
    }

    @Override
    public String toString() {
        return MoreObjects.toStringHelper(getClass()).add("action", action)
                .add("refDocId", refDocId)
                .add("expenseType", expenseType)
                .add("docId", docId)
                .add("taskId", taskId).toString();
    }
}