package com.hikvision.it.expense.web.dto;

import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;

public class FeeInfo {

    private FeeDetail detail;
    private FormHeader header;

    public FeeDetail getDetail() {
        return detail;
    }

    public void setDetail(FeeDetail detail) {
        this.detail = detail;
    }

    public FormHeader getHeader() {
        return header;
    }

    public void setHeader(FormHeader header) {
        this.header = header;
    }
}
