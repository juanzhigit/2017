package com.hikvision.it.expense.web.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import com.alibaba.dubbo.config.ApplicationConfig;
import com.alibaba.dubbo.config.ConsumerConfig;
import com.alibaba.dubbo.config.RegistryConfig;
import com.alibaba.dubbo.config.spring.AnnotationBean;

@Configuration
public class DubboConfig {
	@Value("${spring.dubbo.application.name}")
	private String applicationName;
	@Value("${spring.dubbo.registry.protocol}")
	private String protocol;
	@Value("${spring.dubbo.registry.address}")
	private String registryAddress;
	@Value("${spring.dubbo.timeout}")
	private int timeout;

	/**
	 * 设置dubbo扫描包
	 */
	@Bean
	public static AnnotationBean annotationBean(
			@Value("${spring.dubbo.scan}") String packageName) {
		AnnotationBean annotationBean = new AnnotationBean();
		annotationBean.setPackage(packageName);
		return annotationBean;
	}

	/**
	 * 注入dubbo上下文
	 */
	@Bean
	public ApplicationConfig applicationConfig() {
		// 当前应用配置
		ApplicationConfig applicationConfig = new ApplicationConfig();
		applicationConfig.setName(applicationName);
		return applicationConfig;
	}

	/**
	 * 注入dubbo注册中心配置,基于zookeeper
	 */
	@Bean
	public RegistryConfig registryConfig() {
		// 连接注册中心配置
		RegistryConfig registry = new RegistryConfig();
		registry.setProtocol(protocol);
		registry.setAddress(registryAddress);
		return registry;
	}

	/**
	 * dubbo服务提供
	 */
	@Bean(name = "defaultProvider")
	public ConsumerConfig consumerConfig(ApplicationConfig applicationConfig,
                                         RegistryConfig registryConfig) {
		ConsumerConfig consumerConfig = new ConsumerConfig();
        consumerConfig.setTimeout(timeout);
        consumerConfig.setRetries(0);
        consumerConfig.setApplication(applicationConfig);
        consumerConfig.setRegistry(registryConfig);
        consumerConfig.setFilter("currentUserFilter");
		return consumerConfig;
	}
}
