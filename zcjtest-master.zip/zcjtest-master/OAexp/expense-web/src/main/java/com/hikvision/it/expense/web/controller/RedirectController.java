package com.hikvision.it.expense.web.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/redirect")
public class RedirectController {

    @RequestMapping("/report/draft")
    String draft(HttpSession session) {
        return "report/private/draft";
    }

    @RequestMapping("/report/private/expense")
    String privateExpense(HttpSession session) {
        return "report/private/expense";
    }
    @RequestMapping("/report/apply")
    String apply(HttpSession session) {
        return "report/private/apply";
    }

    @RequestMapping("/report/jhk")
    String jhk(HttpSession session) {
        return "report/private/jhk";
    }

    @RequestMapping("/report/public/expense")
    String publicExpense(HttpSession session) {
        return "report/public/expense";
    }


}
