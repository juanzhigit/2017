package com.hikvision.it.expense.web.controller;


import javax.servlet.http.HttpSession;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import com.alibaba.dubbo.config.annotation.Reference;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.process.IProcessService;

@Controller
@RequestMapping("/process")
public class ProcessController {

    @Reference(version = Version.VERSION_LATEST)
    IProcessService processService;
    @Reference(version = Version.VERSION_LATEST)
    IFormService formService;

    /**
     * 删除草稿单
     *
     * @param docId
     * @return
     */
    @RequestMapping(value = "/delete/{docId}", method = RequestMethod.POST)
    ResponseEntity<HikResult<String>> deleteDoc(HttpSession session, @PathVariable("docId") String docId) {
        HikResult<String> hikResult = formService.deleteDraftDoc(docId);
        return ResponseEntity.ok(hikResult);
    }

    /**
     * 撤回单据
     *
     * @param
     * @return
     */
    @RequestMapping("/revoke/{docId}")
    ResponseEntity<HikResult<String>> revoke(HttpSession session, @PathVariable("docId") String docId) {
        LoginUser user = UserContext.get();
        HikResult<String> hikResult = formService.retrack(docId, user.getUserId());
        return ResponseEntity.ok(hikResult);

    }

    /**
     * 撤销单据
     * @param docId
     * @return
     */
    @RequestMapping("/undo/{docId}")
    ResponseEntity<HikResult<String>> undo(HttpSession session, @PathVariable("docId") String docId) {
        LoginUser user = UserContext.get();
        HikResult<String> hikResult = formService.undo(docId, user.getUserId());
        return ResponseEntity.ok(hikResult);

    }

    /**
     * 作废单据
     * @param docId
     * @return
     */
    @RequestMapping("/applyUndo/{docId}")
    ResponseEntity<HikResult<String>> apply_undo(HttpSession session, @PathVariable("docId") String docId) {
        LoginUser user = UserContext.get();
        HikResult<String> hikResult = formService.applyUndo(docId, user.getUserId());
        return ResponseEntity.ok(hikResult);
    }

}
