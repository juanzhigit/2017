package com.hikvision.it.expense.web.controller.advice;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.alibaba.fastjson.JSON;
import com.google.common.base.Strings;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.web.util.I18nFactory;

@ControllerAdvice(annotations = Controller.class)
public class ExpenseControllerAdvice {

    private Logger logger = LoggerFactory.getLogger(getClass());

    @Value("${system.login}")
    private String loginPath;

    @Value("${system.logoutPath:/login}")
    private String logoutPath;

    @Autowired
    private I18nFactory i18n;

    @ExceptionHandler(Exception.class)
    public void exceptionHandler(HttpServletRequest request, HttpServletResponse response, Throwable th) throws IOException, ServletException {
        logger.error("", th);
        if (th instanceof ExpenseException) {
            expenseExceptionHandler(request, response, (ExpenseException) th);
        } else {
            defaultHandler(request, response, th);
        }
    }

    private void defaultHandler(HttpServletRequest request, HttpServletResponse response, Throwable th) throws IOException, ServletException {
        boolean isAjax = isAjax(request);
        String content;
        if (isAjax) {
            HikResult<String> result = new HikResult<String>();
            result.addError(th.getMessage());
            content = JSON.toJSONString(result);
        } else {
            content = th.getMessage();
        }
        writeResponse(request, response, content, isAjax);
    }

    private void expenseExceptionHandler(HttpServletRequest request, HttpServletResponse response, ExpenseException ex) throws IOException, ServletException {
        boolean isAjax = isAjax(request);
        String content;
        if (ex.getErrorCode() == 401 && isAjax) {
            response.setStatus(401);
        }
        if (isAjax) {
            HikResult<String> result = new HikResult<>();
            result.setErrorCode(ex.getErrorCode());
            if (ex.getErrorCode() != 0 && Strings.isNullOrEmpty(ex.getMessage())) { // 根据error code获取对应错误消息
                result.addError(i18n.get(ex.getErrorCode() + ""));
            } else {
                result.addError(ex.getMessage());
            }
            content = JSON.toJSONString(result);
        } else {
            StringBuilder sb = new StringBuilder();
            if (!Strings.isNullOrEmpty(ex.getMessage())) {
                sb.append("error message: ").append(ex.getMessage());
            }
            if (ex.getErrorCode() != 0) {
                if (sb.length() == 0) {
                    sb.append("; ");
                }
                sb.append("error code: ").append(ex.getErrorCode());
            }
            content = sb.toString();
        }
        writeResponse(request, response, content, isAjax);
    }

    private boolean isAjax(HttpServletRequest request) {
        return "XMLHttpRequest".equals(request.getHeader("x-requested-with"));
    }

    private void writeResponse(HttpServletRequest request, HttpServletResponse response, String content, boolean isAjax) throws IOException, ServletException {
        if (isAjax) {
            response.setContentType("application/json;charset=utf-8");
            response.getWriter().print(content);
        } else {
            response.setContentType("text/html;charset=utf-8");
            request.setAttribute("message", content);
            request.getRequestDispatcher("/WEB-INF/jsp/common/error.jsp").forward(request, response);
        }
    }

}
