package com.hikvision.it.expense.web.controller.fee;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.List;
import java.util.Objects;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.base.Strings;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.base.Rate;
import com.hikvision.it.expense.api.entity.fee.FeeDetail;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.exception.ExpenseException;
import com.hikvision.it.expense.api.service.base.IBaseService;
import com.hikvision.it.expense.api.service.fee.IFeeItemService;
import com.hikvision.it.expense.api.service.fee.IFeeService;
import com.hikvision.it.expense.api.service.user.IUserService;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.web.dto.FeeInfo;
import com.hikvision.it.expense.web.enums.FormAction;

/**
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/23
 * Time: 12:05
 * To change this template use File | Settings | File Templates.
 */
@Controller
@RequestMapping("/fee")
public class FeeController {

    @Reference(version = Version.VERSION_LATEST)
    private IFeeItemService feeItemService;

    @Reference(version = Version.VERSION_LATEST)
    private IBaseService baseService;

    @Reference(version = Version.VERSION_LATEST)
    private IFeeService feeService;

    @Reference(version = Version.VERSION_LATEST)
    private IUserService userService;

    /**
     * 根据action加载相应的
     * @param action    操作action  create|edit|view
     * @param id        费用id      edit|view，参数必须要传
     * @param feeType      标识是长途交通还是fee      edit|view，参数必须要传
     */
    @RequestMapping(value = "/page/{action}", method = RequestMethod.GET)
    public String loadFeeEditPage(@PathVariable("action") FormAction action,
                                  @RequestParam("userId") String userId,
                                  @RequestParam("feeType") String feeType,
                                  @RequestParam(value = "id", required = false) String id,
                                  Model model) {
        String pagePath;
        if(!Strings.isNullOrEmpty(id)){
            model.addAttribute("id", id);
            if ("FEE".equals(feeType)) {
                model.addAttribute("feeDetail", feeItemService.findOne(id, "ofees"));

            }else{
                model.addAttribute("feeDetail", feeItemService.findOne(id, "stays"));

            }
        }
//        model.addAttribute("formType","fgs");
        model.addAttribute("formType", userService.judgeUserFormType(userId));
        model.addAttribute("editType", action);
        model.addAttribute("feeType", feeType);
        if (action == FormAction.create) {
            pagePath = "fee/create";
        } else {
            if (!Strings.isNullOrEmpty(id)) {
                pagePath = "fee/editDetailAll";
            } else {
                pagePath = "fee/error";
            }
        }
        return pagePath;
    }


    @GetMapping("/update/{feeType}/{formType}/{id}")
    public String edit(@PathVariable("feeType") String feeType,
                       @PathVariable("formType") String formType,
                       @PathVariable("id") String id, Model model) {
        model.addAttribute("feeDetail", feeItemService.findOne(id, "ofees"));
        formType="zb";
        return "fee/" + feeType + "/"+formType+"/edit";
    }

    @ResponseBody
    @RequestMapping("/delete{type}/{id}")
    public HikResult deleteOfees(@PathVariable("type") String type, @PathVariable("id") String id) {
        if ("Ofees".equals(type)) {
            feeItemService.delete(id, "ofees");
        } else if ("Stays".equals(type) || "CTJT".equals(type)) {
            feeItemService.delete(id, "stays");
        }
        return new HikResult();
    }

    /**
     * 新增|更新明细
     * @param action add | update
     */
    @ResponseBody
    @RequestMapping("/{action}")
    public HikResult<FeeDetail> addFee(@PathVariable("action") String action, @RequestBody FeeInfo feeInfo) {
        HikResult<FeeDetail> result = new HikResult<>();

        FormHeader header = feeInfo.getHeader();
        FeeDetail fee = feeInfo.getDetail();

        // 计算汇率
        Rate rate = new Rate();
        rate.setDate(fee.getFeeFromDate());
        rate.setAmount(fee.getAmount());
        rate.setCurrency(fee.getCurrency());
        rate.setPayCurrency(header.getCurrency());
        Rate resultRate = baseService.getRates(rate);
        fee.setExchangeRate(resultRate.getRate());
        fee.setLocalAmount(resultRate.getPayAmount());

        // 税率, 税额计算
        if (fee.getLocalAmount() != null && fee.getTaxRate() != null) {
            BigDecimal num100 = BigDecimal.valueOf(100);
            BigDecimal noTaxAmount = fee.getLocalAmount().multiply(num100).divide(num100.add(fee.getTaxRate()), 2, RoundingMode.HALF_UP);
            fee.setNoTaxAmount(noTaxAmount);
            fee.setTaxAmount(fee.getLocalAmount().subtract(noTaxAmount));
        }

        // 超标,超期校验
        FormHeader formHeader = new FormHeader();
        formHeader.setSubmittedOn(header.getSubmittedOn());
        formHeader.setBukrs(header.getBukrs());
        formHeader.setExpensor(header.getExpensor());
        FeeDetail detail = fee;
        // 长途交通, 住宿费用保存行项目时暂不校验, 提交时校验
        if ("SNJT".equals(fee.getFeeType()) || "YWZD".equals(fee.getFeeType()) || "OTHER".equals(fee.getFeeType())) {
            detail = feeService.checkFeeStatus(formHeader, fee);
            if (("Y".equals(detail.getOverDateFlag()) || "Y".equals(detail.getOverStandardFlag())) && Strings.isNullOrEmpty(fee.getSpecialRemark())) {
                // 超标超期需填写特殊情况说明
                result.addError("费用超标/超期, 请填写特殊情况说明");
                return result;
            }
            List<String> errorList = feeItemService.checkItem(header, detail);
            if (errorList.size() > 0) {
                result.setErrorMsgs(errorList);
                return result;
            }
        }
        if ("add".equals(action)) {
            detail.setId(StringUtil.getUUID());
            result.setData(feeItemService.save(detail));
        } else if ("update".equals(action)) {
            result.setData(feeItemService.update(detail));
        } else {
            throw new ExpenseException("error action " + action);
        }
        return result;
    }

    /**
     * 查询费用明细
     * @param type Stays | Ofees
     */
    @ResponseBody
    @GetMapping("/view{type}/{id}")
    public FeeDetail viewFeeItem(@PathVariable("type") String type, @PathVariable("id") String id) {
        if ("Ofees".equals(type)) {
            return feeItemService.findOne(id, "ofees");
        } else if ("Stays".equals(type)) {
            return feeItemService.findOne(id, "stays");
        } else {
            return null;
        }
    }

    @ResponseBody
    @GetMapping("/listOfees/{docId}")
    public GridData<FeeDetail> listOfees(@PathVariable("docId") String docId) {
        List<FeeDetail> list = feeItemService.findAll(docId, "ofees");
        return new GridData<>(list.size(), 1, (long) list.size(), list);
    }

    @ResponseBody
    @RequestMapping("/initStaysDetail/{docId}")
    public HikResult<List<FeeDetail>> initStaysDetail(@PathVariable("docId") String docId) {

        List<FeeDetail> ctjtList = feeItemService.findAll(docId, "stays").stream()
                .filter(o -> "CTJT".equals(o.getFeeType()))
                .collect(Collectors.toList());

        HikResult<List<FeeDetail>> result = new HikResult<>();
        for (int i = 0; i < ctjtList.size(); i++) {
            int cmpIndex = (i == 0) ? ctjtList.size() - 1 : i - 1;
            FeeDetail cmpDetail = ctjtList.get(cmpIndex);
            FeeDetail detail = ctjtList.get(i);
            if (Strings.isNullOrEmpty(detail.getFeeFromDate()) || Strings.isNullOrEmpty(detail.getFeeToDate()) || Strings.isNullOrEmpty(detail.getPlaceFrom()) || Strings.isNullOrEmpty(detail.getPlaceTo())) {
                result.addError("长途交通第" + (i + 1) + "行, 日期/城市必须填写完整");
                continue;
            }
            if (!Objects.equals(detail.getPlaceFrom(), cmpDetail.getPlaceTo())) {
                result.addError("长途交通未形成闭环");
                break;
            }
        }
        if (result.isSuccess()) {
                List<FeeDetail> staysList = feeItemService.initStaysDetail(docId, ctjtList);
            result.setData(staysList);
        }
        return result;
    }
}
