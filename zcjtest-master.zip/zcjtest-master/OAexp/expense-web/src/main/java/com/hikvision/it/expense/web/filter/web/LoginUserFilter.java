package com.hikvision.it.expense.web.filter.web;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.jasig.cas.client.util.AssertionHolder;
import org.jasig.cas.client.validation.Assertion;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import com.alibaba.dubbo.config.annotation.Reference;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.context.UserContext;
import com.hikvision.it.expense.api.entity.user.LoginUser;
import com.hikvision.it.expense.api.entity.user.User;
import com.hikvision.it.expense.api.service.user.IUserService;
import com.hikvision.it.expense.common.utils.StringUtil;

@Component
public class LoginUserFilter implements Filter {

    @Reference(version = Version.VERSION_LATEST)
    IUserService userService;


    @Value("${system.login}")
    private String loginPath;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {

        HttpServletRequest servletRequest = (HttpServletRequest) request;

        String uri = servletRequest.getRequestURI();
        // 不需要登录的url直接放行
        if (uri.endsWith("/login") || uri.endsWith(".jsp") || uri.contains("/static/")) {
            chain.doFilter(request, response);
            return;
        }

        HttpServletResponse servletResponse = (HttpServletResponse) response;
        HttpSession session = servletRequest.getSession();

        Assertion assertion = AssertionHolder.getAssertion();
        if (assertion == null) {
            servletResponse.sendRedirect(loginPath);
            return;
        }
        LoginUser sessionUser = (LoginUser) servletRequest.getSession().getAttribute("ExpenseUser");
        String userShortName = assertion.getPrincipal().getName();
        if (sessionUser != null) {
            // 判断session中的用户和assertion中的userShortName是否一致
            if (StringUtil.equalsIgnoreCase(sessionUser.getNotesId(), userShortName)) {
                UserContext.set(sessionUser);
                chain.doFilter(request, response);
                return;
            } else {
                servletResponse.sendRedirect(loginPath);
                return;
            }
        } else { // session中不存在, 但有assertion, 其他应用登录过, 直接拿assertion中的userShortName登录
            User dbUser = userService.findUserByUserShortName(userShortName, "ZH");
            if (dbUser == null) {
                servletResponse.sendRedirect(loginPath);
                return;
            } else {
                LoginUser loginUser = new LoginUser();
                loginUser.setLanguage("ZH");
                loginUser.setUserId(dbUser.getUserId());
                loginUser.setUserName(dbUser.getUserName());
                loginUser.setNotesId(dbUser.getNotesId());
                loginUser.setSapAccount(dbUser.getSapId());
                loginUser.setUserGrade(dbUser.getGrade());
                loginUser.setBranch(dbUser.isBranch());
                session.setAttribute("ExpenseUser", loginUser);
                UserContext.set(loginUser);
                chain.doFilter(request, response);
            }
        }
    }

    @Override
    public void destroy() {

    }
}
