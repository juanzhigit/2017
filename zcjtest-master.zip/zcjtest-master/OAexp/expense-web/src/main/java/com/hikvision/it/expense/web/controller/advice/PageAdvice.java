package com.hikvision.it.expense.web.controller.advice;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.servlet.resource.ResourceUrlProvider;

import com.hikvision.it.expense.web.util.I18nFactory;
import com.hikvision.it.expense.web.util.JsonFactory;

@ControllerAdvice
public class PageAdvice {

    @Autowired
    private ResourceUrlProvider resourceUrlProvider;

    @Autowired
    private I18nFactory i18nFactory;

    @Autowired
    private JsonFactory jsonFactory;

    /**
     * 资源文件名称重写,计算hash
     * TODO 未完成
     */
    @ModelAttribute("urls")
    public ResourceUrlProvider urls() {
        return this.resourceUrlProvider;
    }

    /**
     * 为页面提供国际化支持: ${i18n.get(code[, args])}
     */
    @ModelAttribute("i18n")
    public I18nFactory i18n() {
        return this.i18nFactory;
    }

    @ModelAttribute("json")
    public JsonFactory json() {
        return jsonFactory;
    }

}
