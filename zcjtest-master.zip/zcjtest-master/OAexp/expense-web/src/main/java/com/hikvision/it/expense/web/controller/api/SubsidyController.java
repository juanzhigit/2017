package com.hikvision.it.expense.web.controller.api;

import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.allowance.Allowance;
import com.hikvision.it.expense.api.entity.allowance.AllowanceDetail;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.form.FormInfo;
import com.hikvision.it.expense.api.entity.trip.Trip;
import com.hikvision.it.expense.api.service.allowance.ICalculateSubsidyService;
import com.hikvision.it.expense.api.service.allowance.ISubsidyService;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.common.utils.ListUtil;
import com.hikvision.it.expense.web.dto.SubsidyRequestInfo;

@Controller
@RequestMapping("/api/subsidy")
public class SubsidyController {

    @Reference(version = Version.VERSION_LATEST)
    ICalculateSubsidyService calculateSubsidyService;

    @Reference(version = Version.VERSION_LATEST)
    ISubsidyService subsidyService;

    @Reference(version = Version.VERSION_LATEST)
    IFormService formService;

    @ResponseBody
    @RequestMapping("/calculateCityCar")
    List<Trip> calculateCityCar(@RequestBody SubsidyRequestInfo info) {
        List<Trip> trips = info.getTrips();
        FormHeader header = info.getHeader();
        return calculateSubsidyService.calculateCityCar(header, trips);
    }

    /**
     * 查看补贴
     *
     * @param formInfo 含有长途交通时,需要重新计算补贴
     * @return
     */
    @ResponseBody
    @RequestMapping("/listAllowance")
    List<Allowance> listAllowance(@RequestBody FormInfo formInfo) {
        if (ListUtil.isNotEmpty(formInfo.getLongDistanceTrafficFees())) {
            formService.calculateSubsidy(formInfo);
        }
        return subsidyService.listAllowance(formInfo.getFormHeader().getDocId());
    }

    @ResponseBody
    @RequestMapping("/listAllowanceDetail")
    List<AllowanceDetail> listAllowanceDetail(String docId) {
        return subsidyService.listAllowanceDetail(docId);
    }

    @ResponseBody
    @RequestMapping("/listRentAllowanceDetail")
    List<AllowanceDetail> listRentAllowanceDetail(@RequestBody FormInfo formInfo) {
        if (ListUtil.isNotEmpty(formInfo.getLongDistanceTrafficFees())) {
            formService.calculateSubsidy(formInfo);
        }
        return subsidyService.listRentAllowanceDetail(formInfo.getFormHeader().getDocId());
    }

    @ResponseBody
    @RequestMapping("/getAllowances/{docId}")
    public List<Allowance> getAllowances(@PathVariable("docId") String docId) {
        return subsidyService.listAllowance(docId);
    }

    @ResponseBody
    @RequestMapping("/adjustAllowances/{docId}")
    public HikResult adjustAllowances(@PathVariable("docId") String docId,
                                      @RequestBody List<Allowance> list) {
        HikResult result = new HikResult();
        List<Allowance> oldList = subsidyService.listAllowance(docId);
        Map<String, Allowance> map = oldList.stream().collect(Collectors.toMap(Allowance::getId, Function.identity()));

        for (int i = 0; i < list.size(); i++) {
            Allowance detail = list.get(i);
            String id = detail.getId();
            detail.setDocId(docId);
            if (!map.containsKey(id)) {
                result.addError("第" + (i + 1) + "行, 补贴汇总记录不存在");
                continue;
            }
            Allowance oldDetail = map.get(id);
            if (detail.getFoodPayAmount() == null || detail.getFoodPayAmount().compareTo(oldDetail.getFoodAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 伙食补贴付款金额范围[0 ~ " + detail.getFoodAllowanceAmount() + "]");
            }
            if (detail.getHolidayPayAmount() == null || detail.getHolidayPayAmount().compareTo(oldDetail.getHolidayAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 周末补贴付款金额范围[0 ~ " + detail.getHolidayAllowanceAmount() + "]");
            }
            if (detail.getHardPayAmount() == null || detail.getHardPayAmount().compareTo(oldDetail.getHardAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 艰苦补贴付款金额范围[0 ~ " + detail.getHardAllowanceAmount() + "]");
            }
            if (detail.getLinePayAmount() == null || detail.getLinePayAmount().compareTo(oldDetail.getLineAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 里程补贴付款金额范围[0 ~ " + detail.getLineAllowanceAmount() + "]");
            }
            if (detail.getAmPayAmount() == null || detail.getAmPayAmount().compareTo(oldDetail.getAmAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 早补贴付款金额范围[0 ~ " + detail.getAmAllowanceAmount() + "]");
            }
            if (detail.getPmPayAmount() == null || detail.getPmPayAmount().compareTo(oldDetail.getPmAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 晚补贴付款金额范围[0 ~ " + detail.getPmAllowanceAmount() + "]");
            }
            if (detail.getRentPayAmount() == null || detail.getRentPayAmount().compareTo(oldDetail.getRentAllowanceAmount()) > 0) {
                result.addError("第" + (i + 1) + "行, 租住补贴付款金额范围[0 ~ " + detail.getRentAllowanceAmount() + "]");
            }
        }
        if (result.isSuccess()) {
            calculateSubsidyService.adjustAllowances(list);
        }
        return result;
    }

}
