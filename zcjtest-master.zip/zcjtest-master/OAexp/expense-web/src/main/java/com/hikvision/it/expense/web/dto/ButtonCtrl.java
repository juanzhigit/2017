package com.hikvision.it.expense.web.dto;

/**
 * 按钮控制
 */
public class ButtonCtrl {

    private boolean existAgree = true;
    private boolean showAgree = true;

    private boolean existPreview = true;

    private boolean editAttachment;

    public boolean isExistAgree() {
        return existAgree;
    }

    public void setExistAgree(boolean existAgree) {
        this.existAgree = existAgree;
    }

    public boolean isShowAgree() {
        return showAgree;
    }

    public void setShowAgree(boolean showAgree) {
        this.showAgree = showAgree;
    }

    public boolean isExistPreview() {
        return existPreview;
    }

    public void setExistPreview(boolean existPreview) {
        this.existPreview = existPreview;
    }

    public boolean isEditAttachment() {
        return editAttachment;
    }

    public void setEditAttachment(boolean editAttachment) {
        this.editAttachment = editAttachment;
    }
}
