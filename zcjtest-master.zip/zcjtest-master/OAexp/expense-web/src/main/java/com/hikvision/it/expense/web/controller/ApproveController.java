package com.hikvision.it.expense.web.controller;

import java.util.List;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.dubbo.config.annotation.Reference;
import com.google.common.base.Strings;
import com.google.common.collect.Lists;
import com.hikvision.it.expense.api.Version;
import com.hikvision.it.expense.api.entity.base.GridData;
import com.hikvision.it.expense.api.entity.base.HikResult;
import com.hikvision.it.expense.api.entity.fee.AdjustAmountBean;
import com.hikvision.it.expense.api.entity.fee.DeductionInfo;
import com.hikvision.it.expense.api.entity.history.ApproveHistory;
import com.hikvision.it.expense.api.entity.voucher.Voucher;
import com.hikvision.it.expense.api.entity.voucher.VoucherHeader;
import com.hikvision.it.expense.api.entity.voucher.VoucherItem;
import com.hikvision.it.expense.api.enums.MessageCode;
import com.hikvision.it.expense.api.enums.ResultEnum;
import com.hikvision.it.expense.api.service.fee.IFeeService;
import com.hikvision.it.expense.api.service.form.IFormService;
import com.hikvision.it.expense.api.service.task.ITaskService;
import com.hikvision.it.expense.api.service.voucher.IVoucherService;
import com.hikvision.it.expense.common.utils.StringUtil;
import com.hikvision.it.expense.web.dto.ApproveInfo;
import com.hikvision.it.expense.web.util.I18nFactory;

@Controller
@RequestMapping("/approve")
public class ApproveController {

    @SuppressWarnings("unused")
    private Logger logger = LoggerFactory.getLogger(getClass());

    @Autowired
    private I18nFactory i18n;

    @Reference(version = Version.VERSION_LATEST)
    ITaskService taskService;
    @Reference(version = Version.VERSION_LATEST)
    IFormService formService;
    @Reference(version = Version.VERSION_LATEST)
    IVoucherService voucherService;
    @Reference(version = Version.VERSION_LATEST)
    IFeeService feeService;

    @ResponseBody
    @RequestMapping("/history/{docId}")
    public List<ApproveHistory> history(@PathVariable("docId") String docId) {
        return formService.getApproveHistories(docId);
    }

    @ResponseBody
    @RequestMapping(value = "/adjustAmount", method = RequestMethod.POST)
    public HikResult<String> adjustAmount(@RequestBody AdjustAmountBean adjustBean) {
        return formService.adjustAmount(adjustBean);
    }

    @RequestMapping("previewVoucher")
    public String previewVoucherPage(@RequestParam("docId") String docId, Model model) {
        HikResult<List<Voucher>> result = voucherService.previewVoucher(docId);
        List<Voucher> list;
        if (!result.isSuccess()) {
            list = Lists.newArrayList();
            model.addAttribute("errorMsgs", result.getErrorMsgs());
        } else {
            list = result.getData();
        }
        model.addAttribute("voucherList", list);
        return "voucher/preview";
    }

    @ResponseBody
    @RequestMapping(value = "previewVoucher", method = RequestMethod.POST)
    public HikResult<String> previewVoucher(@RequestParam("docId") String docId, @RequestBody List<Voucher> vouchers) {
        int headerIdx = 1;
        for (Voucher voucher : vouchers) {
            String headerId = StringUtil.getUUID();
            VoucherHeader header = voucher.getVoucherHeader();
            header.setHeaderId(headerId);
            header.setRn(headerIdx++);

            int itemIdx = 1;
            for (VoucherItem voucherItem : voucher.getVoucherItems()) {
                voucherItem.setRn(itemIdx++);
                voucherItem.setHeaderId(headerId);
                voucherItem.setItemId(StringUtil.getUUID());
            }
        }

        voucherService.previewVoucher(docId, vouchers);
        return voucherService.checkPreVoucher(docId);
    }

    @ResponseBody
    @RequestMapping(value = "/postVoucher", method = RequestMethod.POST)
    public HikResult<String> postVoucher(@RequestParam("docId") String docId, @RequestParam("manual") boolean manual) {
        return voucherService.postVoucher(docId, manual);
    }

    @ResponseBody
    @RequestMapping("/getDeductionInfo")
    public GridData<DeductionInfo> getDeductionInfo(String userId, String docId) {
        return feeService.getDeductionInfos(userId, docId);
    }

    @ResponseBody
    @RequestMapping("/saveDeductionInfo")
    public HikResult saveDeductionInfo(@RequestParam("docId") String docId, @RequestBody List<DeductionInfo> list) {
        feeService.saveDeductionInfos(docId, list);
        return new HikResult();
    }

    /**
     * 单据审批: 同意/驳回/否决/加签
     */
    @ResponseBody
    @RequestMapping("/{action}")
    public HikResult<String> approve(@PathVariable ResultEnum action, @RequestBody ApproveInfo approveInfo) {
        if ((ResultEnum.REFUSE == action || ResultEnum.REJECT == action || ResultEnum.ADDSTEP == action)
                && Strings.isNullOrEmpty(approveInfo.getSuggest())) {
            return new HikResult<>(i18n.get(MessageCode.MSG_COMMENT_NOT_EMPTY));
        }
        return formService.approve(approveInfo.getTaskId(), approveInfo.getSuggest(), approveInfo.getResult(), approveInfo.getReceivers());
    }

}
