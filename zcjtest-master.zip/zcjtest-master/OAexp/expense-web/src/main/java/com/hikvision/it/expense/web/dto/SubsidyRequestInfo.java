package com.hikvision.it.expense.web.dto;

import java.util.List;

import com.hikvision.it.expense.api.entity.form.FormHeader;
import com.hikvision.it.expense.api.entity.trip.Trip;

public class SubsidyRequestInfo {

    private FormHeader header;
    private List<Trip> trips;
    private String fromDate;
    private String toDate;


    public FormHeader getHeader() {
        return header;
    }

    public void setHeader(FormHeader header) {
        this.header = header;
    }

    public List<Trip> getTrips() {
        return trips;
    }

    public void setTrips(List<Trip> trips) {
        this.trips = trips;
    }

    public String getFromDate() {
        return fromDate;
    }

    public void setFromDate(String fromDate) {
        this.fromDate = fromDate;
    }

    public String getToDate() {
        return toDate;
    }

    public void setToDate(String toDate) {
        this.toDate = toDate;
    }
}
