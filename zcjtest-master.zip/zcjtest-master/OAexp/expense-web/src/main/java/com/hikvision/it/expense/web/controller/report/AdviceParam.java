package com.hikvision.it.expense.web.controller.report;

import java.io.Serializable;
import java.util.List;

/**
 * Created with IntelliJ IDEA.
 * User: wuliangxxh1
 * Date: 2017/6/19
 * Time: 13:22
 * To change this template use File | Settings | File Templates.
 */
public class AdviceParam implements Serializable {
    private static final long serialVersionUID = -3507524240857873706L;
    private List<String> bukrsList;          //公司集合
    private List<String> expensorList;       //报销人集合
    private List<String> lifnrList;          //供应商集合
    private List<String> currencyList;       //币别集合
    private List<String> smaFeeList;         //业务细类集合

    public List<String> getSmaFeeList() {
        return smaFeeList;
    }

    public void setSmaFeeList(List<String> smaFeeList) {
        this.smaFeeList = smaFeeList;
    }

    public List<String> getBukrsList() {
        return bukrsList;
    }

    public void setBukrsList(List<String> bukrsList) {
        this.bukrsList = bukrsList;
    }

    public List<String> getExpensorList() {
        return expensorList;
    }

    public void setExpensorList(List<String> expensorList) {
        this.expensorList = expensorList;
    }

    public List<String> getLifnrList() {
        return lifnrList;
    }

    public void setLifnrList(List<String> lifnrList) {
        this.lifnrList = lifnrList;
    }

    public List<String> getCurrencyList() {
        return currencyList;
    }

    public void setCurrencyList(List<String> currencyList) {
        this.currencyList = currencyList;
    }
}
